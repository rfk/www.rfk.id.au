/***********************************************************/
/***  Implementations                                    ***/

#define PYPY_FILE_NAME "rpython_rtyper_module_ll_os.c"
#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"
#include "src/g_include.h"

/*/*/
Signed pypy_g_ll_os_ll_os_write(Signed l_fd_4, struct pypy_rpy_string0 *l_data_5) {
	Signed l_rawtotalsize_5; void* l_result_27; void* l_result_28;
	Signed l_v9311; Signed l_v9312; Signed l_v9313; Signed l_v9314;
	Signed l_v9317; Signed l_v9325; Signed l_v9354; Signed l_v9407;
	Signed l_v9411; Unsigned l_v9326; Unsigned l_v9332; bool_t l_v9320;
	bool_t l_v9338; bool_t l_v9343; bool_t l_v9353; bool_t l_v9355;
	bool_t l_v9360; bool_t l_v9361; bool_t l_v9371; bool_t l_v9379;
	bool_t l_v9389; bool_t l_v9393; bool_t l_v9398; bool_t l_v9402;
	char *l_v9309; char *l_v9315; char *l_v9324; char *l_v9342;
	char *l_v9378; struct pypy_exceptions_Exception0 *l_v9310;
	struct pypy_exceptions_OSError0 *l_v9318;
	struct pypy_header0 *l_v9363; struct pypy_object0 *l_v9372;
	struct pypy_object0 *l_v9384; struct pypy_object_vtable0 *l_v9316;
	struct pypy_object_vtable0 *l_v9388;
	struct pypy_object_vtable0 *l_v9392;
	struct pypy_object_vtable0 *l_v9397; void* l_v9319; void* l_v9321;
	void* l_v9322; void* l_v9323; void* l_v9327; void* l_v9328;
	void* l_v9330; void* l_v9333; void* l_v9334; void* l_v9336;
	void* l_v9339; void* l_v9340; void* l_v9341; void* l_v9345;
	void* l_v9348; void* l_v9349; void* l_v9351; void* l_v9356;
	void* l_v9358; void* l_v9359; void* l_v9362; void* l_v9365;
	void* l_v9366; void* l_v9367; void* l_v9369; void* l_v9375;
	void* l_v9376; void* l_v9377; void* l_v9381; void* l_v9391;
	void* l_v9396; void* l_v9400; void* l_v9403; void* l_v9404;
	void* l_v9405; void* l_v9406; void* l_v9412; void* l_v9413;
	goto block0;

    block0:
	l_v9312 = RPyField(l_data_5, rs_chars).length;
	l_v9319 = (void*)l_data_5;
	l_v9320 = pypy_g_MiniMarkGC_can_move((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_v9319);
	if (l_v9320) {
		goto block23;
	}
	goto block1;

    block1:
	l_v9321 = (void*)l_data_5;
	OP_ADR_ADD(l_v9321, offsetof(struct pypy_rpy_string0, rs_chars), l_v9322);
	OP_ADR_ADD(l_v9322, offsetof(struct pypy_array4, items), l_v9323);
	l_v9324 = (char *)(l_v9323);
	l_v9309 = l_v9324;
	goto block2;

    block2:
	l_v9325 = (Signed)(l_fd_4);
	l_v9326 = (Unsigned)(l_v9312);
	l_v9327 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v9327, sizeof(void*), l_v9328);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v9328;
	l_v9330 = (void*)l_data_5;
	((void* *) (((char *)l_v9327) + 0))[0] = l_v9330;
	l_v9332 = pypy_g_write__Signed_arrayPtr_Unsigned_star_3(l_v9325, l_v9309, l_v9326);
	l_v9333 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v9333, sizeof(void*), l_v9334);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v9334;
	l_v9336 = ((void* *) (((char *)l_v9334) + 0))[0];
	l_data_5 = l_v9336; /* for moving GCs */
	l_v9317 = (Signed)(l_v9332);
	OP_INT_LT(l_v9317, 0L, l_v9338);
	if (l_v9338) {
		goto block6;
	}
	goto block3;

    block3:
	l_v9339 = (void*)l_data_5;
	OP_ADR_ADD(l_v9339, offsetof(struct pypy_rpy_string0, rs_chars), l_v9340);
	OP_ADR_ADD(l_v9340, offsetof(struct pypy_array4, items), l_v9341);
	l_v9342 = (char *)(l_v9341);
	l_v9343 = (l_v9309 == l_v9342);
	/* kept alive: l_data_5 */
	if (l_v9343) {
		l_v9411 = l_v9317;
		goto block5;
	}
	goto block4;

    block4:
	l_v9345 = (void*)l_v9309;
	OP_TRACK_ALLOC_STOP(l_v9345, /* nothing */);
	OP_RAW_FREE(l_v9345, /* nothing */);
	l_v9411 = l_v9317;
	goto block5;

    block5:
	RPY_DEBUG_RETURN();
	return l_v9411;

    block6:
	l_v9311 = pypy_g_get_errno();
	l_v9348 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v9348, sizeof(void*), l_v9349);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v9349;
	l_v9351 = (void*)l_data_5;
	((void* *) (((char *)l_v9348) + 0))[0] = l_v9351;
	OP_RAW_MALLOC_USAGE((0 + ROUND_UP_FOR_ALLOCATION(sizeof(struct pypy_exceptions_OSError0), 0L)), l_rawtotalsize_5);
	OP_INT_GT(l_rawtotalsize_5, 67583L, l_v9353);
	if (l_v9353) {
		goto block21;
	}
	goto block7;

    block7:
	OP_RAW_MALLOC_USAGE((sizeof(struct pypy_header0) + sizeof(void*)), l_v9354);
	OP_INT_LT(l_rawtotalsize_5, l_v9354, l_v9355);
	if (l_v9355) {
		l_v9313 = l_v9354;
		goto block8;
	}
	l_v9313 = (0 + ROUND_UP_FOR_ALLOCATION(sizeof(struct pypy_exceptions_OSError0), 0L));
	goto block8;

    block8:
	l_result_28 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	OP_ADR_ADD(l_result_28, l_v9313, l_v9356);
	(&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free = l_v9356;
	l_v9358 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	l_v9359 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_top;
	OP_ADR_GT(l_v9358, l_v9359, l_v9360);
	if (l_v9360) {
		goto block19;
	}
	l_result_27 = l_result_28;
	goto block9;

    block9:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v9361);
	if (l_v9361) {
		goto block17;
	}
	goto block10;

    block10:
	OP_ADR_ADD(l_result_27, 0, l_v9362);
	l_v9363 = (struct pypy_header0 *)l_result_27;
	RPyField(l_v9363, h_tid) = (GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member1)+0L);
	l_v9412 = l_v9362;
	goto block11;

    block11:
	l_v9365 = (void*)l_v9412;
	l_v9413 = l_v9365;
	goto block12;

    block12:
	l_v9366 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v9366, sizeof(void*), l_v9367);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v9367;
	l_v9369 = ((void* *) (((char *)l_v9367) + 0))[0];
	l_data_5 = l_v9369; /* for moving GCs */
	l_v9318 = (struct pypy_exceptions_OSError0 *)l_v9413;
	l_v9371 = (l_v9318 != NULL);
	if (!l_v9371) {
		goto block16;
	}
	goto block13;

    block13:
	l_v9372 = (struct pypy_object0 *)l_v9318;
	RPyField(l_v9372, o_typeptr) = (&pypy_g_exceptions_OSError_vtable.ose_super.ee_super.se_super.e_super);
	RPyField(l_v9318, ose_inst_errno) = l_v9311;
	l_v9316 = RPyField(l_v9372, o_typeptr);
	l_v9310 = (struct pypy_exceptions_Exception0 *)l_v9318;
	l_v9375 = (void*)l_data_5;
	OP_ADR_ADD(l_v9375, offsetof(struct pypy_rpy_string0, rs_chars), l_v9376);
	OP_ADR_ADD(l_v9376, offsetof(struct pypy_array4, items), l_v9377);
	l_v9378 = (char *)(l_v9377);
	l_v9379 = (l_v9309 == l_v9378);
	/* kept alive: l_data_5 */
	if (l_v9379) {
		goto block15;
	}
	goto block14;

    block14:
	l_v9381 = (void*)l_v9309;
	OP_TRACK_ALLOC_STOP(l_v9381, /* nothing */);
	OP_RAW_FREE(l_v9381, /* nothing */);
	goto block15;

    block15:
	l_v9384 = (struct pypy_object0 *)l_v9310;
	pypy_g_RPyReRaiseException(l_v9316, l_v9384);
	l_v9411 = -1L;
	goto block5;

    block16:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_os_write");
	l_v9411 = -1L;
	goto block5;

    block17:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v9388 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9389 = (l_v9388 == NULL);
	if (!l_v9389) {
		goto block18;
	}
	goto block10;

    block18:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_os_write");
	l_v9413 = NULL;
	goto block12;

    block19:
	l_v9391 = pypy_g_MiniMarkGC_collect_and_reserve((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_result_28, l_v9313);
	l_v9392 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9393 = (l_v9392 == NULL);
	if (!l_v9393) {
		goto block20;
	}
	l_result_27 = l_v9391;
	goto block9;

    block20:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_os_write");
	l_v9413 = NULL;
	goto block12;

    block21:
	RPyAssert(1, "'contains_weakptr' specified for a large object");
	l_v9396 = pypy_g_MiniMarkGC_external_malloc((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member1), 0L, 1);
	l_v9397 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9398 = (l_v9397 == NULL);
	if (!l_v9398) {
		goto block22;
	}
	l_v9412 = l_v9396;
	goto block11;

    block22:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_os_write");
	l_v9413 = NULL;
	goto block12;

    block23:
	l_v9314 = RPyField(l_data_5, rs_chars).length;
	l_v9400 = pypy_g__ll_malloc_varsize_no_length__Signed_Signed_Sign(l_v9314, (0 + 0), sizeof(char));
	OP_TRACK_ALLOC_START(l_v9400, /* nothing */);
	l_v9315 = (char *)l_v9400;
	l_v9402 = (l_v9315 != NULL);
	if (!l_v9402) {
		goto block25;
	}
	goto block24;

    block24:
	l_v9403 = (void*)l_data_5;
	OP_ADR_ADD(l_v9403, (offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v9404);
	l_v9405 = (void*)l_v9315;
	OP_ADR_ADD(l_v9405, 0, l_v9406);
	OP_INT_MUL(sizeof(char), l_v9314, l_v9407);
	OP_RAW_MEMCOPY(l_v9404, l_v9406, l_v9407, /* nothing */);
	/* kept alive: l_v9404 */
	l_v9309 = l_v9315;
	goto block2;

    block25:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_os_write");
	l_v9411 = -1L;
	goto block5;
}
/*/*/
Signed pypy_g_ll_os_ll_os_open(struct pypy_rpy_string0 *l_path_1, Signed l_flags_0, Signed l_mode_0) {
	Signed l_rawtotalsize_6; void* l_result_29; void* l_result_30;
	Signed l_v9414; Signed l_v9416; Signed l_v9418; Signed l_v9419;
	Signed l_v9420; Signed l_v9424; Signed l_v9429; Signed l_v9434;
	Signed l_v9437; Signed l_v9474; bool_t l_v9423; bool_t l_v9433;
	bool_t l_v9435; bool_t l_v9436; bool_t l_v9438; bool_t l_v9443;
	bool_t l_v9444; bool_t l_v9449; bool_t l_v9459; bool_t l_v9463;
	bool_t l_v9468; char *l_v9417;
	struct pypy_exceptions_OSError0 *l_v9415;
	struct pypy_header0 *l_v9446; struct pypy_object0 *l_v9450;
	struct pypy_object_vtable0 *l_v9453;
	struct pypy_object_vtable0 *l_v9458;
	struct pypy_object_vtable0 *l_v9462;
	struct pypy_object_vtable0 *l_v9467; void* l_v9421; void* l_v9425;
	void* l_v9426; void* l_v9427; void* l_v9428; void* l_v9439;
	void* l_v9441; void* l_v9442; void* l_v9445; void* l_v9448;
	void* l_v9461; void* l_v9466; void* l_v9470; void* l_v9475;
	void* l_v9476;
	goto block0;

    block0:
	l_v9419 = RPyField(l_path_1, rs_chars).length;
	OP_INT_ADD(l_v9419, 1L, l_v9420);
	l_v9421 = pypy_g__ll_malloc_varsize_no_length__Signed_Signed_Sign(l_v9420, (0 + 0), sizeof(char));
	OP_TRACK_ALLOC_START(l_v9421, /* nothing */);
	l_v9417 = (char *)l_v9421;
	l_v9423 = (l_v9417 != NULL);
	if (!l_v9423) {
		goto block20;
	}
	goto block1;

    block1:
	l_v9424 = RPyField(l_path_1, rs_chars).length;
	l_v9425 = (void*)l_path_1;
	OP_ADR_ADD(l_v9425, (offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v9426);
	l_v9427 = (void*)l_v9417;
	OP_ADR_ADD(l_v9427, 0, l_v9428);
	OP_INT_MUL(sizeof(char), l_v9424, l_v9429);
	OP_RAW_MEMCOPY(l_v9426, l_v9428, l_v9429, /* nothing */);
	/* kept alive: l_v9426 */
	RPyBareItem(l_v9417, l_v9424) = ((char)0);
	l_v9416 = pypy_g_ccall_open__arrayPtr_Signed_Signed(l_v9417, l_flags_0, l_mode_0);
	l_v9433 = (l_v9417 != NULL);
	if (l_v9433) {
		goto block19;
	}
	goto block2;

    block2:
	l_v9434 = (Signed)(l_v9416);
	OP_INT_EQ(l_v9434, -1L, l_v9435);
	if (l_v9435) {
		goto block4;
	}
	l_v9474 = l_v9434;
	goto block3;

    block3:
	RPY_DEBUG_RETURN();
	return l_v9474;

    block4:
	l_v9414 = get_errno();
	OP_RAW_MALLOC_USAGE((0 + ROUND_UP_FOR_ALLOCATION(sizeof(struct pypy_exceptions_OSError0), 0L)), l_rawtotalsize_6);
	OP_INT_GT(l_rawtotalsize_6, 67583L, l_v9436);
	if (l_v9436) {
		goto block17;
	}
	goto block5;

    block5:
	OP_RAW_MALLOC_USAGE((sizeof(struct pypy_header0) + sizeof(void*)), l_v9437);
	OP_INT_LT(l_rawtotalsize_6, l_v9437, l_v9438);
	if (l_v9438) {
		l_v9418 = l_v9437;
		goto block6;
	}
	l_v9418 = (0 + ROUND_UP_FOR_ALLOCATION(sizeof(struct pypy_exceptions_OSError0), 0L));
	goto block6;

    block6:
	l_result_29 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	OP_ADR_ADD(l_result_29, l_v9418, l_v9439);
	(&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free = l_v9439;
	l_v9441 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	l_v9442 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_top;
	OP_ADR_GT(l_v9441, l_v9442, l_v9443);
	if (l_v9443) {
		goto block15;
	}
	l_result_30 = l_result_29;
	goto block7;

    block7:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v9444);
	if (l_v9444) {
		goto block13;
	}
	goto block8;

    block8:
	OP_ADR_ADD(l_result_30, 0, l_v9445);
	l_v9446 = (struct pypy_header0 *)l_result_30;
	RPyField(l_v9446, h_tid) = (GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member1)+0L);
	l_v9475 = l_v9445;
	goto block9;

    block9:
	l_v9448 = (void*)l_v9475;
	l_v9476 = l_v9448;
	goto block10;

    block10:
	l_v9415 = (struct pypy_exceptions_OSError0 *)l_v9476;
	l_v9449 = (l_v9415 != NULL);
	if (!l_v9449) {
		goto block12;
	}
	goto block11;

    block11:
	l_v9450 = (struct pypy_object0 *)l_v9415;
	RPyField(l_v9450, o_typeptr) = (&pypy_g_exceptions_OSError_vtable.ose_super.ee_super.se_super.e_super);
	RPyField(l_v9415, ose_inst_errno) = l_v9414;
	l_v9453 = RPyField(l_v9450, o_typeptr);
	pypy_g_RPyRaiseException(l_v9453, l_v9450);
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_os_open");
	l_v9474 = -1L;
	goto block3;

    block12:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_os_open");
	l_v9474 = -1L;
	goto block3;

    block13:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v9458 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9459 = (l_v9458 == NULL);
	if (!l_v9459) {
		goto block14;
	}
	goto block8;

    block14:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_os_open");
	l_v9476 = NULL;
	goto block10;

    block15:
	l_v9461 = pypy_g_MiniMarkGC_collect_and_reserve((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_result_29, l_v9418);
	l_v9462 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9463 = (l_v9462 == NULL);
	if (!l_v9463) {
		goto block16;
	}
	l_result_30 = l_v9461;
	goto block7;

    block16:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_os_open");
	l_v9476 = NULL;
	goto block10;

    block17:
	RPyAssert(1, "'contains_weakptr' specified for a large object");
	l_v9466 = pypy_g_MiniMarkGC_external_malloc((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member1), 0L, 1);
	l_v9467 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9468 = (l_v9467 == NULL);
	if (!l_v9468) {
		goto block18;
	}
	l_v9475 = l_v9466;
	goto block9;

    block18:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_os_open");
	l_v9476 = NULL;
	goto block10;

    block19:
	l_v9470 = (void*)l_v9417;
	OP_TRACK_ALLOC_STOP(l_v9470, /* nothing */);
	OP_RAW_FREE(l_v9470, /* nothing */);
	goto block2;

    block20:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_os_open");
	l_v9474 = -1L;
	goto block3;
}
/*/*/
struct pypy_rpy_string0 *pypy_g_ll_os_ll_os_read(Signed l_fd_1, Signed l_count_11) {
	char *l_raw_buf_2; Signed l_rawtotalsize_7; Signed l_rawtotalsize_8;
	void* l_result_31; void* l_result_32; void* l_result_33;
	void* l_result_34; Signed l_v9477; Signed l_v9478; Signed l_v9481;
	Signed l_v9482; Signed l_v9512; Signed l_v9546; Unsigned l_v9491;
	bool_t l_v9486; bool_t l_v9489; bool_t l_v9492; bool_t l_v9494;
	bool_t l_v9495; bool_t l_v9505; bool_t l_v9511; bool_t l_v9513;
	bool_t l_v9518; bool_t l_v9519; bool_t l_v9524; bool_t l_v9533;
	bool_t l_v9537; bool_t l_v9542; bool_t l_v9545; bool_t l_v9547;
	bool_t l_v9552; bool_t l_v9553; bool_t l_v9558; bool_t l_v9568;
	bool_t l_v9572; bool_t l_v9577;
	struct pypy_exceptions_Exception0 *l_v9484;
	struct pypy_exceptions_Exception0 *l_v9504;
	struct pypy_exceptions_Exception0 *l_v9529;
	struct pypy_exceptions_OSError0 *l_v9480;
	struct pypy_exceptions_OSError0 *l_v9485;
	struct pypy_header0 *l_v9521; struct pypy_header0 *l_v9555;
	struct pypy_object0 *l_v9499; struct pypy_object0 *l_v9506;
	struct pypy_object0 *l_v9525; struct pypy_object0 *l_v9559;
	struct pypy_object_vtable0 *l_v9483;
	struct pypy_object_vtable0 *l_v9493;
	struct pypy_object_vtable0 *l_v9500;
	struct pypy_object_vtable0 *l_v9528;
	struct pypy_object_vtable0 *l_v9532;
	struct pypy_object_vtable0 *l_v9536;
	struct pypy_object_vtable0 *l_v9541;
	struct pypy_object_vtable0 *l_v9562;
	struct pypy_object_vtable0 *l_v9567;
	struct pypy_object_vtable0 *l_v9571;
	struct pypy_object_vtable0 *l_v9576;
	struct pypy_rpy_string0 *l_v9479; struct pypy_rpy_string0 *l_v9579;
	void *l_v9490; void* l_v9487; void* l_v9496; void* l_v9508;
	void* l_v9514; void* l_v9516; void* l_v9517; void* l_v9520;
	void* l_v9523; void* l_v9535; void* l_v9540; void* l_v9548;
	void* l_v9550; void* l_v9551; void* l_v9554; void* l_v9557;
	void* l_v9570; void* l_v9575; void* l_v9580; void* l_v9581;
	void* l_v9582; void* l_v9583;
	goto block0;

    block0:
	OP_INT_LT(l_count_11, 0L, l_v9486);
	if (l_v9486) {
		goto block27;
	}
	goto block1;

    block1:
	l_v9487 = pypy_g__ll_malloc_varsize_no_length__Signed_Signed_Sign(l_count_11, (0 + 0), sizeof(char));
	OP_TRACK_ALLOC_START(l_v9487, /* nothing */);
	l_raw_buf_2 = (char *)l_v9487;
	l_v9489 = (l_raw_buf_2 != NULL);
	if (!l_v9489) {
		goto block26;
	}
	goto block2;

    block2:
	l_v9490 = (void *)(l_raw_buf_2);
	l_v9491 = pypy_g_read__Signed_arrayPtr_Signed_star_3(l_fd_1, l_v9490, l_count_11);
	l_v9482 = (Signed)(l_v9491);
	OP_INT_LT(l_v9482, 0L, l_v9492);
	if (l_v9492) {
		goto block11;
	}
	goto block3;

    block3:
	l_v9479 = pypy_g_str_from_buffer(l_raw_buf_2, ((struct pypy_rpy_string0 *) NULL), l_count_11, l_v9482);
	l_v9493 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9494 = (l_v9493 == NULL);
	if (!l_v9494) {
		goto block7;
	}
	goto block4;

    block4:
	l_v9495 = (l_raw_buf_2 != NULL);
	if (l_v9495) {
		goto block6;
	}
	l_v9579 = l_v9479;
	goto block5;

    block5:
	RPY_DEBUG_RETURN();
	return l_v9579;

    block6:
	l_v9496 = (void*)l_raw_buf_2;
	OP_TRACK_ALLOC_STOP(l_v9496, /* nothing */);
	OP_RAW_FREE(l_v9496, /* nothing */);
	l_v9579 = l_v9479;
	goto block5;

    block7:
	l_v9499 = (&pypy_g_ExcData)->ed_exc_value;
	l_v9500 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("ll_os_ll_os_read", l_v9500, l_v9500 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_v9500 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	l_v9504 = (struct pypy_exceptions_Exception0 *)l_v9499;
	l_v9484 = l_v9504;
	l_v9483 = l_v9500;
	goto block8;

    block8:
	l_v9505 = (l_raw_buf_2 != NULL);
	if (l_v9505) {
		goto block10;
	}
	goto block9;

    block9:
	l_v9506 = (struct pypy_object0 *)l_v9484;
	pypy_g_RPyReRaiseException(l_v9483, l_v9506);
	l_v9579 = ((struct pypy_rpy_string0 *) NULL);
	goto block5;

    block10:
	l_v9508 = (void*)l_raw_buf_2;
	OP_TRACK_ALLOC_STOP(l_v9508, /* nothing */);
	OP_RAW_FREE(l_v9508, /* nothing */);
	goto block9;

    block11:
	l_v9478 = pypy_g_get_errno();
	OP_RAW_MALLOC_USAGE((0 + ROUND_UP_FOR_ALLOCATION(sizeof(struct pypy_exceptions_OSError0), 0L)), l_rawtotalsize_7);
	OP_INT_GT(l_rawtotalsize_7, 67583L, l_v9511);
	if (l_v9511) {
		goto block24;
	}
	goto block12;

    block12:
	OP_RAW_MALLOC_USAGE((sizeof(struct pypy_header0) + sizeof(void*)), l_v9512);
	OP_INT_LT(l_rawtotalsize_7, l_v9512, l_v9513);
	if (l_v9513) {
		l_v9481 = l_v9512;
		goto block13;
	}
	l_v9481 = (0 + ROUND_UP_FOR_ALLOCATION(sizeof(struct pypy_exceptions_OSError0), 0L));
	goto block13;

    block13:
	l_result_32 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	OP_ADR_ADD(l_result_32, l_v9481, l_v9514);
	(&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free = l_v9514;
	l_v9516 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	l_v9517 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_top;
	OP_ADR_GT(l_v9516, l_v9517, l_v9518);
	if (l_v9518) {
		goto block22;
	}
	l_result_33 = l_result_32;
	goto block14;

    block14:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v9519);
	if (l_v9519) {
		goto block20;
	}
	goto block15;

    block15:
	OP_ADR_ADD(l_result_33, 0, l_v9520);
	l_v9521 = (struct pypy_header0 *)l_result_33;
	RPyField(l_v9521, h_tid) = (GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member1)+0L);
	l_v9580 = l_v9520;
	goto block16;

    block16:
	l_v9523 = (void*)l_v9580;
	l_v9581 = l_v9523;
	goto block17;

    block17:
	l_v9485 = (struct pypy_exceptions_OSError0 *)l_v9581;
	l_v9524 = (l_v9485 != NULL);
	if (!l_v9524) {
		goto block19;
	}
	goto block18;

    block18:
	l_v9525 = (struct pypy_object0 *)l_v9485;
	RPyField(l_v9525, o_typeptr) = (&pypy_g_exceptions_OSError_vtable.ose_super.ee_super.se_super.e_super);
	RPyField(l_v9485, ose_inst_errno) = l_v9478;
	l_v9528 = RPyField(l_v9525, o_typeptr);
	l_v9529 = (struct pypy_exceptions_Exception0 *)l_v9485;
	l_v9484 = l_v9529;
	l_v9483 = l_v9528;
	goto block8;

    block19:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_os_read");
	l_v9579 = ((struct pypy_rpy_string0 *) NULL);
	goto block5;

    block20:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v9532 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9533 = (l_v9532 == NULL);
	if (!l_v9533) {
		goto block21;
	}
	goto block15;

    block21:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_os_read");
	l_v9581 = NULL;
	goto block17;

    block22:
	l_v9535 = pypy_g_MiniMarkGC_collect_and_reserve((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_result_32, l_v9481);
	l_v9536 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9537 = (l_v9536 == NULL);
	if (!l_v9537) {
		goto block23;
	}
	l_result_33 = l_v9535;
	goto block14;

    block23:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_os_read");
	l_v9581 = NULL;
	goto block17;

    block24:
	RPyAssert(1, "'contains_weakptr' specified for a large object");
	l_v9540 = pypy_g_MiniMarkGC_external_malloc((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member1), 0L, 1);
	l_v9541 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9542 = (l_v9541 == NULL);
	if (!l_v9542) {
		goto block25;
	}
	l_v9580 = l_v9540;
	goto block16;

    block25:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_os_read");
	l_v9581 = NULL;
	goto block17;

    block26:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_os_read");
	l_v9579 = ((struct pypy_rpy_string0 *) NULL);
	goto block5;

    block27:
	OP_RAW_MALLOC_USAGE((0 + ROUND_UP_FOR_ALLOCATION(sizeof(struct pypy_exceptions_OSError0), 0L)), l_rawtotalsize_8);
	OP_INT_GT(l_rawtotalsize_8, 67583L, l_v9545);
	if (l_v9545) {
		goto block40;
	}
	goto block28;

    block28:
	OP_RAW_MALLOC_USAGE((sizeof(struct pypy_header0) + sizeof(void*)), l_v9546);
	OP_INT_LT(l_rawtotalsize_8, l_v9546, l_v9547);
	if (l_v9547) {
		l_v9477 = l_v9546;
		goto block29;
	}
	l_v9477 = (0 + ROUND_UP_FOR_ALLOCATION(sizeof(struct pypy_exceptions_OSError0), 0L));
	goto block29;

    block29:
	l_result_34 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	OP_ADR_ADD(l_result_34, l_v9477, l_v9548);
	(&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free = l_v9548;
	l_v9550 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	l_v9551 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_top;
	OP_ADR_GT(l_v9550, l_v9551, l_v9552);
	if (l_v9552) {
		goto block38;
	}
	l_result_31 = l_result_34;
	goto block30;

    block30:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v9553);
	if (l_v9553) {
		goto block36;
	}
	goto block31;

    block31:
	OP_ADR_ADD(l_result_31, 0, l_v9554);
	l_v9555 = (struct pypy_header0 *)l_result_31;
	RPyField(l_v9555, h_tid) = (GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member1)+0L);
	l_v9582 = l_v9554;
	goto block32;

    block32:
	l_v9557 = (void*)l_v9582;
	l_v9583 = l_v9557;
	goto block33;

    block33:
	l_v9480 = (struct pypy_exceptions_OSError0 *)l_v9583;
	l_v9558 = (l_v9480 != NULL);
	if (!l_v9558) {
		goto block35;
	}
	goto block34;

    block34:
	l_v9559 = (struct pypy_object0 *)l_v9480;
	RPyField(l_v9559, o_typeptr) = (&pypy_g_exceptions_OSError_vtable.ose_super.ee_super.se_super.e_super);
	RPyField(l_v9480, ose_inst_errno) = 22L;
	l_v9562 = RPyField(l_v9559, o_typeptr);
	pypy_g_RPyRaiseException(l_v9562, l_v9559);
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_os_read");
	l_v9579 = ((struct pypy_rpy_string0 *) NULL);
	goto block5;

    block35:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_os_read");
	l_v9579 = ((struct pypy_rpy_string0 *) NULL);
	goto block5;

    block36:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v9567 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9568 = (l_v9567 == NULL);
	if (!l_v9568) {
		goto block37;
	}
	goto block31;

    block37:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_os_read");
	l_v9583 = NULL;
	goto block33;

    block38:
	l_v9570 = pypy_g_MiniMarkGC_collect_and_reserve((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_result_34, l_v9477);
	l_v9571 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9572 = (l_v9571 == NULL);
	if (!l_v9572) {
		goto block39;
	}
	l_result_31 = l_v9570;
	goto block30;

    block39:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_os_read");
	l_v9583 = NULL;
	goto block33;

    block40:
	RPyAssert(1, "'contains_weakptr' specified for a large object");
	l_v9575 = pypy_g_MiniMarkGC_external_malloc((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member1), 0L, 1);
	l_v9576 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9577 = (l_v9576 == NULL);
	if (!l_v9577) {
		goto block41;
	}
	l_v9582 = l_v9575;
	goto block32;

    block41:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_os_read");
	l_v9583 = NULL;
	goto block33;
}
/*/*/
void pypy_g_ll_os_ll_os_close(Signed l_fd_2) {
	Signed l_rawtotalsize_9; void* l_result_35; void* l_result_36;
	Signed l_v9584; Signed l_v9585; Signed l_v9587; Signed l_v9588;
	Signed l_v9589; Signed l_v9592; bool_t l_v9590; bool_t l_v9591;
	bool_t l_v9593; bool_t l_v9598; bool_t l_v9599; bool_t l_v9604;
	bool_t l_v9614; bool_t l_v9618; bool_t l_v9623;
	struct pypy_exceptions_OSError0 *l_v9586;
	struct pypy_header0 *l_v9601; struct pypy_object0 *l_v9605;
	struct pypy_object_vtable0 *l_v9608;
	struct pypy_object_vtable0 *l_v9613;
	struct pypy_object_vtable0 *l_v9617;
	struct pypy_object_vtable0 *l_v9622; void* l_v9594; void* l_v9596;
	void* l_v9597; void* l_v9600; void* l_v9603; void* l_v9616;
	void* l_v9621; void* l_v9626; void* l_v9627;
	goto block0;

    block0:
	l_v9587 = (Signed)(l_fd_2);
	l_v9588 = close(l_v9587);
	l_v9589 = (Signed)(l_v9588);
	OP_INT_EQ(l_v9589, -1L, l_v9590);
	if (l_v9590) {
		goto block2;
	}
	goto block1;

    block1:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block2:
	l_v9584 = get_errno();
	OP_RAW_MALLOC_USAGE((0 + ROUND_UP_FOR_ALLOCATION(sizeof(struct pypy_exceptions_OSError0), 0L)), l_rawtotalsize_9);
	OP_INT_GT(l_rawtotalsize_9, 67583L, l_v9591);
	if (l_v9591) {
		goto block15;
	}
	goto block3;

    block3:
	OP_RAW_MALLOC_USAGE((sizeof(struct pypy_header0) + sizeof(void*)), l_v9592);
	OP_INT_LT(l_rawtotalsize_9, l_v9592, l_v9593);
	if (l_v9593) {
		l_v9585 = l_v9592;
		goto block4;
	}
	l_v9585 = (0 + ROUND_UP_FOR_ALLOCATION(sizeof(struct pypy_exceptions_OSError0), 0L));
	goto block4;

    block4:
	l_result_36 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	OP_ADR_ADD(l_result_36, l_v9585, l_v9594);
	(&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free = l_v9594;
	l_v9596 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	l_v9597 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_top;
	OP_ADR_GT(l_v9596, l_v9597, l_v9598);
	if (l_v9598) {
		goto block13;
	}
	l_result_35 = l_result_36;
	goto block5;

    block5:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v9599);
	if (l_v9599) {
		goto block11;
	}
	goto block6;

    block6:
	OP_ADR_ADD(l_result_35, 0, l_v9600);
	l_v9601 = (struct pypy_header0 *)l_result_35;
	RPyField(l_v9601, h_tid) = (GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member1)+0L);
	l_v9626 = l_v9600;
	goto block7;

    block7:
	l_v9603 = (void*)l_v9626;
	l_v9627 = l_v9603;
	goto block8;

    block8:
	l_v9586 = (struct pypy_exceptions_OSError0 *)l_v9627;
	l_v9604 = (l_v9586 != NULL);
	if (!l_v9604) {
		goto block10;
	}
	goto block9;

    block9:
	l_v9605 = (struct pypy_object0 *)l_v9586;
	RPyField(l_v9605, o_typeptr) = (&pypy_g_exceptions_OSError_vtable.ose_super.ee_super.se_super.e_super);
	RPyField(l_v9586, ose_inst_errno) = l_v9584;
	l_v9608 = RPyField(l_v9605, o_typeptr);
	pypy_g_RPyRaiseException(l_v9608, l_v9605);
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_os_close");
	goto block1;

    block10:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_os_close");
	goto block1;

    block11:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v9613 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9614 = (l_v9613 == NULL);
	if (!l_v9614) {
		goto block12;
	}
	goto block6;

    block12:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_os_close");
	l_v9627 = NULL;
	goto block8;

    block13:
	l_v9616 = pypy_g_MiniMarkGC_collect_and_reserve((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_result_36, l_v9585);
	l_v9617 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9618 = (l_v9617 == NULL);
	if (!l_v9618) {
		goto block14;
	}
	l_result_35 = l_v9616;
	goto block5;

    block14:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_os_close");
	l_v9627 = NULL;
	goto block8;

    block15:
	RPyAssert(1, "'contains_weakptr' specified for a large object");
	l_v9621 = pypy_g_MiniMarkGC_external_malloc((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member1), 0L, 1);
	l_v9622 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9623 = (l_v9622 == NULL);
	if (!l_v9623) {
		goto block16;
	}
	l_v9626 = l_v9621;
	goto block7;

    block16:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_os_close");
	l_v9627 = NULL;
	goto block8;
}
/*/*/
struct pypy_tuple5_0 *pypy_g_ll_os_ll_uname(void) {
	struct utsname *l_l_utsbuf_0; Signed l_rawtotalsize_10;
	Signed l_rawtotalsize_11; void* l_result_37; void* l_result_38;
	void* l_result_39; void* l_result_40; Signed l_v9629; Signed l_v9634;
	Signed l_v9635; Signed l_v9644; Signed l_v9744; Signed l_v9798;
	bool_t l_v9639; bool_t l_v9643; bool_t l_v9645; bool_t l_v9649;
	bool_t l_v9663; bool_t l_v9681; bool_t l_v9703; bool_t l_v9729;
	bool_t l_v9743; bool_t l_v9745; bool_t l_v9750; bool_t l_v9751;
	bool_t l_v9769; bool_t l_v9781; bool_t l_v9785; bool_t l_v9790;
	bool_t l_v9797; bool_t l_v9799; bool_t l_v9804; bool_t l_v9805;
	bool_t l_v9810; bool_t l_v9820; bool_t l_v9824; bool_t l_v9829;
	char *l_v9646; char *l_v9647; char *l_v9650; char *l_v9651;
	char *l_v9664; char *l_v9665; char *l_v9682; char *l_v9683;
	char *l_v9704; char *l_v9705;
	struct pypy_exceptions_OSError0 *l_v9636;
	struct pypy_header0 *l_v9753; struct pypy_header0 *l_v9807;
	struct pypy_object0 *l_v9811; struct pypy_object_vtable0 *l_v9648;
	struct pypy_object_vtable0 *l_v9662;
	struct pypy_object_vtable0 *l_v9680;
	struct pypy_object_vtable0 *l_v9702;
	struct pypy_object_vtable0 *l_v9728;
	struct pypy_object_vtable0 *l_v9780;
	struct pypy_object_vtable0 *l_v9784;
	struct pypy_object_vtable0 *l_v9789;
	struct pypy_object_vtable0 *l_v9814;
	struct pypy_object_vtable0 *l_v9819;
	struct pypy_object_vtable0 *l_v9823;
	struct pypy_object_vtable0 *l_v9828;
	struct pypy_rpy_string0 *l_v9628; struct pypy_rpy_string0 *l_v9630;
	struct pypy_rpy_string0 *l_v9631; struct pypy_rpy_string0 *l_v9632;
	struct pypy_rpy_string0 *l_v9633; struct pypy_tuple5_0 *l_v9637;
	struct pypy_tuple5_0 *l_v9832; void* l_v9638; void* l_v9652;
	void* l_v9653; void* l_v9655; void* l_v9657; void* l_v9658;
	void* l_v9660; void* l_v9666; void* l_v9667; void* l_v9669;
	void* l_v9671; void* l_v9673; void* l_v9674; void* l_v9676;
	void* l_v9678; void* l_v9684; void* l_v9685; void* l_v9687;
	void* l_v9689; void* l_v9691; void* l_v9693; void* l_v9694;
	void* l_v9696; void* l_v9698; void* l_v9700; void* l_v9706;
	void* l_v9707; void* l_v9709; void* l_v9711; void* l_v9713;
	void* l_v9715; void* l_v9717; void* l_v9718; void* l_v9720;
	void* l_v9722; void* l_v9724; void* l_v9726; void* l_v9730;
	void* l_v9731; void* l_v9733; void* l_v9735; void* l_v9737;
	void* l_v9739; void* l_v9741; void* l_v9746; void* l_v9748;
	void* l_v9749; void* l_v9752; void* l_v9755; void* l_v9756;
	void* l_v9757; void* l_v9759; void* l_v9761; void* l_v9763;
	void* l_v9765; void* l_v9767; void* l_v9775; void* l_v9783;
	void* l_v9788; void* l_v9800; void* l_v9802; void* l_v9803;
	void* l_v9806; void* l_v9809; void* l_v9822; void* l_v9827;
	void* l_v9833; void* l_v9834; void* l_v9835; void* l_v9836;
	void* l_v9837;
	goto block0;

    block0:
	OP_RAW_MALLOC(sizeof(struct utsname), l_v9638, void *);
	OP_ADR_NE(l_v9638, NULL, l_v9639);
	if (l_v9639) {
		l_v9833 = l_v9638;
		goto block2;
	}
	goto block1;

    block1:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_uname");
	l_v9833 = NULL;
	goto block2;

    block2:
	OP_TRACK_ALLOC_START(l_v9833, /* nothing */);
	l_l_utsbuf_0 = (struct utsname *)l_v9833;
	l_v9643 = (l_l_utsbuf_0 != NULL);
	if (!l_v9643) {
		goto block45;
	}
	goto block3;

    block3:
	l_v9644 = pypy_g_ccall_uname__utsnamePtr(l_l_utsbuf_0);
	OP_INT_EQ(l_v9644, -1L, l_v9645);
	if (l_v9645) {
		goto block30;
	}
	goto block4;

    block4:
	l_v9646 = (char *)l_l_utsbuf_0;
	l_v9647 = (char *)(l_v9646);
	l_v9633 = pypy_g_charp2str(l_v9647);
	l_v9648 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9649 = (l_v9648 == NULL);
	if (!l_v9649) {
		goto block29;
	}
	goto block5;

    block5:
	l_v9650 = RPyField(l_l_utsbuf_0, nodename);
	l_v9651 = (char *)(l_v9650);
	l_v9652 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v9652, sizeof(void*), l_v9653);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v9653;
	l_v9655 = (void*)l_v9633;
	((void* *) (((char *)l_v9652) + 0))[0] = l_v9655;
	l_v9632 = pypy_g_charp2str(l_v9651);
	l_v9657 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v9657, sizeof(void*), l_v9658);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v9658;
	l_v9660 = ((void* *) (((char *)l_v9658) + 0))[0];
	l_v9633 = l_v9660; /* for moving GCs */
	l_v9662 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9663 = (l_v9662 == NULL);
	if (!l_v9663) {
		goto block28;
	}
	goto block6;

    block6:
	l_v9664 = RPyField(l_l_utsbuf_0, release);
	l_v9665 = (char *)(l_v9664);
	l_v9666 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v9666, (sizeof(void*) * 2), l_v9667);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v9667;
	l_v9669 = (void*)l_v9633;
	((void* *) (((char *)l_v9666) + 0))[0] = l_v9669;
	l_v9671 = (void*)l_v9632;
	((void* *) (((char *)l_v9666) + sizeof(void*)))[0] = l_v9671;
	l_v9628 = pypy_g_charp2str(l_v9665);
	l_v9673 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v9673, (sizeof(void*) * 2), l_v9674);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v9674;
	l_v9676 = ((void* *) (((char *)l_v9674) + 0))[0];
	l_v9633 = l_v9676; /* for moving GCs */
	l_v9678 = ((void* *) (((char *)l_v9674) + sizeof(void*)))[0];
	l_v9632 = l_v9678; /* for moving GCs */
	l_v9680 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9681 = (l_v9680 == NULL);
	if (!l_v9681) {
		goto block27;
	}
	goto block7;

    block7:
	l_v9682 = RPyField(l_l_utsbuf_0, version);
	l_v9683 = (char *)(l_v9682);
	l_v9684 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v9684, (sizeof(void*) * 3), l_v9685);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v9685;
	l_v9687 = (void*)l_v9633;
	((void* *) (((char *)l_v9684) + 0))[0] = l_v9687;
	l_v9689 = (void*)l_v9632;
	((void* *) (((char *)l_v9684) + sizeof(void*)))[0] = l_v9689;
	l_v9691 = (void*)l_v9628;
	((void* *) (((char *)l_v9684) + (sizeof(void*) * 2)))[0] = l_v9691;
	l_v9630 = pypy_g_charp2str(l_v9683);
	l_v9693 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v9693, (sizeof(void*) * 3), l_v9694);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v9694;
	l_v9696 = ((void* *) (((char *)l_v9694) + 0))[0];
	l_v9633 = l_v9696; /* for moving GCs */
	l_v9698 = ((void* *) (((char *)l_v9694) + sizeof(void*)))[0];
	l_v9632 = l_v9698; /* for moving GCs */
	l_v9700 = ((void* *) (((char *)l_v9694) + (sizeof(void*) * 2)))[0];
	l_v9628 = l_v9700; /* for moving GCs */
	l_v9702 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9703 = (l_v9702 == NULL);
	if (!l_v9703) {
		goto block26;
	}
	goto block8;

    block8:
	l_v9704 = RPyField(l_l_utsbuf_0, machine);
	l_v9705 = (char *)(l_v9704);
	l_v9706 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v9706, (sizeof(void*) * 4), l_v9707);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v9707;
	l_v9709 = (void*)l_v9630;
	((void* *) (((char *)l_v9706) + 0))[0] = l_v9709;
	l_v9711 = (void*)l_v9633;
	((void* *) (((char *)l_v9706) + sizeof(void*)))[0] = l_v9711;
	l_v9713 = (void*)l_v9632;
	((void* *) (((char *)l_v9706) + (sizeof(void*) * 2)))[0] = l_v9713;
	l_v9715 = (void*)l_v9628;
	((void* *) (((char *)l_v9706) + (sizeof(void*) * 3)))[0] = l_v9715;
	l_v9631 = pypy_g_charp2str(l_v9705);
	l_v9717 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v9717, (sizeof(void*) * 4), l_v9718);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v9718;
	l_v9720 = ((void* *) (((char *)l_v9718) + 0))[0];
	l_v9630 = l_v9720; /* for moving GCs */
	l_v9722 = ((void* *) (((char *)l_v9718) + sizeof(void*)))[0];
	l_v9633 = l_v9722; /* for moving GCs */
	l_v9724 = ((void* *) (((char *)l_v9718) + (sizeof(void*) * 2)))[0];
	l_v9632 = l_v9724; /* for moving GCs */
	l_v9726 = ((void* *) (((char *)l_v9718) + (sizeof(void*) * 3)))[0];
	l_v9628 = l_v9726; /* for moving GCs */
	l_v9728 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9729 = (l_v9728 == NULL);
	if (!l_v9729) {
		goto block25;
	}
	goto block9;

    block9:
	l_v9730 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v9730, (sizeof(void*) * 5), l_v9731);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v9731;
	l_v9733 = (void*)l_v9628;
	((void* *) (((char *)l_v9730) + 0))[0] = l_v9733;
	l_v9735 = (void*)l_v9633;
	((void* *) (((char *)l_v9730) + sizeof(void*)))[0] = l_v9735;
	l_v9737 = (void*)l_v9630;
	((void* *) (((char *)l_v9730) + (sizeof(void*) * 2)))[0] = l_v9737;
	l_v9739 = (void*)l_v9632;
	((void* *) (((char *)l_v9730) + (sizeof(void*) * 3)))[0] = l_v9739;
	l_v9741 = (void*)l_v9631;
	((void* *) (((char *)l_v9730) + (sizeof(void*) * 4)))[0] = l_v9741;
	OP_RAW_MALLOC_USAGE((0 + ROUND_UP_FOR_ALLOCATION(sizeof(struct pypy_tuple5_0), 0L)), l_rawtotalsize_11);
	OP_INT_GT(l_rawtotalsize_11, 67583L, l_v9743);
	if (l_v9743) {
		goto block23;
	}
	goto block10;

    block10:
	OP_RAW_MALLOC_USAGE((sizeof(struct pypy_header0) + sizeof(void*)), l_v9744);
	OP_INT_LT(l_rawtotalsize_11, l_v9744, l_v9745);
	if (l_v9745) {
		l_v9629 = l_v9744;
		goto block11;
	}
	l_v9629 = (0 + ROUND_UP_FOR_ALLOCATION(sizeof(struct pypy_tuple5_0), 0L));
	goto block11;

    block11:
	l_result_37 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	OP_ADR_ADD(l_result_37, l_v9629, l_v9746);
	(&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free = l_v9746;
	l_v9748 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	l_v9749 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_top;
	OP_ADR_GT(l_v9748, l_v9749, l_v9750);
	if (l_v9750) {
		goto block21;
	}
	l_result_38 = l_result_37;
	goto block12;

    block12:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v9751);
	if (l_v9751) {
		goto block19;
	}
	goto block13;

    block13:
	OP_ADR_ADD(l_result_38, 0, l_v9752);
	l_v9753 = (struct pypy_header0 *)l_result_38;
	RPyField(l_v9753, h_tid) = (GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member23)+0L);
	l_v9834 = l_v9752;
	goto block14;

    block14:
	l_v9755 = (void*)l_v9834;
	l_v9835 = l_v9755;
	goto block15;

    block15:
	l_v9756 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v9756, (sizeof(void*) * 5), l_v9757);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v9757;
	l_v9759 = ((void* *) (((char *)l_v9757) + 0))[0];
	l_v9628 = l_v9759; /* for moving GCs */
	l_v9761 = ((void* *) (((char *)l_v9757) + sizeof(void*)))[0];
	l_v9633 = l_v9761; /* for moving GCs */
	l_v9763 = ((void* *) (((char *)l_v9757) + (sizeof(void*) * 2)))[0];
	l_v9630 = l_v9763; /* for moving GCs */
	l_v9765 = ((void* *) (((char *)l_v9757) + (sizeof(void*) * 3)))[0];
	l_v9632 = l_v9765; /* for moving GCs */
	l_v9767 = ((void* *) (((char *)l_v9757) + (sizeof(void*) * 4)))[0];
	l_v9631 = l_v9767; /* for moving GCs */
	l_v9637 = (struct pypy_tuple5_0 *)l_v9835;
	l_v9769 = (l_v9637 != NULL);
	if (!l_v9769) {
		goto block18;
	}
	goto block16;

    block16:
	RPyField(l_v9637, t_item0) = l_v9633;
	RPyField(l_v9637, t_item1) = l_v9632;
	RPyField(l_v9637, t_item2) = l_v9628;
	RPyField(l_v9637, t_item3) = l_v9630;
	RPyField(l_v9637, t_item4) = l_v9631;
	l_v9775 = (void*)l_l_utsbuf_0;
	OP_TRACK_ALLOC_STOP(l_v9775, /* nothing */);
	OP_RAW_FREE(l_v9775, /* nothing */);
	l_v9832 = l_v9637;
	goto block17;

    block17:
	RPY_DEBUG_RETURN();
	return l_v9832;

    block18:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_uname");
	l_v9832 = ((struct pypy_tuple5_0 *) NULL);
	goto block17;

    block19:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v9780 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9781 = (l_v9780 == NULL);
	if (!l_v9781) {
		goto block20;
	}
	goto block13;

    block20:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_uname");
	l_v9835 = NULL;
	goto block15;

    block21:
	l_v9783 = pypy_g_MiniMarkGC_collect_and_reserve((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_result_37, l_v9629);
	l_v9784 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9785 = (l_v9784 == NULL);
	if (!l_v9785) {
		goto block22;
	}
	l_result_38 = l_v9783;
	goto block12;

    block22:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_uname");
	l_v9835 = NULL;
	goto block15;

    block23:
	RPyAssert(1, "'contains_weakptr' specified for a large object");
	l_v9788 = pypy_g_MiniMarkGC_external_malloc((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member23), 0L, 1);
	l_v9789 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9790 = (l_v9789 == NULL);
	if (!l_v9790) {
		goto block24;
	}
	l_v9834 = l_v9788;
	goto block14;

    block24:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_uname");
	l_v9835 = NULL;
	goto block15;

    block25:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_uname");
	l_v9832 = ((struct pypy_tuple5_0 *) NULL);
	goto block17;

    block26:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_uname");
	l_v9832 = ((struct pypy_tuple5_0 *) NULL);
	goto block17;

    block27:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_uname");
	l_v9832 = ((struct pypy_tuple5_0 *) NULL);
	goto block17;

    block28:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_uname");
	l_v9832 = ((struct pypy_tuple5_0 *) NULL);
	goto block17;

    block29:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_uname");
	l_v9832 = ((struct pypy_tuple5_0 *) NULL);
	goto block17;

    block30:
	l_v9634 = get_errno();
	OP_RAW_MALLOC_USAGE((0 + ROUND_UP_FOR_ALLOCATION(sizeof(struct pypy_exceptions_OSError0), 0L)), l_rawtotalsize_10);
	OP_INT_GT(l_rawtotalsize_10, 67583L, l_v9797);
	if (l_v9797) {
		goto block43;
	}
	goto block31;

    block31:
	OP_RAW_MALLOC_USAGE((sizeof(struct pypy_header0) + sizeof(void*)), l_v9798);
	OP_INT_LT(l_rawtotalsize_10, l_v9798, l_v9799);
	if (l_v9799) {
		l_v9635 = l_v9798;
		goto block32;
	}
	l_v9635 = (0 + ROUND_UP_FOR_ALLOCATION(sizeof(struct pypy_exceptions_OSError0), 0L));
	goto block32;

    block32:
	l_result_40 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	OP_ADR_ADD(l_result_40, l_v9635, l_v9800);
	(&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free = l_v9800;
	l_v9802 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	l_v9803 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_top;
	OP_ADR_GT(l_v9802, l_v9803, l_v9804);
	if (l_v9804) {
		goto block41;
	}
	l_result_39 = l_result_40;
	goto block33;

    block33:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v9805);
	if (l_v9805) {
		goto block39;
	}
	goto block34;

    block34:
	OP_ADR_ADD(l_result_39, 0, l_v9806);
	l_v9807 = (struct pypy_header0 *)l_result_39;
	RPyField(l_v9807, h_tid) = (GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member1)+0L);
	l_v9836 = l_v9806;
	goto block35;

    block35:
	l_v9809 = (void*)l_v9836;
	l_v9837 = l_v9809;
	goto block36;

    block36:
	l_v9636 = (struct pypy_exceptions_OSError0 *)l_v9837;
	l_v9810 = (l_v9636 != NULL);
	if (!l_v9810) {
		goto block38;
	}
	goto block37;

    block37:
	l_v9811 = (struct pypy_object0 *)l_v9636;
	RPyField(l_v9811, o_typeptr) = (&pypy_g_exceptions_OSError_vtable.ose_super.ee_super.se_super.e_super);
	RPyField(l_v9636, ose_inst_errno) = l_v9634;
	l_v9814 = RPyField(l_v9811, o_typeptr);
	pypy_g_RPyRaiseException(l_v9814, l_v9811);
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_uname");
	l_v9832 = ((struct pypy_tuple5_0 *) NULL);
	goto block17;

    block38:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_uname");
	l_v9832 = ((struct pypy_tuple5_0 *) NULL);
	goto block17;

    block39:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v9819 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9820 = (l_v9819 == NULL);
	if (!l_v9820) {
		goto block40;
	}
	goto block34;

    block40:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_uname");
	l_v9837 = NULL;
	goto block36;

    block41:
	l_v9822 = pypy_g_MiniMarkGC_collect_and_reserve((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_result_40, l_v9635);
	l_v9823 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9824 = (l_v9823 == NULL);
	if (!l_v9824) {
		goto block42;
	}
	l_result_39 = l_v9822;
	goto block33;

    block42:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_uname");
	l_v9837 = NULL;
	goto block36;

    block43:
	RPyAssert(1, "'contains_weakptr' specified for a large object");
	l_v9827 = pypy_g_MiniMarkGC_external_malloc((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member1), 0L, 1);
	l_v9828 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9829 = (l_v9828 == NULL);
	if (!l_v9829) {
		goto block44;
	}
	l_v9836 = l_v9827;
	goto block35;

    block44:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_uname");
	l_v9837 = NULL;
	goto block36;

    block45:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_uname");
	l_v9832 = ((struct pypy_tuple5_0 *) NULL);
	goto block17;
}
/*/*/
/***********************************************************/
