/***********************************************************/
/***  Implementations                                    ***/

#define PYPY_FILE_NAME "rpython_memory_gctransform_transform.c"
#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"
#include "src/g_include.h"

/*/*/
void* pypy_g__ll_malloc_fixedsize__Signed(Signed l_size_5) {
	bool_t l_v6655; void* l_v6654; void* l_v6658;
	goto block0;

    block0:
	OP_RAW_MALLOC(l_size_5, l_v6654, void *);
	OP_ADR_NE(l_v6654, NULL, l_v6655);
	if (l_v6655) {
		l_v6658 = l_v6654;
		goto block2;
	}
	goto block1;

    block1:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("_ll_malloc_fixedsize__Signed");
	l_v6658 = NULL;
	goto block2;

    block2:
	RPY_DEBUG_RETURN();
	return l_v6658;
}
/*/*/
void* pypy_g_ll_malloc_varsize__Signed_Signed_Signed_Signed(Signed l_length_39, Signed l_v6659, Signed l_itemsize_1, Signed l_lengthoffset_1) {
	Signed l_v6661; Signed l_v6662; bool_t l_v6664; bool_t l_v6666;
	bool_t l_v6667; struct pypy_object0 *l_v6672;
	struct pypy_object0 *l_v6679; struct pypy_object_vtable0 *l_v6663;
	struct pypy_object_vtable0 *l_v6665;
	struct pypy_object_vtable0 *l_v6673;
	struct pypy_object_vtable0 *l_v6680; void* l_v6660; void* l_v6670;
	void* l_v6686;
	goto block0;

    block0:
	OP_INT_MUL_OVF(l_itemsize_1, l_length_39, l_v6661);
	l_v6663 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6664 = (l_v6663 == NULL);
	if (!l_v6664) {
		goto block7;
	}
	goto block1;

    block1:
	OP_INT_ADD_OVF(l_v6659, l_v6661, l_v6662);
	l_v6665 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6666 = (l_v6665 == NULL);
	if (!l_v6666) {
		goto block6;
	}
	goto block2;

    block2:
	OP_RAW_MALLOC(l_v6662, l_v6660, void *);
	OP_ADR_NE(l_v6660, NULL, l_v6667);
	if (l_v6667) {
		goto block5;
	}
	goto block3;

    block3:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("ll_malloc_varsize__Signed_Signed_Signed_Signed");
	l_v6686 = NULL;
	goto block4;

    block4:
	RPY_DEBUG_RETURN();
	return l_v6686;

    block5:
	OP_ADR_ADD(l_v6660, l_lengthoffset_1, l_v6670);
	((Signed *) (((char *)l_v6670) + 0))[0] = l_length_39;
	l_v6686 = l_v6660;
	goto block4;

    block6:
	l_v6672 = (&pypy_g_ExcData)->ed_exc_value;
	l_v6673 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("ll_malloc_varsize__Signed_Signed_Signed_Signed", l_v6673, l_v6673 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_v6673 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("ll_malloc_varsize__Signed_Signed_Signed_Signed");
	l_v6686 = NULL;
	goto block4;

    block7:
	l_v6679 = (&pypy_g_ExcData)->ed_exc_value;
	l_v6680 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("ll_malloc_varsize__Signed_Signed_Signed_Signed", l_v6680, l_v6680 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_v6680 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("ll_malloc_varsize__Signed_Signed_Signed_Signed");
	l_v6686 = NULL;
	goto block4;
}
/*/*/
void* pypy_g__ll_malloc_varsize_no_length__Signed_Signed_Sign(Signed l_length_40, Signed l_v6688, Signed l_itemsize_4) {
	Signed l_v6687; Signed l_v6689; bool_t l_v6691; bool_t l_v6693;
	bool_t l_v6695; struct pypy_object0 *l_v6698;
	struct pypy_object0 *l_v6705; struct pypy_object_vtable0 *l_v6690;
	struct pypy_object_vtable0 *l_v6692;
	struct pypy_object_vtable0 *l_v6699;
	struct pypy_object_vtable0 *l_v6706; void* l_v6694; void* l_v6712;
	goto block0;

    block0:
	OP_INT_MUL_OVF(l_itemsize_4, l_length_40, l_v6687);
	l_v6690 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6691 = (l_v6690 == NULL);
	if (!l_v6691) {
		goto block6;
	}
	goto block1;

    block1:
	OP_INT_ADD_OVF(l_v6688, l_v6687, l_v6689);
	l_v6692 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6693 = (l_v6692 == NULL);
	if (!l_v6693) {
		goto block5;
	}
	goto block2;

    block2:
	OP_RAW_MALLOC(l_v6689, l_v6694, void *);
	OP_ADR_NE(l_v6694, NULL, l_v6695);
	if (l_v6695) {
		l_v6712 = l_v6694;
		goto block4;
	}
	goto block3;

    block3:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("_ll_malloc_varsize_no_length__Signed_Signed_Sign");
	l_v6712 = NULL;
	goto block4;

    block4:
	RPY_DEBUG_RETURN();
	return l_v6712;

    block5:
	l_v6698 = (&pypy_g_ExcData)->ed_exc_value;
	l_v6699 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("_ll_malloc_varsize_no_length__Signed_Signed_Sign", l_v6699, l_v6699 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_v6699 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("_ll_malloc_varsize_no_length__Signed_Signed_Sign");
	l_v6712 = NULL;
	goto block4;

    block6:
	l_v6705 = (&pypy_g_ExcData)->ed_exc_value;
	l_v6706 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("_ll_malloc_varsize_no_length__Signed_Signed_Sign", l_v6706, l_v6706 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_v6706 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("_ll_malloc_varsize_no_length__Signed_Signed_Sign");
	l_v6712 = NULL;
	goto block4;
}
/*/*/
/***********************************************************/
