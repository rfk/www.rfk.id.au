/***********************************************************/
/***  Implementations                                    ***/

#define PYPY_FILE_NAME "rpython_memory_support.c"
#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"
#include "src/g_include.h"

/*/*/
void pypy_g_AddressStack_enlarge(struct pypy_rpython_memory_support_AddressStack0 *l_self_125) {
	bool_t l_v6731; bool_t l_v6733; bool_t l_v6734;
	struct pypy_AddressChunk0 *l_v6729;
	struct pypy_AddressChunk0 *l_v6732;
	struct pypy_AddressChunk0 *l_v6738;
	struct pypy_AddressChunk0 *l_v6742;
	struct pypy_AddressChunk0 *l_v6743;
	struct pypy_AddressChunk0 *l_v6746; void* l_v6730;
	goto block0;

    block0:
	l_v6732 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v6733 = (l_v6732 != NULL);
	if (l_v6733) {
		goto block8;
	}
	goto block1;

    block1:
	OP_RAW_MALLOC(sizeof(struct pypy_AddressChunk0), l_v6730, void *);
	OP_ADR_NE(l_v6730, NULL, l_v6734);
	if (l_v6734) {
		goto block5;
	}
	goto block2;

    block2:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("AddressStack_enlarge");
	goto block3;

    block3:
	PYPY_DEBUG_RECORD_TRACEBACK("AddressStack_enlarge");
	goto block4;

    block4:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block5:
	l_v6729 = (struct pypy_AddressChunk0 *)l_v6730;
	l_v6731 = (l_v6729 != NULL);
	goto block6;

    block6:
	if (!l_v6731) {
		goto block3;
	}
	l_v6746 = l_v6729;
	goto block7;

    block7:
	l_v6738 = RPyField(l_self_125, as_inst_chunk);
	RPyField(l_v6746, ac_next) = l_v6738;
	RPyField(l_self_125, as_inst_chunk) = l_v6746;
	RPyField(l_self_125, as_inst_used_in_last_chunk) = 0L;
	goto block4;

    block8:
	l_v6742 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v6743 = RPyField(l_v6742, ac_next);
	(&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list = l_v6743;
	l_v6746 = l_v6742;
	goto block7;
}
/*/*/
void pypy_g_AddressStack_shrink(struct pypy_rpython_memory_support_AddressStack0 *l_self_28) {
	struct pypy_AddressChunk0 *l_v6747;
	struct pypy_AddressChunk0 *l_v6748;
	struct pypy_AddressChunk0 *l_v6750;
	goto block0;

    block0:
	l_v6747 = RPyField(l_self_28, as_inst_chunk);
	l_v6748 = RPyField(l_v6747, ac_next);
	RPyField(l_self_28, as_inst_chunk) = l_v6748;
	l_v6750 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	RPyField(l_v6747, ac_next) = l_v6750;
	(&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list = l_v6747;
	RPyField(l_self_28, as_inst_used_in_last_chunk) = 1019L;
	goto block1;

    block1:
	RPY_DEBUG_RETURN();
	return /* nothing */;
}
/*/*/
void pypy_g_foreach___debug_callback(struct pypy_rpython_memory_support_AddressStack0 *l_self_30, struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_arg_17) {
	struct pypy_AddressChunk0 *l_chunk_0; Signed l_count_4;
	Signed l_count_5; Signed l_v6756; Signed l_v6760; bool_t l_v6757;
	bool_t l_v6758; bool_t l_v6765; struct pypy_AddressChunk0 *l_v6755;
	struct pypy_AddressChunk0 *l_v6759;
	struct pypy_object_vtable0 *l_v6764; void* *l_v6761; void* l_v6762;
	goto block0;

    block0:
	l_v6755 = RPyField(l_self_30, as_inst_chunk);
	l_v6756 = RPyField(l_self_30, as_inst_used_in_last_chunk);
	l_count_5 = l_v6756;
	l_chunk_0 = l_v6755;
	goto block1;

    block1:
	l_v6757 = (l_chunk_0 != NULL);
	if (l_v6757) {
		l_count_4 = l_count_5;
		goto block3;
	}
	goto block2;

    block2:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block3:
	while (1) {
		OP_INT_GT(l_count_4, 0L, l_v6758);
		if (!l_v6758) break;
		goto block5;
	  block3_back: ;
	}
	goto block4;

    block4:
	l_v6759 = RPyField(l_chunk_0, ac_next);
	l_count_5 = 1019L;
	l_chunk_0 = l_v6759;
	goto block1;

    block5:
	OP_INT_SUB(l_count_4, 1L, l_v6760);
	l_v6761 = RPyField(l_chunk_0, ac_items);
	l_v6762 = RPyFxItem(l_v6761, l_v6760, 1019);
	pypy_g_GCBase__debug_record(l_arg_17, l_v6762);
	l_v6764 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6765 = (l_v6764 == NULL);
	if (!l_v6765) {
		goto block6;
	}
	l_count_4 = l_v6760;
	goto block3_back;

    block6:
	PYPY_DEBUG_RECORD_TRACEBACK("foreach___debug_callback");
	goto block2;
}
/*/*/
void pypy_g_foreach___debug_callback_1(struct pypy_rpython_memory_support_AddressDeque0 *l_self_126, struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_arg_18) {
	struct pypy_AddressChunk0 *l_chunk_1; Signed l_index_15;
	Signed l_index_16; Signed l_index_17; Signed l_limit_0;
	Signed l_v6769; Signed l_v6779; Signed l_v6787; bool_t l_v6771;
	bool_t l_v6772; bool_t l_v6778; bool_t l_v6781; bool_t l_v6786;
	struct pypy_AddressChunk0 *l_v6768;
	struct pypy_AddressChunk0 *l_v6770;
	struct pypy_AddressChunk0 *l_v6773;
	struct pypy_object_vtable0 *l_v6777;
	struct pypy_object_vtable0 *l_v6785; void* *l_v6774; void* *l_v6782;
	void* l_v6775; void* l_v6783;
	goto block0;

    block0:
	l_v6768 = RPyField(l_self_126, ad_inst_oldest_chunk);
	l_v6769 = RPyField(l_self_126, ad_inst_index_in_oldest);
	l_chunk_1 = l_v6768;
	l_index_16 = l_v6769;
	goto block1;

    block1:
	l_v6770 = RPyField(l_self_126, ad_inst_newest_chunk);
	l_v6771 = (l_chunk_1 == l_v6770);
	if (l_v6771) {
		goto block8;
	}
	l_index_17 = l_index_16;
	goto block2;

    block2:
	while (1) {
		OP_INT_LT(l_index_17, 1019L, l_v6772);
		if (!l_v6772) break;
		goto block4;
	  block2_back: ;
	}
	goto block3;

    block3:
	l_v6773 = RPyField(l_chunk_1, ac_next);
	l_chunk_1 = l_v6773;
	l_index_16 = 0L;
	goto block1;

    block4:
	l_v6774 = RPyField(l_chunk_1, ac_items);
	l_v6775 = RPyFxItem(l_v6774, l_index_17, 1019);
	pypy_g_GCBase__debug_record(l_arg_18, l_v6775);
	l_v6777 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6778 = (l_v6777 == NULL);
	if (!l_v6778) {
		goto block6;
	}
	goto block5;

    block5:
	OP_INT_ADD(l_index_17, 1L, l_v6779);
	l_index_17 = l_v6779;
	goto block2_back;

    block6:
	PYPY_DEBUG_RECORD_TRACEBACK("foreach___debug_callback_1");
	goto block7;

    block7:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block8:
	l_limit_0 = RPyField(l_self_126, ad_inst_index_in_newest);
	l_index_15 = l_index_16;
	goto block9;

    block9:
	while (1) {
		OP_INT_LT(l_index_15, l_limit_0, l_v6781);
		if (!l_v6781) break;
		goto block10;
	  block9_back: ;
	}
	goto block7;

    block10:
	l_v6782 = RPyField(l_chunk_1, ac_items);
	l_v6783 = RPyFxItem(l_v6782, l_index_15, 1019);
	pypy_g_GCBase__debug_record(l_arg_18, l_v6783);
	l_v6785 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6786 = (l_v6785 == NULL);
	if (!l_v6786) {
		goto block12;
	}
	goto block11;

    block11:
	OP_INT_ADD(l_index_15, 1L, l_v6787);
	l_index_15 = l_v6787;
	goto block9_back;

    block12:
	PYPY_DEBUG_RECORD_TRACEBACK("foreach___debug_callback_1");
	goto block7;
}
/*/*/
void pypy_g_foreach___reset_gcflag_visited(struct pypy_rpython_memory_support_AddressStack0 *l_self_38, struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_callback_7) {
	struct pypy_AddressChunk0 *l_chunk_2; Signed l_count_6;
	Signed l_v6790; Signed l_v6792; Signed l_v6796; Signed l_v6801;
	Signed l_v6802; bool_t l_v6793; bool_t l_v6794;
	struct pypy_AddressChunk0 *l_v6791;
	struct pypy_AddressChunk0 *l_v6795; struct pypy_header0 *l_v6800;
	void* *l_v6797; void* l_v6798; void* l_v6799;
	goto block0;

    block0:
	l_v6791 = RPyField(l_self_38, as_inst_chunk);
	l_v6792 = RPyField(l_self_38, as_inst_used_in_last_chunk);
	l_chunk_2 = l_v6791;
	l_count_6 = l_v6792;
	goto block1;

    block1:
	l_v6793 = (l_chunk_2 != NULL);
	if (l_v6793) {
		l_v6790 = l_count_6;
		goto block3;
	}
	goto block2;

    block2:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block3:
	while (1) {
		OP_INT_GT(l_v6790, 0L, l_v6794);
		if (!l_v6794) break;
		goto block5;
	  block3_back: ;
	}
	goto block4;

    block4:
	l_v6795 = RPyField(l_chunk_2, ac_next);
	l_chunk_2 = l_v6795;
	l_count_6 = 1019L;
	goto block1;

    block5:
	OP_INT_SUB(l_v6790, 1L, l_v6796);
	l_v6797 = RPyField(l_chunk_2, ac_items);
	l_v6798 = RPyFxItem(l_v6797, l_v6796, 1019);
	OP_ADR_SUB(l_v6798, 0, l_v6799);
	l_v6800 = (struct pypy_header0 *)l_v6799;
	l_v6801 = RPyField(l_v6800, h_tid);
	OP_INT_AND(l_v6801, -262145L, l_v6802);
	RPyField(l_v6800, h_tid) = l_v6802;
	l_v6790 = l_v6796;
	goto block3_back;
}
/*/*/
void pypy_g_foreach___collect_obj(struct pypy_rpython_memory_support_AddressStack0 *l_self_48, struct pypy_rpython_memory_support_AddressStack0 *l_self_127) {
	void* l_addr_17; struct pypy_AddressChunk0 *l_chunk_3;
	Signed l_count_7; Signed l_count_8; Signed l_used_39; Signed l_v6805;
	Signed l_v6807; Signed l_v6812; Signed l_v6817; bool_t l_v6808;
	bool_t l_v6809; bool_t l_v6813; bool_t l_v6821;
	struct pypy_AddressChunk0 *l_v6806;
	struct pypy_AddressChunk0 *l_v6810;
	struct pypy_AddressChunk0 *l_v6814;
	struct pypy_object_vtable0 *l_v6820; void* *l_v6811; void* *l_v6815;
	goto block0;

    block0:
	l_v6806 = RPyField(l_self_48, as_inst_chunk);
	l_v6807 = RPyField(l_self_48, as_inst_used_in_last_chunk);
	l_chunk_3 = l_v6806;
	l_count_8 = l_v6807;
	goto block1;

    block1:
	while (1) {
		l_v6808 = (l_chunk_3 != NULL);
		if (!l_v6808) break;
		l_count_7 = l_count_8;
		goto block3;
	  block1_back: ;
	}
	goto block2;

    block2:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block3:
	OP_INT_GT(l_count_7, 0L, l_v6809);
	if (l_v6809) {
		goto block5;
	}
	goto block4;

    block4:
	l_v6810 = RPyField(l_chunk_3, ac_next);
	l_chunk_3 = l_v6810;
	l_count_8 = 1019L;
	goto block1_back;

    block5:
	OP_INT_SUB(l_count_7, 1L, l_v6805);
	l_v6811 = RPyField(l_chunk_3, ac_items);
	l_addr_17 = RPyFxItem(l_v6811, l_v6805, 1019);
	l_v6812 = RPyField(l_self_127, as_inst_used_in_last_chunk);
	OP_INT_EQ(l_v6812, 1019L, l_v6813);
	if (l_v6813) {
		goto block7;
	}
	l_used_39 = l_v6812;
	goto block6;

    block6:
	l_v6814 = RPyField(l_self_127, as_inst_chunk);
	l_v6815 = RPyField(l_v6814, ac_items);
	RPyFxItem(l_v6815, l_used_39, 1019) = l_addr_17;
	OP_INT_ADD(l_used_39, 1L, l_v6817);
	RPyField(l_self_127, as_inst_used_in_last_chunk) = l_v6817;
	l_count_7 = l_v6805;
	goto block3;

    block7:
	pypy_g_AddressStack_enlarge(l_self_127);
	l_v6820 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6821 = (l_v6820 == NULL);
	if (!l_v6821) {
		goto block8;
	}
	l_used_39 = 0L;
	goto block6;

    block8:
	PYPY_DEBUG_RECORD_TRACEBACK("foreach___collect_obj");
	goto block2;
}
/*/*/
void pypy_g_foreach___collect_obj_1(struct pypy_rpython_memory_support_AddressDeque0 *l_self_128, struct pypy_rpython_memory_support_AddressStack0 *l_arg_19) {
	struct pypy_AddressChunk0 *l_chunk_4; Signed l_index_18;
	Signed l_index_19; Signed l_index_20; Signed l_limit_1;
	Signed l_used_40; Signed l_used_41; Signed l_v6827; Signed l_v6833;
	Signed l_v6838; Signed l_v6840; Signed l_v6847; Signed l_v6852;
	Signed l_v6854; bool_t l_v6829; bool_t l_v6830; bool_t l_v6834;
	bool_t l_v6843; bool_t l_v6845; bool_t l_v6848; bool_t l_v6857;
	struct pypy_AddressChunk0 *l_v6826;
	struct pypy_AddressChunk0 *l_v6828;
	struct pypy_AddressChunk0 *l_v6831;
	struct pypy_AddressChunk0 *l_v6835;
	struct pypy_AddressChunk0 *l_v6849;
	struct pypy_object_vtable0 *l_v6842;
	struct pypy_object_vtable0 *l_v6856; void* *l_v6832; void* *l_v6836;
	void* *l_v6846; void* *l_v6850; void* l_v6824; void* l_v6825;
	goto block0;

    block0:
	l_v6826 = RPyField(l_self_128, ad_inst_oldest_chunk);
	l_v6827 = RPyField(l_self_128, ad_inst_index_in_oldest);
	l_index_20 = l_v6827;
	l_chunk_4 = l_v6826;
	goto block1;

    block1:
	l_v6828 = RPyField(l_self_128, ad_inst_newest_chunk);
	l_v6829 = (l_chunk_4 == l_v6828);
	if (l_v6829) {
		goto block9;
	}
	l_index_18 = l_index_20;
	goto block2;

    block2:
	while (1) {
		OP_INT_LT(l_index_18, 1019L, l_v6830);
		if (!l_v6830) break;
		goto block4;
	  block2_back: ;
	}
	goto block3;

    block3:
	l_v6831 = RPyField(l_chunk_4, ac_next);
	l_index_20 = 0L;
	l_chunk_4 = l_v6831;
	goto block1;

    block4:
	l_v6832 = RPyField(l_chunk_4, ac_items);
	l_v6825 = RPyFxItem(l_v6832, l_index_18, 1019);
	l_v6833 = RPyField(l_arg_19, as_inst_used_in_last_chunk);
	OP_INT_EQ(l_v6833, 1019L, l_v6834);
	if (l_v6834) {
		goto block6;
	}
	l_used_40 = l_v6833;
	goto block5;

    block5:
	l_v6835 = RPyField(l_arg_19, as_inst_chunk);
	l_v6836 = RPyField(l_v6835, ac_items);
	RPyFxItem(l_v6836, l_used_40, 1019) = l_v6825;
	OP_INT_ADD(l_used_40, 1L, l_v6838);
	RPyField(l_arg_19, as_inst_used_in_last_chunk) = l_v6838;
	OP_INT_ADD(l_index_18, 1L, l_v6840);
	l_index_18 = l_v6840;
	goto block2_back;

    block6:
	pypy_g_AddressStack_enlarge(l_arg_19);
	l_v6842 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6843 = (l_v6842 == NULL);
	if (!l_v6843) {
		goto block7;
	}
	l_used_40 = 0L;
	goto block5;

    block7:
	PYPY_DEBUG_RECORD_TRACEBACK("foreach___collect_obj_1");
	goto block8;

    block8:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block9:
	l_limit_1 = RPyField(l_self_128, ad_inst_index_in_newest);
	l_index_19 = l_index_20;
	goto block10;

    block10:
	while (1) {
		OP_INT_LT(l_index_19, l_limit_1, l_v6845);
		if (!l_v6845) break;
		goto block11;
	  block10_back: ;
	}
	goto block8;

    block11:
	l_v6846 = RPyField(l_chunk_4, ac_items);
	l_v6824 = RPyFxItem(l_v6846, l_index_19, 1019);
	l_v6847 = RPyField(l_arg_19, as_inst_used_in_last_chunk);
	OP_INT_EQ(l_v6847, 1019L, l_v6848);
	if (l_v6848) {
		goto block13;
	}
	l_used_41 = l_v6847;
	goto block12;

    block12:
	l_v6849 = RPyField(l_arg_19, as_inst_chunk);
	l_v6850 = RPyField(l_v6849, ac_items);
	RPyFxItem(l_v6850, l_used_41, 1019) = l_v6824;
	OP_INT_ADD(l_used_41, 1L, l_v6852);
	RPyField(l_arg_19, as_inst_used_in_last_chunk) = l_v6852;
	OP_INT_ADD(l_index_19, 1L, l_v6854);
	l_index_19 = l_v6854;
	goto block10_back;

    block13:
	pypy_g_AddressStack_enlarge(l_arg_19);
	l_v6856 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6857 = (l_v6856 == NULL);
	if (!l_v6857) {
		goto block14;
	}
	l_used_41 = 0L;
	goto block12;

    block14:
	PYPY_DEBUG_RECORD_TRACEBACK("foreach___collect_obj_1");
	goto block8;
}
/*/*/
void pypy_g_AddressDeque_shrink(struct pypy_rpython_memory_support_AddressDeque0 *l_self_53) {
	struct pypy_AddressChunk0 *l_v6860;
	struct pypy_AddressChunk0 *l_v6861;
	struct pypy_AddressChunk0 *l_v6863;
	goto block0;

    block0:
	l_v6860 = RPyField(l_self_53, ad_inst_oldest_chunk);
	l_v6861 = RPyField(l_v6860, ac_next);
	RPyField(l_self_53, ad_inst_oldest_chunk) = l_v6861;
	l_v6863 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	RPyField(l_v6860, ac_next) = l_v6863;
	(&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list = l_v6860;
	RPyField(l_self_53, ad_inst_index_in_oldest) = 0L;
	goto block1;

    block1:
	RPY_DEBUG_RETURN();
	return /* nothing */;
}
/*/*/
void pypy_g_AddressDeque_enlarge(struct pypy_rpython_memory_support_AddressDeque0 *l_self_129) {
	bool_t l_v6869; bool_t l_v6872; bool_t l_v6873;
	struct pypy_AddressChunk0 *l_v6870;
	struct pypy_AddressChunk0 *l_v6871;
	struct pypy_AddressChunk0 *l_v6878;
	struct pypy_AddressChunk0 *l_v6882;
	struct pypy_AddressChunk0 *l_v6883;
	struct pypy_AddressChunk0 *l_v6886; void* l_v6868;
	goto block0;

    block0:
	l_v6871 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v6872 = (l_v6871 != NULL);
	if (l_v6872) {
		goto block8;
	}
	goto block1;

    block1:
	OP_RAW_MALLOC(sizeof(struct pypy_AddressChunk0), l_v6868, void *);
	OP_ADR_NE(l_v6868, NULL, l_v6873);
	if (l_v6873) {
		goto block5;
	}
	goto block2;

    block2:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("AddressDeque_enlarge");
	goto block3;

    block3:
	PYPY_DEBUG_RECORD_TRACEBACK("AddressDeque_enlarge");
	goto block4;

    block4:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block5:
	l_v6870 = (struct pypy_AddressChunk0 *)l_v6868;
	l_v6869 = (l_v6870 != NULL);
	goto block6;

    block6:
	if (!l_v6869) {
		goto block3;
	}
	l_v6886 = l_v6870;
	goto block7;

    block7:
	RPyField(l_v6886, ac_next) = ((struct pypy_AddressChunk0 *) NULL);
	l_v6878 = RPyField(l_self_129, ad_inst_newest_chunk);
	RPyField(l_v6878, ac_next) = l_v6886;
	RPyField(l_self_129, ad_inst_newest_chunk) = l_v6886;
	RPyField(l_self_129, ad_inst_index_in_newest) = 0L;
	goto block4;

    block8:
	l_v6882 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v6883 = RPyField(l_v6882, ac_next);
	(&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list = l_v6883;
	l_v6886 = l_v6882;
	goto block7;
}
/*/*/
/***********************************************************/
