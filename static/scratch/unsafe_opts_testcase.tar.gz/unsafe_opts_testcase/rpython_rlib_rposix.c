/***********************************************************/
/***  Implementations                                    ***/

#define PYPY_FILE_NAME "rpython_rlib_rposix.c"
#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"
#include "src/g_include.h"

/*/*/
Signed pypy_g_get_errno(void) {
	Signed l_v7048;
	goto block0;

    block0:
	l_v7048 = get_errno();
	goto block1;

    block1:
	RPY_DEBUG_RETURN();
	return l_v7048;
}
/*/*/
/***********************************************************/
