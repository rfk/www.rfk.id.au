/***********************************************************/
/***  Implementations                                    ***/

#define PYPY_FILE_NAME "rpython_rtyper_lltypesystem_rbuilder.c"
#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"
#include "src/g_include.h"

/*/*/
void pypy_g_stringbuilder_grow__stringbuilderPtr_Signed(struct pypy_stringbuilder0 *l_ll_builder_1, Signed l_needed_1) {
	Signed l_length_43; Signed l_maxsize_5;
	struct pypy_rpy_string0 *l_r_1; Unsigned l_toobig_6;
	Signed l_totalsize_21; Signed l_v7172; Signed l_v7173;
	Signed l_v7174; Signed l_v7178; Signed l_v7180; Signed l_v7192;
	Signed l_v7194; Signed l_v7198; Signed l_v7200; Signed l_v7201;
	Signed l_v7202; Signed l_v7232; Signed l_v7238; Signed l_v7239;
	Signed l_v7253; Signed l_v7261; Signed l_v7262; Unsigned l_v7196;
	Unsigned l_v7263; Unsigned l_v7264; bool_t l_v7182; bool_t l_v7184;
	bool_t l_v7185; bool_t l_v7193; bool_t l_v7195; bool_t l_v7197;
	bool_t l_v7199; bool_t l_v7203; bool_t l_v7209; bool_t l_v7210;
	bool_t l_v7222; bool_t l_v7223; bool_t l_v7225; bool_t l_v7240;
	bool_t l_v7247; bool_t l_v7251; bool_t l_v7255; bool_t l_v7259;
	struct pypy_header0 *l_v7211; struct pypy_header0 *l_v7237;
	struct pypy_object0 *l_v7265; struct pypy_object0 *l_v7272;
	struct pypy_object_vtable0 *l_v7181;
	struct pypy_object_vtable0 *l_v7183;
	struct pypy_object_vtable0 *l_v7246;
	struct pypy_object_vtable0 *l_v7250;
	struct pypy_object_vtable0 *l_v7254;
	struct pypy_object_vtable0 *l_v7258;
	struct pypy_object_vtable0 *l_v7266;
	struct pypy_object_vtable0 *l_v7273;
	struct pypy_rpy_string0 *l_v7175; void* l_v7171; void* l_v7176;
	void* l_v7177; void* l_v7179; void* l_v7187; void* l_v7188;
	void* l_v7190; void* l_v7205; void* l_v7207; void* l_v7208;
	void* l_v7213; void* l_v7214; void* l_v7216; void* l_v7217;
	void* l_v7218; void* l_v7220; void* l_v7228; void* l_v7229;
	void* l_v7230; void* l_v7231; void* l_v7236; void* l_v7249;
	void* l_v7257; void* l_v7280; void* l_v7281;
	goto block0;

    block0:
	l_v7174 = RPyField(l_ll_builder_1, s_allocated);
	OP_INT_RSHIFT(l_v7174, 2L, l_v7178);
	OP_INT_ADD_OVF(l_v7174, l_v7178, l_v7180);
	l_v7181 = (&pypy_g_ExcData)->ed_exc_type;
	l_v7182 = (l_v7181 == NULL);
	if (!l_v7182) {
		goto block31;
	}
	goto block1;

    block1:
	OP_INT_ADD_OVF(l_v7180, l_needed_1, l_length_43);
	l_v7183 = (&pypy_g_ExcData)->ed_exc_type;
	l_v7184 = (l_v7183 == NULL);
	if (!l_v7184) {
		goto block30;
	}
	goto block2;

    block2:
	OP_INT_GE(l_length_43, 0L, l_v7185);
	RPyAssert(l_v7185, "negative string length");
	l_v7187 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v7187, sizeof(void*), l_v7188);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v7188;
	l_v7190 = (void*)l_ll_builder_1;
	((void* *) (((char *)l_v7187) + 0))[0] = l_v7190;
	OP_RAW_MALLOC_USAGE((0 + offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v7192);
	OP_INT_SUB(67583L, l_v7192, l_maxsize_5);
	OP_INT_LT(l_maxsize_5, 0L, l_v7193);
	if (l_v7193) {
		l_toobig_6 = 0UL;
		goto block4;
	}
	goto block3;

    block3:
	OP_RAW_MALLOC_USAGE(sizeof(char), l_v7194);
	OP_INT_IS_TRUE(l_v7194, l_v7195);
	if (l_v7195) {
		goto block29;
	}
	l_toobig_6 = 2147483648UL;
	goto block4;

    block4:
	OP_CAST_INT_TO_UINT(l_length_43, l_v7196);
	OP_UINT_GE(l_v7196, l_toobig_6, l_v7197);
	if (l_v7197) {
		goto block27;
	}
	goto block5;

    block5:
	OP_INT_MUL(sizeof(char), l_length_43, l_v7198);
	OP_INT_ADD((0 + offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v7198, l_v7172);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v7199);
	if (l_v7199) {
		goto block25;
	}
	goto block6;

    block6:
	l_v7200 = ROUND_UP_FOR_ALLOCATION(l_v7172, 0L);
	l_totalsize_21 = l_v7200;
	goto block7;

    block7:
	OP_RAW_MALLOC_USAGE(l_totalsize_21, l_v7201);
	OP_RAW_MALLOC_USAGE((sizeof(struct pypy_header0) + sizeof(void*)), l_v7202);
	OP_INT_GE(l_v7201, l_v7202, l_v7203);
	RPyAssert(l_v7203, "malloc_varsize_clear(): totalsize < minimalsize");
	l_v7176 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	OP_ADR_ADD(l_v7176, l_totalsize_21, l_v7205);
	(&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free = l_v7205;
	l_v7207 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	l_v7208 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_top;
	OP_ADR_GT(l_v7207, l_v7208, l_v7209);
	if (l_v7209) {
		goto block23;
	}
	l_v7171 = l_v7176;
	goto block8;

    block8:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v7210);
	if (l_v7210) {
		goto block21;
	}
	goto block9;

    block9:
	l_v7211 = (struct pypy_header0 *)l_v7171;
	RPyField(l_v7211, h_tid) = (GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+0L);
	OP_ADR_ADD(l_v7171, 0, l_v7213);
	OP_ADR_ADD(l_v7213, (offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, length)), l_v7214);
	((Signed *) (((char *)l_v7214) + 0))[0] = l_length_43;
	l_v7280 = l_v7213;
	goto block10;

    block10:
	l_v7216 = (void*)l_v7280;
	l_v7281 = l_v7216;
	goto block11;

    block11:
	l_v7217 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v7217, sizeof(void*), l_v7218);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v7218;
	l_v7220 = ((void* *) (((char *)l_v7218) + 0))[0];
	l_ll_builder_1 = l_v7220; /* for moving GCs */
	l_r_1 = (struct pypy_rpy_string0 *)l_v7281;
	l_v7222 = (l_r_1 != NULL);
	if (!l_v7222) {
		goto block20;
	}
	goto block12;

    block12:
	OP_INT_IS_TRUE(MALLOC_ZERO_FILLED, l_v7223);
	if (l_v7223) {
		goto block14;
	}
	goto block13;

    block13:
	RPyField(l_r_1, rs_hash) = 0L;
	goto block14;

    block14:
	l_v7175 = RPyField(l_ll_builder_1, s_buf);
	l_v7173 = RPyField(l_ll_builder_1, s_used);
	OP_INT_GE(l_v7173, 0L, l_v7225);
	if (l_v7225) {
		goto block17;
	}
	goto block15;

    block15:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("stringbuilder_grow__stringbuilderPtr_Signed");
	goto block16;

    block16:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block17:
	l_v7228 = (void*)l_v7175;
	OP_ADR_ADD(l_v7228, (offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v7229);
	l_v7230 = (void*)l_r_1;
	OP_ADR_ADD(l_v7230, (offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v7231);
	OP_INT_MUL(sizeof(char), l_v7173, l_v7232);
	OP_RAW_MEMCOPY(l_v7229, l_v7231, l_v7232, /* nothing */);
	/* kept alive: l_v7229 */
	/* kept alive: l_v7231 */
	l_v7179 = (void*)l_r_1;
	l_v7177 = (void*)l_ll_builder_1;
	OP_ADR_SUB(l_v7177, 0, l_v7236);
	l_v7237 = (struct pypy_header0 *)l_v7236;
	l_v7238 = RPyField(l_v7237, h_tid);
	OP_INT_AND(l_v7238, 65536L, l_v7239);
	OP_INT_IS_TRUE(l_v7239, l_v7240);
	if (l_v7240) {
		goto block19;
	}
	goto block18;

    block18:
	RPyField(l_ll_builder_1, s_buf) = l_r_1;
	RPyField(l_ll_builder_1, s_allocated) = l_length_43;
	goto block16;

    block19:
	pypy_g_remember_young_pointer(l_v7177, l_v7179);
	goto block18;

    block20:
	PYPY_DEBUG_RECORD_TRACEBACK("stringbuilder_grow__stringbuilderPtr_Signed");
	goto block16;

    block21:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v7246 = (&pypy_g_ExcData)->ed_exc_type;
	l_v7247 = (l_v7246 == NULL);
	if (!l_v7247) {
		goto block22;
	}
	goto block9;

    block22:
	PYPY_DEBUG_RECORD_TRACEBACK("stringbuilder_grow__stringbuilderPtr_Signed");
	l_v7281 = NULL;
	goto block11;

    block23:
	l_v7249 = pypy_g_MiniMarkGC_collect_and_reserve((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_v7176, l_totalsize_21);
	l_v7250 = (&pypy_g_ExcData)->ed_exc_type;
	l_v7251 = (l_v7250 == NULL);
	if (!l_v7251) {
		goto block24;
	}
	l_v7171 = l_v7249;
	goto block8;

    block24:
	PYPY_DEBUG_RECORD_TRACEBACK("stringbuilder_grow__stringbuilderPtr_Signed");
	l_v7281 = NULL;
	goto block11;

    block25:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v7253 = (Signed)0;
	l_v7254 = (&pypy_g_ExcData)->ed_exc_type;
	l_v7255 = (l_v7254 == NULL);
	if (!l_v7255) {
		goto block26;
	}
	l_totalsize_21 = l_v7253;
	goto block7;

    block26:
	PYPY_DEBUG_RECORD_TRACEBACK("stringbuilder_grow__stringbuilderPtr_Signed");
	l_v7281 = NULL;
	goto block11;

    block27:
	l_v7257 = pypy_g_MiniMarkGC_external_malloc((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17), l_length_43, 1);
	l_v7258 = (&pypy_g_ExcData)->ed_exc_type;
	l_v7259 = (l_v7258 == NULL);
	if (!l_v7259) {
		goto block28;
	}
	l_v7280 = l_v7257;
	goto block10;

    block28:
	PYPY_DEBUG_RECORD_TRACEBACK("stringbuilder_grow__stringbuilderPtr_Signed");
	l_v7281 = NULL;
	goto block11;

    block29:
	OP_RAW_MALLOC_USAGE(sizeof(char), l_v7261);
	OP_INT_FLOORDIV(l_maxsize_5, l_v7261, l_v7262);
	OP_CAST_INT_TO_UINT(l_v7262, l_v7263);
	OP_UINT_ADD(l_v7263, 1UL, l_v7264);
	l_toobig_6 = l_v7264;
	goto block4;

    block30:
	l_v7265 = (&pypy_g_ExcData)->ed_exc_value;
	l_v7266 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("stringbuilder_grow__stringbuilderPtr_Signed", l_v7266, l_v7266 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_v7266 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("stringbuilder_grow__stringbuilderPtr_Signed");
	goto block16;

    block31:
	l_v7272 = (&pypy_g_ExcData)->ed_exc_value;
	l_v7273 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("stringbuilder_grow__stringbuilderPtr_Signed", l_v7273, l_v7273 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_v7273 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("stringbuilder_grow__stringbuilderPtr_Signed");
	goto block16;
}
/*/*/
/***********************************************************/
