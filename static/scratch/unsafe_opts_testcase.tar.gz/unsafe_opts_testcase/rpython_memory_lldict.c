/***********************************************************/
/***  Implementations                                    ***/

#define PYPY_FILE_NAME "rpython_memory_lldict.c"
#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"
#include "src/g_include.h"

/*/*/
void pypy_g_dict_foreach___free_young_rawmalloced_obj(struct pypy_DICT0 *l_d_15, struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_callback_22) {
	struct pypy_array5 *l_entries_1; Signed l_i_21; Signed l_v6713;
	Signed l_v6714; Signed l_v6717; Signed l_v6721; Unsigned l_v6716;
	bool_t l_v6715; bool_t l_v6720; bool_t l_v6726;
	struct pypy_ENTRY0 *l_v6718; struct pypy_ENTRY0 *l_v6722;
	struct pypy_object_vtable0 *l_v6725; void* l_v6719; void* l_v6723;
	goto block0;

    block0:
	l_entries_1 = RPyField(l_d_15, di_entries);
	l_v6713 = l_entries_1->length;
	OP_INT_SUB(l_v6713, 1L, l_v6714);
	l_i_21 = l_v6714;
	goto block1;

    block1:
	while (1) {
		OP_INT_GE(l_i_21, 0L, l_v6715);
		if (!l_v6715) break;
		goto block3;
	  block1_back: ;
	}
	goto block2;

    block2:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block3:
	OP_CAST_INT_TO_UINT(l_i_21, l_v6716);
	OP_CAST_UINT_TO_INT(l_v6716, l_v6717);
	l_v6718 = &RPyItem(l_entries_1, l_v6717);
	l_v6719 = RPyField(l_v6718, en_key);
	OP_ADR_NE(l_v6719, NULL, l_v6720);
	if (l_v6720) {
		goto block5;
	}
	goto block4;

    block4:
	OP_INT_SUB(l_i_21, 1L, l_v6721);
	l_i_21 = l_v6721;
	goto block1_back;

    block5:
	l_v6722 = &RPyItem(l_entries_1, l_i_21);
	l_v6723 = RPyField(l_v6722, en_key);
	pypy_g_MiniMarkGC_free_rawmalloced_object_if_unvisited(l_callback_22, l_v6723);
	l_v6725 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6726 = (l_v6725 == NULL);
	if (!l_v6726) {
		goto block6;
	}
	goto block4;

    block6:
	PYPY_DEBUG_RECORD_TRACEBACK("dict_foreach___free_young_rawmalloced_obj");
	goto block2;
}
/*/*/
/***********************************************************/
