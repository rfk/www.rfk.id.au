/***********************************************************/
/***  Implementations                                    ***/

#define PYPY_FILE_NAME "rpython_rtyper_lltypesystem_ll_str.c"
#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"
#include "src/g_include.h"

/*/*/
struct pypy_rpy_string0 *pypy_g_ll_int2dec__Signed(Signed l_val_0) {
	Unsigned l_i_23; Signed l_j_7; Signed l_len_0; Signed l_length_42;
	Signed l_maxsize_4; Signed l_sign_0; Unsigned l_toobig_5;
	Signed l_totalsize_20; Signed l_v7088; Signed l_v7096;
	Signed l_v7098; Signed l_v7101; Signed l_v7103; Signed l_v7107;
	Signed l_v7109; Signed l_v7110; Signed l_v7111; Signed l_v7134;
	Signed l_v7136; Signed l_v7137; Signed l_v7140; Signed l_v7152;
	Signed l_v7160; Signed l_v7161; Signed l_v7164; Signed l_v7166;
	Unsigned l_v7094; Unsigned l_v7105; Unsigned l_v7132;
	Unsigned l_v7133; Unsigned l_v7139; Unsigned l_v7162;
	Unsigned l_v7163; Unsigned l_v7165; Unsigned l_v7167; bool_t l_v7092;
	bool_t l_v7093; bool_t l_v7095; bool_t l_v7097; bool_t l_v7099;
	bool_t l_v7102; bool_t l_v7104; bool_t l_v7106; bool_t l_v7108;
	bool_t l_v7112; bool_t l_v7118; bool_t l_v7119; bool_t l_v7126;
	bool_t l_v7127; bool_t l_v7129; bool_t l_v7130; bool_t l_v7131;
	bool_t l_v7146; bool_t l_v7150; bool_t l_v7154; bool_t l_v7158;
	char l_v7135; struct pypy_header0 *l_v7120;
	struct pypy_object_vtable0 *l_v7145;
	struct pypy_object_vtable0 *l_v7149;
	struct pypy_object_vtable0 *l_v7153;
	struct pypy_object_vtable0 *l_v7157;
	struct pypy_rpy_string0 *l_v7089; struct pypy_rpy_string0 *l_v7168;
	void* l_v7090; void* l_v7091; void* l_v7114; void* l_v7116;
	void* l_v7117; void* l_v7122; void* l_v7123; void* l_v7125;
	void* l_v7148; void* l_v7156; void* l_v7169; void* l_v7170;
	Unsigned l_val_1; Unsigned l_val_2;
	goto block0;

    block0:
	OP_INT_LT(l_val_0, 0L, l_v7092);
	OP_CAST_BOOL_TO_INT(l_v7092, l_sign_0);
	OP_INT_IS_TRUE(l_sign_0, l_v7093);
	if (l_v7093) {
		goto block33;
	}
	goto block1;

    block1:
	OP_CAST_INT_TO_UINT(l_val_0, l_v7094);
	l_i_23 = l_v7094;
	l_len_0 = 0L;
	l_val_1 = l_v7094;
	goto block2;

    block2:
	while (1) {
		OP_UINT_IS_TRUE(l_i_23, l_v7095);
		if (!l_v7095) break;
		goto block32;
	  block2_back: ;
	}
	goto block3;

    block3:
	OP_INT_ADD(l_sign_0, l_len_0, l_v7096);
	OP_UINT_EQ(l_val_1, 0UL, l_v7097);
	OP_CAST_BOOL_TO_INT(l_v7097, l_v7098);
	OP_INT_ADD(l_v7096, l_v7098, l_length_42);
	OP_INT_GE(l_length_42, 0L, l_v7099);
	RPyAssert(l_v7099, "negative string length");
	OP_RAW_MALLOC_USAGE((0 + offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v7101);
	OP_INT_SUB(67583L, l_v7101, l_maxsize_4);
	OP_INT_LT(l_maxsize_4, 0L, l_v7102);
	if (l_v7102) {
		l_toobig_5 = 0UL;
		goto block5;
	}
	goto block4;

    block4:
	OP_RAW_MALLOC_USAGE(sizeof(char), l_v7103);
	OP_INT_IS_TRUE(l_v7103, l_v7104);
	if (l_v7104) {
		goto block31;
	}
	l_toobig_5 = 2147483648UL;
	goto block5;

    block5:
	OP_CAST_INT_TO_UINT(l_length_42, l_v7105);
	OP_UINT_GE(l_v7105, l_toobig_5, l_v7106);
	if (l_v7106) {
		goto block29;
	}
	goto block6;

    block6:
	OP_INT_MUL(sizeof(char), l_length_42, l_v7107);
	OP_INT_ADD((0 + offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v7107, l_v7088);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v7108);
	if (l_v7108) {
		goto block27;
	}
	goto block7;

    block7:
	l_v7109 = ROUND_UP_FOR_ALLOCATION(l_v7088, 0L);
	l_totalsize_20 = l_v7109;
	goto block8;

    block8:
	OP_RAW_MALLOC_USAGE(l_totalsize_20, l_v7110);
	OP_RAW_MALLOC_USAGE((sizeof(struct pypy_header0) + sizeof(void*)), l_v7111);
	OP_INT_GE(l_v7110, l_v7111, l_v7112);
	RPyAssert(l_v7112, "malloc_varsize_clear(): totalsize < minimalsize");
	l_v7091 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	OP_ADR_ADD(l_v7091, l_totalsize_20, l_v7114);
	(&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free = l_v7114;
	l_v7116 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	l_v7117 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_top;
	OP_ADR_GT(l_v7116, l_v7117, l_v7118);
	if (l_v7118) {
		goto block25;
	}
	l_v7090 = l_v7091;
	goto block9;

    block9:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v7119);
	if (l_v7119) {
		goto block23;
	}
	goto block10;

    block10:
	l_v7120 = (struct pypy_header0 *)l_v7090;
	RPyField(l_v7120, h_tid) = (GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+0L);
	OP_ADR_ADD(l_v7090, 0, l_v7122);
	OP_ADR_ADD(l_v7122, (offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, length)), l_v7123);
	((Signed *) (((char *)l_v7123) + 0))[0] = l_length_42;
	l_v7169 = l_v7122;
	goto block11;

    block11:
	l_v7125 = (void*)l_v7169;
	l_v7170 = l_v7125;
	goto block12;

    block12:
	l_v7089 = (struct pypy_rpy_string0 *)l_v7170;
	l_v7126 = (l_v7089 != NULL);
	if (!l_v7126) {
		goto block22;
	}
	goto block13;

    block13:
	OP_INT_IS_TRUE(MALLOC_ZERO_FILLED, l_v7127);
	if (l_v7127) {
		goto block15;
	}
	goto block14;

    block14:
	RPyField(l_v7089, rs_hash) = 0L;
	goto block15;

    block15:
	OP_INT_IS_TRUE(l_sign_0, l_v7129);
	if (l_v7129) {
		goto block21;
	}
	goto block16;

    block16:
	OP_UINT_EQ(l_val_1, 0UL, l_v7130);
	if (l_v7130) {
		goto block20;
	}
	l_val_2 = l_val_1;
	l_j_7 = 0L;
	goto block17;

    block17:
	while (1) {
		OP_INT_LT(l_j_7, l_len_0, l_v7131);
		if (!l_v7131) break;
		goto block19;
	  block17_back: ;
	}
	l_v7168 = l_v7089;
	goto block18;

    block18:
	RPY_DEBUG_RETURN();
	return l_v7168;

    block19:
	OP_UINT_MOD(l_val_2, 10UL, l_v7132);
	OP_UINT_ADD(l_v7132, 48UL, l_v7133);
	OP_CAST_UINT_TO_INT(l_v7133, l_v7134);
	OP_CAST_INT_TO_CHAR(l_v7134, l_v7135);
	OP_INT_SUB(l_length_42, l_j_7, l_v7136);
	OP_INT_SUB(l_v7136, 1L, l_v7137);
	RPyField(l_v7089, rs_chars).items[l_v7137] = l_v7135;
	OP_UINT_FLOORDIV(l_val_2, 10UL, l_v7139);
	OP_INT_ADD(l_j_7, 1L, l_v7140);
	l_val_2 = l_v7139;
	l_j_7 = l_v7140;
	goto block17_back;

    block20:
	RPyField(l_v7089, rs_chars).items[0L] = '0';
	l_val_2 = l_val_1;
	l_j_7 = 0L;
	goto block17;

    block21:
	RPyField(l_v7089, rs_chars).items[0L] = '-';
	l_val_2 = l_val_1;
	l_j_7 = 0L;
	goto block17;

    block22:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_int2dec__Signed");
	l_v7168 = ((struct pypy_rpy_string0 *) NULL);
	goto block18;

    block23:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v7145 = (&pypy_g_ExcData)->ed_exc_type;
	l_v7146 = (l_v7145 == NULL);
	if (!l_v7146) {
		goto block24;
	}
	goto block10;

    block24:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_int2dec__Signed");
	l_v7170 = NULL;
	goto block12;

    block25:
	l_v7148 = pypy_g_MiniMarkGC_collect_and_reserve((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_v7091, l_totalsize_20);
	l_v7149 = (&pypy_g_ExcData)->ed_exc_type;
	l_v7150 = (l_v7149 == NULL);
	if (!l_v7150) {
		goto block26;
	}
	l_v7090 = l_v7148;
	goto block9;

    block26:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_int2dec__Signed");
	l_v7170 = NULL;
	goto block12;

    block27:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v7152 = (Signed)0;
	l_v7153 = (&pypy_g_ExcData)->ed_exc_type;
	l_v7154 = (l_v7153 == NULL);
	if (!l_v7154) {
		goto block28;
	}
	l_totalsize_20 = l_v7152;
	goto block8;

    block28:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_int2dec__Signed");
	l_v7170 = NULL;
	goto block12;

    block29:
	l_v7156 = pypy_g_MiniMarkGC_external_malloc((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17), l_length_42, 1);
	l_v7157 = (&pypy_g_ExcData)->ed_exc_type;
	l_v7158 = (l_v7157 == NULL);
	if (!l_v7158) {
		goto block30;
	}
	l_v7169 = l_v7156;
	goto block11;

    block30:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_int2dec__Signed");
	l_v7170 = NULL;
	goto block12;

    block31:
	OP_RAW_MALLOC_USAGE(sizeof(char), l_v7160);
	OP_INT_FLOORDIV(l_maxsize_4, l_v7160, l_v7161);
	OP_CAST_INT_TO_UINT(l_v7161, l_v7162);
	OP_UINT_ADD(l_v7162, 1UL, l_v7163);
	l_toobig_5 = l_v7163;
	goto block5;

    block32:
	OP_INT_ADD(l_len_0, 1L, l_v7164);
	OP_UINT_FLOORDIV(l_i_23, 10UL, l_v7165);
	l_i_23 = l_v7165;
	l_len_0 = l_v7164;
	goto block2_back;

    block33:
	OP_INT_NEG(l_val_0, l_v7166);
	OP_CAST_INT_TO_UINT(l_v7166, l_v7167);
	l_i_23 = l_v7167;
	l_len_0 = 0L;
	l_val_1 = l_v7167;
	goto block2;
}
/*/*/
/***********************************************************/
