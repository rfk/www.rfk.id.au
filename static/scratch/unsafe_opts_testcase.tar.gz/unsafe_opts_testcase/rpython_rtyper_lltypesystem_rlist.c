/***********************************************************/
/***  Implementations                                    ***/

#define PYPY_FILE_NAME "rpython_rtyper_lltypesystem_rlist.c"
#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"
#include "src/g_include.h"

/*/*/
struct pypy_rpy_string0 *pypy_g_ll_getitem_fast__listPtr_Signed(struct pypy_list0 *l_l_12, Signed l_index_3) {
	Signed l_v8134; bool_t l_v8135; struct pypy_array3 *l_v8138;
	struct pypy_list0 *l_v8137; struct pypy_rpy_string0 *l_v8133;
	goto block0;

    block0:
	l_v8134 = RPyField(l_l_12, l_length);
	OP_INT_LT(l_index_3, l_v8134, l_v8135);
	RPyAssert(l_v8135, "getitem out of bounds");
	l_v8137 = l_l_12;
	l_v8138 = pypy_g_ll_items__listPtr(l_v8137);
	l_v8133 = RPyItem(l_v8138, l_index_3);
	goto block1;

    block1:
	RPY_DEBUG_RETURN();
	return l_v8133;
}
/*/*/
struct pypy_list0 *pypy_g_ll_newlist__GcStruct_listLlT_Signed(Signed l_length_47) {
	void* l_addr_struct_5; Signed l_maxsize_8; Signed l_rawtotalsize_4;
	void* l_result_23; void* l_result_24; Unsigned l_toobig_9;
	Signed l_totalsize_24; Signed l_v8141; Signed l_v8143;
	Signed l_v8149; Signed l_v8168; Signed l_v8170; Signed l_v8174;
	Signed l_v8176; Signed l_v8177; Signed l_v8178; Signed l_v8201;
	Signed l_v8202; Signed l_v8215; Signed l_v8223; Signed l_v8224;
	Unsigned l_v8172; Unsigned l_v8225; Unsigned l_v8226; bool_t l_v8146;
	bool_t l_v8148; bool_t l_v8150; bool_t l_v8155; bool_t l_v8156;
	bool_t l_v8161; bool_t l_v8169; bool_t l_v8171; bool_t l_v8173;
	bool_t l_v8175; bool_t l_v8179; bool_t l_v8185; bool_t l_v8186;
	bool_t l_v8198; bool_t l_v8203; bool_t l_v8209; bool_t l_v8213;
	bool_t l_v8217; bool_t l_v8221; bool_t l_v8230; bool_t l_v8234;
	bool_t l_v8239; struct pypy_array3 *l_v8139;
	struct pypy_header0 *l_v8158; struct pypy_header0 *l_v8187;
	struct pypy_header0 *l_v8200; struct pypy_list0 *l_v8140;
	struct pypy_list0 *l_v8241; struct pypy_object_vtable0 *l_v8208;
	struct pypy_object_vtable0 *l_v8212;
	struct pypy_object_vtable0 *l_v8216;
	struct pypy_object_vtable0 *l_v8220;
	struct pypy_object_vtable0 *l_v8229;
	struct pypy_object_vtable0 *l_v8233;
	struct pypy_object_vtable0 *l_v8238; void* l_v8142; void* l_v8144;
	void* l_v8145; void* l_v8151; void* l_v8153; void* l_v8154;
	void* l_v8157; void* l_v8160; void* l_v8163; void* l_v8164;
	void* l_v8166; void* l_v8181; void* l_v8183; void* l_v8184;
	void* l_v8189; void* l_v8190; void* l_v8192; void* l_v8193;
	void* l_v8194; void* l_v8196; void* l_v8199; void* l_v8211;
	void* l_v8219; void* l_v8232; void* l_v8237; void* l_v8242;
	void* l_v8243; void* l_v8244; void* l_v8245;
	goto block0;

    block0:
	OP_INT_GE(l_length_47, 0L, l_v8146);
	RPyAssert(l_v8146, "negative list length");
	OP_RAW_MALLOC_USAGE((0 + ROUND_UP_FOR_ALLOCATION(sizeof(struct pypy_list0), 0L)), l_rawtotalsize_4);
	OP_INT_GT(l_rawtotalsize_4, 67583L, l_v8148);
	if (l_v8148) {
		goto block36;
	}
	goto block1;

    block1:
	OP_RAW_MALLOC_USAGE((sizeof(struct pypy_header0) + sizeof(void*)), l_v8149);
	OP_INT_LT(l_rawtotalsize_4, l_v8149, l_v8150);
	if (l_v8150) {
		l_v8143 = l_v8149;
		goto block2;
	}
	l_v8143 = (0 + ROUND_UP_FOR_ALLOCATION(sizeof(struct pypy_list0), 0L));
	goto block2;

    block2:
	l_result_24 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	OP_ADR_ADD(l_result_24, l_v8143, l_v8151);
	(&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free = l_v8151;
	l_v8153 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	l_v8154 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_top;
	OP_ADR_GT(l_v8153, l_v8154, l_v8155);
	if (l_v8155) {
		goto block34;
	}
	l_result_23 = l_result_24;
	goto block3;

    block3:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v8156);
	if (l_v8156) {
		goto block32;
	}
	goto block4;

    block4:
	OP_ADR_ADD(l_result_23, 0, l_v8157);
	l_v8158 = (struct pypy_header0 *)l_result_23;
	RPyField(l_v8158, h_tid) = (GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member19)+0L);
	l_v8242 = l_v8157;
	goto block5;

    block5:
	l_v8160 = (void*)l_v8242;
	l_v8243 = l_v8160;
	goto block6;

    block6:
	l_v8140 = (struct pypy_list0 *)l_v8243;
	l_v8161 = (l_v8140 != NULL);
	if (!l_v8161) {
		goto block31;
	}
	goto block7;

    block7:
	RPyField(l_v8140, l_length) = l_length_47;
	l_v8163 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v8163, sizeof(void*), l_v8164);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v8164;
	l_v8166 = (void*)l_v8140;
	((void* *) (((char *)l_v8163) + 0))[0] = l_v8166;
	OP_RAW_MALLOC_USAGE((0 + offsetof(struct pypy_array3, items) + 0), l_v8168);
	OP_INT_SUB(67583L, l_v8168, l_maxsize_8);
	OP_INT_LT(l_maxsize_8, 0L, l_v8169);
	if (l_v8169) {
		l_toobig_9 = 0UL;
		goto block9;
	}
	goto block8;

    block8:
	OP_RAW_MALLOC_USAGE(sizeof(struct pypy_rpy_string0 *), l_v8170);
	OP_INT_IS_TRUE(l_v8170, l_v8171);
	if (l_v8171) {
		goto block30;
	}
	l_toobig_9 = 2147483648UL;
	goto block9;

    block9:
	OP_CAST_INT_TO_UINT(l_length_47, l_v8172);
	OP_UINT_GE(l_v8172, l_toobig_9, l_v8173);
	if (l_v8173) {
		goto block28;
	}
	goto block10;

    block10:
	OP_INT_MUL(sizeof(struct pypy_rpy_string0 *), l_length_47, l_v8174);
	OP_INT_ADD((0 + offsetof(struct pypy_array3, items) + 0), l_v8174, l_v8141);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v8175);
	if (l_v8175) {
		goto block26;
	}
	goto block11;

    block11:
	l_v8176 = ROUND_UP_FOR_ALLOCATION(l_v8141, 0L);
	l_totalsize_24 = l_v8176;
	goto block12;

    block12:
	OP_RAW_MALLOC_USAGE(l_totalsize_24, l_v8177);
	OP_RAW_MALLOC_USAGE((sizeof(struct pypy_header0) + sizeof(void*)), l_v8178);
	OP_INT_GE(l_v8177, l_v8178, l_v8179);
	RPyAssert(l_v8179, "malloc_varsize_clear(): totalsize < minimalsize");
	l_v8144 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	OP_ADR_ADD(l_v8144, l_totalsize_24, l_v8181);
	(&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free = l_v8181;
	l_v8183 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	l_v8184 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_top;
	OP_ADR_GT(l_v8183, l_v8184, l_v8185);
	if (l_v8185) {
		goto block24;
	}
	l_v8145 = l_v8144;
	goto block13;

    block13:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v8186);
	if (l_v8186) {
		goto block22;
	}
	goto block14;

    block14:
	l_v8187 = (struct pypy_header0 *)l_v8145;
	RPyField(l_v8187, h_tid) = (GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member20)+0L);
	OP_ADR_ADD(l_v8145, 0, l_v8189);
	OP_ADR_ADD(l_v8189, offsetof(struct pypy_array3, length), l_v8190);
	((Signed *) (((char *)l_v8190) + 0))[0] = l_length_47;
	l_v8244 = l_v8189;
	goto block15;

    block15:
	l_v8192 = (void*)l_v8244;
	l_v8245 = l_v8192;
	goto block16;

    block16:
	l_v8193 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v8193, sizeof(void*), l_v8194);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v8194;
	l_v8196 = ((void* *) (((char *)l_v8194) + 0))[0];
	l_v8140 = l_v8196; /* for moving GCs */
	l_v8139 = (struct pypy_array3 *)l_v8245;
	l_v8198 = (l_v8139 != NULL);
	if (!l_v8198) {
		goto block21;
	}
	goto block17;

    block17:
	l_v8142 = (void*)l_v8139;
	l_addr_struct_5 = (void*)l_v8140;
	OP_ADR_SUB(l_addr_struct_5, 0, l_v8199);
	l_v8200 = (struct pypy_header0 *)l_v8199;
	l_v8201 = RPyField(l_v8200, h_tid);
	OP_INT_AND(l_v8201, 65536L, l_v8202);
	OP_INT_IS_TRUE(l_v8202, l_v8203);
	if (l_v8203) {
		goto block20;
	}
	goto block18;

    block18:
	RPyField(l_v8140, l_items) = l_v8139;
	l_v8241 = l_v8140;
	goto block19;

    block19:
	RPY_DEBUG_RETURN();
	return l_v8241;

    block20:
	pypy_g_remember_young_pointer(l_addr_struct_5, l_v8142);
	goto block18;

    block21:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_newlist__GcStruct_listLlT_Signed");
	l_v8241 = ((struct pypy_list0 *) NULL);
	goto block19;

    block22:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v8208 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8209 = (l_v8208 == NULL);
	if (!l_v8209) {
		goto block23;
	}
	goto block14;

    block23:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_newlist__GcStruct_listLlT_Signed");
	l_v8245 = NULL;
	goto block16;

    block24:
	l_v8211 = pypy_g_MiniMarkGC_collect_and_reserve((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_v8144, l_totalsize_24);
	l_v8212 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8213 = (l_v8212 == NULL);
	if (!l_v8213) {
		goto block25;
	}
	l_v8145 = l_v8211;
	goto block13;

    block25:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_newlist__GcStruct_listLlT_Signed");
	l_v8245 = NULL;
	goto block16;

    block26:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v8215 = (Signed)0;
	l_v8216 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8217 = (l_v8216 == NULL);
	if (!l_v8217) {
		goto block27;
	}
	l_totalsize_24 = l_v8215;
	goto block12;

    block27:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_newlist__GcStruct_listLlT_Signed");
	l_v8245 = NULL;
	goto block16;

    block28:
	l_v8219 = pypy_g_MiniMarkGC_external_malloc((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member20), l_length_47, 1);
	l_v8220 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8221 = (l_v8220 == NULL);
	if (!l_v8221) {
		goto block29;
	}
	l_v8244 = l_v8219;
	goto block15;

    block29:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_newlist__GcStruct_listLlT_Signed");
	l_v8245 = NULL;
	goto block16;

    block30:
	OP_RAW_MALLOC_USAGE(sizeof(struct pypy_rpy_string0 *), l_v8223);
	OP_INT_FLOORDIV(l_maxsize_8, l_v8223, l_v8224);
	OP_CAST_INT_TO_UINT(l_v8224, l_v8225);
	OP_UINT_ADD(l_v8225, 1UL, l_v8226);
	l_toobig_9 = l_v8226;
	goto block9;

    block31:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_newlist__GcStruct_listLlT_Signed");
	l_v8241 = ((struct pypy_list0 *) NULL);
	goto block19;

    block32:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v8229 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8230 = (l_v8229 == NULL);
	if (!l_v8230) {
		goto block33;
	}
	goto block4;

    block33:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_newlist__GcStruct_listLlT_Signed");
	l_v8243 = NULL;
	goto block6;

    block34:
	l_v8232 = pypy_g_MiniMarkGC_collect_and_reserve((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_result_24, l_v8143);
	l_v8233 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8234 = (l_v8233 == NULL);
	if (!l_v8234) {
		goto block35;
	}
	l_result_23 = l_v8232;
	goto block3;

    block35:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_newlist__GcStruct_listLlT_Signed");
	l_v8243 = NULL;
	goto block6;

    block36:
	RPyAssert(1, "'contains_weakptr' specified for a large object");
	l_v8237 = pypy_g_MiniMarkGC_external_malloc((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member19), 0L, 1);
	l_v8238 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8239 = (l_v8238 == NULL);
	if (!l_v8239) {
		goto block37;
	}
	l_v8242 = l_v8237;
	goto block5;

    block37:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_newlist__GcStruct_listLlT_Signed");
	l_v8243 = NULL;
	goto block6;
}
/*/*/
Signed pypy_g_ll_length__listPtr(struct pypy_list0 *l_l_13) {
	Signed l_v8246;
	goto block0;

    block0:
	l_v8246 = RPyField(l_l_13, l_length);
	goto block1;

    block1:
	RPY_DEBUG_RETURN();
	return l_v8246;
}
/*/*/
void pypy_g_ll_setitem_fast__listPtr_Signed_rpy_stringPtr(struct pypy_list0 *l_l_16, Signed l_index_4, struct pypy_rpy_string0 *l_item_15) {
	void* l_addr_array_7; Signed l_v8249; Signed l_v8254; Signed l_v8255;
	bool_t l_v8250; bool_t l_v8256; struct pypy_array3 *l_v8248;
	struct pypy_header0 *l_v8253; void* l_v8247; void* l_v8252;
	goto block0;

    block0:
	l_v8249 = RPyField(l_l_16, l_length);
	OP_INT_LT(l_index_4, l_v8249, l_v8250);
	RPyAssert(l_v8250, "setitem out of bounds");
	l_v8248 = RPyField(l_l_16, l_items);
	l_v8247 = (void*)l_item_15;
	l_addr_array_7 = (void*)l_v8248;
	OP_ADR_SUB(l_addr_array_7, 0, l_v8252);
	l_v8253 = (struct pypy_header0 *)l_v8252;
	l_v8254 = RPyField(l_v8253, h_tid);
	OP_INT_AND(l_v8254, 65536L, l_v8255);
	OP_INT_IS_TRUE(l_v8255, l_v8256);
	if (l_v8256) {
		goto block3;
	}
	goto block1;

    block1:
	RPyItem(l_v8248, l_index_4) = l_item_15;
	goto block2;

    block2:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block3:
	pypy_g_remember_young_pointer_from_array2(l_addr_array_7, l_index_4);
	goto block1;
}
/*/*/
struct pypy_array3 *pypy_g_ll_items__listPtr(struct pypy_list0 *l_l_17) {
	struct pypy_array3 *l_v8260;
	goto block0;

    block0:
	l_v8260 = RPyField(l_l_17, l_items);
	goto block1;

    block1:
	RPY_DEBUG_RETURN();
	return l_v8260;
}
/*/*/
void pypy_g__ll_list_resize_hint_really__listPtr_Signed_Bool(struct pypy_list1 *l_l_22, Signed l_newsize_12, bool_t l_overallocate_0) {
	Signed l_length_48; Signed l_length_49; Signed l_maxsize_9;
	void* l_newvalue_6; Unsigned l_toobig_10; Signed l_totalsize_25;
	Signed l_v8266; Signed l_v8267; Signed l_v8276; Signed l_v8278;
	Signed l_v8282; Signed l_v8284; Signed l_v8285; Signed l_v8286;
	Signed l_v8312; Signed l_v8313; Signed l_v8325; Signed l_v8341;
	Signed l_v8349; Signed l_v8350; Signed l_v8354; Signed l_v8355;
	Signed l_v8356; Signed l_v8364; Unsigned l_v8280; Unsigned l_v8351;
	Unsigned l_v8352; bool_t l_v8268; bool_t l_v8277; bool_t l_v8279;
	bool_t l_v8281; bool_t l_v8283; bool_t l_v8287; bool_t l_v8293;
	bool_t l_v8294; bool_t l_v8308; bool_t l_v8309; bool_t l_v8314;
	bool_t l_v8317; bool_t l_v8318; bool_t l_v8329; bool_t l_v8335;
	bool_t l_v8339; bool_t l_v8343; bool_t l_v8347; bool_t l_v8353;
	bool_t l_v8357; char l_v8330; struct pypy_array6 *l_v8261;
	struct pypy_array6 *l_v8262; struct pypy_header0 *l_v8295;
	struct pypy_header0 *l_v8311; struct pypy_object_vtable0 *l_v8334;
	struct pypy_object_vtable0 *l_v8338;
	struct pypy_object_vtable0 *l_v8342;
	struct pypy_object_vtable0 *l_v8346; void* l_v8263; void* l_v8264;
	void* l_v8265; void* l_v8269; void* l_v8270; void* l_v8272;
	void* l_v8274; void* l_v8289; void* l_v8291; void* l_v8292;
	void* l_v8297; void* l_v8298; void* l_v8300; void* l_v8301;
	void* l_v8302; void* l_v8304; void* l_v8306; void* l_v8310;
	void* l_v8319; void* l_v8320; void* l_v8321; void* l_v8322;
	void* l_v8323; void* l_v8324; void* l_v8337; void* l_v8345;
	void* l_v8362; void* l_v8363;
	goto block0;

    block0:
	OP_INT_LE(l_newsize_12, 0L, l_v8268);
	if (l_v8268) {
		goto block34;
	}
	goto block1;

    block1:
	if (l_overallocate_0) {
		goto block32;
	}
	l_length_48 = l_newsize_12;
	goto block2;

    block2:
	l_v8261 = RPyField(l_l_22, l_items);
	l_v8269 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v8269, (sizeof(void*) * 2), l_v8270);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v8270;
	l_v8272 = (void*)l_l_22;
	((void* *) (((char *)l_v8269) + 0))[0] = l_v8272;
	l_v8274 = (void*)l_v8261;
	((void* *) (((char *)l_v8269) + sizeof(void*)))[0] = l_v8274;
	OP_RAW_MALLOC_USAGE((0 + offsetof(struct pypy_array6, items) + 0), l_v8276);
	OP_INT_SUB(67583L, l_v8276, l_maxsize_9);
	OP_INT_LT(l_maxsize_9, 0L, l_v8277);
	if (l_v8277) {
		l_toobig_10 = 0UL;
		goto block4;
	}
	goto block3;

    block3:
	OP_RAW_MALLOC_USAGE(sizeof(char), l_v8278);
	OP_INT_IS_TRUE(l_v8278, l_v8279);
	if (l_v8279) {
		goto block31;
	}
	l_toobig_10 = 2147483648UL;
	goto block4;

    block4:
	OP_CAST_INT_TO_UINT(l_length_48, l_v8280);
	OP_UINT_GE(l_v8280, l_toobig_10, l_v8281);
	if (l_v8281) {
		goto block29;
	}
	goto block5;

    block5:
	OP_INT_MUL(sizeof(char), l_length_48, l_v8282);
	OP_INT_ADD((0 + offsetof(struct pypy_array6, items) + 0), l_v8282, l_v8266);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v8283);
	if (l_v8283) {
		goto block27;
	}
	goto block6;

    block6:
	l_v8284 = ROUND_UP_FOR_ALLOCATION(l_v8266, 0L);
	l_totalsize_25 = l_v8284;
	goto block7;

    block7:
	OP_RAW_MALLOC_USAGE(l_totalsize_25, l_v8285);
	OP_RAW_MALLOC_USAGE((sizeof(struct pypy_header0) + sizeof(void*)), l_v8286);
	OP_INT_GE(l_v8285, l_v8286, l_v8287);
	RPyAssert(l_v8287, "malloc_varsize_clear(): totalsize < minimalsize");
	l_v8265 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	OP_ADR_ADD(l_v8265, l_totalsize_25, l_v8289);
	(&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free = l_v8289;
	l_v8291 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	l_v8292 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_top;
	OP_ADR_GT(l_v8291, l_v8292, l_v8293);
	if (l_v8293) {
		goto block25;
	}
	l_v8263 = l_v8265;
	goto block8;

    block8:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v8294);
	if (l_v8294) {
		goto block23;
	}
	goto block9;

    block9:
	l_v8295 = (struct pypy_header0 *)l_v8263;
	RPyField(l_v8295, h_tid) = (GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member25)+0L);
	OP_ADR_ADD(l_v8263, 0, l_v8297);
	OP_ADR_ADD(l_v8297, offsetof(struct pypy_array6, length), l_v8298);
	((Signed *) (((char *)l_v8298) + 0))[0] = l_length_48;
	l_v8362 = l_v8297;
	goto block10;

    block10:
	l_v8300 = (void*)l_v8362;
	l_v8363 = l_v8300;
	goto block11;

    block11:
	l_v8301 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v8301, (sizeof(void*) * 2), l_v8302);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v8302;
	l_v8304 = ((void* *) (((char *)l_v8302) + 0))[0];
	l_l_22 = l_v8304; /* for moving GCs */
	l_v8306 = ((void* *) (((char *)l_v8302) + sizeof(void*)))[0];
	l_v8261 = l_v8306; /* for moving GCs */
	l_v8262 = (struct pypy_array6 *)l_v8363;
	l_v8308 = (l_v8262 != NULL);
	if (!l_v8308) {
		goto block22;
	}
	goto block12;

    block12:
	l_v8267 = RPyField(l_l_22, l_length);
	OP_INT_IS_TRUE(l_v8267, l_v8309);
	if (l_v8309) {
		goto block17;
	}
	goto block13;

    block13:
	l_newvalue_6 = (void*)l_v8262;
	l_v8264 = (void*)l_l_22;
	OP_ADR_SUB(l_v8264, 0, l_v8310);
	l_v8311 = (struct pypy_header0 *)l_v8310;
	l_v8312 = RPyField(l_v8311, h_tid);
	OP_INT_AND(l_v8312, 65536L, l_v8313);
	OP_INT_IS_TRUE(l_v8313, l_v8314);
	if (l_v8314) {
		goto block16;
	}
	goto block14;

    block14:
	RPyField(l_l_22, l_items) = l_v8262;
	goto block15;

    block15:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block16:
	pypy_g_remember_young_pointer(l_v8264, l_newvalue_6);
	goto block14;

    block17:
	OP_INT_LT(l_v8267, l_newsize_12, l_v8317);
	if (l_v8317) {
		l_length_49 = l_v8267;
		goto block18;
	}
	l_length_49 = l_newsize_12;
	goto block18;

    block18:
	OP_INT_LE(l_length_49, 1L, l_v8318);
	if (l_v8318) {
		goto block20;
	}
	goto block19;

    block19:
	l_v8319 = (void*)l_v8261;
	l_v8320 = (void*)l_v8262;
	OP_ADR_ADD(l_v8319, offsetof(struct pypy_array6, items), l_v8321);
	OP_ADR_ADD(l_v8321, 0, l_v8322);
	OP_ADR_ADD(l_v8320, offsetof(struct pypy_array6, items), l_v8323);
	OP_ADR_ADD(l_v8323, 0, l_v8324);
	OP_INT_MUL(sizeof(char), l_length_49, l_v8325);
	OP_RAW_MEMCOPY(l_v8322, l_v8324, l_v8325, /* nothing */);
	/* kept alive: l_v8261 */
	/* kept alive: l_v8262 */
	goto block13;

    block20:
	OP_INT_EQ(l_length_49, 1L, l_v8329);
	if (l_v8329) {
		goto block21;
	}
	goto block13;

    block21:
	l_v8330 = RPyItem(l_v8261, 0L);
	RPyItem(l_v8262, 0L) = l_v8330;
	goto block13;

    block22:
	PYPY_DEBUG_RECORD_TRACEBACK("_ll_list_resize_hint_really__listPtr_Signed_Bool");
	goto block15;

    block23:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v8334 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8335 = (l_v8334 == NULL);
	if (!l_v8335) {
		goto block24;
	}
	goto block9;

    block24:
	PYPY_DEBUG_RECORD_TRACEBACK("_ll_list_resize_hint_really__listPtr_Signed_Bool");
	l_v8363 = NULL;
	goto block11;

    block25:
	l_v8337 = pypy_g_MiniMarkGC_collect_and_reserve((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_v8265, l_totalsize_25);
	l_v8338 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8339 = (l_v8338 == NULL);
	if (!l_v8339) {
		goto block26;
	}
	l_v8263 = l_v8337;
	goto block8;

    block26:
	PYPY_DEBUG_RECORD_TRACEBACK("_ll_list_resize_hint_really__listPtr_Signed_Bool");
	l_v8363 = NULL;
	goto block11;

    block27:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v8341 = (Signed)0;
	l_v8342 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8343 = (l_v8342 == NULL);
	if (!l_v8343) {
		goto block28;
	}
	l_totalsize_25 = l_v8341;
	goto block7;

    block28:
	PYPY_DEBUG_RECORD_TRACEBACK("_ll_list_resize_hint_really__listPtr_Signed_Bool");
	l_v8363 = NULL;
	goto block11;

    block29:
	l_v8345 = pypy_g_MiniMarkGC_external_malloc((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member25), l_length_48, 1);
	l_v8346 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8347 = (l_v8346 == NULL);
	if (!l_v8347) {
		goto block30;
	}
	l_v8362 = l_v8345;
	goto block10;

    block30:
	PYPY_DEBUG_RECORD_TRACEBACK("_ll_list_resize_hint_really__listPtr_Signed_Bool");
	l_v8363 = NULL;
	goto block11;

    block31:
	OP_RAW_MALLOC_USAGE(sizeof(char), l_v8349);
	OP_INT_FLOORDIV(l_maxsize_9, l_v8349, l_v8350);
	OP_CAST_INT_TO_UINT(l_v8350, l_v8351);
	OP_UINT_ADD(l_v8351, 1UL, l_v8352);
	l_toobig_10 = l_v8352;
	goto block4;

    block32:
	OP_INT_LT(l_newsize_12, 9L, l_v8353);
	if (l_v8353) {
		l_v8364 = 3L;
		goto block33;
	}
	l_v8364 = 6L;
	goto block33;

    block33:
	OP_INT_RSHIFT(l_newsize_12, 3L, l_v8354);
	OP_INT_ADD(l_v8364, l_v8354, l_v8355);
	OP_INT_ADD(l_newsize_12, l_v8355, l_v8356);
	l_length_48 = l_v8356;
	goto block2;

    block34:
	OP_INT_EQ(l_newsize_12, 0L, l_v8357);
	RPyAssert(l_v8357, "negative list length");
	RPyField(l_l_22, l_length) = 0L;
	RPyField(l_l_22, l_items) = (&pypy_g_array_34.b);
	goto block15;
}
/*/*/
void pypy_g__ll_list_resize_hint_really__listPtr_Signed_Bool_1(struct pypy_list0 *l_l_23, Signed l_newsize_13, bool_t l_v8368) {
	void* l_addr_struct_6; Signed l_length_50; Signed l_maxsize_10;
	Signed l_new_allocated_0; struct pypy_array3 *l_newitems_0;
	void* l_newvalue_7; Unsigned l_toobig_11; Signed l_totalsize_26;
	Signed l_v8367; Signed l_v8369; Signed l_v8379; Signed l_v8381;
	Signed l_v8385; Signed l_v8387; Signed l_v8388; Signed l_v8389;
	Signed l_v8415; Signed l_v8416; Signed l_v8431; Signed l_v8439;
	Signed l_v8440; Signed l_v8444; Signed l_v8445; Signed l_v8446;
	Signed l_v8454; Unsigned l_v8383; Unsigned l_v8441; Unsigned l_v8442;
	bool_t l_v8371; bool_t l_v8380; bool_t l_v8382; bool_t l_v8384;
	bool_t l_v8386; bool_t l_v8390; bool_t l_v8396; bool_t l_v8397;
	bool_t l_v8411; bool_t l_v8412; bool_t l_v8417; bool_t l_v8420;
	bool_t l_v8425; bool_t l_v8429; bool_t l_v8433; bool_t l_v8437;
	bool_t l_v8443; bool_t l_v8447; struct pypy_array3 *l_v8365;
	struct pypy_header0 *l_v8398; struct pypy_header0 *l_v8414;
	struct pypy_object_vtable0 *l_v8424;
	struct pypy_object_vtable0 *l_v8428;
	struct pypy_object_vtable0 *l_v8432;
	struct pypy_object_vtable0 *l_v8436; void* l_v8366; void* l_v8370;
	void* l_v8372; void* l_v8373; void* l_v8375; void* l_v8377;
	void* l_v8392; void* l_v8394; void* l_v8395; void* l_v8400;
	void* l_v8401; void* l_v8403; void* l_v8404; void* l_v8405;
	void* l_v8407; void* l_v8409; void* l_v8413; void* l_v8427;
	void* l_v8435; void* l_v8452; void* l_v8453;
	goto block0;

    block0:
	OP_INT_LE(l_newsize_13, 0L, l_v8371);
	if (l_v8371) {
		goto block31;
	}
	goto block1;

    block1:
	if (l_v8368) {
		goto block29;
	}
	l_new_allocated_0 = l_newsize_13;
	goto block2;

    block2:
	l_v8365 = RPyField(l_l_23, l_items);
	l_v8372 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v8372, (sizeof(void*) * 2), l_v8373);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v8373;
	l_v8375 = (void*)l_l_23;
	((void* *) (((char *)l_v8372) + 0))[0] = l_v8375;
	l_v8377 = (void*)l_v8365;
	((void* *) (((char *)l_v8372) + sizeof(void*)))[0] = l_v8377;
	OP_RAW_MALLOC_USAGE((0 + offsetof(struct pypy_array3, items) + 0), l_v8379);
	OP_INT_SUB(67583L, l_v8379, l_maxsize_10);
	OP_INT_LT(l_maxsize_10, 0L, l_v8380);
	if (l_v8380) {
		l_toobig_11 = 0UL;
		goto block4;
	}
	goto block3;

    block3:
	OP_RAW_MALLOC_USAGE(sizeof(struct pypy_rpy_string0 *), l_v8381);
	OP_INT_IS_TRUE(l_v8381, l_v8382);
	if (l_v8382) {
		goto block28;
	}
	l_toobig_11 = 2147483648UL;
	goto block4;

    block4:
	OP_CAST_INT_TO_UINT(l_new_allocated_0, l_v8383);
	OP_UINT_GE(l_v8383, l_toobig_11, l_v8384);
	if (l_v8384) {
		goto block26;
	}
	goto block5;

    block5:
	OP_INT_MUL(sizeof(struct pypy_rpy_string0 *), l_new_allocated_0, l_v8385);
	OP_INT_ADD((0 + offsetof(struct pypy_array3, items) + 0), l_v8385, l_v8369);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v8386);
	if (l_v8386) {
		goto block24;
	}
	goto block6;

    block6:
	l_v8387 = ROUND_UP_FOR_ALLOCATION(l_v8369, 0L);
	l_totalsize_26 = l_v8387;
	goto block7;

    block7:
	OP_RAW_MALLOC_USAGE(l_totalsize_26, l_v8388);
	OP_RAW_MALLOC_USAGE((sizeof(struct pypy_header0) + sizeof(void*)), l_v8389);
	OP_INT_GE(l_v8388, l_v8389, l_v8390);
	RPyAssert(l_v8390, "malloc_varsize_clear(): totalsize < minimalsize");
	l_v8370 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	OP_ADR_ADD(l_v8370, l_totalsize_26, l_v8392);
	(&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free = l_v8392;
	l_v8394 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	l_v8395 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_top;
	OP_ADR_GT(l_v8394, l_v8395, l_v8396);
	if (l_v8396) {
		goto block22;
	}
	l_v8366 = l_v8370;
	goto block8;

    block8:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v8397);
	if (l_v8397) {
		goto block20;
	}
	goto block9;

    block9:
	l_v8398 = (struct pypy_header0 *)l_v8366;
	RPyField(l_v8398, h_tid) = (GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member20)+0L);
	OP_ADR_ADD(l_v8366, 0, l_v8400);
	OP_ADR_ADD(l_v8400, offsetof(struct pypy_array3, length), l_v8401);
	((Signed *) (((char *)l_v8401) + 0))[0] = l_new_allocated_0;
	l_v8452 = l_v8400;
	goto block10;

    block10:
	l_v8403 = (void*)l_v8452;
	l_v8453 = l_v8403;
	goto block11;

    block11:
	l_v8404 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v8404, (sizeof(void*) * 2), l_v8405);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v8405;
	l_v8407 = ((void* *) (((char *)l_v8405) + 0))[0];
	l_l_23 = l_v8407; /* for moving GCs */
	l_v8409 = ((void* *) (((char *)l_v8405) + sizeof(void*)))[0];
	l_v8365 = l_v8409; /* for moving GCs */
	l_newitems_0 = (struct pypy_array3 *)l_v8453;
	l_v8411 = (l_newitems_0 != NULL);
	if (!l_v8411) {
		goto block19;
	}
	goto block12;

    block12:
	l_v8367 = RPyField(l_l_23, l_length);
	OP_INT_IS_TRUE(l_v8367, l_v8412);
	if (l_v8412) {
		goto block17;
	}
	goto block13;

    block13:
	l_newvalue_7 = (void*)l_newitems_0;
	l_addr_struct_6 = (void*)l_l_23;
	OP_ADR_SUB(l_addr_struct_6, 0, l_v8413);
	l_v8414 = (struct pypy_header0 *)l_v8413;
	l_v8415 = RPyField(l_v8414, h_tid);
	OP_INT_AND(l_v8415, 65536L, l_v8416);
	OP_INT_IS_TRUE(l_v8416, l_v8417);
	if (l_v8417) {
		goto block16;
	}
	goto block14;

    block14:
	RPyField(l_l_23, l_items) = l_newitems_0;
	goto block15;

    block15:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block16:
	pypy_g_remember_young_pointer(l_addr_struct_6, l_newvalue_7);
	goto block14;

    block17:
	OP_INT_LT(l_v8367, l_newsize_13, l_v8420);
	if (l_v8420) {
		l_length_50 = l_v8367;
		goto block18;
	}
	l_length_50 = l_newsize_13;
	goto block18;

    block18:
	pypy_g_ll_arraycopy__arrayPtr_arrayPtr_Signed_Signed_Si(l_v8365, l_newitems_0, 0L, 0L, l_length_50);
	goto block13;

    block19:
	PYPY_DEBUG_RECORD_TRACEBACK("_ll_list_resize_hint_really__listPtr_Signed_Bool_1");
	goto block15;

    block20:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v8424 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8425 = (l_v8424 == NULL);
	if (!l_v8425) {
		goto block21;
	}
	goto block9;

    block21:
	PYPY_DEBUG_RECORD_TRACEBACK("_ll_list_resize_hint_really__listPtr_Signed_Bool_1");
	l_v8453 = NULL;
	goto block11;

    block22:
	l_v8427 = pypy_g_MiniMarkGC_collect_and_reserve((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_v8370, l_totalsize_26);
	l_v8428 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8429 = (l_v8428 == NULL);
	if (!l_v8429) {
		goto block23;
	}
	l_v8366 = l_v8427;
	goto block8;

    block23:
	PYPY_DEBUG_RECORD_TRACEBACK("_ll_list_resize_hint_really__listPtr_Signed_Bool_1");
	l_v8453 = NULL;
	goto block11;

    block24:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v8431 = (Signed)0;
	l_v8432 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8433 = (l_v8432 == NULL);
	if (!l_v8433) {
		goto block25;
	}
	l_totalsize_26 = l_v8431;
	goto block7;

    block25:
	PYPY_DEBUG_RECORD_TRACEBACK("_ll_list_resize_hint_really__listPtr_Signed_Bool_1");
	l_v8453 = NULL;
	goto block11;

    block26:
	l_v8435 = pypy_g_MiniMarkGC_external_malloc((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member20), l_new_allocated_0, 1);
	l_v8436 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8437 = (l_v8436 == NULL);
	if (!l_v8437) {
		goto block27;
	}
	l_v8452 = l_v8435;
	goto block10;

    block27:
	PYPY_DEBUG_RECORD_TRACEBACK("_ll_list_resize_hint_really__listPtr_Signed_Bool_1");
	l_v8453 = NULL;
	goto block11;

    block28:
	OP_RAW_MALLOC_USAGE(sizeof(struct pypy_rpy_string0 *), l_v8439);
	OP_INT_FLOORDIV(l_maxsize_10, l_v8439, l_v8440);
	OP_CAST_INT_TO_UINT(l_v8440, l_v8441);
	OP_UINT_ADD(l_v8441, 1UL, l_v8442);
	l_toobig_11 = l_v8442;
	goto block4;

    block29:
	OP_INT_LT(l_newsize_13, 9L, l_v8443);
	if (l_v8443) {
		l_v8454 = 3L;
		goto block30;
	}
	l_v8454 = 6L;
	goto block30;

    block30:
	OP_INT_RSHIFT(l_newsize_13, 3L, l_v8444);
	OP_INT_ADD(l_v8454, l_v8444, l_v8445);
	OP_INT_ADD(l_newsize_13, l_v8445, l_v8446);
	l_new_allocated_0 = l_v8446;
	goto block2;

    block31:
	OP_INT_EQ(l_newsize_13, 0L, l_v8447);
	RPyAssert(l_v8447, "negative list length");
	RPyField(l_l_23, l_length) = 0L;
	RPyField(l_l_23, l_items) = (&pypy_g_array_30.b);
	goto block15;
}
/*/*/
/***********************************************************/
