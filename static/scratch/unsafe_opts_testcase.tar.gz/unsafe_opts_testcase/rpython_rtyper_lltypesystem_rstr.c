/***********************************************************/
/***  Implementations                                    ***/

#define PYPY_FILE_NAME "rpython_rtyper_lltypesystem_rstr.c"
#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"
#include "src/g_include.h"

/*/*/
struct pypy_rpy_string0 *pypy_g_mallocstr__Signed(Signed l_length_51) {
	Signed l_maxsize_11; Unsigned l_toobig_12; Signed l_totalsize_27;
	Signed l_v8456; Signed l_v8461; Signed l_v8463; Signed l_v8467;
	Signed l_v8469; Signed l_v8470; Signed l_v8471; Signed l_v8498;
	Signed l_v8506; Signed l_v8507; Unsigned l_v8465; Unsigned l_v8508;
	Unsigned l_v8509; bool_t l_v8459; bool_t l_v8462; bool_t l_v8464;
	bool_t l_v8466; bool_t l_v8468; bool_t l_v8472; bool_t l_v8478;
	bool_t l_v8479; bool_t l_v8486; bool_t l_v8487; bool_t l_v8492;
	bool_t l_v8496; bool_t l_v8500; bool_t l_v8504;
	struct pypy_header0 *l_v8480; struct pypy_object_vtable0 *l_v8491;
	struct pypy_object_vtable0 *l_v8495;
	struct pypy_object_vtable0 *l_v8499;
	struct pypy_object_vtable0 *l_v8503;
	struct pypy_rpy_string0 *l_v8458; struct pypy_rpy_string0 *l_v8510;
	void* l_v8455; void* l_v8457; void* l_v8474; void* l_v8476;
	void* l_v8477; void* l_v8482; void* l_v8483; void* l_v8485;
	void* l_v8494; void* l_v8502; void* l_v8511; void* l_v8512;
	goto block0;

    block0:
	OP_INT_GE(l_length_51, 0L, l_v8459);
	RPyAssert(l_v8459, "negative string length");
	OP_RAW_MALLOC_USAGE((0 + offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v8461);
	OP_INT_SUB(67583L, l_v8461, l_maxsize_11);
	OP_INT_LT(l_maxsize_11, 0L, l_v8462);
	if (l_v8462) {
		l_toobig_12 = 0UL;
		goto block2;
	}
	goto block1;

    block1:
	OP_RAW_MALLOC_USAGE(sizeof(char), l_v8463);
	OP_INT_IS_TRUE(l_v8463, l_v8464);
	if (l_v8464) {
		goto block22;
	}
	l_toobig_12 = 2147483648UL;
	goto block2;

    block2:
	OP_CAST_INT_TO_UINT(l_length_51, l_v8465);
	OP_UINT_GE(l_v8465, l_toobig_12, l_v8466);
	if (l_v8466) {
		goto block20;
	}
	goto block3;

    block3:
	OP_INT_MUL(sizeof(char), l_length_51, l_v8467);
	OP_INT_ADD((0 + offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v8467, l_v8456);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v8468);
	if (l_v8468) {
		goto block18;
	}
	goto block4;

    block4:
	l_v8469 = ROUND_UP_FOR_ALLOCATION(l_v8456, 0L);
	l_totalsize_27 = l_v8469;
	goto block5;

    block5:
	OP_RAW_MALLOC_USAGE(l_totalsize_27, l_v8470);
	OP_RAW_MALLOC_USAGE((sizeof(struct pypy_header0) + sizeof(void*)), l_v8471);
	OP_INT_GE(l_v8470, l_v8471, l_v8472);
	RPyAssert(l_v8472, "malloc_varsize_clear(): totalsize < minimalsize");
	l_v8457 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	OP_ADR_ADD(l_v8457, l_totalsize_27, l_v8474);
	(&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free = l_v8474;
	l_v8476 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	l_v8477 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_top;
	OP_ADR_GT(l_v8476, l_v8477, l_v8478);
	if (l_v8478) {
		goto block16;
	}
	l_v8455 = l_v8457;
	goto block6;

    block6:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v8479);
	if (l_v8479) {
		goto block14;
	}
	goto block7;

    block7:
	l_v8480 = (struct pypy_header0 *)l_v8455;
	RPyField(l_v8480, h_tid) = (GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+0L);
	OP_ADR_ADD(l_v8455, 0, l_v8482);
	OP_ADR_ADD(l_v8482, (offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, length)), l_v8483);
	((Signed *) (((char *)l_v8483) + 0))[0] = l_length_51;
	l_v8511 = l_v8482;
	goto block8;

    block8:
	l_v8485 = (void*)l_v8511;
	l_v8512 = l_v8485;
	goto block9;

    block9:
	l_v8458 = (struct pypy_rpy_string0 *)l_v8512;
	l_v8486 = (l_v8458 != NULL);
	if (!l_v8486) {
		goto block13;
	}
	goto block10;

    block10:
	OP_INT_IS_TRUE(MALLOC_ZERO_FILLED, l_v8487);
	if (l_v8487) {
		l_v8510 = l_v8458;
		goto block12;
	}
	goto block11;

    block11:
	RPyField(l_v8458, rs_hash) = 0L;
	l_v8510 = l_v8458;
	goto block12;

    block12:
	RPY_DEBUG_RETURN();
	return l_v8510;

    block13:
	PYPY_DEBUG_RECORD_TRACEBACK("mallocstr__Signed");
	l_v8510 = ((struct pypy_rpy_string0 *) NULL);
	goto block12;

    block14:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v8491 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8492 = (l_v8491 == NULL);
	if (!l_v8492) {
		goto block15;
	}
	goto block7;

    block15:
	PYPY_DEBUG_RECORD_TRACEBACK("mallocstr__Signed");
	l_v8512 = NULL;
	goto block9;

    block16:
	l_v8494 = pypy_g_MiniMarkGC_collect_and_reserve((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_v8457, l_totalsize_27);
	l_v8495 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8496 = (l_v8495 == NULL);
	if (!l_v8496) {
		goto block17;
	}
	l_v8455 = l_v8494;
	goto block6;

    block17:
	PYPY_DEBUG_RECORD_TRACEBACK("mallocstr__Signed");
	l_v8512 = NULL;
	goto block9;

    block18:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v8498 = (Signed)0;
	l_v8499 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8500 = (l_v8499 == NULL);
	if (!l_v8500) {
		goto block19;
	}
	l_totalsize_27 = l_v8498;
	goto block5;

    block19:
	PYPY_DEBUG_RECORD_TRACEBACK("mallocstr__Signed");
	l_v8512 = NULL;
	goto block9;

    block20:
	l_v8502 = pypy_g_MiniMarkGC_external_malloc((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17), l_length_51, 1);
	l_v8503 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8504 = (l_v8503 == NULL);
	if (!l_v8504) {
		goto block21;
	}
	l_v8511 = l_v8502;
	goto block8;

    block21:
	PYPY_DEBUG_RECORD_TRACEBACK("mallocstr__Signed");
	l_v8512 = NULL;
	goto block9;

    block22:
	OP_RAW_MALLOC_USAGE(sizeof(char), l_v8506);
	OP_INT_FLOORDIV(l_maxsize_11, l_v8506, l_v8507);
	OP_CAST_INT_TO_UINT(l_v8507, l_v8508);
	OP_UINT_ADD(l_v8508, 1UL, l_v8509);
	l_toobig_12 = l_v8509;
	goto block2;
}
/*/*/
struct pypy_rpy_string0 *pypy_g__ll_stringslice__rpy_stringPtr_Signed_Signed(struct pypy_rpy_string0 *l_s1_8, Signed l_start_14, Signed l_stop_0) {
	Signed l_length_52; Signed l_maxsize_12; Unsigned l_toobig_13;
	Signed l_totalsize_28; Signed l_v8514; Signed l_v8528;
	Signed l_v8530; Signed l_v8534; Signed l_v8536; Signed l_v8537;
	Signed l_v8538; Signed l_v8568; Signed l_v8569; Signed l_v8573;
	Signed l_v8586; Signed l_v8594; Signed l_v8595; Unsigned l_v8532;
	Unsigned l_v8596; Unsigned l_v8597; bool_t l_v8517; bool_t l_v8520;
	bool_t l_v8521; bool_t l_v8529; bool_t l_v8531; bool_t l_v8533;
	bool_t l_v8535; bool_t l_v8539; bool_t l_v8545; bool_t l_v8546;
	bool_t l_v8558; bool_t l_v8559; bool_t l_v8561; bool_t l_v8564;
	bool_t l_v8580; bool_t l_v8584; bool_t l_v8588; bool_t l_v8592;
	struct pypy_header0 *l_v8547; struct pypy_object_vtable0 *l_v8579;
	struct pypy_object_vtable0 *l_v8583;
	struct pypy_object_vtable0 *l_v8587;
	struct pypy_object_vtable0 *l_v8591;
	struct pypy_rpy_string0 *l_v8513; struct pypy_rpy_string0 *l_v8598;
	void* l_v8515; void* l_v8516; void* l_v8523; void* l_v8524;
	void* l_v8526; void* l_v8541; void* l_v8543; void* l_v8544;
	void* l_v8549; void* l_v8550; void* l_v8552; void* l_v8553;
	void* l_v8554; void* l_v8556; void* l_v8567; void* l_v8570;
	void* l_v8571; void* l_v8572; void* l_v8582; void* l_v8590;
	void* l_v8599; void* l_v8600;
	goto block0;

    block0:
	OP_INT_SUB(l_stop_0, l_start_14, l_length_52);
	OP_INT_GE(l_start_14, 0L, l_v8517);
	if (l_v8517) {
		goto block3;
	}
	goto block1;

    block1:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("_ll_stringslice__rpy_stringPtr_Signed_Signed");
	l_v8598 = ((struct pypy_rpy_string0 *) NULL);
	goto block2;

    block2:
	RPY_DEBUG_RETURN();
	return l_v8598;

    block3:
	OP_INT_LT(l_length_52, 0L, l_v8520);
	if (l_v8520) {
		l_v8598 = (&pypy_g_rpy_string_35.b);
		goto block2;
	}
	goto block4;

    block4:
	OP_INT_GE(l_length_52, 0L, l_v8521);
	RPyAssert(l_v8521, "negative string length");
	l_v8523 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v8523, sizeof(void*), l_v8524);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v8524;
	l_v8526 = (void*)l_s1_8;
	((void* *) (((char *)l_v8523) + 0))[0] = l_v8526;
	OP_RAW_MALLOC_USAGE((0 + offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v8528);
	OP_INT_SUB(67583L, l_v8528, l_maxsize_12);
	OP_INT_LT(l_maxsize_12, 0L, l_v8529);
	if (l_v8529) {
		l_toobig_13 = 0UL;
		goto block6;
	}
	goto block5;

    block5:
	OP_RAW_MALLOC_USAGE(sizeof(char), l_v8530);
	OP_INT_IS_TRUE(l_v8530, l_v8531);
	if (l_v8531) {
		goto block30;
	}
	l_toobig_13 = 2147483648UL;
	goto block6;

    block6:
	OP_CAST_INT_TO_UINT(l_length_52, l_v8532);
	OP_UINT_GE(l_v8532, l_toobig_13, l_v8533);
	if (l_v8533) {
		goto block28;
	}
	goto block7;

    block7:
	OP_INT_MUL(sizeof(char), l_length_52, l_v8534);
	OP_INT_ADD((0 + offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v8534, l_v8514);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v8535);
	if (l_v8535) {
		goto block26;
	}
	goto block8;

    block8:
	l_v8536 = ROUND_UP_FOR_ALLOCATION(l_v8514, 0L);
	l_totalsize_28 = l_v8536;
	goto block9;

    block9:
	OP_RAW_MALLOC_USAGE(l_totalsize_28, l_v8537);
	OP_RAW_MALLOC_USAGE((sizeof(struct pypy_header0) + sizeof(void*)), l_v8538);
	OP_INT_GE(l_v8537, l_v8538, l_v8539);
	RPyAssert(l_v8539, "malloc_varsize_clear(): totalsize < minimalsize");
	l_v8516 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	OP_ADR_ADD(l_v8516, l_totalsize_28, l_v8541);
	(&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free = l_v8541;
	l_v8543 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	l_v8544 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_top;
	OP_ADR_GT(l_v8543, l_v8544, l_v8545);
	if (l_v8545) {
		goto block24;
	}
	l_v8515 = l_v8516;
	goto block10;

    block10:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v8546);
	if (l_v8546) {
		goto block22;
	}
	goto block11;

    block11:
	l_v8547 = (struct pypy_header0 *)l_v8515;
	RPyField(l_v8547, h_tid) = (GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+0L);
	OP_ADR_ADD(l_v8515, 0, l_v8549);
	OP_ADR_ADD(l_v8549, (offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, length)), l_v8550);
	((Signed *) (((char *)l_v8550) + 0))[0] = l_length_52;
	l_v8599 = l_v8549;
	goto block12;

    block12:
	l_v8552 = (void*)l_v8599;
	l_v8600 = l_v8552;
	goto block13;

    block13:
	l_v8553 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v8553, sizeof(void*), l_v8554);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v8554;
	l_v8556 = ((void* *) (((char *)l_v8554) + 0))[0];
	l_s1_8 = l_v8556; /* for moving GCs */
	l_v8513 = (struct pypy_rpy_string0 *)l_v8600;
	l_v8558 = (l_v8513 != NULL);
	if (!l_v8558) {
		goto block21;
	}
	goto block14;

    block14:
	OP_INT_IS_TRUE(MALLOC_ZERO_FILLED, l_v8559);
	if (l_v8559) {
		goto block16;
	}
	goto block15;

    block15:
	RPyField(l_v8513, rs_hash) = 0L;
	goto block16;

    block16:
	OP_INT_GE(l_length_52, 0L, l_v8561);
	if (l_v8561) {
		goto block18;
	}
	goto block17;

    block17:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("_ll_stringslice__rpy_stringPtr_Signed_Signed");
	l_v8598 = ((struct pypy_rpy_string0 *) NULL);
	goto block2;

    block18:
	OP_INT_GE(l_start_14, 0L, l_v8564);
	if (l_v8564) {
		goto block20;
	}
	goto block19;

    block19:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("_ll_stringslice__rpy_stringPtr_Signed_Signed");
	l_v8598 = ((struct pypy_rpy_string0 *) NULL);
	goto block2;

    block20:
	l_v8567 = (void*)l_s1_8;
	OP_INT_MUL(sizeof(char), l_start_14, l_v8568);
	OP_INT_ADD((offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items)), l_v8568, l_v8569);
	OP_ADR_ADD(l_v8567, l_v8569, l_v8570);
	l_v8571 = (void*)l_v8513;
	OP_ADR_ADD(l_v8571, (offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v8572);
	OP_INT_MUL(sizeof(char), l_length_52, l_v8573);
	OP_RAW_MEMCOPY(l_v8570, l_v8572, l_v8573, /* nothing */);
	/* kept alive: l_v8570 */
	/* kept alive: l_v8572 */
	l_v8598 = l_v8513;
	goto block2;

    block21:
	PYPY_DEBUG_RECORD_TRACEBACK("_ll_stringslice__rpy_stringPtr_Signed_Signed");
	l_v8598 = ((struct pypy_rpy_string0 *) NULL);
	goto block2;

    block22:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v8579 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8580 = (l_v8579 == NULL);
	if (!l_v8580) {
		goto block23;
	}
	goto block11;

    block23:
	PYPY_DEBUG_RECORD_TRACEBACK("_ll_stringslice__rpy_stringPtr_Signed_Signed");
	l_v8600 = NULL;
	goto block13;

    block24:
	l_v8582 = pypy_g_MiniMarkGC_collect_and_reserve((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_v8516, l_totalsize_28);
	l_v8583 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8584 = (l_v8583 == NULL);
	if (!l_v8584) {
		goto block25;
	}
	l_v8515 = l_v8582;
	goto block10;

    block25:
	PYPY_DEBUG_RECORD_TRACEBACK("_ll_stringslice__rpy_stringPtr_Signed_Signed");
	l_v8600 = NULL;
	goto block13;

    block26:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v8586 = (Signed)0;
	l_v8587 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8588 = (l_v8587 == NULL);
	if (!l_v8588) {
		goto block27;
	}
	l_totalsize_28 = l_v8586;
	goto block9;

    block27:
	PYPY_DEBUG_RECORD_TRACEBACK("_ll_stringslice__rpy_stringPtr_Signed_Signed");
	l_v8600 = NULL;
	goto block13;

    block28:
	l_v8590 = pypy_g_MiniMarkGC_external_malloc((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17), l_length_52, 1);
	l_v8591 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8592 = (l_v8591 == NULL);
	if (!l_v8592) {
		goto block29;
	}
	l_v8599 = l_v8590;
	goto block12;

    block29:
	PYPY_DEBUG_RECORD_TRACEBACK("_ll_stringslice__rpy_stringPtr_Signed_Signed");
	l_v8600 = NULL;
	goto block13;

    block30:
	OP_RAW_MALLOC_USAGE(sizeof(char), l_v8594);
	OP_INT_FLOORDIV(l_maxsize_12, l_v8594, l_v8595);
	OP_CAST_INT_TO_UINT(l_v8595, l_v8596);
	OP_UINT_ADD(l_v8596, 1UL, l_v8597);
	l_toobig_13 = l_v8597;
	goto block6;
}
/*/*/
struct pypy_rpy_string0 *pypy_g_ll_join_strs__v107___simple_call__function_l(Signed l_num_items_0, struct pypy_array3 *l_items_10) {
	Signed l_i_54; Signed l_length_53; Signed l_length_54;
	Signed l_maxsize_13; Signed l_ofs_0;
	struct pypy_rpy_string0 *l_result_25; Unsigned l_toobig_14;
	Signed l_totalsize_29; Signed l_v8602; Signed l_v8605;
	Signed l_v8607; Signed l_v8608; Signed l_v8618; Signed l_v8620;
	Signed l_v8624; Signed l_v8626; Signed l_v8627; Signed l_v8628;
	Signed l_v8661; Signed l_v8662; Signed l_v8664; Signed l_v8668;
	Signed l_v8669; Signed l_v8679; Signed l_v8687; Signed l_v8688;
	Signed l_v8694; Unsigned l_v8622; Unsigned l_v8689; Unsigned l_v8690;
	bool_t l_v8609; bool_t l_v8610; bool_t l_v8611; bool_t l_v8619;
	bool_t l_v8621; bool_t l_v8623; bool_t l_v8625; bool_t l_v8629;
	bool_t l_v8635; bool_t l_v8636; bool_t l_v8648; bool_t l_v8649;
	bool_t l_v8651; bool_t l_v8653; bool_t l_v8657; bool_t l_v8673;
	bool_t l_v8677; bool_t l_v8681; bool_t l_v8685; bool_t l_v8693;
	struct pypy_header0 *l_v8637; struct pypy_object0 *l_v8695;
	struct pypy_object_vtable0 *l_v8672;
	struct pypy_object_vtable0 *l_v8676;
	struct pypy_object_vtable0 *l_v8680;
	struct pypy_object_vtable0 *l_v8684;
	struct pypy_object_vtable0 *l_v8692;
	struct pypy_object_vtable0 *l_v8696;
	struct pypy_rpy_string0 *l_v8604; struct pypy_rpy_string0 *l_v8652;
	struct pypy_rpy_string0 *l_v8691; struct pypy_rpy_string0 *l_v8702;
	struct pypy_rpy_string0 *l_v8703; void* l_v8601; void* l_v8603;
	void* l_v8606; void* l_v8613; void* l_v8614; void* l_v8616;
	void* l_v8631; void* l_v8633; void* l_v8634; void* l_v8639;
	void* l_v8640; void* l_v8642; void* l_v8643; void* l_v8644;
	void* l_v8646; void* l_v8656; void* l_v8660; void* l_v8663;
	void* l_v8675; void* l_v8683; void* l_v8704; void* l_v8705;
	goto block0;

    block0:
	OP_INT_EQ(l_num_items_0, 1L, l_v8609);
	if (l_v8609) {
		goto block34;
	}
	l_v8602 = 0L;
	l_length_53 = 0L;
	goto block1;

    block1:
	while (1) {
		OP_INT_LT(l_v8602, l_num_items_0, l_v8610);
		if (!l_v8610) break;
		goto block31;
	  block1_back: ;
	}
	goto block2;

    block2:
	OP_INT_GE(l_length_53, 0L, l_v8611);
	RPyAssert(l_v8611, "negative string length");
	l_v8613 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v8613, sizeof(void*), l_v8614);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v8614;
	l_v8616 = (void*)l_items_10;
	((void* *) (((char *)l_v8613) + 0))[0] = l_v8616;
	OP_RAW_MALLOC_USAGE((0 + offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v8618);
	OP_INT_SUB(67583L, l_v8618, l_maxsize_13);
	OP_INT_LT(l_maxsize_13, 0L, l_v8619);
	if (l_v8619) {
		l_toobig_14 = 0UL;
		goto block4;
	}
	goto block3;

    block3:
	OP_RAW_MALLOC_USAGE(sizeof(char), l_v8620);
	OP_INT_IS_TRUE(l_v8620, l_v8621);
	if (l_v8621) {
		goto block30;
	}
	l_toobig_14 = 2147483648UL;
	goto block4;

    block4:
	OP_CAST_INT_TO_UINT(l_length_53, l_v8622);
	OP_UINT_GE(l_v8622, l_toobig_14, l_v8623);
	if (l_v8623) {
		goto block28;
	}
	goto block5;

    block5:
	OP_INT_MUL(sizeof(char), l_length_53, l_v8624);
	OP_INT_ADD((0 + offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v8624, l_v8607);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v8625);
	if (l_v8625) {
		goto block26;
	}
	goto block6;

    block6:
	l_v8626 = ROUND_UP_FOR_ALLOCATION(l_v8607, 0L);
	l_totalsize_29 = l_v8626;
	goto block7;

    block7:
	OP_RAW_MALLOC_USAGE(l_totalsize_29, l_v8627);
	OP_RAW_MALLOC_USAGE((sizeof(struct pypy_header0) + sizeof(void*)), l_v8628);
	OP_INT_GE(l_v8627, l_v8628, l_v8629);
	RPyAssert(l_v8629, "malloc_varsize_clear(): totalsize < minimalsize");
	l_v8606 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	OP_ADR_ADD(l_v8606, l_totalsize_29, l_v8631);
	(&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free = l_v8631;
	l_v8633 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	l_v8634 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_top;
	OP_ADR_GT(l_v8633, l_v8634, l_v8635);
	if (l_v8635) {
		goto block24;
	}
	l_v8603 = l_v8606;
	goto block8;

    block8:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v8636);
	if (l_v8636) {
		goto block22;
	}
	goto block9;

    block9:
	l_v8637 = (struct pypy_header0 *)l_v8603;
	RPyField(l_v8637, h_tid) = (GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+0L);
	OP_ADR_ADD(l_v8603, 0, l_v8639);
	OP_ADR_ADD(l_v8639, (offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, length)), l_v8640);
	((Signed *) (((char *)l_v8640) + 0))[0] = l_length_53;
	l_v8704 = l_v8639;
	goto block10;

    block10:
	l_v8642 = (void*)l_v8704;
	l_v8705 = l_v8642;
	goto block11;

    block11:
	l_v8643 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v8643, sizeof(void*), l_v8644);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v8644;
	l_v8646 = ((void* *) (((char *)l_v8644) + 0))[0];
	l_items_10 = l_v8646; /* for moving GCs */
	l_result_25 = (struct pypy_rpy_string0 *)l_v8705;
	l_v8648 = (l_result_25 != NULL);
	if (!l_v8648) {
		goto block21;
	}
	goto block12;

    block12:
	OP_INT_IS_TRUE(MALLOC_ZERO_FILLED, l_v8649);
	if (l_v8649) {
		l_ofs_0 = 0L;
		l_i_54 = 0L;
		goto block14;
	}
	goto block13;

    block13:
	RPyField(l_result_25, rs_hash) = 0L;
	l_ofs_0 = 0L;
	l_i_54 = 0L;
	goto block14;

    block14:
	while (1) {
		OP_INT_LT(l_i_54, l_num_items_0, l_v8651);
		if (!l_v8651) break;
		goto block16;
	  block14_back: ;
	}
	l_v8703 = l_result_25;
	goto block15;

    block15:
	RPY_DEBUG_RETURN();
	return l_v8703;

    block16:
	l_v8652 = RPyItem(l_items_10, l_i_54);
	l_length_54 = RPyField(l_v8652, rs_chars).length;
	l_v8604 = RPyItem(l_items_10, l_i_54);
	OP_INT_GE(l_length_54, 0L, l_v8653);
	if (l_v8653) {
		goto block18;
	}
	goto block17;

    block17:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("ll_join_strs__v107___simple_call__function_l");
	l_v8703 = ((struct pypy_rpy_string0 *) NULL);
	goto block15;

    block18:
	l_v8656 = (void*)l_v8604;
	OP_ADR_ADD(l_v8656, (offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v8601);
	OP_INT_GE(l_ofs_0, 0L, l_v8657);
	if (l_v8657) {
		goto block20;
	}
	goto block19;

    block19:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("ll_join_strs__v107___simple_call__function_l");
	l_v8703 = ((struct pypy_rpy_string0 *) NULL);
	goto block15;

    block20:
	l_v8660 = (void*)l_result_25;
	OP_INT_MUL(sizeof(char), l_ofs_0, l_v8661);
	OP_INT_ADD((offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items)), l_v8661, l_v8662);
	OP_ADR_ADD(l_v8660, l_v8662, l_v8663);
	OP_INT_MUL(sizeof(char), l_length_54, l_v8664);
	OP_RAW_MEMCOPY(l_v8601, l_v8663, l_v8664, /* nothing */);
	/* kept alive: l_v8601 */
	/* kept alive: l_v8663 */
	OP_INT_ADD(l_ofs_0, l_length_54, l_v8668);
	OP_INT_ADD(l_i_54, 1L, l_v8669);
	l_ofs_0 = l_v8668;
	l_i_54 = l_v8669;
	goto block14_back;

    block21:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_join_strs__v107___simple_call__function_l");
	l_v8703 = ((struct pypy_rpy_string0 *) NULL);
	goto block15;

    block22:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v8672 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8673 = (l_v8672 == NULL);
	if (!l_v8673) {
		goto block23;
	}
	goto block9;

    block23:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_join_strs__v107___simple_call__function_l");
	l_v8705 = NULL;
	goto block11;

    block24:
	l_v8675 = pypy_g_MiniMarkGC_collect_and_reserve((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_v8606, l_totalsize_29);
	l_v8676 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8677 = (l_v8676 == NULL);
	if (!l_v8677) {
		goto block25;
	}
	l_v8603 = l_v8675;
	goto block8;

    block25:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_join_strs__v107___simple_call__function_l");
	l_v8705 = NULL;
	goto block11;

    block26:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v8679 = (Signed)0;
	l_v8680 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8681 = (l_v8680 == NULL);
	if (!l_v8681) {
		goto block27;
	}
	l_totalsize_29 = l_v8679;
	goto block7;

    block27:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_join_strs__v107___simple_call__function_l");
	l_v8705 = NULL;
	goto block11;

    block28:
	l_v8683 = pypy_g_MiniMarkGC_external_malloc((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17), l_length_53, 1);
	l_v8684 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8685 = (l_v8684 == NULL);
	if (!l_v8685) {
		goto block29;
	}
	l_v8704 = l_v8683;
	goto block10;

    block29:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_join_strs__v107___simple_call__function_l");
	l_v8705 = NULL;
	goto block11;

    block30:
	OP_RAW_MALLOC_USAGE(sizeof(char), l_v8687);
	OP_INT_FLOORDIV(l_maxsize_13, l_v8687, l_v8688);
	OP_CAST_INT_TO_UINT(l_v8688, l_v8689);
	OP_UINT_ADD(l_v8689, 1UL, l_v8690);
	l_toobig_14 = l_v8690;
	goto block4;

    block31:
	l_v8691 = RPyItem(l_items_10, l_v8602);
	l_v8605 = RPyField(l_v8691, rs_chars).length;
	OP_INT_ADD_NONNEG_OVF(l_length_53, l_v8605, l_v8608);
	l_v8692 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8693 = (l_v8692 == NULL);
	if (!l_v8693) {
		goto block33;
	}
	goto block32;

    block32:
	OP_INT_ADD(l_v8602, 1L, l_v8694);
	l_v8602 = l_v8694;
	l_length_53 = l_v8608;
	goto block1_back;

    block33:
	l_v8695 = (&pypy_g_ExcData)->ed_exc_value;
	l_v8696 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("ll_join_strs__v107___simple_call__function_l", l_v8696, l_v8696 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_v8696 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("ll_join_strs__v107___simple_call__function_l");
	l_v8703 = ((struct pypy_rpy_string0 *) NULL);
	goto block15;

    block34:
	l_v8702 = RPyItem(l_items_10, 0L);
	l_v8703 = l_v8702;
	goto block15;
}
/*/*/
struct pypy_rpy_string0 *pypy_g_ll_strconcat__rpy_stringPtr_rpy_stringPtr(struct pypy_rpy_string0 *l_s1_9, struct pypy_rpy_string0 *l_s2_3) {
	Signed l_length_55; Signed l_maxsize_14;
	struct pypy_rpy_string0 *l_r_2; Unsigned l_toobig_15;
	Signed l_totalsize_30; Signed l_v8706; Signed l_v8707;
	Signed l_v8708; Signed l_v8721; Signed l_v8723; Signed l_v8727;
	Signed l_v8729; Signed l_v8730; Signed l_v8731; Signed l_v8763;
	Signed l_v8775; Signed l_v8776; Signed l_v8778; Signed l_v8791;
	Signed l_v8799; Signed l_v8800; Unsigned l_v8725; Unsigned l_v8801;
	Unsigned l_v8802; bool_t l_v8712; bool_t l_v8722; bool_t l_v8724;
	bool_t l_v8726; bool_t l_v8728; bool_t l_v8732; bool_t l_v8738;
	bool_t l_v8739; bool_t l_v8753; bool_t l_v8754; bool_t l_v8756;
	bool_t l_v8767; bool_t l_v8771; bool_t l_v8785; bool_t l_v8789;
	bool_t l_v8793; bool_t l_v8797; struct pypy_header0 *l_v8740;
	struct pypy_object_vtable0 *l_v8784;
	struct pypy_object_vtable0 *l_v8788;
	struct pypy_object_vtable0 *l_v8792;
	struct pypy_object_vtable0 *l_v8796;
	struct pypy_rpy_string0 *l_v8803; void* l_v8709; void* l_v8710;
	void* l_v8711; void* l_v8714; void* l_v8715; void* l_v8717;
	void* l_v8719; void* l_v8734; void* l_v8736; void* l_v8737;
	void* l_v8742; void* l_v8743; void* l_v8745; void* l_v8746;
	void* l_v8747; void* l_v8749; void* l_v8751; void* l_v8759;
	void* l_v8760; void* l_v8761; void* l_v8762; void* l_v8770;
	void* l_v8774; void* l_v8777; void* l_v8787; void* l_v8795;
	void* l_v8804; void* l_v8805;
	goto block0;

    block0:
	l_v8706 = RPyField(l_s1_9, rs_chars).length;
	l_v8707 = RPyField(l_s2_3, rs_chars).length;
	OP_INT_ADD(l_v8706, l_v8707, l_length_55);
	OP_INT_GE(l_length_55, 0L, l_v8712);
	RPyAssert(l_v8712, "negative string length");
	l_v8714 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v8714, (sizeof(void*) * 2), l_v8715);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v8715;
	l_v8717 = (void*)l_s1_9;
	((void* *) (((char *)l_v8714) + 0))[0] = l_v8717;
	l_v8719 = (void*)l_s2_3;
	((void* *) (((char *)l_v8714) + sizeof(void*)))[0] = l_v8719;
	OP_RAW_MALLOC_USAGE((0 + offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v8721);
	OP_INT_SUB(67583L, l_v8721, l_maxsize_14);
	OP_INT_LT(l_maxsize_14, 0L, l_v8722);
	if (l_v8722) {
		l_toobig_15 = 0UL;
		goto block2;
	}
	goto block1;

    block1:
	OP_RAW_MALLOC_USAGE(sizeof(char), l_v8723);
	OP_INT_IS_TRUE(l_v8723, l_v8724);
	if (l_v8724) {
		goto block29;
	}
	l_toobig_15 = 2147483648UL;
	goto block2;

    block2:
	OP_CAST_INT_TO_UINT(l_length_55, l_v8725);
	OP_UINT_GE(l_v8725, l_toobig_15, l_v8726);
	if (l_v8726) {
		goto block27;
	}
	goto block3;

    block3:
	OP_INT_MUL(sizeof(char), l_length_55, l_v8727);
	OP_INT_ADD((0 + offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v8727, l_v8708);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v8728);
	if (l_v8728) {
		goto block25;
	}
	goto block4;

    block4:
	l_v8729 = ROUND_UP_FOR_ALLOCATION(l_v8708, 0L);
	l_totalsize_30 = l_v8729;
	goto block5;

    block5:
	OP_RAW_MALLOC_USAGE(l_totalsize_30, l_v8730);
	OP_RAW_MALLOC_USAGE((sizeof(struct pypy_header0) + sizeof(void*)), l_v8731);
	OP_INT_GE(l_v8730, l_v8731, l_v8732);
	RPyAssert(l_v8732, "malloc_varsize_clear(): totalsize < minimalsize");
	l_v8709 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	OP_ADR_ADD(l_v8709, l_totalsize_30, l_v8734);
	(&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free = l_v8734;
	l_v8736 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	l_v8737 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_top;
	OP_ADR_GT(l_v8736, l_v8737, l_v8738);
	if (l_v8738) {
		goto block23;
	}
	l_v8711 = l_v8709;
	goto block6;

    block6:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v8739);
	if (l_v8739) {
		goto block21;
	}
	goto block7;

    block7:
	l_v8740 = (struct pypy_header0 *)l_v8711;
	RPyField(l_v8740, h_tid) = (GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+0L);
	OP_ADR_ADD(l_v8711, 0, l_v8742);
	OP_ADR_ADD(l_v8742, (offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, length)), l_v8743);
	((Signed *) (((char *)l_v8743) + 0))[0] = l_length_55;
	l_v8804 = l_v8742;
	goto block8;

    block8:
	l_v8745 = (void*)l_v8804;
	l_v8805 = l_v8745;
	goto block9;

    block9:
	l_v8746 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v8746, (sizeof(void*) * 2), l_v8747);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v8747;
	l_v8749 = ((void* *) (((char *)l_v8747) + 0))[0];
	l_s1_9 = l_v8749; /* for moving GCs */
	l_v8751 = ((void* *) (((char *)l_v8747) + sizeof(void*)))[0];
	l_s2_3 = l_v8751; /* for moving GCs */
	l_r_2 = (struct pypy_rpy_string0 *)l_v8805;
	l_v8753 = (l_r_2 != NULL);
	if (!l_v8753) {
		goto block20;
	}
	goto block10;

    block10:
	OP_INT_IS_TRUE(MALLOC_ZERO_FILLED, l_v8754);
	if (l_v8754) {
		goto block12;
	}
	goto block11;

    block11:
	RPyField(l_r_2, rs_hash) = 0L;
	goto block12;

    block12:
	OP_INT_GE(l_v8706, 0L, l_v8756);
	if (l_v8756) {
		goto block15;
	}
	goto block13;

    block13:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("ll_strconcat__rpy_stringPtr_rpy_stringPtr");
	l_v8803 = ((struct pypy_rpy_string0 *) NULL);
	goto block14;

    block14:
	RPY_DEBUG_RETURN();
	return l_v8803;

    block15:
	l_v8759 = (void*)l_s1_9;
	OP_ADR_ADD(l_v8759, (offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v8760);
	l_v8761 = (void*)l_r_2;
	OP_ADR_ADD(l_v8761, (offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v8762);
	OP_INT_MUL(sizeof(char), l_v8706, l_v8763);
	OP_RAW_MEMCOPY(l_v8760, l_v8762, l_v8763, /* nothing */);
	/* kept alive: l_v8760 */
	/* kept alive: l_v8762 */
	OP_INT_GE(l_v8707, 0L, l_v8767);
	if (l_v8767) {
		goto block17;
	}
	goto block16;

    block16:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("ll_strconcat__rpy_stringPtr_rpy_stringPtr");
	l_v8803 = ((struct pypy_rpy_string0 *) NULL);
	goto block14;

    block17:
	l_v8770 = (void*)l_s2_3;
	OP_ADR_ADD(l_v8770, (offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v8710);
	OP_INT_GE(l_v8706, 0L, l_v8771);
	if (l_v8771) {
		goto block19;
	}
	goto block18;

    block18:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("ll_strconcat__rpy_stringPtr_rpy_stringPtr");
	l_v8803 = ((struct pypy_rpy_string0 *) NULL);
	goto block14;

    block19:
	l_v8774 = (void*)l_r_2;
	OP_INT_MUL(sizeof(char), l_v8706, l_v8775);
	OP_INT_ADD((offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items)), l_v8775, l_v8776);
	OP_ADR_ADD(l_v8774, l_v8776, l_v8777);
	OP_INT_MUL(sizeof(char), l_v8707, l_v8778);
	OP_RAW_MEMCOPY(l_v8710, l_v8777, l_v8778, /* nothing */);
	/* kept alive: l_v8710 */
	/* kept alive: l_v8777 */
	l_v8803 = l_r_2;
	goto block14;

    block20:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_strconcat__rpy_stringPtr_rpy_stringPtr");
	l_v8803 = ((struct pypy_rpy_string0 *) NULL);
	goto block14;

    block21:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v8784 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8785 = (l_v8784 == NULL);
	if (!l_v8785) {
		goto block22;
	}
	goto block7;

    block22:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_strconcat__rpy_stringPtr_rpy_stringPtr");
	l_v8805 = NULL;
	goto block9;

    block23:
	l_v8787 = pypy_g_MiniMarkGC_collect_and_reserve((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_v8709, l_totalsize_30);
	l_v8788 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8789 = (l_v8788 == NULL);
	if (!l_v8789) {
		goto block24;
	}
	l_v8711 = l_v8787;
	goto block6;

    block24:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_strconcat__rpy_stringPtr_rpy_stringPtr");
	l_v8805 = NULL;
	goto block9;

    block25:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v8791 = (Signed)0;
	l_v8792 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8793 = (l_v8792 == NULL);
	if (!l_v8793) {
		goto block26;
	}
	l_totalsize_30 = l_v8791;
	goto block5;

    block26:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_strconcat__rpy_stringPtr_rpy_stringPtr");
	l_v8805 = NULL;
	goto block9;

    block27:
	l_v8795 = pypy_g_MiniMarkGC_external_malloc((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17), l_length_55, 1);
	l_v8796 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8797 = (l_v8796 == NULL);
	if (!l_v8797) {
		goto block28;
	}
	l_v8804 = l_v8795;
	goto block8;

    block28:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_strconcat__rpy_stringPtr_rpy_stringPtr");
	l_v8805 = NULL;
	goto block9;

    block29:
	OP_RAW_MALLOC_USAGE(sizeof(char), l_v8799);
	OP_INT_FLOORDIV(l_maxsize_14, l_v8799, l_v8800);
	OP_CAST_INT_TO_UINT(l_v8800, l_v8801);
	OP_UINT_ADD(l_v8801, 1UL, l_v8802);
	l_toobig_15 = l_v8802;
	goto block2;
}
/*/*/
Signed pypy_g_ll_find__LLHelpersConst_rpy_stringPtr_rpy_string(struct pypy_rpy_string0 *l_s1_10, struct pypy_rpy_string0 *l_s2_4, Signed l_start_7, Signed l_end_8) {
	char l_ch_0; Signed l_end_10; Signed l_end_9; Signed l_start_15;
	Signed l_v8806; Signed l_v8808; Signed l_v8810; Signed l_v8812;
	Signed l_v8813; Signed l_v8818; Signed l_v8819; Signed l_v8820;
	Signed l_v8821; Signed l_v8822; bool_t l_v8807; bool_t l_v8809;
	bool_t l_v8811; bool_t l_v8814; bool_t l_v8815; bool_t l_v8817;
	char l_v8816;
	goto block0;

    block0:
	OP_INT_LT(l_start_7, 0L, l_v8807);
	if (l_v8807) {
		l_start_15 = 0L;
		goto block1;
	}
	l_start_15 = l_start_7;
	goto block1;

    block1:
	l_v8808 = RPyField(l_s1_10, rs_chars).length;
	OP_INT_GT(l_end_8, l_v8808, l_v8809);
	if (l_v8809) {
		goto block11;
	}
	l_end_10 = l_end_8;
	goto block2;

    block2:
	OP_INT_SUB(l_end_10, l_start_15, l_v8810);
	OP_INT_LT(l_v8810, 0L, l_v8811);
	if (l_v8811) {
		l_v8822 = -1L;
		goto block4;
	}
	goto block3;

    block3:
	l_v8812 = RPyField(l_s2_4, rs_chars).length;
	switch (l_v8812) {
    case 0L:
		l_v8822 = l_start_15;
		goto block4;
    case 1L:
		goto block5;
    default:
		goto block10;
	}

    block4:
	RPY_DEBUG_RETURN();
	return l_v8822;

    block5:
	l_ch_0 = RPyField(l_s2_4, rs_chars).items[0L];
	l_v8813 = RPyField(l_s1_10, rs_chars).length;
	OP_INT_GT(l_end_10, l_v8813, l_v8814);
	if (l_v8814) {
		goto block9;
	}
	l_end_9 = l_end_10;
	l_v8806 = l_start_15;
	goto block6;

    block6:
	while (1) {
		OP_INT_LT(l_v8806, l_end_9, l_v8815);
		if (!l_v8815) break;
		goto block7;
	  block6_back: ;
	}
	l_v8822 = -1L;
	goto block4;

    block7:
	l_v8816 = RPyField(l_s1_10, rs_chars).items[l_v8806];
	OP_CHAR_EQ(l_v8816, l_ch_0, l_v8817);
	if (l_v8817) {
		l_v8822 = l_v8806;
		goto block4;
	}
	goto block8;

    block8:
	OP_INT_ADD(l_v8806, 1L, l_v8818);
	l_v8806 = l_v8818;
	goto block6_back;

    block9:
	l_v8819 = RPyField(l_s1_10, rs_chars).length;
	l_end_9 = l_v8819;
	l_v8806 = l_start_15;
	goto block6;

    block10:
	l_v8820 = pypy_g_ll_search__rpy_stringPtr_rpy_stringPtr_Signed_Si(l_s1_10, l_s2_4, l_start_15, l_end_10, 1L);
	l_v8822 = l_v8820;
	goto block4;

    block11:
	l_v8821 = RPyField(l_s1_10, rs_chars).length;
	l_end_10 = l_v8821;
	goto block2;
}
/*/*/
Signed pypy_g_ll_int__rpy_stringPtr_Signed(struct pypy_rpy_string0 *l_chars_7, Signed l_base_1) {
	Signed l_c_4; Signed l_digit_0; Signed l_i_55; Signed l_i_56;
	Signed l_oldpos_0; Signed l_sign_1; Signed l_strlen_4;
	Signed l_v8823; Signed l_v8845; Signed l_v8848; Signed l_v8856;
	Signed l_v8858; Signed l_v8859; Signed l_v8860; Signed l_v8862;
	Signed l_v8863; Signed l_v8865; Signed l_v8866; Signed l_v8869;
	Signed l_v8870; Signed l_v8871; Signed l_v8874; Signed l_v8875;
	bool_t l_v8824; bool_t l_v8827; bool_t l_v8830; bool_t l_v8831;
	bool_t l_v8835; bool_t l_v8837; bool_t l_v8838; bool_t l_v8839;
	bool_t l_v8840; bool_t l_v8841; bool_t l_v8842; bool_t l_v8847;
	bool_t l_v8852; bool_t l_v8853; bool_t l_v8854; bool_t l_v8855;
	bool_t l_v8857; bool_t l_v8861; bool_t l_v8864; bool_t l_v8868;
	bool_t l_v8873; char l_v8834; char l_v8836; char l_v8846;
	char l_v8851; char l_v8867; char l_v8872; Signed l_val_3;
	goto block0;

    block0:
	OP_INT_LE(2L, l_base_1, l_v8824);
	if (l_v8824) {
		goto block3;
	}
	goto block1;

    block1:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_ValueError_vtable.ve_super.se_super.e_super), (&pypy_g_exceptions_ValueError.ve_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("ll_int__rpy_stringPtr_Signed");
	l_v8875 = -1L;
	goto block2;

    block2:
	RPY_DEBUG_RETURN();
	return l_v8875;

    block3:
	OP_INT_LE(l_base_1, 36L, l_v8827);
	if (l_v8827) {
		goto block5;
	}
	goto block4;

    block4:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_ValueError_vtable.ve_super.se_super.e_super), (&pypy_g_exceptions_ValueError.ve_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("ll_int__rpy_stringPtr_Signed");
	l_v8875 = -1L;
	goto block2;

    block5:
	l_strlen_4 = RPyField(l_chars_7, rs_chars).length;
	l_v8823 = 0L;
	goto block6;

    block6:
	while (1) {
		OP_INT_LT(l_v8823, l_strlen_4, l_v8830);
		if (!l_v8830) break;
		goto block36;
	  block6_back: ;
	}
	goto block7;

    block7:
	OP_INT_LT(l_v8823, l_strlen_4, l_v8831);
	if (l_v8831) {
		goto block9;
	}
	goto block8;

    block8:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_ValueError_vtable.ve_super.se_super.e_super), (&pypy_g_exceptions_ValueError.ve_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("ll_int__rpy_stringPtr_Signed");
	l_v8875 = -1L;
	goto block2;

    block9:
	l_v8834 = RPyField(l_chars_7, rs_chars).items[l_v8823];
	OP_CHAR_EQ(l_v8834, '-', l_v8835);
	if (l_v8835) {
		goto block35;
	}
	goto block10;

    block10:
	l_v8836 = RPyField(l_chars_7, rs_chars).items[l_v8823];
	OP_CHAR_EQ(l_v8836, '+', l_v8837);
	if (l_v8837) {
		goto block34;
	}
	l_sign_1 = 1L;
	l_oldpos_0 = l_v8823;
	goto block11;

    block11:
	while (1) {
		OP_INT_LT(l_oldpos_0, l_strlen_4, l_v8838);
		if (!l_v8838) break;
		goto block32;
	  block11_back: ;
	}
	l_val_3 = 0L;
	l_i_55 = l_oldpos_0;
	goto block12;

    block12:
	while (1) {
		OP_INT_LT(l_i_55, l_strlen_4, l_v8839);
		if (!l_v8839) break;
		goto block21;
	  block12_back: ;
	}
	goto block13;

    block13:
	OP_INT_EQ(l_i_55, l_oldpos_0, l_v8840);
	if (l_v8840) {
		goto block20;
	}
	l_i_56 = l_i_55;
	goto block14;

    block14:
	while (1) {
		OP_INT_LT(l_i_56, l_strlen_4, l_v8841);
		if (!l_v8841) break;
		goto block18;
	  block14_back: ;
	}
	goto block15;

    block15:
	OP_INT_EQ(l_i_56, l_strlen_4, l_v8842);
	if (l_v8842) {
		goto block17;
	}
	goto block16;

    block16:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_ValueError_vtable.ve_super.se_super.e_super), (&pypy_g_exceptions_ValueError.ve_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("ll_int__rpy_stringPtr_Signed");
	l_v8875 = -1L;
	goto block2;

    block17:
	OP_INT_MUL(l_sign_1, l_val_3, l_v8845);
	l_v8875 = l_v8845;
	goto block2;

    block18:
	l_v8846 = RPyField(l_chars_7, rs_chars).items[l_i_56];
	OP_CHAR_EQ(l_v8846, ' ', l_v8847);
	if (l_v8847) {
		goto block19;
	}
	goto block15;

    block19:
	OP_INT_ADD(l_i_56, 1L, l_v8848);
	l_i_56 = l_v8848;
	goto block14_back;

    block20:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_ValueError_vtable.ve_super.se_super.e_super), (&pypy_g_exceptions_ValueError.ve_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("ll_int__rpy_stringPtr_Signed");
	l_v8875 = -1L;
	goto block2;

    block21:
	l_v8851 = RPyField(l_chars_7, rs_chars).items[l_i_55];
	OP_CAST_CHAR_TO_INT(l_v8851, l_c_4);
	OP_INT_LE(97L, l_c_4, l_v8852);
	if (l_v8852) {
		goto block30;
	}
	goto block22;

    block22:
	OP_INT_LE(65L, l_c_4, l_v8853);
	if (l_v8853) {
		goto block28;
	}
	goto block23;

    block23:
	OP_INT_LE(48L, l_c_4, l_v8854);
	if (l_v8854) {
		goto block24;
	}
	goto block13;

    block24:
	OP_INT_LE(l_c_4, 57L, l_v8855);
	if (l_v8855) {
		goto block25;
	}
	goto block13;

    block25:
	OP_INT_SUB(l_c_4, 48L, l_v8856);
	l_digit_0 = l_v8856;
	goto block26;

    block26:
	OP_INT_GE(l_digit_0, l_base_1, l_v8857);
	if (l_v8857) {
		goto block13;
	}
	goto block27;

    block27:
	OP_INT_MUL(l_val_3, l_base_1, l_v8858);
	OP_INT_ADD(l_v8858, l_digit_0, l_v8859);
	OP_INT_ADD(l_i_55, 1L, l_v8860);
	l_val_3 = l_v8859;
	l_i_55 = l_v8860;
	goto block12_back;

    block28:
	OP_INT_LE(l_c_4, 90L, l_v8861);
	if (l_v8861) {
		goto block29;
	}
	goto block23;

    block29:
	OP_INT_SUB(l_c_4, 65L, l_v8862);
	OP_INT_ADD(l_v8862, 10L, l_v8863);
	l_digit_0 = l_v8863;
	goto block26;

    block30:
	OP_INT_LE(l_c_4, 122L, l_v8864);
	if (l_v8864) {
		goto block31;
	}
	goto block22;

    block31:
	OP_INT_SUB(l_c_4, 97L, l_v8865);
	OP_INT_ADD(l_v8865, 10L, l_v8866);
	l_digit_0 = l_v8866;
	goto block26;

    block32:
	l_v8867 = RPyField(l_chars_7, rs_chars).items[l_oldpos_0];
	OP_CHAR_EQ(l_v8867, ' ', l_v8868);
	if (l_v8868) {
		goto block33;
	}
	l_val_3 = 0L;
	l_i_55 = l_oldpos_0;
	goto block12;

    block33:
	OP_INT_ADD(l_oldpos_0, 1L, l_v8869);
	l_oldpos_0 = l_v8869;
	goto block11_back;

    block34:
	OP_INT_ADD(l_v8823, 1L, l_v8870);
	l_sign_1 = 1L;
	l_oldpos_0 = l_v8870;
	goto block11;

    block35:
	OP_INT_ADD(l_v8823, 1L, l_v8871);
	l_sign_1 = -1L;
	l_oldpos_0 = l_v8871;
	goto block11;

    block36:
	l_v8872 = RPyField(l_chars_7, rs_chars).items[l_v8823];
	OP_CHAR_EQ(l_v8872, ' ', l_v8873);
	if (l_v8873) {
		goto block37;
	}
	goto block7;

    block37:
	OP_INT_ADD(l_v8823, 1L, l_v8874);
	l_v8823 = l_v8874;
	goto block6_back;
}
/*/*/
struct pypy_rpy_string0 *pypy_g_ll_join_strs__v114___simple_call__function_l(Signed l_num_items_1, struct pypy_array3 *l_items_11) {
	struct pypy_rpy_string0 *l_dst_0; Signed l_i_57; Signed l_length_56;
	Signed l_length_57; Signed l_maxsize_15; Signed l_ofs_1;
	Unsigned l_toobig_16; Signed l_totalsize_31; Signed l_v8876;
	Signed l_v8877; Signed l_v8881; Signed l_v8883; Signed l_v8893;
	Signed l_v8895; Signed l_v8899; Signed l_v8901; Signed l_v8902;
	Signed l_v8903; Signed l_v8936; Signed l_v8937; Signed l_v8939;
	Signed l_v8943; Signed l_v8944; Signed l_v8954; Signed l_v8962;
	Signed l_v8963; Signed l_v8969; Unsigned l_v8897; Unsigned l_v8964;
	Unsigned l_v8965; bool_t l_v8884; bool_t l_v8885; bool_t l_v8886;
	bool_t l_v8894; bool_t l_v8896; bool_t l_v8898; bool_t l_v8900;
	bool_t l_v8904; bool_t l_v8910; bool_t l_v8911; bool_t l_v8923;
	bool_t l_v8924; bool_t l_v8926; bool_t l_v8928; bool_t l_v8932;
	bool_t l_v8948; bool_t l_v8952; bool_t l_v8956; bool_t l_v8960;
	bool_t l_v8968; struct pypy_header0 *l_v8912;
	struct pypy_object0 *l_v8970; struct pypy_object_vtable0 *l_v8947;
	struct pypy_object_vtable0 *l_v8951;
	struct pypy_object_vtable0 *l_v8955;
	struct pypy_object_vtable0 *l_v8959;
	struct pypy_object_vtable0 *l_v8967;
	struct pypy_object_vtable0 *l_v8971;
	struct pypy_rpy_string0 *l_v8878; struct pypy_rpy_string0 *l_v8927;
	struct pypy_rpy_string0 *l_v8966; struct pypy_rpy_string0 *l_v8977;
	struct pypy_rpy_string0 *l_v8978; void* l_v8879; void* l_v8880;
	void* l_v8882; void* l_v8888; void* l_v8889; void* l_v8891;
	void* l_v8906; void* l_v8908; void* l_v8909; void* l_v8914;
	void* l_v8915; void* l_v8917; void* l_v8918; void* l_v8919;
	void* l_v8921; void* l_v8931; void* l_v8935; void* l_v8938;
	void* l_v8950; void* l_v8958; void* l_v8979; void* l_v8980;
	goto block0;

    block0:
	OP_INT_EQ(l_num_items_1, 1L, l_v8884);
	if (l_v8884) {
		goto block34;
	}
	l_length_56 = 0L;
	l_v8881 = 0L;
	goto block1;

    block1:
	while (1) {
		OP_INT_LT(l_v8881, l_num_items_1, l_v8885);
		if (!l_v8885) break;
		goto block31;
	  block1_back: ;
	}
	goto block2;

    block2:
	OP_INT_GE(l_length_56, 0L, l_v8886);
	RPyAssert(l_v8886, "negative string length");
	l_v8888 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v8888, sizeof(void*), l_v8889);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v8889;
	l_v8891 = (void*)l_items_11;
	((void* *) (((char *)l_v8888) + 0))[0] = l_v8891;
	OP_RAW_MALLOC_USAGE((0 + offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v8893);
	OP_INT_SUB(67583L, l_v8893, l_maxsize_15);
	OP_INT_LT(l_maxsize_15, 0L, l_v8894);
	if (l_v8894) {
		l_toobig_16 = 0UL;
		goto block4;
	}
	goto block3;

    block3:
	OP_RAW_MALLOC_USAGE(sizeof(char), l_v8895);
	OP_INT_IS_TRUE(l_v8895, l_v8896);
	if (l_v8896) {
		goto block30;
	}
	l_toobig_16 = 2147483648UL;
	goto block4;

    block4:
	OP_CAST_INT_TO_UINT(l_length_56, l_v8897);
	OP_UINT_GE(l_v8897, l_toobig_16, l_v8898);
	if (l_v8898) {
		goto block28;
	}
	goto block5;

    block5:
	OP_INT_MUL(sizeof(char), l_length_56, l_v8899);
	OP_INT_ADD((0 + offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v8899, l_v8876);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v8900);
	if (l_v8900) {
		goto block26;
	}
	goto block6;

    block6:
	l_v8901 = ROUND_UP_FOR_ALLOCATION(l_v8876, 0L);
	l_totalsize_31 = l_v8901;
	goto block7;

    block7:
	OP_RAW_MALLOC_USAGE(l_totalsize_31, l_v8902);
	OP_RAW_MALLOC_USAGE((sizeof(struct pypy_header0) + sizeof(void*)), l_v8903);
	OP_INT_GE(l_v8902, l_v8903, l_v8904);
	RPyAssert(l_v8904, "malloc_varsize_clear(): totalsize < minimalsize");
	l_v8880 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	OP_ADR_ADD(l_v8880, l_totalsize_31, l_v8906);
	(&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free = l_v8906;
	l_v8908 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	l_v8909 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_top;
	OP_ADR_GT(l_v8908, l_v8909, l_v8910);
	if (l_v8910) {
		goto block24;
	}
	l_v8879 = l_v8880;
	goto block8;

    block8:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v8911);
	if (l_v8911) {
		goto block22;
	}
	goto block9;

    block9:
	l_v8912 = (struct pypy_header0 *)l_v8879;
	RPyField(l_v8912, h_tid) = (GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+0L);
	OP_ADR_ADD(l_v8879, 0, l_v8914);
	OP_ADR_ADD(l_v8914, (offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, length)), l_v8915);
	((Signed *) (((char *)l_v8915) + 0))[0] = l_length_56;
	l_v8979 = l_v8914;
	goto block10;

    block10:
	l_v8917 = (void*)l_v8979;
	l_v8980 = l_v8917;
	goto block11;

    block11:
	l_v8918 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v8918, sizeof(void*), l_v8919);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v8919;
	l_v8921 = ((void* *) (((char *)l_v8919) + 0))[0];
	l_items_11 = l_v8921; /* for moving GCs */
	l_dst_0 = (struct pypy_rpy_string0 *)l_v8980;
	l_v8923 = (l_dst_0 != NULL);
	if (!l_v8923) {
		goto block21;
	}
	goto block12;

    block12:
	OP_INT_IS_TRUE(MALLOC_ZERO_FILLED, l_v8924);
	if (l_v8924) {
		l_ofs_1 = 0L;
		l_i_57 = 0L;
		goto block14;
	}
	goto block13;

    block13:
	RPyField(l_dst_0, rs_hash) = 0L;
	l_ofs_1 = 0L;
	l_i_57 = 0L;
	goto block14;

    block14:
	while (1) {
		OP_INT_LT(l_i_57, l_num_items_1, l_v8926);
		if (!l_v8926) break;
		goto block16;
	  block14_back: ;
	}
	l_v8978 = l_dst_0;
	goto block15;

    block15:
	RPY_DEBUG_RETURN();
	return l_v8978;

    block16:
	l_v8927 = RPyItem(l_items_11, l_i_57);
	l_length_57 = RPyField(l_v8927, rs_chars).length;
	l_v8878 = RPyItem(l_items_11, l_i_57);
	OP_INT_GE(l_length_57, 0L, l_v8928);
	if (l_v8928) {
		goto block18;
	}
	goto block17;

    block17:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("ll_join_strs__v114___simple_call__function_l");
	l_v8978 = ((struct pypy_rpy_string0 *) NULL);
	goto block15;

    block18:
	l_v8931 = (void*)l_v8878;
	OP_ADR_ADD(l_v8931, (offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v8882);
	OP_INT_GE(l_ofs_1, 0L, l_v8932);
	if (l_v8932) {
		goto block20;
	}
	goto block19;

    block19:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("ll_join_strs__v114___simple_call__function_l");
	l_v8978 = ((struct pypy_rpy_string0 *) NULL);
	goto block15;

    block20:
	l_v8935 = (void*)l_dst_0;
	OP_INT_MUL(sizeof(char), l_ofs_1, l_v8936);
	OP_INT_ADD((offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items)), l_v8936, l_v8937);
	OP_ADR_ADD(l_v8935, l_v8937, l_v8938);
	OP_INT_MUL(sizeof(char), l_length_57, l_v8939);
	OP_RAW_MEMCOPY(l_v8882, l_v8938, l_v8939, /* nothing */);
	/* kept alive: l_v8882 */
	/* kept alive: l_v8938 */
	OP_INT_ADD(l_ofs_1, l_length_57, l_v8943);
	OP_INT_ADD(l_i_57, 1L, l_v8944);
	l_ofs_1 = l_v8943;
	l_i_57 = l_v8944;
	goto block14_back;

    block21:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_join_strs__v114___simple_call__function_l");
	l_v8978 = ((struct pypy_rpy_string0 *) NULL);
	goto block15;

    block22:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v8947 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8948 = (l_v8947 == NULL);
	if (!l_v8948) {
		goto block23;
	}
	goto block9;

    block23:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_join_strs__v114___simple_call__function_l");
	l_v8980 = NULL;
	goto block11;

    block24:
	l_v8950 = pypy_g_MiniMarkGC_collect_and_reserve((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_v8880, l_totalsize_31);
	l_v8951 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8952 = (l_v8951 == NULL);
	if (!l_v8952) {
		goto block25;
	}
	l_v8879 = l_v8950;
	goto block8;

    block25:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_join_strs__v114___simple_call__function_l");
	l_v8980 = NULL;
	goto block11;

    block26:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v8954 = (Signed)0;
	l_v8955 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8956 = (l_v8955 == NULL);
	if (!l_v8956) {
		goto block27;
	}
	l_totalsize_31 = l_v8954;
	goto block7;

    block27:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_join_strs__v114___simple_call__function_l");
	l_v8980 = NULL;
	goto block11;

    block28:
	l_v8958 = pypy_g_MiniMarkGC_external_malloc((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17), l_length_56, 1);
	l_v8959 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8960 = (l_v8959 == NULL);
	if (!l_v8960) {
		goto block29;
	}
	l_v8979 = l_v8958;
	goto block10;

    block29:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_join_strs__v114___simple_call__function_l");
	l_v8980 = NULL;
	goto block11;

    block30:
	OP_RAW_MALLOC_USAGE(sizeof(char), l_v8962);
	OP_INT_FLOORDIV(l_maxsize_15, l_v8962, l_v8963);
	OP_CAST_INT_TO_UINT(l_v8963, l_v8964);
	OP_UINT_ADD(l_v8964, 1UL, l_v8965);
	l_toobig_16 = l_v8965;
	goto block4;

    block31:
	l_v8966 = RPyItem(l_items_11, l_v8881);
	l_v8877 = RPyField(l_v8966, rs_chars).length;
	OP_INT_ADD_NONNEG_OVF(l_length_56, l_v8877, l_v8883);
	l_v8967 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8968 = (l_v8967 == NULL);
	if (!l_v8968) {
		goto block33;
	}
	goto block32;

    block32:
	OP_INT_ADD(l_v8881, 1L, l_v8969);
	l_length_56 = l_v8883;
	l_v8881 = l_v8969;
	goto block1_back;

    block33:
	l_v8970 = (&pypy_g_ExcData)->ed_exc_value;
	l_v8971 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("ll_join_strs__v114___simple_call__function_l", l_v8971, l_v8971 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_v8971 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("ll_join_strs__v114___simple_call__function_l");
	l_v8978 = ((struct pypy_rpy_string0 *) NULL);
	goto block15;

    block34:
	l_v8977 = RPyItem(l_items_11, 0L);
	l_v8978 = l_v8977;
	goto block15;
}
/*/*/
struct pypy_rpy_string0 *pypy_g_ll_join_strs__v153___simple_call__function_l(Signed l_num_items_2, struct pypy_array11 *l_items_12) {
	Signed l_dststart_0; Signed l_i_58; Signed l_i_59;
	Signed l_length_58; Signed l_length_59; Signed l_maxsize_16;
	struct pypy_rpy_string0 *l_result_26; Unsigned l_toobig_17;
	Signed l_totalsize_32; Signed l_v8981; Signed l_v8984;
	Signed l_v8985; Signed l_v8997; Signed l_v8999; Signed l_v9003;
	Signed l_v9005; Signed l_v9006; Signed l_v9007; Signed l_v9040;
	Signed l_v9041; Signed l_v9043; Signed l_v9047; Signed l_v9048;
	Signed l_v9058; Signed l_v9066; Signed l_v9067; Signed l_v9073;
	Unsigned l_v9001; Unsigned l_v9068; Unsigned l_v9069; bool_t l_v8988;
	bool_t l_v8989; bool_t l_v8990; bool_t l_v8998; bool_t l_v9000;
	bool_t l_v9002; bool_t l_v9004; bool_t l_v9008; bool_t l_v9014;
	bool_t l_v9015; bool_t l_v9027; bool_t l_v9028; bool_t l_v9030;
	bool_t l_v9032; bool_t l_v9036; bool_t l_v9052; bool_t l_v9056;
	bool_t l_v9060; bool_t l_v9064; bool_t l_v9072;
	struct pypy_header0 *l_v9016; struct pypy_object0 *l_v9074;
	struct pypy_object_vtable0 *l_v9051;
	struct pypy_object_vtable0 *l_v9055;
	struct pypy_object_vtable0 *l_v9059;
	struct pypy_object_vtable0 *l_v9063;
	struct pypy_object_vtable0 *l_v9071;
	struct pypy_object_vtable0 *l_v9075;
	struct pypy_rpy_string0 *l_v8986; struct pypy_rpy_string0 *l_v9031;
	struct pypy_rpy_string0 *l_v9070; struct pypy_rpy_string0 *l_v9081;
	struct pypy_rpy_string0 *l_v9082; void* l_v8982; void* l_v8983;
	void* l_v8987; void* l_v8992; void* l_v8993; void* l_v8995;
	void* l_v9010; void* l_v9012; void* l_v9013; void* l_v9018;
	void* l_v9019; void* l_v9021; void* l_v9022; void* l_v9023;
	void* l_v9025; void* l_v9035; void* l_v9039; void* l_v9042;
	void* l_v9054; void* l_v9062; void* l_v9083; void* l_v9084;
	goto block0;

    block0:
	OP_INT_EQ(l_num_items_2, 1L, l_v8988);
	if (l_v8988) {
		goto block34;
	}
	l_length_58 = 0L;
	l_i_59 = 0L;
	goto block1;

    block1:
	while (1) {
		OP_INT_LT(l_i_59, l_num_items_2, l_v8989);
		if (!l_v8989) break;
		goto block31;
	  block1_back: ;
	}
	goto block2;

    block2:
	OP_INT_GE(l_length_58, 0L, l_v8990);
	RPyAssert(l_v8990, "negative string length");
	l_v8992 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v8992, sizeof(void*), l_v8993);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v8993;
	l_v8995 = (void*)l_items_12;
	((void* *) (((char *)l_v8992) + 0))[0] = l_v8995;
	OP_RAW_MALLOC_USAGE((0 + offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v8997);
	OP_INT_SUB(67583L, l_v8997, l_maxsize_16);
	OP_INT_LT(l_maxsize_16, 0L, l_v8998);
	if (l_v8998) {
		l_toobig_17 = 0UL;
		goto block4;
	}
	goto block3;

    block3:
	OP_RAW_MALLOC_USAGE(sizeof(char), l_v8999);
	OP_INT_IS_TRUE(l_v8999, l_v9000);
	if (l_v9000) {
		goto block30;
	}
	l_toobig_17 = 2147483648UL;
	goto block4;

    block4:
	OP_CAST_INT_TO_UINT(l_length_58, l_v9001);
	OP_UINT_GE(l_v9001, l_toobig_17, l_v9002);
	if (l_v9002) {
		goto block28;
	}
	goto block5;

    block5:
	OP_INT_MUL(sizeof(char), l_length_58, l_v9003);
	OP_INT_ADD((0 + offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v9003, l_v8981);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v9004);
	if (l_v9004) {
		goto block26;
	}
	goto block6;

    block6:
	l_v9005 = ROUND_UP_FOR_ALLOCATION(l_v8981, 0L);
	l_totalsize_32 = l_v9005;
	goto block7;

    block7:
	OP_RAW_MALLOC_USAGE(l_totalsize_32, l_v9006);
	OP_RAW_MALLOC_USAGE((sizeof(struct pypy_header0) + sizeof(void*)), l_v9007);
	OP_INT_GE(l_v9006, l_v9007, l_v9008);
	RPyAssert(l_v9008, "malloc_varsize_clear(): totalsize < minimalsize");
	l_v8983 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	OP_ADR_ADD(l_v8983, l_totalsize_32, l_v9010);
	(&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free = l_v9010;
	l_v9012 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	l_v9013 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_top;
	OP_ADR_GT(l_v9012, l_v9013, l_v9014);
	if (l_v9014) {
		goto block24;
	}
	l_v8982 = l_v8983;
	goto block8;

    block8:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v9015);
	if (l_v9015) {
		goto block22;
	}
	goto block9;

    block9:
	l_v9016 = (struct pypy_header0 *)l_v8982;
	RPyField(l_v9016, h_tid) = (GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+0L);
	OP_ADR_ADD(l_v8982, 0, l_v9018);
	OP_ADR_ADD(l_v9018, (offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, length)), l_v9019);
	((Signed *) (((char *)l_v9019) + 0))[0] = l_length_58;
	l_v9083 = l_v9018;
	goto block10;

    block10:
	l_v9021 = (void*)l_v9083;
	l_v9084 = l_v9021;
	goto block11;

    block11:
	l_v9022 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v9022, sizeof(void*), l_v9023);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v9023;
	l_v9025 = ((void* *) (((char *)l_v9023) + 0))[0];
	l_items_12 = l_v9025; /* for moving GCs */
	l_result_26 = (struct pypy_rpy_string0 *)l_v9084;
	l_v9027 = (l_result_26 != NULL);
	if (!l_v9027) {
		goto block21;
	}
	goto block12;

    block12:
	OP_INT_IS_TRUE(MALLOC_ZERO_FILLED, l_v9028);
	if (l_v9028) {
		l_dststart_0 = 0L;
		l_i_58 = 0L;
		goto block14;
	}
	goto block13;

    block13:
	RPyField(l_result_26, rs_hash) = 0L;
	l_dststart_0 = 0L;
	l_i_58 = 0L;
	goto block14;

    block14:
	while (1) {
		OP_INT_LT(l_i_58, l_num_items_2, l_v9030);
		if (!l_v9030) break;
		goto block16;
	  block14_back: ;
	}
	l_v9082 = l_result_26;
	goto block15;

    block15:
	RPY_DEBUG_RETURN();
	return l_v9082;

    block16:
	l_v9031 = RPyItem(l_items_12, l_i_58);
	l_length_59 = RPyField(l_v9031, rs_chars).length;
	l_v8986 = RPyItem(l_items_12, l_i_58);
	OP_INT_GE(l_length_59, 0L, l_v9032);
	if (l_v9032) {
		goto block18;
	}
	goto block17;

    block17:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("ll_join_strs__v153___simple_call__function_l");
	l_v9082 = ((struct pypy_rpy_string0 *) NULL);
	goto block15;

    block18:
	l_v9035 = (void*)l_v8986;
	OP_ADR_ADD(l_v9035, (offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v8987);
	OP_INT_GE(l_dststart_0, 0L, l_v9036);
	if (l_v9036) {
		goto block20;
	}
	goto block19;

    block19:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("ll_join_strs__v153___simple_call__function_l");
	l_v9082 = ((struct pypy_rpy_string0 *) NULL);
	goto block15;

    block20:
	l_v9039 = (void*)l_result_26;
	OP_INT_MUL(sizeof(char), l_dststart_0, l_v9040);
	OP_INT_ADD((offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items)), l_v9040, l_v9041);
	OP_ADR_ADD(l_v9039, l_v9041, l_v9042);
	OP_INT_MUL(sizeof(char), l_length_59, l_v9043);
	OP_RAW_MEMCOPY(l_v8987, l_v9042, l_v9043, /* nothing */);
	/* kept alive: l_v8987 */
	/* kept alive: l_v9042 */
	OP_INT_ADD(l_dststart_0, l_length_59, l_v9047);
	OP_INT_ADD(l_i_58, 1L, l_v9048);
	l_dststart_0 = l_v9047;
	l_i_58 = l_v9048;
	goto block14_back;

    block21:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_join_strs__v153___simple_call__function_l");
	l_v9082 = ((struct pypy_rpy_string0 *) NULL);
	goto block15;

    block22:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v9051 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9052 = (l_v9051 == NULL);
	if (!l_v9052) {
		goto block23;
	}
	goto block9;

    block23:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_join_strs__v153___simple_call__function_l");
	l_v9084 = NULL;
	goto block11;

    block24:
	l_v9054 = pypy_g_MiniMarkGC_collect_and_reserve((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_v8983, l_totalsize_32);
	l_v9055 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9056 = (l_v9055 == NULL);
	if (!l_v9056) {
		goto block25;
	}
	l_v8982 = l_v9054;
	goto block8;

    block25:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_join_strs__v153___simple_call__function_l");
	l_v9084 = NULL;
	goto block11;

    block26:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v9058 = (Signed)0;
	l_v9059 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9060 = (l_v9059 == NULL);
	if (!l_v9060) {
		goto block27;
	}
	l_totalsize_32 = l_v9058;
	goto block7;

    block27:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_join_strs__v153___simple_call__function_l");
	l_v9084 = NULL;
	goto block11;

    block28:
	l_v9062 = pypy_g_MiniMarkGC_external_malloc((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17), l_length_58, 1);
	l_v9063 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9064 = (l_v9063 == NULL);
	if (!l_v9064) {
		goto block29;
	}
	l_v9083 = l_v9062;
	goto block10;

    block29:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_join_strs__v153___simple_call__function_l");
	l_v9084 = NULL;
	goto block11;

    block30:
	OP_RAW_MALLOC_USAGE(sizeof(char), l_v9066);
	OP_INT_FLOORDIV(l_maxsize_16, l_v9066, l_v9067);
	OP_CAST_INT_TO_UINT(l_v9067, l_v9068);
	OP_UINT_ADD(l_v9068, 1UL, l_v9069);
	l_toobig_17 = l_v9069;
	goto block4;

    block31:
	l_v9070 = RPyItem(l_items_12, l_i_59);
	l_v8984 = RPyField(l_v9070, rs_chars).length;
	OP_INT_ADD_NONNEG_OVF(l_length_58, l_v8984, l_v8985);
	l_v9071 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9072 = (l_v9071 == NULL);
	if (!l_v9072) {
		goto block33;
	}
	goto block32;

    block32:
	OP_INT_ADD(l_i_59, 1L, l_v9073);
	l_length_58 = l_v8985;
	l_i_59 = l_v9073;
	goto block1_back;

    block33:
	l_v9074 = (&pypy_g_ExcData)->ed_exc_value;
	l_v9075 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("ll_join_strs__v153___simple_call__function_l", l_v9075, l_v9075 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_v9075 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("ll_join_strs__v153___simple_call__function_l");
	l_v9082 = ((struct pypy_rpy_string0 *) NULL);
	goto block15;

    block34:
	l_v9081 = RPyItem(l_items_12, 0L);
	l_v9082 = l_v9081;
	goto block15;
}
/*/*/
struct pypy_rpy_string0 *pypy_g_ll_join_strs__v161___simple_call__function_l(Signed l_num_items_3, struct pypy_array11 *l_items_13) {
	struct pypy_rpy_string0 *l_dst_1; Signed l_dststart_1; Signed l_i_60;
	Signed l_i_61; Signed l_length_60; Signed l_length_61;
	Signed l_maxsize_17; Unsigned l_toobig_18; Signed l_totalsize_33;
	Signed l_v9085; Signed l_v9086; Signed l_v9090; Signed l_v9101;
	Signed l_v9103; Signed l_v9107; Signed l_v9109; Signed l_v9110;
	Signed l_v9111; Signed l_v9144; Signed l_v9145; Signed l_v9147;
	Signed l_v9151; Signed l_v9152; Signed l_v9162; Signed l_v9170;
	Signed l_v9171; Signed l_v9177; Unsigned l_v9105; Unsigned l_v9172;
	Unsigned l_v9173; bool_t l_v9092; bool_t l_v9093; bool_t l_v9094;
	bool_t l_v9102; bool_t l_v9104; bool_t l_v9106; bool_t l_v9108;
	bool_t l_v9112; bool_t l_v9118; bool_t l_v9119; bool_t l_v9131;
	bool_t l_v9132; bool_t l_v9134; bool_t l_v9136; bool_t l_v9140;
	bool_t l_v9156; bool_t l_v9160; bool_t l_v9164; bool_t l_v9168;
	bool_t l_v9176; struct pypy_header0 *l_v9120;
	struct pypy_object0 *l_v9178; struct pypy_object_vtable0 *l_v9155;
	struct pypy_object_vtable0 *l_v9159;
	struct pypy_object_vtable0 *l_v9163;
	struct pypy_object_vtable0 *l_v9167;
	struct pypy_object_vtable0 *l_v9175;
	struct pypy_object_vtable0 *l_v9179;
	struct pypy_rpy_string0 *l_v9087; struct pypy_rpy_string0 *l_v9135;
	struct pypy_rpy_string0 *l_v9174; struct pypy_rpy_string0 *l_v9185;
	struct pypy_rpy_string0 *l_v9186; void* l_v9088; void* l_v9089;
	void* l_v9091; void* l_v9096; void* l_v9097; void* l_v9099;
	void* l_v9114; void* l_v9116; void* l_v9117; void* l_v9122;
	void* l_v9123; void* l_v9125; void* l_v9126; void* l_v9127;
	void* l_v9129; void* l_v9139; void* l_v9143; void* l_v9146;
	void* l_v9158; void* l_v9166; void* l_v9187; void* l_v9188;
	goto block0;

    block0:
	OP_INT_EQ(l_num_items_3, 1L, l_v9092);
	if (l_v9092) {
		goto block34;
	}
	l_i_61 = 0L;
	l_length_61 = 0L;
	goto block1;

    block1:
	while (1) {
		OP_INT_LT(l_i_61, l_num_items_3, l_v9093);
		if (!l_v9093) break;
		goto block31;
	  block1_back: ;
	}
	goto block2;

    block2:
	OP_INT_GE(l_length_61, 0L, l_v9094);
	RPyAssert(l_v9094, "negative string length");
	l_v9096 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v9096, sizeof(void*), l_v9097);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v9097;
	l_v9099 = (void*)l_items_13;
	((void* *) (((char *)l_v9096) + 0))[0] = l_v9099;
	OP_RAW_MALLOC_USAGE((0 + offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v9101);
	OP_INT_SUB(67583L, l_v9101, l_maxsize_17);
	OP_INT_LT(l_maxsize_17, 0L, l_v9102);
	if (l_v9102) {
		l_toobig_18 = 0UL;
		goto block4;
	}
	goto block3;

    block3:
	OP_RAW_MALLOC_USAGE(sizeof(char), l_v9103);
	OP_INT_IS_TRUE(l_v9103, l_v9104);
	if (l_v9104) {
		goto block30;
	}
	l_toobig_18 = 2147483648UL;
	goto block4;

    block4:
	OP_CAST_INT_TO_UINT(l_length_61, l_v9105);
	OP_UINT_GE(l_v9105, l_toobig_18, l_v9106);
	if (l_v9106) {
		goto block28;
	}
	goto block5;

    block5:
	OP_INT_MUL(sizeof(char), l_length_61, l_v9107);
	OP_INT_ADD((0 + offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v9107, l_v9086);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v9108);
	if (l_v9108) {
		goto block26;
	}
	goto block6;

    block6:
	l_v9109 = ROUND_UP_FOR_ALLOCATION(l_v9086, 0L);
	l_totalsize_33 = l_v9109;
	goto block7;

    block7:
	OP_RAW_MALLOC_USAGE(l_totalsize_33, l_v9110);
	OP_RAW_MALLOC_USAGE((sizeof(struct pypy_header0) + sizeof(void*)), l_v9111);
	OP_INT_GE(l_v9110, l_v9111, l_v9112);
	RPyAssert(l_v9112, "malloc_varsize_clear(): totalsize < minimalsize");
	l_v9088 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	OP_ADR_ADD(l_v9088, l_totalsize_33, l_v9114);
	(&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free = l_v9114;
	l_v9116 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	l_v9117 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_top;
	OP_ADR_GT(l_v9116, l_v9117, l_v9118);
	if (l_v9118) {
		goto block24;
	}
	l_v9089 = l_v9088;
	goto block8;

    block8:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v9119);
	if (l_v9119) {
		goto block22;
	}
	goto block9;

    block9:
	l_v9120 = (struct pypy_header0 *)l_v9089;
	RPyField(l_v9120, h_tid) = (GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+0L);
	OP_ADR_ADD(l_v9089, 0, l_v9122);
	OP_ADR_ADD(l_v9122, (offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, length)), l_v9123);
	((Signed *) (((char *)l_v9123) + 0))[0] = l_length_61;
	l_v9187 = l_v9122;
	goto block10;

    block10:
	l_v9125 = (void*)l_v9187;
	l_v9188 = l_v9125;
	goto block11;

    block11:
	l_v9126 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v9126, sizeof(void*), l_v9127);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v9127;
	l_v9129 = ((void* *) (((char *)l_v9127) + 0))[0];
	l_items_13 = l_v9129; /* for moving GCs */
	l_dst_1 = (struct pypy_rpy_string0 *)l_v9188;
	l_v9131 = (l_dst_1 != NULL);
	if (!l_v9131) {
		goto block21;
	}
	goto block12;

    block12:
	OP_INT_IS_TRUE(MALLOC_ZERO_FILLED, l_v9132);
	if (l_v9132) {
		l_dststart_1 = 0L;
		l_i_60 = 0L;
		goto block14;
	}
	goto block13;

    block13:
	RPyField(l_dst_1, rs_hash) = 0L;
	l_dststart_1 = 0L;
	l_i_60 = 0L;
	goto block14;

    block14:
	while (1) {
		OP_INT_LT(l_i_60, l_num_items_3, l_v9134);
		if (!l_v9134) break;
		goto block16;
	  block14_back: ;
	}
	l_v9186 = l_dst_1;
	goto block15;

    block15:
	RPY_DEBUG_RETURN();
	return l_v9186;

    block16:
	l_v9135 = RPyItem(l_items_13, l_i_60);
	l_length_60 = RPyField(l_v9135, rs_chars).length;
	l_v9087 = RPyItem(l_items_13, l_i_60);
	OP_INT_GE(l_length_60, 0L, l_v9136);
	if (l_v9136) {
		goto block18;
	}
	goto block17;

    block17:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("ll_join_strs__v161___simple_call__function_l");
	l_v9186 = ((struct pypy_rpy_string0 *) NULL);
	goto block15;

    block18:
	l_v9139 = (void*)l_v9087;
	OP_ADR_ADD(l_v9139, (offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v9091);
	OP_INT_GE(l_dststart_1, 0L, l_v9140);
	if (l_v9140) {
		goto block20;
	}
	goto block19;

    block19:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("ll_join_strs__v161___simple_call__function_l");
	l_v9186 = ((struct pypy_rpy_string0 *) NULL);
	goto block15;

    block20:
	l_v9143 = (void*)l_dst_1;
	OP_INT_MUL(sizeof(char), l_dststart_1, l_v9144);
	OP_INT_ADD((offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items)), l_v9144, l_v9145);
	OP_ADR_ADD(l_v9143, l_v9145, l_v9146);
	OP_INT_MUL(sizeof(char), l_length_60, l_v9147);
	OP_RAW_MEMCOPY(l_v9091, l_v9146, l_v9147, /* nothing */);
	/* kept alive: l_v9091 */
	/* kept alive: l_v9146 */
	OP_INT_ADD(l_dststart_1, l_length_60, l_v9151);
	OP_INT_ADD(l_i_60, 1L, l_v9152);
	l_dststart_1 = l_v9151;
	l_i_60 = l_v9152;
	goto block14_back;

    block21:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_join_strs__v161___simple_call__function_l");
	l_v9186 = ((struct pypy_rpy_string0 *) NULL);
	goto block15;

    block22:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v9155 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9156 = (l_v9155 == NULL);
	if (!l_v9156) {
		goto block23;
	}
	goto block9;

    block23:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_join_strs__v161___simple_call__function_l");
	l_v9188 = NULL;
	goto block11;

    block24:
	l_v9158 = pypy_g_MiniMarkGC_collect_and_reserve((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_v9088, l_totalsize_33);
	l_v9159 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9160 = (l_v9159 == NULL);
	if (!l_v9160) {
		goto block25;
	}
	l_v9089 = l_v9158;
	goto block8;

    block25:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_join_strs__v161___simple_call__function_l");
	l_v9188 = NULL;
	goto block11;

    block26:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v9162 = (Signed)0;
	l_v9163 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9164 = (l_v9163 == NULL);
	if (!l_v9164) {
		goto block27;
	}
	l_totalsize_33 = l_v9162;
	goto block7;

    block27:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_join_strs__v161___simple_call__function_l");
	l_v9188 = NULL;
	goto block11;

    block28:
	l_v9166 = pypy_g_MiniMarkGC_external_malloc((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17), l_length_61, 1);
	l_v9167 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9168 = (l_v9167 == NULL);
	if (!l_v9168) {
		goto block29;
	}
	l_v9187 = l_v9166;
	goto block10;

    block29:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_join_strs__v161___simple_call__function_l");
	l_v9188 = NULL;
	goto block11;

    block30:
	OP_RAW_MALLOC_USAGE(sizeof(char), l_v9170);
	OP_INT_FLOORDIV(l_maxsize_17, l_v9170, l_v9171);
	OP_CAST_INT_TO_UINT(l_v9171, l_v9172);
	OP_UINT_ADD(l_v9172, 1UL, l_v9173);
	l_toobig_18 = l_v9173;
	goto block4;

    block31:
	l_v9174 = RPyItem(l_items_13, l_i_61);
	l_v9090 = RPyField(l_v9174, rs_chars).length;
	OP_INT_ADD_NONNEG_OVF(l_length_61, l_v9090, l_v9085);
	l_v9175 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9176 = (l_v9175 == NULL);
	if (!l_v9176) {
		goto block33;
	}
	goto block32;

    block32:
	OP_INT_ADD(l_i_61, 1L, l_v9177);
	l_i_61 = l_v9177;
	l_length_61 = l_v9085;
	goto block1_back;

    block33:
	l_v9178 = (&pypy_g_ExcData)->ed_exc_value;
	l_v9179 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("ll_join_strs__v161___simple_call__function_l", l_v9179, l_v9179 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_v9179 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("ll_join_strs__v161___simple_call__function_l");
	l_v9186 = ((struct pypy_rpy_string0 *) NULL);
	goto block15;

    block34:
	l_v9185 = RPyItem(l_items_13, 0L);
	l_v9186 = l_v9185;
	goto block15;
}
/*/*/
Signed pypy_g_ll_search__rpy_stringPtr_rpy_stringPtr_Signed_Si(struct pypy_rpy_string0 *l_s1_11, struct pypy_rpy_string0 *l_s2_5, Signed l_start_16, Signed l_end_2, Signed l_mode_2) {
	Signed l_count_10; Signed l_count_9; Signed l_i_62; Signed l_m_0;
	Signed l_mask_10; Signed l_mask_11; Signed l_mask_12;
	Signed l_mask_13; Signed l_mask_9; Signed l_mlast_0; Signed l_next_0;
	Signed l_next_1; Signed l_next_2; Signed l_skip_0; Signed l_skip_1;
	Signed l_v9189; Signed l_v9190; Signed l_v9191; Signed l_v9192;
	Signed l_v9193; Signed l_v9194; Signed l_v9195; Signed l_v9196;
	Signed l_v9197; Signed l_v9198; Signed l_v9202; Signed l_v9203;
	Signed l_v9204; Signed l_v9205; Signed l_v9208; Signed l_v9209;
	Signed l_v9210; Signed l_v9214; Signed l_v9215; Signed l_v9216;
	Signed l_v9217; Signed l_v9223; Signed l_v9225; Signed l_v9227;
	Signed l_v9228; Signed l_v9229; Signed l_v9230; Signed l_v9232;
	Signed l_v9234; Signed l_v9235; Signed l_v9239; Signed l_v9241;
	Signed l_v9242; Signed l_v9244; Signed l_v9245; Signed l_v9246;
	Signed l_v9247; Signed l_v9249; Signed l_v9252; Signed l_v9253;
	Signed l_v9254; Signed l_v9258; Signed l_v9259; Signed l_v9261;
	Signed l_v9262; Signed l_v9263; Signed l_v9264; Signed l_v9265;
	Signed l_v9266; Signed l_v9268; Signed l_v9269; Signed l_v9271;
	Signed l_v9274; Signed l_v9275; Signed l_v9277; Signed l_v9279;
	Signed l_v9280; Signed l_v9282; Signed l_v9283; Signed l_v9284;
	Signed l_v9286; Signed l_v9287; Signed l_v9291; Signed l_v9292;
	Signed l_v9294; Signed l_v9296; Signed l_v9297; Signed l_v9298;
	Signed l_v9300; Signed l_v9301; Signed l_v9302; Signed l_v9304;
	Signed l_v9305; Signed l_v9306; Signed l_v9307; Signed l_v9308;
	bool_t l_v9199; bool_t l_v9200; bool_t l_v9206; bool_t l_v9213;
	bool_t l_v9218; bool_t l_v9219; bool_t l_v9222; bool_t l_v9224;
	bool_t l_v9231; bool_t l_v9233; bool_t l_v9238; bool_t l_v9240;
	bool_t l_v9248; bool_t l_v9250; bool_t l_v9257; bool_t l_v9267;
	bool_t l_v9273; bool_t l_v9276; bool_t l_v9278; bool_t l_v9285;
	bool_t l_v9290; bool_t l_v9293; bool_t l_v9295; bool_t l_v9303;
	char l_v9201; char l_v9207; char l_v9211; char l_v9212; char l_v9220;
	char l_v9221; char l_v9226; char l_v9236; char l_v9237; char l_v9243;
	char l_v9251; char l_v9255; char l_v9256; char l_v9260; char l_v9270;
	char l_v9272; char l_v9281; char l_v9288; char l_v9289; char l_v9299;
	Signed l_w_0;
	goto block0;

    block0:
	OP_INT_SUB(l_end_2, l_start_16, l_v9198);
	l_m_0 = RPyField(l_s2_5, rs_chars).length;
	OP_INT_SUB(l_v9198, l_m_0, l_w_0);
	OP_INT_LT(l_w_0, 0L, l_v9199);
	if (l_v9199) {
		l_v9306 = -1L;
		goto block9;
	}
	goto block1;

    block1:
	OP_INT_SUB(l_m_0, 1L, l_mlast_0);
	OP_INT_SUB(l_mlast_0, 1L, l_v9194);
	OP_INT_NE(l_mode_2, 2L, l_v9200);
	if (l_v9200) {
		l_next_1 = 0L;
		l_skip_1 = l_v9194;
		l_mask_13 = 0L;
		goto block20;
	}
	goto block2;

    block2:
	l_v9201 = RPyField(l_s2_5, rs_chars).items[0L];
	OP_CAST_CHAR_TO_INT(l_v9201, l_v9202);
	OP_INT_AND(l_v9202, 31L, l_v9203);
	OP_INT_LSHIFT(1L, l_v9203, l_v9204);
	OP_INT_OR(0L, l_v9204, l_v9205);
	l_next_0 = l_mlast_0;
	l_skip_0 = l_v9194;
	l_v9191 = 0L;
	l_mask_9 = l_v9205;
	goto block3;

    block3:
	while (1) {
		OP_INT_LE(l_next_0, l_v9191, l_v9206);
		if (l_v9206) break;
		goto block4;
	  block3_back: ;
	}
	goto block6;

    block4:
	OP_INT_ADD(l_next_0, -1L, l_v9193);
	l_v9207 = RPyField(l_s2_5, rs_chars).items[l_next_0];
	OP_CAST_CHAR_TO_INT(l_v9207, l_v9208);
	OP_INT_AND(l_v9208, 31L, l_v9209);
	OP_INT_LSHIFT(1L, l_v9209, l_v9210);
	OP_INT_OR(l_mask_9, l_v9210, l_mask_12);
	l_v9211 = RPyField(l_s2_5, rs_chars).items[l_next_0];
	l_v9212 = RPyField(l_s2_5, rs_chars).items[0L];
	OP_CHAR_EQ(l_v9211, l_v9212, l_v9213);
	if (l_v9213) {
		goto block5;
	}
	l_next_0 = l_v9193;
	l_mask_9 = l_mask_12;
	goto block3_back;

    block5:
	OP_INT_SUB(l_next_0, 1L, l_v9214);
	l_next_0 = l_v9193;
	l_skip_0 = l_v9214;
	l_mask_9 = l_mask_12;
	goto block3;

    block6:
	OP_INT_ADD(l_start_16, l_w_0, l_v9215);
	OP_INT_ADD(l_v9215, 1L, l_v9216);
	l_v9196 = l_v9216;
	goto block7;

    block7:
	while (1) {
		OP_INT_SUB(l_v9196, 1L, l_v9217);
		OP_INT_GE(l_v9217, l_start_16, l_v9218);
		if (!l_v9218) break;
		goto block10;
	  block7_back: ;
	}
	l_count_10 = 0L;
	goto block8;

    block8:
	OP_INT_NE(l_mode_2, 0L, l_v9219);
	if (l_v9219) {
		l_v9306 = -1L;
		goto block9;
	}
	l_v9306 = l_count_10;
	goto block9;

    block9:
	RPY_DEBUG_RETURN();
	return l_v9306;

    block10:
	OP_INT_SUB(l_v9196, 1L, l_i_62);
	l_v9220 = RPyField(l_s1_11, rs_chars).items[l_i_62];
	l_v9221 = RPyField(l_s2_5, rs_chars).items[0L];
	OP_CHAR_EQ(l_v9220, l_v9221, l_v9222);
	if (l_v9222) {
		l_v9195 = 0L;
		l_next_2 = l_mlast_0;
		goto block14;
	}
	goto block11;

    block11:
	OP_INT_SUB(l_i_62, 1L, l_v9223);
	OP_INT_GE(l_v9223, 0L, l_v9224);
	if (l_v9224) {
		goto block12;
	}
	l_v9196 = l_i_62;
	goto block7_back;

    block12:
	OP_INT_SUB(l_i_62, 1L, l_v9225);
	l_v9226 = RPyField(l_s1_11, rs_chars).items[l_v9225];
	OP_CAST_CHAR_TO_INT(l_v9226, l_v9227);
	OP_INT_AND(l_v9227, 31L, l_v9228);
	OP_INT_LSHIFT(1L, l_v9228, l_v9229);
	OP_INT_AND(l_mask_9, l_v9229, l_v9230);
	OP_INT_IS_TRUE(l_v9230, l_v9231);
	if (l_v9231) {
		l_v9196 = l_i_62;
		goto block7;
	}
	goto block13;

    block13:
	OP_INT_SUB(l_i_62, l_m_0, l_v9232);
	l_v9196 = l_v9232;
	goto block7;

    block14:
	while (1) {
		OP_INT_LE(l_next_2, l_v9195, l_v9233);
		if (l_v9233) break;
		goto block15;
	  block14_back: ;
	}
	l_v9306 = l_i_62;
	goto block9;

    block15:
	OP_INT_ADD(l_next_2, -1L, l_v9234);
	OP_INT_ADD(l_i_62, l_next_2, l_v9235);
	l_v9236 = RPyField(l_s1_11, rs_chars).items[l_v9235];
	l_v9237 = RPyField(l_s2_5, rs_chars).items[l_next_2];
	OP_CHAR_NE(l_v9236, l_v9237, l_v9238);
	if (l_v9238) {
		goto block16;
	}
	l_next_2 = l_v9234;
	goto block14_back;

    block16:
	OP_INT_SUB(l_i_62, 1L, l_v9239);
	OP_INT_GE(l_v9239, 0L, l_v9240);
	if (l_v9240) {
		goto block18;
	}
	goto block17;

    block17:
	OP_INT_SUB(l_i_62, l_skip_0, l_v9241);
	l_v9196 = l_v9241;
	goto block7;

    block18:
	OP_INT_SUB(l_i_62, 1L, l_v9242);
	l_v9243 = RPyField(l_s1_11, rs_chars).items[l_v9242];
	OP_CAST_CHAR_TO_INT(l_v9243, l_v9244);
	OP_INT_AND(l_v9244, 31L, l_v9245);
	OP_INT_LSHIFT(1L, l_v9245, l_v9246);
	OP_INT_AND(l_mask_9, l_v9246, l_v9247);
	OP_INT_IS_TRUE(l_v9247, l_v9248);
	if (l_v9248) {
		goto block17;
	}
	goto block19;

    block19:
	OP_INT_SUB(l_i_62, l_m_0, l_v9249);
	l_v9196 = l_v9249;
	goto block7;

    block20:
	while (1) {
		OP_INT_GE(l_next_1, l_mlast_0, l_v9250);
		if (l_v9250) break;
		goto block21;
	  block20_back: ;
	}
	goto block23;

    block21:
	OP_INT_ADD(l_next_1, 1L, l_v9192);
	l_v9251 = RPyField(l_s2_5, rs_chars).items[l_next_1];
	OP_CAST_CHAR_TO_INT(l_v9251, l_v9252);
	OP_INT_AND(l_v9252, 31L, l_v9253);
	OP_INT_LSHIFT(1L, l_v9253, l_v9254);
	OP_INT_OR(l_mask_13, l_v9254, l_mask_11);
	l_v9255 = RPyField(l_s2_5, rs_chars).items[l_next_1];
	l_v9256 = RPyField(l_s2_5, rs_chars).items[l_mlast_0];
	OP_CHAR_EQ(l_v9255, l_v9256, l_v9257);
	if (l_v9257) {
		goto block22;
	}
	l_next_1 = l_v9192;
	l_mask_13 = l_mask_11;
	goto block20_back;

    block22:
	OP_INT_SUB(l_mlast_0, l_next_1, l_v9258);
	OP_INT_SUB(l_v9258, 1L, l_v9259);
	l_next_1 = l_v9192;
	l_skip_1 = l_v9259;
	l_mask_13 = l_mask_11;
	goto block20;

    block23:
	l_v9260 = RPyField(l_s2_5, rs_chars).items[l_mlast_0];
	OP_CAST_CHAR_TO_INT(l_v9260, l_v9261);
	OP_INT_AND(l_v9261, 31L, l_v9262);
	OP_INT_LSHIFT(1L, l_v9262, l_v9263);
	OP_INT_OR(l_mask_13, l_v9263, l_mask_10);
	OP_INT_SUB(l_start_16, 1L, l_v9264);
	l_count_9 = 0L;
	l_v9190 = l_v9264;
	goto block24;

    block24:
	while (1) {
		OP_INT_ADD(l_v9190, 1L, l_v9265);
		OP_INT_ADD(l_start_16, l_w_0, l_v9266);
		OP_INT_LE(l_v9265, l_v9266, l_v9267);
		if (!l_v9267) break;
		goto block25;
	  block24_back: ;
	}
	l_count_10 = l_count_9;
	goto block8;

    block25:
	OP_INT_ADD(l_v9190, 1L, l_v9189);
	OP_INT_ADD(l_v9189, l_m_0, l_v9268);
	OP_INT_SUB(l_v9268, 1L, l_v9269);
	l_v9270 = RPyField(l_s1_11, rs_chars).items[l_v9269];
	OP_INT_SUB(l_m_0, 1L, l_v9271);
	l_v9272 = RPyField(l_s2_5, rs_chars).items[l_v9271];
	OP_CHAR_EQ(l_v9270, l_v9272, l_v9273);
	if (l_v9273) {
		l_v9197 = 0L;
		goto block30;
	}
	goto block26;

    block26:
	OP_INT_ADD(l_v9189, l_m_0, l_v9274);
	l_v9275 = RPyField(l_s1_11, rs_chars).length;
	OP_INT_LT(l_v9274, l_v9275, l_v9276);
	if (l_v9276) {
		goto block29;
	}
	l_v9307 = 1L;
	goto block27;

    block27:
	OP_INT_AND(l_mask_10, l_v9307, l_v9277);
	OP_INT_IS_TRUE(l_v9277, l_v9278);
	if (l_v9278) {
		l_v9190 = l_v9189;
		goto block24_back;
	}
	goto block28;

    block28:
	OP_INT_ADD(l_v9189, l_m_0, l_v9279);
	l_v9190 = l_v9279;
	goto block24;

    block29:
	OP_INT_ADD(l_v9189, l_m_0, l_v9280);
	l_v9281 = RPyField(l_s1_11, rs_chars).items[l_v9280];
	OP_CAST_CHAR_TO_INT(l_v9281, l_v9282);
	OP_INT_AND(l_v9282, 31L, l_v9283);
	OP_INT_LSHIFT(1L, l_v9283, l_v9284);
	l_v9307 = l_v9284;
	goto block27;

    block30:
	while (1) {
		OP_INT_GE(l_v9197, l_mlast_0, l_v9285);
		if (l_v9285) break;
		goto block31;
	  block30_back: ;
	}
	goto block37;

    block31:
	OP_INT_ADD(l_v9197, 1L, l_v9286);
	OP_INT_ADD(l_v9189, l_v9197, l_v9287);
	l_v9288 = RPyField(l_s1_11, rs_chars).items[l_v9287];
	l_v9289 = RPyField(l_s2_5, rs_chars).items[l_v9197];
	OP_CHAR_NE(l_v9288, l_v9289, l_v9290);
	if (l_v9290) {
		goto block32;
	}
	l_v9197 = l_v9286;
	goto block30_back;

    block32:
	OP_INT_ADD(l_v9189, l_m_0, l_v9291);
	l_v9292 = RPyField(l_s1_11, rs_chars).length;
	OP_INT_LT(l_v9291, l_v9292, l_v9293);
	if (l_v9293) {
		goto block36;
	}
	l_v9308 = 1L;
	goto block33;

    block33:
	OP_INT_AND(l_mask_10, l_v9308, l_v9294);
	OP_INT_IS_TRUE(l_v9294, l_v9295);
	if (l_v9295) {
		goto block35;
	}
	goto block34;

    block34:
	OP_INT_ADD(l_v9189, l_m_0, l_v9296);
	l_v9190 = l_v9296;
	goto block24;

    block35:
	OP_INT_ADD(l_v9189, l_skip_1, l_v9297);
	l_v9190 = l_v9297;
	goto block24;

    block36:
	OP_INT_ADD(l_v9189, l_m_0, l_v9298);
	l_v9299 = RPyField(l_s1_11, rs_chars).items[l_v9298];
	OP_CAST_CHAR_TO_INT(l_v9299, l_v9300);
	OP_INT_AND(l_v9300, 31L, l_v9301);
	OP_INT_LSHIFT(1L, l_v9301, l_v9302);
	l_v9308 = l_v9302;
	goto block33;

    block37:
	OP_INT_NE(l_mode_2, 0L, l_v9303);
	if (l_v9303) {
		l_v9306 = l_v9189;
		goto block9;
	}
	goto block38;

    block38:
	OP_INT_ADD(l_count_9, 1L, l_v9304);
	OP_INT_ADD(l_v9189, l_mlast_0, l_v9305);
	l_count_9 = l_v9304;
	l_v9190 = l_v9305;
	goto block24;
}
/*/*/
/***********************************************************/
