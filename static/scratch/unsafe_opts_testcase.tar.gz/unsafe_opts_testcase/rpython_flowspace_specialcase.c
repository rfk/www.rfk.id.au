/***********************************************************/
/***  Implementations                                    ***/

#define PYPY_FILE_NAME "rpython_flowspace_specialcase.c"
#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"
#include "src/g_include.h"

/*/*/
void pypy_g_rpython_print_item(struct pypy_rpy_string0 *l_v418) {
	Signed l_v419; Signed l_v421; Signed l_v422; Signed l_v423;
	Signed l_v424; Signed l_v426; Signed l_v440; Signed l_v446;
	Signed l_v450; bool_t l_v425; bool_t l_v439; bool_t l_v441;
	bool_t l_v449; bool_t l_v451; char l_v420;
	struct pypy_array6 *l_v443; struct pypy_array6 *l_v453;
	struct pypy_object_vtable0 *l_v438;
	struct pypy_object_vtable0 *l_v448; void* l_v427; void* l_v428;
	void* l_v430; void* l_v433; void* l_v434; void* l_v436;
	goto block0;

    block0:
	l_v419 = 0L;
	goto block1;

    block1:
	while (1) {
		l_v424 = RPyField(l_v418, rs_chars).length;
		OP_INT_GE(l_v419, l_v424, l_v425);
		if (l_v425) break;
		goto block2;
	  block1_back: ;
	}
	goto block6;

    block2:
	OP_INT_ADD(l_v419, 1L, l_v421);
	l_v420 = RPyField(l_v418, rs_chars).items[l_v419];
	l_v422 = (&pypy_g_list)->l_length;
	OP_INT_ADD(l_v422, 1L, l_v426);
	l_v427 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v427, sizeof(void*), l_v428);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v428;
	l_v430 = (void*)l_v418;
	((void* *) (((char *)l_v427) + 0))[0] = l_v430;
	pypy_g__ll_list_resize_ge_look_inside_iff__listPtr_Sign((&pypy_g_list), l_v426);
	l_v433 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v433, sizeof(void*), l_v434);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v434;
	l_v436 = ((void* *) (((char *)l_v434) + 0))[0];
	l_v418 = l_v436; /* for moving GCs */
	l_v438 = (&pypy_g_ExcData)->ed_exc_type;
	l_v439 = (l_v438 == NULL);
	if (!l_v439) {
		goto block4;
	}
	goto block3;

    block3:
	l_v440 = (&pypy_g_list)->l_length;
	OP_INT_LT(l_v422, l_v440, l_v441);
	RPyAssert(l_v441, "setitem out of bounds");
	l_v443 = (&pypy_g_list)->l_items;
	RPyItem(l_v443, l_v422) = l_v420;
	l_v419 = l_v421;
	goto block1_back;

    block4:
	PYPY_DEBUG_RECORD_TRACEBACK("rpython_print_item");
	goto block5;

    block5:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block6:
	l_v423 = (&pypy_g_list)->l_length;
	OP_INT_ADD(l_v423, 1L, l_v446);
	pypy_g__ll_list_resize_ge_look_inside_iff__listPtr_Sign((&pypy_g_list), l_v446);
	l_v448 = (&pypy_g_ExcData)->ed_exc_type;
	l_v449 = (l_v448 == NULL);
	if (!l_v449) {
		goto block8;
	}
	goto block7;

    block7:
	l_v450 = (&pypy_g_list)->l_length;
	OP_INT_LT(l_v423, l_v450, l_v451);
	RPyAssert(l_v451, "setitem out of bounds");
	l_v453 = (&pypy_g_list)->l_items;
	RPyItem(l_v453, l_v423) = ' ';
	goto block5;

    block8:
	PYPY_DEBUG_RECORD_TRACEBACK("rpython_print_item");
	goto block5;
}
/*/*/
void pypy_g_rpython_print_newline(void) {
	struct pypy_array6 *l_chars_2; Signed l_i_5; Signed l_i_6;
	Signed l_length_24; Signed l_maxsize_0; Signed l_maxsize_1;
	struct pypy_rpy_string0 *l_r_0; void* l_result_2; void* l_result_3;
	Unsigned l_toobig_1; Unsigned l_toobig_2; Signed l_totalsize_2;
	Signed l_v458; Signed l_v459; Signed l_v460; Signed l_v463;
	Signed l_v465; Signed l_v466; Signed l_v467; Signed l_v481;
	Signed l_v483; Signed l_v487; Signed l_v489; Signed l_v490;
	Signed l_v491; Signed l_v531; Signed l_v541; Signed l_v549;
	Signed l_v550; Signed l_v560; Signed l_v562; Signed l_v566;
	Signed l_v568; Signed l_v569; Signed l_v570; Signed l_v596;
	Signed l_v606; Signed l_v614; Signed l_v615; Unsigned l_v485;
	Unsigned l_v551; Unsigned l_v552; Unsigned l_v564; Unsigned l_v616;
	Unsigned l_v617; bool_t l_v464; bool_t l_v468; bool_t l_v470;
	bool_t l_v473; bool_t l_v474; bool_t l_v482; bool_t l_v484;
	bool_t l_v486; bool_t l_v488; bool_t l_v492; bool_t l_v498;
	bool_t l_v499; bool_t l_v511; bool_t l_v512; bool_t l_v514;
	bool_t l_v527; bool_t l_v535; bool_t l_v539; bool_t l_v543;
	bool_t l_v547; bool_t l_v553; bool_t l_v561; bool_t l_v563;
	bool_t l_v565; bool_t l_v567; bool_t l_v571; bool_t l_v577;
	bool_t l_v578; bool_t l_v590; bool_t l_v591; bool_t l_v593;
	bool_t l_v600; bool_t l_v604; bool_t l_v608; bool_t l_v612;
	char l_v529; char l_v594; struct pypy_header0 *l_v500;
	struct pypy_header0 *l_v579; struct pypy_object_vtable0 *l_v526;
	struct pypy_object_vtable0 *l_v534;
	struct pypy_object_vtable0 *l_v538;
	struct pypy_object_vtable0 *l_v542;
	struct pypy_object_vtable0 *l_v546;
	struct pypy_object_vtable0 *l_v599;
	struct pypy_object_vtable0 *l_v603;
	struct pypy_object_vtable0 *l_v607;
	struct pypy_object_vtable0 *l_v611; struct pypy_rpy_string0 *l_v457;
	struct pypy_rpy_string0 *l_v619; struct pypy_rpy_string0 *l_v622;
	void* l_v461; void* l_v462; void* l_v476; void* l_v477; void* l_v479;
	void* l_v494; void* l_v496; void* l_v497; void* l_v502; void* l_v503;
	void* l_v505; void* l_v506; void* l_v507; void* l_v509; void* l_v515;
	void* l_v516; void* l_v518; void* l_v521; void* l_v522; void* l_v524;
	void* l_v537; void* l_v545; void* l_v555; void* l_v556; void* l_v558;
	void* l_v573; void* l_v575; void* l_v576; void* l_v581; void* l_v582;
	void* l_v584; void* l_v585; void* l_v586; void* l_v588; void* l_v602;
	void* l_v610; void* l_v620; void* l_v621; void* l_v623; void* l_v624;
	goto block0;

    block0:
	l_v463 = (&pypy_g_list)->l_length;
	OP_INT_NE(l_v463, 0L, l_v464);
	if (l_v464) {
		goto block3;
	}
	l_v619 = (&pypy_g_rpy_string_14.b);
	goto block1;

    block1:
	l_v465 = pypy_g_ll_os_ll_os_write(2L, l_v619);
	goto block2;

    block2:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block3:
	l_v466 = (&pypy_g_list)->l_length;
	OP_INT_ADD(-1L, l_v466, l_v467);
	OP_INT_GE(l_v467, 0L, l_v468);
	RPyAssert(l_v468, "negative list setitem index out of bound");
	l_length_24 = (&pypy_g_list)->l_length;
	OP_INT_LT(l_v467, l_length_24, l_v470);
	RPyAssert(l_v470, "setitem out of bounds");
	l_chars_2 = (&pypy_g_list)->l_items;
	RPyItem(l_chars_2, l_v467) = ((char)10);
	OP_INT_IS_TRUE(0 /* we are not jitted here */, l_v473);
	if (l_v473) {
		goto block30;
	}
	goto block4;

    block4:
	OP_INT_GE(l_length_24, 0L, l_v474);
	RPyAssert(l_v474, "negative string length");
	l_v476 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v476, sizeof(void*), l_v477);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v477;
	l_v479 = (void*)l_chars_2;
	((void* *) (((char *)l_v476) + 0))[0] = l_v479;
	OP_RAW_MALLOC_USAGE((0 + offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v481);
	OP_INT_SUB(67583L, l_v481, l_maxsize_0);
	OP_INT_LT(l_maxsize_0, 0L, l_v482);
	if (l_v482) {
		l_toobig_1 = 0UL;
		goto block6;
	}
	goto block5;

    block5:
	OP_RAW_MALLOC_USAGE(sizeof(char), l_v483);
	OP_INT_IS_TRUE(l_v483, l_v484);
	if (l_v484) {
		goto block29;
	}
	l_toobig_1 = 2147483648UL;
	goto block6;

    block6:
	OP_CAST_INT_TO_UINT(l_length_24, l_v485);
	OP_UINT_GE(l_v485, l_toobig_1, l_v486);
	if (l_v486) {
		goto block27;
	}
	goto block7;

    block7:
	OP_INT_MUL(sizeof(char), l_length_24, l_v487);
	OP_INT_ADD((0 + offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v487, l_v458);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v488);
	if (l_v488) {
		goto block25;
	}
	goto block8;

    block8:
	l_v489 = ROUND_UP_FOR_ALLOCATION(l_v458, 0L);
	l_totalsize_2 = l_v489;
	goto block9;

    block9:
	OP_RAW_MALLOC_USAGE(l_totalsize_2, l_v490);
	OP_RAW_MALLOC_USAGE((sizeof(struct pypy_header0) + sizeof(void*)), l_v491);
	OP_INT_GE(l_v490, l_v491, l_v492);
	RPyAssert(l_v492, "malloc_varsize_clear(): totalsize < minimalsize");
	l_result_3 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	OP_ADR_ADD(l_result_3, l_totalsize_2, l_v494);
	(&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free = l_v494;
	l_v496 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	l_v497 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_top;
	OP_ADR_GT(l_v496, l_v497, l_v498);
	if (l_v498) {
		goto block23;
	}
	l_v461 = l_result_3;
	goto block10;

    block10:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v499);
	if (l_v499) {
		goto block21;
	}
	goto block11;

    block11:
	l_v500 = (struct pypy_header0 *)l_v461;
	RPyField(l_v500, h_tid) = (GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+0L);
	OP_ADR_ADD(l_v461, 0, l_v502);
	OP_ADR_ADD(l_v502, (offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, length)), l_v503);
	((Signed *) (((char *)l_v503) + 0))[0] = l_length_24;
	l_v620 = l_v502;
	goto block12;

    block12:
	l_v505 = (void*)l_v620;
	l_v621 = l_v505;
	goto block13;

    block13:
	l_v506 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v506, sizeof(void*), l_v507);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v507;
	l_v509 = ((void* *) (((char *)l_v507) + 0))[0];
	l_chars_2 = l_v509; /* for moving GCs */
	l_v457 = (struct pypy_rpy_string0 *)l_v621;
	l_v511 = (l_v457 != NULL);
	if (!l_v511) {
		goto block20;
	}
	goto block14;

    block14:
	OP_INT_IS_TRUE(MALLOC_ZERO_FILLED, l_v512);
	if (l_v512) {
		l_i_5 = 0L;
		goto block16;
	}
	goto block15;

    block15:
	RPyField(l_v457, rs_hash) = 0L;
	l_i_5 = 0L;
	goto block16;

    block16:
	while (1) {
		OP_INT_LT(l_i_5, l_length_24, l_v514);
		if (!l_v514) break;
		goto block19;
	  block16_back: ;
	}
	l_v622 = l_v457;
	goto block17;

    block17:
	l_v515 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v515, sizeof(void*), l_v516);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v516;
	l_v518 = (void*)l_v622;
	((void* *) (((char *)l_v515) + 0))[0] = l_v518;
	pypy_g_ll_listdelslice_startonly_look_inside_iff__listP((&pypy_g_list), 0L);
	l_v521 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v521, sizeof(void*), l_v522);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v522;
	l_v524 = ((void* *) (((char *)l_v522) + 0))[0];
	l_v622 = l_v524; /* for moving GCs */
	l_v526 = (&pypy_g_ExcData)->ed_exc_type;
	l_v527 = (l_v526 == NULL);
	if (!l_v527) {
		goto block18;
	}
	l_v619 = l_v622;
	goto block1;

    block18:
	PYPY_DEBUG_RECORD_TRACEBACK("rpython_print_newline");
	goto block2;

    block19:
	l_v529 = RPyItem(l_chars_2, l_i_5);
	RPyField(l_v457, rs_chars).items[l_i_5] = l_v529;
	OP_INT_ADD(l_i_5, 1L, l_v531);
	l_i_5 = l_v531;
	goto block16_back;

    block20:
	PYPY_DEBUG_RECORD_TRACEBACK("rpython_print_newline");
	goto block2;

    block21:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v534 = (&pypy_g_ExcData)->ed_exc_type;
	l_v535 = (l_v534 == NULL);
	if (!l_v535) {
		goto block22;
	}
	goto block11;

    block22:
	PYPY_DEBUG_RECORD_TRACEBACK("rpython_print_newline");
	l_v621 = NULL;
	goto block13;

    block23:
	l_v537 = pypy_g_MiniMarkGC_collect_and_reserve((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_result_3, l_totalsize_2);
	l_v538 = (&pypy_g_ExcData)->ed_exc_type;
	l_v539 = (l_v538 == NULL);
	if (!l_v539) {
		goto block24;
	}
	l_v461 = l_v537;
	goto block10;

    block24:
	PYPY_DEBUG_RECORD_TRACEBACK("rpython_print_newline");
	l_v621 = NULL;
	goto block13;

    block25:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v541 = (Signed)0;
	l_v542 = (&pypy_g_ExcData)->ed_exc_type;
	l_v543 = (l_v542 == NULL);
	if (!l_v543) {
		goto block26;
	}
	l_totalsize_2 = l_v541;
	goto block9;

    block26:
	PYPY_DEBUG_RECORD_TRACEBACK("rpython_print_newline");
	l_v621 = NULL;
	goto block13;

    block27:
	l_v545 = pypy_g_MiniMarkGC_external_malloc((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17), l_length_24, 1);
	l_v546 = (&pypy_g_ExcData)->ed_exc_type;
	l_v547 = (l_v546 == NULL);
	if (!l_v547) {
		goto block28;
	}
	l_v620 = l_v545;
	goto block12;

    block28:
	PYPY_DEBUG_RECORD_TRACEBACK("rpython_print_newline");
	l_v621 = NULL;
	goto block13;

    block29:
	OP_RAW_MALLOC_USAGE(sizeof(char), l_v549);
	OP_INT_FLOORDIV(l_maxsize_0, l_v549, l_v550);
	OP_CAST_INT_TO_UINT(l_v550, l_v551);
	OP_UINT_ADD(l_v551, 1UL, l_v552);
	l_toobig_1 = l_v552;
	goto block6;

    block30:
	OP_INT_GE(l_length_24, 0L, l_v553);
	RPyAssert(l_v553, "negative string length");
	l_v555 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v555, sizeof(void*), l_v556);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v556;
	l_v558 = (void*)l_chars_2;
	((void* *) (((char *)l_v555) + 0))[0] = l_v558;
	OP_RAW_MALLOC_USAGE((0 + offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v560);
	OP_INT_SUB(67583L, l_v560, l_maxsize_1);
	OP_INT_LT(l_maxsize_1, 0L, l_v561);
	if (l_v561) {
		l_toobig_2 = 0UL;
		goto block32;
	}
	goto block31;

    block31:
	OP_RAW_MALLOC_USAGE(sizeof(char), l_v562);
	OP_INT_IS_TRUE(l_v562, l_v563);
	if (l_v563) {
		goto block53;
	}
	l_toobig_2 = 2147483648UL;
	goto block32;

    block32:
	OP_CAST_INT_TO_UINT(l_length_24, l_v564);
	OP_UINT_GE(l_v564, l_toobig_2, l_v565);
	if (l_v565) {
		goto block51;
	}
	goto block33;

    block33:
	OP_INT_MUL(sizeof(char), l_length_24, l_v566);
	OP_INT_ADD((0 + offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v566, l_v459);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v567);
	if (l_v567) {
		goto block49;
	}
	goto block34;

    block34:
	l_v568 = ROUND_UP_FOR_ALLOCATION(l_v459, 0L);
	l_v460 = l_v568;
	goto block35;

    block35:
	OP_RAW_MALLOC_USAGE(l_v460, l_v569);
	OP_RAW_MALLOC_USAGE((sizeof(struct pypy_header0) + sizeof(void*)), l_v570);
	OP_INT_GE(l_v569, l_v570, l_v571);
	RPyAssert(l_v571, "malloc_varsize_clear(): totalsize < minimalsize");
	l_v462 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	OP_ADR_ADD(l_v462, l_v460, l_v573);
	(&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free = l_v573;
	l_v575 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	l_v576 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_top;
	OP_ADR_GT(l_v575, l_v576, l_v577);
	if (l_v577) {
		goto block47;
	}
	l_result_2 = l_v462;
	goto block36;

    block36:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v578);
	if (l_v578) {
		goto block45;
	}
	goto block37;

    block37:
	l_v579 = (struct pypy_header0 *)l_result_2;
	RPyField(l_v579, h_tid) = (GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+0L);
	OP_ADR_ADD(l_result_2, 0, l_v581);
	OP_ADR_ADD(l_v581, (offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, length)), l_v582);
	((Signed *) (((char *)l_v582) + 0))[0] = l_length_24;
	l_v623 = l_v581;
	goto block38;

    block38:
	l_v584 = (void*)l_v623;
	l_v624 = l_v584;
	goto block39;

    block39:
	l_v585 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v585, sizeof(void*), l_v586);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v586;
	l_v588 = ((void* *) (((char *)l_v586) + 0))[0];
	l_chars_2 = l_v588; /* for moving GCs */
	l_r_0 = (struct pypy_rpy_string0 *)l_v624;
	l_v590 = (l_r_0 != NULL);
	if (!l_v590) {
		goto block44;
	}
	goto block40;

    block40:
	OP_INT_IS_TRUE(MALLOC_ZERO_FILLED, l_v591);
	if (l_v591) {
		l_i_6 = 0L;
		goto block42;
	}
	goto block41;

    block41:
	RPyField(l_r_0, rs_hash) = 0L;
	l_i_6 = 0L;
	goto block42;

    block42:
	while (1) {
		OP_INT_LT(l_i_6, l_length_24, l_v593);
		if (!l_v593) break;
		goto block43;
	  block42_back: ;
	}
	l_v622 = l_r_0;
	goto block17;

    block43:
	l_v594 = RPyItem(l_chars_2, l_i_6);
	RPyField(l_r_0, rs_chars).items[l_i_6] = l_v594;
	OP_INT_ADD(l_i_6, 1L, l_v596);
	l_i_6 = l_v596;
	goto block42_back;

    block44:
	PYPY_DEBUG_RECORD_TRACEBACK("rpython_print_newline");
	goto block2;

    block45:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v599 = (&pypy_g_ExcData)->ed_exc_type;
	l_v600 = (l_v599 == NULL);
	if (!l_v600) {
		goto block46;
	}
	goto block37;

    block46:
	PYPY_DEBUG_RECORD_TRACEBACK("rpython_print_newline");
	l_v624 = NULL;
	goto block39;

    block47:
	l_v602 = pypy_g_MiniMarkGC_collect_and_reserve((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_v462, l_v460);
	l_v603 = (&pypy_g_ExcData)->ed_exc_type;
	l_v604 = (l_v603 == NULL);
	if (!l_v604) {
		goto block48;
	}
	l_result_2 = l_v602;
	goto block36;

    block48:
	PYPY_DEBUG_RECORD_TRACEBACK("rpython_print_newline");
	l_v624 = NULL;
	goto block39;

    block49:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v606 = (Signed)0;
	l_v607 = (&pypy_g_ExcData)->ed_exc_type;
	l_v608 = (l_v607 == NULL);
	if (!l_v608) {
		goto block50;
	}
	l_v460 = l_v606;
	goto block35;

    block50:
	PYPY_DEBUG_RECORD_TRACEBACK("rpython_print_newline");
	l_v624 = NULL;
	goto block39;

    block51:
	l_v610 = pypy_g_MiniMarkGC_external_malloc((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17), l_length_24, 1);
	l_v611 = (&pypy_g_ExcData)->ed_exc_type;
	l_v612 = (l_v611 == NULL);
	if (!l_v612) {
		goto block52;
	}
	l_v623 = l_v610;
	goto block38;

    block52:
	PYPY_DEBUG_RECORD_TRACEBACK("rpython_print_newline");
	l_v624 = NULL;
	goto block39;

    block53:
	OP_RAW_MALLOC_USAGE(sizeof(char), l_v614);
	OP_INT_FLOORDIV(l_maxsize_1, l_v614, l_v615);
	OP_CAST_INT_TO_UINT(l_v615, l_v616);
	OP_UINT_ADD(l_v616, 1UL, l_v617);
	l_toobig_2 = l_v617;
	goto block32;
}
/*/*/
/***********************************************************/
