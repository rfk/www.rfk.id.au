/***********************************************************/
/***  Implementations                                    ***/

#define PYPY_FILE_NAME "rpython_memory_gc_minimarkpage.c"
#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"
#include "src/g_include.h"

/*/*/
void* pypy_g_ArenaCollection_malloc(struct pypy_rpython_memory_gc_minimarkpage_ArenaCollection0 *l_self_23, Signed l_size_9) {
	void* l_freeblock_0; Signed l_nsize_0;
	struct pypy_PageHeader0 *l_page_2; void* l_result_17;
	Signed l_size_class_2; Signed l_v6302; Signed l_v6311;
	Signed l_v6316; Signed l_v6317; Signed l_v6333; Signed l_v6334;
	Unsigned l_v6305; Unsigned l_v6306; Unsigned l_v6307; bool_t l_v6298;
	bool_t l_v6300; bool_t l_v6303; bool_t l_v6310; bool_t l_v6312;
	bool_t l_v6315; bool_t l_v6318; bool_t l_v6319; bool_t l_v6322;
	bool_t l_v6331; bool_t l_v6336; bool_t l_v6339; bool_t l_v6343;
	struct pypy_PageHeader0 *l_v6309; struct pypy_PageHeader0 *l_v6324;
	struct pypy_PageHeader0 *l_v6326; struct pypy_PageHeader0 *l_v6341;
	struct pypy_object_vtable0 *l_v6321;
	struct pypy_object_vtable0 *l_v6330;
	struct pypy_object_vtable0 *l_v6338;
	struct pypy_object_vtable0 *l_v6342; void* l_v6296; void* l_v6297;
	void* l_v6313; void* l_v6329; void* l_v6345; void* l_v6346;
	goto block0;

    block0:
	OP_RAW_MALLOC_USAGE(l_size_9, l_nsize_0);
	OP_INT_GT(l_nsize_0, 0L, l_v6298);
	RPyAssert(l_v6298, "malloc: size is null or negative");
	OP_INT_LE(l_nsize_0, 140L, l_v6300);
	RPyAssert(l_v6300, "malloc: size too big");
	OP_INT_AND(l_nsize_0, 3L, l_v6302);
	OP_INT_EQ(l_v6302, 0L, l_v6303);
	RPyAssert(l_v6303, "malloc: size is not aligned");
	l_v6305 = RPyField(l_self_23, ac_inst_total_memory_used);
	OP_CAST_INT_TO_UINT(l_nsize_0, l_v6306);
	OP_UINT_ADD(l_v6305, l_v6306, l_v6307);
	RPyField(l_self_23, ac_inst_total_memory_used) = l_v6307;
	OP_INT_RSHIFT(l_nsize_0, 2L, l_size_class_2);
	l_v6309 = RPyBareItem(pypy_g_array_22, l_size_class_2);
	l_v6310 = (l_v6309 == ((struct pypy_PageHeader0 *) NULL));
	if (l_v6310) {
		goto block15;
	}
	l_page_2 = l_v6309;
	goto block1;

    block1:
	l_result_17 = RPyField(l_page_2, ph_freeblock);
	l_v6311 = RPyField(l_page_2, ph_nfree);
	OP_INT_GT(l_v6311, 0L, l_v6312);
	if (l_v6312) {
		goto block12;
	}
	goto block2;

    block2:
	OP_ADR_ADD(l_result_17, l_nsize_0, l_v6313);
	l_freeblock_0 = l_v6313;
	goto block3;

    block3:
	RPyField(l_page_2, ph_freeblock) = l_freeblock_0;
	l_v6296 = (void*)l_page_2;
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v6315);
	if (l_v6315) {
		goto block10;
	}
	l_v6346 = l_v6296;
	goto block4;

    block4:
	OP_ADR_DELTA(l_freeblock_0, l_v6346, l_v6316);
	OP_INT_SUB(4096L, l_nsize_0, l_v6317);
	OP_INT_GT(l_v6316, l_v6317, l_v6318);
	if (l_v6318) {
		goto block9;
	}
	goto block5;

    block5:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v6319);
	if (l_v6319) {
		goto block7;
	}
	l_v6345 = l_result_17;
	goto block6;

    block6:
	RPY_DEBUG_RETURN();
	return l_v6345;

    block7:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v6321 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6322 = (l_v6321 == NULL);
	if (!l_v6322) {
		goto block8;
	}
	l_v6345 = l_result_17;
	goto block6;

    block8:
	PYPY_DEBUG_RECORD_TRACEBACK("ArenaCollection_malloc");
	l_v6345 = NULL;
	goto block6;

    block9:
	l_v6324 = RPyField(l_page_2, ph_nextpage);
	RPyBareItem(pypy_g_array_22, l_size_class_2) = l_v6324;
	l_v6326 = RPyBareItem(pypy_g_array_19, l_size_class_2);
	RPyField(l_page_2, ph_nextpage) = l_v6326;
	RPyBareItem(pypy_g_array_19, l_size_class_2) = l_page_2;
	goto block5;

    block10:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v6329 = (void*)0;
	l_v6330 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6331 = (l_v6330 == NULL);
	if (!l_v6331) {
		goto block11;
	}
	l_v6346 = l_v6329;
	goto block4;

    block11:
	PYPY_DEBUG_RECORD_TRACEBACK("ArenaCollection_malloc");
	l_v6345 = NULL;
	goto block6;

    block12:
	l_v6333 = RPyField(l_page_2, ph_nfree);
	OP_INT_SUB(l_v6333, 1L, l_v6334);
	RPyField(l_page_2, ph_nfree) = l_v6334;
	l_v6297 = ((void* *) (((char *)l_result_17) + 0))[0];
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v6336);
	if (l_v6336) {
		goto block13;
	}
	l_freeblock_0 = l_v6297;
	goto block3;

    block13:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v6338 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6339 = (l_v6338 == NULL);
	if (!l_v6339) {
		goto block14;
	}
	l_freeblock_0 = l_v6297;
	goto block3;

    block14:
	PYPY_DEBUG_RECORD_TRACEBACK("ArenaCollection_malloc");
	l_v6345 = NULL;
	goto block6;

    block15:
	l_v6341 = pypy_g_ArenaCollection_allocate_new_page(l_self_23, l_size_class_2);
	l_v6342 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6343 = (l_v6342 == NULL);
	if (!l_v6343) {
		goto block16;
	}
	l_page_2 = l_v6341;
	goto block1;

    block16:
	PYPY_DEBUG_RECORD_TRACEBACK("ArenaCollection_malloc");
	l_v6345 = NULL;
	goto block6;
}
/*/*/
void pypy_g_ArenaCollection_mass_free(struct pypy_rpython_memory_gc_minimarkpage_ArenaCollection0 *l_self_121, struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_ok_to_free_func_3) {
	struct pypy_ArenaReference0 *l_arena_2; Signed l_i_18; Signed l_i_19;
	Signed l_size_class_3; Signed l_v6353; Signed l_v6361;
	Signed l_v6366; Signed l_v6369; Signed l_v6370; Signed l_v6372;
	bool_t l_v6352; bool_t l_v6354; bool_t l_v6362; bool_t l_v6365;
	bool_t l_v6367; bool_t l_v6371; bool_t l_v6373; bool_t l_v6379;
	bool_t l_v6385; struct pypy_ArenaReference0 **l_v6355;
	struct pypy_ArenaReference0 **l_v6356;
	struct pypy_ArenaReference0 **l_v6359;
	struct pypy_ArenaReference0 **l_v6363;
	struct pypy_ArenaReference0 **l_v6375;
	struct pypy_ArenaReference0 *l_v6347;
	struct pypy_ArenaReference0 *l_v6364;
	struct pypy_ArenaReference0 *l_v6376;
	struct pypy_object_vtable0 *l_v6351;
	struct pypy_object_vtable0 *l_v6384; void* l_v6348; void* l_v6381;
	goto block0;

    block0:
	RPyField(l_self_121, ac_inst_total_memory_used) = 0UL;
	l_size_class_3 = 35L;
	goto block1;

    block1:
	while (1) {
		pypy_g_ArenaCollection_mass_free_in_pages(l_self_121, l_size_class_3, l_ok_to_free_func_3);
		l_v6351 = (&pypy_g_ExcData)->ed_exc_type;
		l_v6352 = (l_v6351 == NULL);
		if (!l_v6352) break;
		goto block2;
	  block1_back: ;
	}
	goto block17;

    block2:
	OP_INT_SUB(l_size_class_3, 1L, l_v6353);
	OP_INT_GE(l_v6353, 1L, l_v6354);
	if (l_v6354) {
		l_size_class_3 = l_v6353;
		goto block1_back;
	}
	goto block3;

    block3:
	l_v6355 = RPyField(l_self_121, ac_inst_arenas_lists);
	l_v6356 = RPyField(l_self_121, ac_inst_old_arenas_lists);
	RPyField(l_self_121, ac_inst_old_arenas_lists) = l_v6355;
	RPyField(l_self_121, ac_inst_arenas_lists) = l_v6356;
	l_i_19 = 0L;
	goto block4;

    block4:
	while (1) {
		l_v6359 = RPyField(l_self_121, ac_inst_arenas_lists);
		RPyBareItem(l_v6359, l_i_19) = ((struct pypy_ArenaReference0 *) NULL);
		OP_INT_ADD(l_i_19, 1L, l_v6361);
		OP_INT_LT(l_v6361, 64L, l_v6362);
		if (!l_v6362) break;
		l_i_19 = l_v6361;
		goto block4_back;
	  block4_back: ;
	}
	l_i_18 = 0L;
	goto block5;

    block5:
	l_v6363 = RPyField(l_self_121, ac_inst_old_arenas_lists);
	l_v6364 = RPyBareItem(l_v6363, l_i_18);
	l_arena_2 = l_v6364;
	goto block6;

    block6:
	while (1) {
		l_v6365 = (l_arena_2 != ((struct pypy_ArenaReference0 *) NULL));
		if (!l_v6365) break;
		goto block10;
	  block6_back: ;
	}
	goto block7;

    block7:
	OP_INT_ADD(l_i_18, 1L, l_v6366);
	OP_INT_LT(l_v6366, 64L, l_v6367);
	if (l_v6367) {
		l_i_18 = l_v6366;
		goto block5;
	}
	goto block8;

    block8:
	RPyField(l_self_121, ac_inst_min_empty_nfreepages) = 1L;
	goto block9;

    block9:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block10:
	l_v6347 = RPyField(l_arena_2, ar_nextarena);
	l_v6369 = RPyField(l_arena_2, ar_nfreepages);
	l_v6370 = RPyField(l_arena_2, ar_totalpages);
	OP_INT_EQ(l_v6369, l_v6370, l_v6371);
	if (l_v6371) {
		goto block12;
	}
	goto block11;

    block11:
	l_v6372 = RPyField(l_arena_2, ar_nfreepages);
	OP_INT_LT(l_v6372, 64L, l_v6373);
	RPyAssert(l_v6373, "totalpages != nfreepages >= max_pages_per_arena");
	l_v6375 = RPyField(l_self_121, ac_inst_arenas_lists);
	l_v6376 = RPyBareItem(l_v6375, l_v6372);
	RPyField(l_arena_2, ar_nextarena) = l_v6376;
	RPyBareItem(l_v6375, l_v6372) = l_arena_2;
	l_arena_2 = l_v6347;
	goto block6_back;

    block12:
	l_v6348 = RPyField(l_arena_2, ar_base);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v6379);
	if (l_v6379) {
		goto block15;
	}
	goto block13;

    block13:
	free(l_v6348);
	goto block14;

    block14:
	l_v6381 = (void*)l_arena_2;
	OP_RAW_FREE(l_v6381, /* nothing */);
	l_arena_2 = l_v6347;
	goto block6;

    block15:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v6384 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6385 = (l_v6384 == NULL);
	if (!l_v6385) {
		goto block16;
	}
	goto block14;

    block16:
	PYPY_DEBUG_RECORD_TRACEBACK("ArenaCollection_mass_free");
	goto block9;

    block17:
	PYPY_DEBUG_RECORD_TRACEBACK("ArenaCollection_mass_free");
	goto block9;
}
/*/*/
struct pypy_PageHeader0 *pypy_g_ArenaCollection_allocate_new_page(struct pypy_rpython_memory_gc_minimarkpage_ArenaCollection0 *l_self_122, Signed l_size_class_4) {
	struct pypy_ArenaReference0 *l_arena_3; void* l_freepages_0;
	void* l_result_18; Signed l_v6392; Signed l_v6394; Signed l_v6397;
	Signed l_v6399; Signed l_v6418; Signed l_v6427; Signed l_v6428;
	bool_t l_v6391; bool_t l_v6393; bool_t l_v6395; bool_t l_v6400;
	bool_t l_v6402; bool_t l_v6403; bool_t l_v6411; bool_t l_v6416;
	bool_t l_v6419; bool_t l_v6430; bool_t l_v6433; bool_t l_v6437;
	struct pypy_ArenaReference0 **l_v6421;
	struct pypy_ArenaReference0 *l_v6390;
	struct pypy_ArenaReference0 *l_v6422;
	struct pypy_PageHeader0 *l_v6404; struct pypy_PageHeader0 *l_v6410;
	struct pypy_PageHeader0 *l_v6439;
	struct pypy_object_vtable0 *l_v6415;
	struct pypy_object_vtable0 *l_v6432;
	struct pypy_object_vtable0 *l_v6436; void* l_v6389; void* l_v6407;
	void* l_v6426;
	goto block0;

    block0:
	l_v6390 = RPyField(l_self_122, ac_inst_current_arena);
	l_v6391 = (l_v6390 == ((struct pypy_ArenaReference0 *) NULL));
	if (l_v6391) {
		goto block14;
	}
	goto block1;

    block1:
	l_arena_3 = RPyField(l_self_122, ac_inst_current_arena);
	l_result_18 = RPyField(l_arena_3, ar_freepages);
	l_v6392 = RPyField(l_arena_3, ar_nfreepages);
	OP_INT_GT(l_v6392, 0L, l_v6393);
	if (l_v6393) {
		goto block11;
	}
	goto block2;

    block2:
	l_v6394 = RPyField(l_self_122, ac_inst_num_uninitialized_pages);
	OP_INT_GT(l_v6394, 0L, l_v6395);
	RPyAssert(l_v6395, "fully allocated arena found in self.current_arena");
	OP_INT_SUB(l_v6394, 1L, l_v6397);
	RPyField(l_self_122, ac_inst_num_uninitialized_pages) = l_v6397;
	l_v6399 = RPyField(l_self_122, ac_inst_num_uninitialized_pages);
	OP_INT_GT(l_v6399, 0L, l_v6400);
	if (l_v6400) {
		goto block10;
	}
	l_freepages_0 = NULL;
	goto block3;

    block3:
	RPyField(l_arena_3, ar_freepages) = l_freepages_0;
	OP_ADR_EQ(l_freepages_0, NULL, l_v6402);
	if (l_v6402) {
		goto block9;
	}
	goto block4;

    block4:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v6403);
	if (l_v6403) {
		goto block7;
	}
	goto block5;

    block5:
	l_v6404 = (struct pypy_PageHeader0 *)l_result_18;
	RPyField(l_v6404, ph_arena) = l_arena_3;
	RPyField(l_v6404, ph_nfree) = 0L;
	OP_ADR_ADD(l_result_18, 16L, l_v6407);
	RPyField(l_v6404, ph_freeblock) = l_v6407;
	RPyField(l_v6404, ph_nextpage) = ((struct pypy_PageHeader0 *) NULL);
	l_v6410 = RPyBareItem(pypy_g_array_22, l_size_class_4);
	l_v6411 = (l_v6410 == ((struct pypy_PageHeader0 *) NULL));
	RPyAssert(l_v6411, "allocate_new_page() called but a page is already waiting");
	RPyBareItem(pypy_g_array_22, l_size_class_4) = l_v6404;
	l_v6439 = l_v6404;
	goto block6;

    block6:
	RPY_DEBUG_RETURN();
	return l_v6439;

    block7:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v6415 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6416 = (l_v6415 == NULL);
	if (!l_v6416) {
		goto block8;
	}
	goto block5;

    block8:
	PYPY_DEBUG_RECORD_TRACEBACK("ArenaCollection_allocate_new_page");
	l_v6439 = ((struct pypy_PageHeader0 *) NULL);
	goto block6;

    block9:
	l_v6418 = RPyField(l_arena_3, ar_nfreepages);
	OP_INT_EQ(l_v6418, 0L, l_v6419);
	RPyAssert(l_v6419, "freepages == NULL but nfreepages > 0");
	l_v6421 = RPyField(l_self_122, ac_inst_arenas_lists);
	l_v6422 = RPyBareItem(l_v6421, 0L);
	RPyField(l_arena_3, ar_nextarena) = l_v6422;
	RPyBareItem(l_v6421, 0L) = l_arena_3;
	RPyField(l_self_122, ac_inst_current_arena) = ((struct pypy_ArenaReference0 *) NULL);
	goto block4;

    block10:
	OP_ADR_ADD(l_result_18, 4096L, l_v6426);
	l_freepages_0 = l_v6426;
	goto block3;

    block11:
	l_v6427 = RPyField(l_arena_3, ar_nfreepages);
	OP_INT_SUB(l_v6427, 1L, l_v6428);
	RPyField(l_arena_3, ar_nfreepages) = l_v6428;
	l_v6389 = ((void* *) (((char *)l_result_18) + 0))[0];
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v6430);
	if (l_v6430) {
		goto block12;
	}
	l_freepages_0 = l_v6389;
	goto block3;

    block12:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v6432 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6433 = (l_v6432 == NULL);
	if (!l_v6433) {
		goto block13;
	}
	l_freepages_0 = l_v6389;
	goto block3;

    block13:
	PYPY_DEBUG_RECORD_TRACEBACK("ArenaCollection_allocate_new_page");
	l_v6439 = ((struct pypy_PageHeader0 *) NULL);
	goto block6;

    block14:
	pypy_g_ArenaCollection_allocate_new_arena(l_self_122);
	l_v6436 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6437 = (l_v6436 == NULL);
	if (!l_v6437) {
		goto block15;
	}
	goto block1;

    block15:
	PYPY_DEBUG_RECORD_TRACEBACK("ArenaCollection_allocate_new_page");
	l_v6439 = ((struct pypy_PageHeader0 *) NULL);
	goto block6;
}
/*/*/
void pypy_g_ArenaCollection_mass_free_in_pages(struct pypy_rpython_memory_gc_minimarkpage_ArenaCollection0 *l_self_123, Signed l_size_class_5, struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_ok_to_free_func_4) {
	Signed l_block_size_1; Signed l_nblocks_0;
	struct pypy_PageHeader0 *l_page_3;
	struct pypy_PageHeader0 *l_remaining_full_pages_0;
	struct pypy_PageHeader0 *l_remaining_full_pages_1;
	struct pypy_PageHeader0 *l_remaining_partial_pages_0;
	struct pypy_PageHeader0 *l_remaining_partial_pages_1;
	Signed l_step_0; Signed l_step_1; Signed l_step_2; Signed l_v6441;
	bool_t l_v6443; bool_t l_v6444; bool_t l_v6447; bool_t l_v6450;
	bool_t l_v6451; bool_t l_v6452; bool_t l_v6455; bool_t l_v6458;
	struct pypy_PageHeader0 *l_v6440; struct pypy_PageHeader0 *l_v6442;
	struct pypy_PageHeader0 *l_v6448;
	struct pypy_object_vtable0 *l_v6449;
	struct pypy_object_vtable0 *l_v6454;
	goto block0;

    block0:
	l_nblocks_0 = RPyBareItem(pypy_g_array_20, l_size_class_5);
	OP_INT_MUL(l_size_class_5, 4L, l_block_size_1);
	l_remaining_partial_pages_1 = ((struct pypy_PageHeader0 *) NULL);
	l_step_2 = 0L;
	l_remaining_full_pages_1 = ((struct pypy_PageHeader0 *) NULL);
	goto block1;

    block1:
	l_v6442 = RPyBareItem(pypy_g_array_19, l_size_class_5);
	l_remaining_partial_pages_0 = l_remaining_partial_pages_1;
	l_page_3 = l_v6442;
	l_step_0 = l_step_2;
	l_remaining_full_pages_0 = l_remaining_full_pages_1;
	goto block2;

    block2:
	while (1) {
		l_v6443 = (l_page_3 != ((struct pypy_PageHeader0 *) NULL));
		if (!l_v6443) break;
		goto block8;
	  block2_back: ;
	}
	goto block3;

    block3:
	OP_INT_ADD(l_step_0, 1L, l_step_1);
	OP_INT_LT(l_step_1, 2L, l_v6444);
	if (l_v6444) {
		goto block6;
	}
	goto block4;

    block4:
	RPyBareItem(pypy_g_array_22, l_size_class_5) = l_remaining_partial_pages_0;
	RPyBareItem(pypy_g_array_19, l_size_class_5) = l_remaining_full_pages_0;
	goto block5;

    block5:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block6:
	OP_INT_EQ(l_step_1, 0L, l_v6447);
	if (l_v6447) {
		l_remaining_partial_pages_1 = l_remaining_partial_pages_0;
		l_step_2 = l_step_1;
		l_remaining_full_pages_1 = l_remaining_full_pages_0;
		goto block1;
	}
	goto block7;

    block7:
	l_v6448 = RPyBareItem(pypy_g_array_22, l_size_class_5);
	l_page_3 = l_v6448;
	l_step_0 = l_step_1;
	goto block2;

    block8:
	l_v6441 = pypy_g_ArenaCollection_walk_page(l_self_123, l_page_3, l_block_size_1, l_ok_to_free_func_4);
	l_v6449 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6450 = (l_v6449 == NULL);
	if (!l_v6450) {
		goto block15;
	}
	goto block9;

    block9:
	l_v6440 = RPyField(l_page_3, ph_nextpage);
	OP_INT_EQ(l_v6441, l_nblocks_0, l_v6451);
	if (l_v6451) {
		goto block14;
	}
	goto block10;

    block10:
	OP_INT_GT(l_v6441, 0L, l_v6452);
	if (l_v6452) {
		goto block13;
	}
	goto block11;

    block11:
	pypy_g_ArenaCollection_free_page(l_self_123, l_page_3);
	l_v6454 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6455 = (l_v6454 == NULL);
	if (!l_v6455) {
		goto block12;
	}
	l_page_3 = l_v6440;
	goto block2;

    block12:
	PYPY_DEBUG_RECORD_TRACEBACK("ArenaCollection_mass_free_in_pages");
	goto block5;

    block13:
	RPyField(l_page_3, ph_nextpage) = l_remaining_partial_pages_0;
	l_remaining_partial_pages_0 = l_page_3;
	l_page_3 = l_v6440;
	goto block2;

    block14:
	OP_INT_EQ(l_step_0, 0L, l_v6458);
	RPyAssert(l_v6458, "A non-full page became full while freeing");
	RPyField(l_page_3, ph_nextpage) = l_remaining_full_pages_0;
	l_remaining_full_pages_0 = l_page_3;
	l_page_3 = l_v6440;
	goto block2_back;

    block15:
	PYPY_DEBUG_RECORD_TRACEBACK("ArenaCollection_mass_free_in_pages");
	goto block5;
}
/*/*/
void pypy_g_ArenaCollection_allocate_new_arena(struct pypy_rpython_memory_gc_minimarkpage_ArenaCollection0 *l_self_124) {
	void* l_arena_base_0; Signed l_i_20; Signed l_v6464; Signed l_v6468;
	Signed l_v6479; Signed l_v6480; Signed l_v6481; Signed l_v6482;
	Signed l_v6483; Signed l_v6484; Signed l_v6485; Signed l_v6486;
	Signed l_v6487; Signed l_v6488; Signed l_v6506; bool_t l_v6467;
	bool_t l_v6469; bool_t l_v6470; bool_t l_v6472; bool_t l_v6473;
	bool_t l_v6489; bool_t l_v6501; bool_t l_v6505;
	struct pypy_ArenaReference0 **l_v6503;
	struct pypy_ArenaReference0 **l_v6508;
	struct pypy_ArenaReference0 *l_v6466;
	struct pypy_ArenaReference0 *l_v6504;
	struct pypy_ArenaReference0 *l_v6509;
	struct pypy_ArenaReference0 *l_v6511;
	struct pypy_ArenaReference0 *l_v6512;
	struct pypy_object_vtable0 *l_v6500; void* l_v6463; void* l_v6465;
	void* l_v6471; void* l_v6476; void* l_v6477; void* l_v6478;
	void* l_v6499;
	goto block0;

    block0:
	l_v6468 = RPyField(l_self_124, ac_inst_min_empty_nfreepages);
	l_i_20 = l_v6468;
	goto block1;

    block1:
	while (1) {
		OP_INT_LT(l_i_20, 64L, l_v6469);
		if (!l_v6469) break;
		goto block15;
	  block1_back: ;
	}
	goto block2;

    block2:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v6470);
	if (l_v6470) {
		goto block13;
	}
	goto block3;

    block3:
	l_v6471 = malloc(262144L);
	OP_ADR_NE(l_v6471, NULL, l_v6472);
	if (l_v6472) {
		l_arena_base_0 = l_v6471;
		goto block4;
	}
	l_arena_base_0 = l_v6471;
	goto block4;

    block4:
	OP_ADR_NE(l_arena_base_0, NULL, l_v6473);
	if (l_v6473) {
		goto block7;
	}
	goto block5;

    block5:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("ArenaCollection_allocate_new_arena");
	goto block6;

    block6:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block7:
	OP_ADR_ADD(l_arena_base_0, 262144L, l_v6476);
	OP_ADR_ADD(l_arena_base_0, 4096L, l_v6477);
	OP_ADR_SUB(l_v6477, 1L, l_v6478);
	OP_CAST_ADR_TO_INT(l_v6478, /* nothing */, l_v6479);
	OP_INT_MOD(l_v6479, 4096L, l_v6480);
	OP_INT_RSHIFT(l_v6480, 31L, l_v6481);
	OP_INT_AND(4096L, l_v6481, l_v6482);
	OP_INT_ADD(l_v6480, l_v6482, l_v6483);
	OP_ADR_SUB(l_v6478, l_v6483, l_v6465);
	OP_ADR_DELTA(l_v6476, l_v6465, l_v6484);
	OP_INT_FLOORDIV(l_v6484, 4096L, l_v6485);
	OP_INT_MUL(l_v6485, 4096L, l_v6486);
	OP_INT_SUB(l_v6484, l_v6486, l_v6487);
	OP_INT_RSHIFT(l_v6487, 31L, l_v6488);
	OP_INT_ADD(l_v6485, l_v6488, l_v6464);
	OP_RAW_MALLOC(sizeof(struct pypy_ArenaReference0), l_v6463, void *);
	OP_ADR_NE(l_v6463, NULL, l_v6489);
	if (l_v6489) {
		goto block10;
	}
	goto block8;

    block8:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("ArenaCollection_allocate_new_arena");
	goto block9;

    block9:
	PYPY_DEBUG_RECORD_TRACEBACK("ArenaCollection_allocate_new_arena");
	goto block6;

    block10:
	l_v6466 = (struct pypy_ArenaReference0 *)l_v6463;
	l_v6467 = (l_v6466 != NULL);
	goto block11;

    block11:
	if (!l_v6467) {
		goto block9;
	}
	goto block12;

    block12:
	RPyField(l_v6466, ar_base) = l_arena_base_0;
	RPyField(l_v6466, ar_nfreepages) = 0L;
	RPyField(l_v6466, ar_totalpages) = l_v6464;
	RPyField(l_v6466, ar_freepages) = l_v6465;
	RPyField(l_self_124, ac_inst_num_uninitialized_pages) = l_v6464;
	RPyField(l_self_124, ac_inst_current_arena) = l_v6466;
	goto block6;

    block13:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v6499 = (void*)0;
	l_v6500 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6501 = (l_v6500 == NULL);
	if (!l_v6501) {
		goto block14;
	}
	l_arena_base_0 = l_v6499;
	goto block4;

    block14:
	PYPY_DEBUG_RECORD_TRACEBACK("ArenaCollection_allocate_new_arena");
	goto block6;

    block15:
	l_v6503 = RPyField(l_self_124, ac_inst_arenas_lists);
	l_v6504 = RPyBareItem(l_v6503, l_i_20);
	l_v6505 = (l_v6504 != ((struct pypy_ArenaReference0 *) NULL));
	if (l_v6505) {
		goto block17;
	}
	goto block16;

    block16:
	OP_INT_ADD(l_i_20, 1L, l_v6506);
	RPyField(l_self_124, ac_inst_min_empty_nfreepages) = l_v6506;
	l_i_20 = l_v6506;
	goto block1_back;

    block17:
	l_v6508 = RPyField(l_self_124, ac_inst_arenas_lists);
	l_v6509 = RPyBareItem(l_v6508, l_i_20);
	RPyField(l_self_124, ac_inst_current_arena) = l_v6509;
	l_v6511 = RPyField(l_self_124, ac_inst_current_arena);
	l_v6512 = RPyField(l_v6511, ar_nextarena);
	RPyBareItem(l_v6508, l_i_20) = l_v6512;
	goto block6;
}
/*/*/
Signed pypy_g_ArenaCollection_walk_page(struct pypy_rpython_memory_gc_minimarkpage_ArenaCollection0 *l_v6516, struct pypy_PageHeader0 *l_page_4, Signed l_block_size_2, struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_ok_to_free_func_2) {
	void* l_freeblock_1; void* l_freeblock_2; void* l_obj_33;
	void* l_prevfreeblockat_0; void* l_prevfreeblockat_1;
	Signed l_skip_free_blocks_0; Signed l_skip_free_blocks_1;
	Signed l_surviving_0; Signed l_surviving_1; Signed l_v6523;
	Signed l_v6529; Signed l_v6530; Signed l_v6536; Signed l_v6537;
	Signed l_v6550; Signed l_v6551; Signed l_v6553; Signed l_v6555;
	Signed l_v6558; Signed l_v6566; Unsigned l_v6557; Unsigned l_v6559;
	Unsigned l_v6560; bool_t l_v6521; bool_t l_v6524; bool_t l_v6525;
	bool_t l_v6531; bool_t l_v6532; bool_t l_v6533; bool_t l_v6542;
	bool_t l_v6546; bool_t l_v6554; bool_t l_v6564;
	struct pypy_header0 *l_v6528; struct pypy_header0 *l_v6549;
	struct pypy_object_vtable0 *l_v6541;
	struct pypy_object_vtable0 *l_v6545;
	struct pypy_object_vtable0 *l_v6563; void* *l_v6520; void* l_v6515;
	void* l_v6517; void* l_v6518; void* l_v6519; void* l_v6522;
	void* l_v6527; void* l_v6539; void* l_v6548; void* l_v6556;
	void* l_v6562; void* l_v6567;
	goto block0;

    block0:
	l_v6515 = RPyField(l_page_4, ph_freeblock);
	l_v6520 = &RPyField(l_page_4, ph_freeblock);
	l_v6517 = (void*)l_v6520;
	l_v6519 = (void*)l_page_4;
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v6521);
	if (l_v6521) {
		goto block17;
	}
	l_v6567 = l_v6519;
	goto block1;

    block1:
	OP_ADR_ADD(l_v6567, 16L, l_v6522);
	l_v6523 = RPyField(l_page_4, ph_nfree);
	l_freeblock_1 = l_v6515;
	l_surviving_0 = 0L;
	l_obj_33 = l_v6522;
	l_prevfreeblockat_0 = l_v6517;
	l_skip_free_blocks_0 = l_v6523;
	goto block2;

    block2:
	while (1) {
		OP_ADR_EQ(l_obj_33, l_freeblock_1, l_v6524);
		if (l_v6524) break;
		goto block3;
	  block2_back: ;
	}
	goto block14;

    block3:
	OP_ADR_GT(l_freeblock_1, l_obj_33, l_v6525);
	RPyAssert(l_v6525, "freeblocks are linked out of order");
	OP_ADR_ADD(l_obj_33, 0, l_v6518);
	OP_ADR_SUB(l_v6518, 0, l_v6527);
	l_v6528 = (struct pypy_header0 *)l_v6527;
	l_v6529 = RPyField(l_v6528, h_tid);
	OP_INT_AND(l_v6529, 262144L, l_v6530);
	OP_INT_IS_TRUE(l_v6530, l_v6531);
	if (l_v6531) {
		goto block13;
	}
	goto block4;

    block4:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v6532);
	if (l_v6532) {
		goto block11;
	}
	goto block5;

    block5:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v6533);
	if (l_v6533) {
		goto block8;
	}
	goto block6;

    block6:
	((void* *) (((char *)l_prevfreeblockat_0) + 0))[0] = l_obj_33;
	((void* *) (((char *)l_obj_33) + 0))[0] = l_freeblock_1;
	l_v6536 = RPyField(l_page_4, ph_nfree);
	OP_INT_ADD(l_v6536, 1L, l_v6537);
	RPyField(l_page_4, ph_nfree) = l_v6537;
	l_freeblock_2 = l_freeblock_1;
	l_surviving_1 = l_surviving_0;
	l_skip_free_blocks_1 = l_skip_free_blocks_0;
	l_prevfreeblockat_1 = l_obj_33;
	goto block7;

    block7:
	OP_ADR_ADD(l_obj_33, l_block_size_2, l_v6539);
	l_freeblock_1 = l_freeblock_2;
	l_surviving_0 = l_surviving_1;
	l_obj_33 = l_v6539;
	l_prevfreeblockat_0 = l_prevfreeblockat_1;
	l_skip_free_blocks_0 = l_skip_free_blocks_1;
	goto block2_back;

    block8:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v6541 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6542 = (l_v6541 == NULL);
	if (!l_v6542) {
		goto block9;
	}
	goto block6;

    block9:
	PYPY_DEBUG_RECORD_TRACEBACK("ArenaCollection_walk_page");
	l_v6566 = -1L;
	goto block10;

    block10:
	RPY_DEBUG_RETURN();
	return l_v6566;

    block11:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v6545 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6546 = (l_v6545 == NULL);
	if (!l_v6546) {
		goto block12;
	}
	goto block5;

    block12:
	PYPY_DEBUG_RECORD_TRACEBACK("ArenaCollection_walk_page");
	l_v6566 = -1L;
	goto block10;

    block13:
	OP_ADR_SUB(l_v6518, 0, l_v6548);
	l_v6549 = (struct pypy_header0 *)l_v6548;
	l_v6550 = RPyField(l_v6549, h_tid);
	OP_INT_AND(l_v6550, -262145L, l_v6551);
	RPyField(l_v6549, h_tid) = l_v6551;
	OP_INT_ADD(l_surviving_0, 1L, l_v6553);
	l_freeblock_2 = l_freeblock_1;
	l_surviving_1 = l_v6553;
	l_skip_free_blocks_1 = l_skip_free_blocks_0;
	l_prevfreeblockat_1 = l_prevfreeblockat_0;
	goto block7;

    block14:
	OP_INT_EQ(l_skip_free_blocks_0, 0L, l_v6554);
	if (l_v6554) {
		goto block16;
	}
	goto block15;

    block15:
	OP_INT_SUB(l_skip_free_blocks_0, 1L, l_v6555);
	l_v6556 = ((void* *) (((char *)l_obj_33) + 0))[0];
	l_freeblock_2 = l_v6556;
	l_surviving_1 = l_surviving_0;
	l_skip_free_blocks_1 = l_v6555;
	l_prevfreeblockat_1 = l_obj_33;
	goto block7;

    block16:
	l_v6557 = RPyField(l_v6516, ac_inst_total_memory_used);
	OP_INT_MUL(l_surviving_0, l_block_size_2, l_v6558);
	OP_CAST_INT_TO_UINT(l_v6558, l_v6559);
	OP_UINT_ADD(l_v6557, l_v6559, l_v6560);
	RPyField(l_v6516, ac_inst_total_memory_used) = l_v6560;
	l_v6566 = l_surviving_0;
	goto block10;

    block17:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v6562 = (void*)0;
	l_v6563 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6564 = (l_v6563 == NULL);
	if (!l_v6564) {
		goto block18;
	}
	l_v6567 = l_v6562;
	goto block1;

    block18:
	PYPY_DEBUG_RECORD_TRACEBACK("ArenaCollection_walk_page");
	l_v6566 = -1L;
	goto block10;
}
/*/*/
void pypy_g_ArenaCollection_free_page(struct pypy_rpython_memory_gc_minimarkpage_ArenaCollection0 *l_self_61, struct pypy_PageHeader0 *l_page_1) {
	Signed l_v6571; Signed l_v6572; bool_t l_v6574; bool_t l_v6575;
	bool_t l_v6576; bool_t l_v6582; bool_t l_v6586; bool_t l_v6590;
	struct pypy_ArenaReference0 *l_v6569;
	struct pypy_object_vtable0 *l_v6581;
	struct pypy_object_vtable0 *l_v6585;
	struct pypy_object_vtable0 *l_v6589; void* l_v6568; void* l_v6570;
	void* l_v6577; void* l_v6588;
	goto block0;

    block0:
	l_v6569 = RPyField(l_page_1, ph_arena);
	l_v6571 = RPyField(l_v6569, ar_nfreepages);
	OP_INT_ADD(l_v6571, 1L, l_v6572);
	RPyField(l_v6569, ar_nfreepages) = l_v6572;
	l_v6570 = (void*)l_page_1;
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v6574);
	if (l_v6574) {
		goto block9;
	}
	l_v6568 = l_v6570;
	goto block1;

    block1:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v6575);
	if (l_v6575) {
		goto block7;
	}
	goto block2;

    block2:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v6576);
	if (l_v6576) {
		goto block5;
	}
	goto block3;

    block3:
	l_v6577 = RPyField(l_v6569, ar_freepages);
	((void* *) (((char *)l_v6568) + 0))[0] = l_v6577;
	RPyField(l_v6569, ar_freepages) = l_v6568;
	goto block4;

    block4:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block5:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v6581 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6582 = (l_v6581 == NULL);
	if (!l_v6582) {
		goto block6;
	}
	goto block3;

    block6:
	PYPY_DEBUG_RECORD_TRACEBACK("ArenaCollection_free_page");
	goto block4;

    block7:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v6585 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6586 = (l_v6585 == NULL);
	if (!l_v6586) {
		goto block8;
	}
	goto block2;

    block8:
	PYPY_DEBUG_RECORD_TRACEBACK("ArenaCollection_free_page");
	goto block4;

    block9:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v6588 = (void*)0;
	l_v6589 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6590 = (l_v6589 == NULL);
	if (!l_v6590) {
		goto block10;
	}
	l_v6568 = l_v6588;
	goto block1;

    block10:
	PYPY_DEBUG_RECORD_TRACEBACK("ArenaCollection_free_page");
	goto block4;
}
/*/*/
/***********************************************************/
