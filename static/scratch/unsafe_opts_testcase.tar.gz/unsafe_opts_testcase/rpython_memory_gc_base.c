/***********************************************************/
/***  Implementations                                    ***/

#define PYPY_FILE_NAME "rpython_memory_gc_base.c"
#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"
#include "src/g_include.h"

/*/*/
void pypy_g_GCBase_debug_check_consistency(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_65) {
	struct pypy_AddressChunk0 *l_cur_0; void* l_result_4;
	struct pypy_rpython_memory_support_AddressStack0 *l_self_66;
	struct pypy_rpython_memory_support_AddressStack0 *l_self_67;
	Signed l_v630; Signed l_v665; Signed l_v684; Signed l_v685;
	bool_t l_v629; bool_t l_v631; bool_t l_v633; bool_t l_v636;
	bool_t l_v640; bool_t l_v644; bool_t l_v645; bool_t l_v656;
	bool_t l_v660; bool_t l_v664; bool_t l_v666; bool_t l_v676;
	bool_t l_v686; bool_t l_v691; bool_t l_v694; bool_t l_v698;
	struct pypy_AddressChunk0 *l_v627; struct pypy_AddressChunk0 *l_v643;
	struct pypy_AddressChunk0 *l_v650; struct pypy_AddressChunk0 *l_v675;
	struct pypy_AddressChunk0 *l_v680; struct pypy_AddressChunk0 *l_v681;
	struct pypy_AddressChunk0 *l_v688; struct pypy_AddressChunk0 *l_v696;
	struct pypy_AddressChunk0 *l_v697; struct pypy_AddressChunk0 *l_v703;
	struct pypy_AddressChunk0 *l_v704; struct pypy_AddressChunk0 *l_v710;
	struct pypy_DICT0 *l_v628; struct pypy_DICT0 *l_v667;
	struct pypy_array5 *l_v668; struct pypy_nongcobject0 *l_v641;
	struct pypy_object_vtable0 *l_v632;
	struct pypy_object_vtable0 *l_v655;
	struct pypy_object_vtable0 *l_v659;
	struct pypy_object_vtable0 *l_v663;
	struct pypy_object_vtable0 *l_v693;
	struct pypy_rpython_memory_support_AddressDeque0 *l_v661;
	struct pypy_rpython_memory_support_AddressStack0 *l_v625;
	void* *l_v689; void* l_v626; void* l_v635; void* l_v669;
	void* l_v672; void* l_v677; void* l_v709;
	goto block0;

    block0:
	l_v630 = RPyField(l_self_65, mmgc_inst_DEBUG);
	OP_INT_IS_TRUE(l_v630, l_v631);
	if (l_v631) {
		goto block2;
	}
	goto block1;

    block1:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block2:
	l_v628 = pypy_g_ll_newdict_size__Struct_DICTLlT_Signed(0L);
	l_v632 = (&pypy_g_ExcData)->ed_exc_type;
	l_v633 = (l_v632 == NULL);
	if (!l_v633) {
		goto block31;
	}
	goto block3;

    block3:
	RPyField(l_self_65, mmgc_inst__debug_seen) = l_v628;
	OP_RAW_MALLOC(sizeof(struct pypy_rpython_memory_support_AddressStack0), l_v635, void *);
	OP_ADR_NE(l_v635, NULL, l_v636);
	if (l_v636) {
		l_v709 = l_v635;
		goto block5;
	}
	goto block4;

    block4:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("GCBase_debug_check_consistency");
	l_v709 = NULL;
	goto block5;

    block5:
	OP_TRACK_ALLOC_START(l_v709, /* nothing */);
	l_self_66 = (struct pypy_rpython_memory_support_AddressStack0 *)l_v709;
	l_v640 = (l_self_66 != NULL);
	if (!l_v640) {
		goto block30;
	}
	goto block6;

    block6:
	l_v641 = (struct pypy_nongcobject0 *)l_self_66;
	RPyField(l_v641, n_typeptr) = (&pypy_g_rpython_memory_support_AddressStack_vtable.as_super);
	l_v643 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v644 = (l_v643 != NULL);
	if (l_v644) {
		goto block29;
	}
	goto block7;

    block7:
	OP_RAW_MALLOC(sizeof(struct pypy_AddressChunk0), l_v626, void *);
	OP_ADR_NE(l_v626, NULL, l_v645);
	if (l_v645) {
		goto block10;
	}
	goto block8;

    block8:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("GCBase_debug_check_consistency");
	goto block9;

    block9:
	PYPY_DEBUG_RECORD_TRACEBACK("GCBase_debug_check_consistency");
	goto block1;

    block10:
	l_v627 = (struct pypy_AddressChunk0 *)l_v626;
	l_v629 = (l_v627 != NULL);
	goto block11;

    block11:
	if (!l_v629) {
		goto block9;
	}
	l_v710 = l_v627;
	goto block12;

    block12:
	RPyField(l_self_66, as_inst_chunk) = l_v710;
	l_v650 = RPyField(l_self_66, as_inst_chunk);
	RPyField(l_v650, ac_next) = ((struct pypy_AddressChunk0 *) NULL);
	RPyField(l_self_66, as_inst_used_in_last_chunk) = 0L;
	RPyField(l_self_65, mmgc_inst__debug_pending) = l_self_66;
	pypy_g_foreach___debug_callback((&pypy_g_rpython_memory_support_AddressStack_2), l_self_65);
	l_v655 = (&pypy_g_ExcData)->ed_exc_type;
	l_v656 = (l_v655 == NULL);
	if (!l_v656) {
		goto block28;
	}
	goto block13;

    block13:
	RPyField(l_self_65, mmgc_inst__callback2_arg4) = l_self_65;
	pypy_g_walk_roots(pypy_g_callback2, pypy_g_callback2, pypy_g_callback2);
	l_v659 = (&pypy_g_ExcData)->ed_exc_type;
	l_v660 = (l_v659 == NULL);
	if (!l_v660) {
		goto block27;
	}
	goto block14;

    block14:
	l_v661 = RPyField(l_self_65, mmgc_inst_run_finalizers);
	pypy_g_foreach___debug_callback_1(l_v661, l_self_65);
	l_v663 = (&pypy_g_ExcData)->ed_exc_type;
	l_v664 = (l_v663 == NULL);
	if (!l_v664) {
		goto block26;
	}
	goto block15;

    block15:
	l_v625 = RPyField(l_self_65, mmgc_inst__debug_pending);
	goto block16;

    block16:
	while (1) {
		l_v665 = RPyField(l_v625, as_inst_used_in_last_chunk);
		OP_INT_NE(l_v665, 0L, l_v666);
		if (!l_v666) break;
		goto block21;
	  block16_back: ;
	}
	goto block17;

    block17:
	l_v667 = RPyField(l_self_65, mmgc_inst__debug_seen);
	l_v668 = RPyField(l_v667, di_entries);
	l_v669 = (void*)l_v668;
	OP_TRACK_ALLOC_STOP(l_v669, /* nothing */);
	OP_RAW_FREE(l_v669, /* nothing */);
	l_v672 = (void*)l_v667;
	OP_TRACK_ALLOC_STOP(l_v672, /* nothing */);
	OP_RAW_FREE(l_v672, /* nothing */);
	l_self_67 = RPyField(l_self_65, mmgc_inst__debug_pending);
	l_v675 = RPyField(l_self_67, as_inst_chunk);
	l_cur_0 = l_v675;
	goto block18;

    block18:
	while (1) {
		l_v676 = (l_cur_0 != NULL);
		if (!l_v676) break;
		goto block20;
	  block18_back: ;
	}
	goto block19;

    block19:
	l_v677 = (void*)l_self_67;
	OP_TRACK_ALLOC_STOP(l_v677, /* nothing */);
	OP_RAW_FREE(l_v677, /* nothing */);
	goto block1;

    block20:
	l_v680 = RPyField(l_cur_0, ac_next);
	l_v681 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	RPyField(l_cur_0, ac_next) = l_v681;
	(&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list = l_cur_0;
	l_cur_0 = l_v680;
	goto block18_back;

    block21:
	l_v684 = RPyField(l_v625, as_inst_used_in_last_chunk);
	OP_INT_SUB(l_v684, 1L, l_v685);
	OP_INT_GE(l_v685, 0L, l_v686);
	RPyAssert(l_v686, "pop on empty AddressStack");
	l_v688 = RPyField(l_v625, as_inst_chunk);
	l_v689 = RPyField(l_v688, ac_items);
	l_result_4 = RPyFxItem(l_v689, l_v685, 1019);
	RPyField(l_v625, as_inst_used_in_last_chunk) = l_v685;
	OP_INT_EQ(l_v685, 0L, l_v691);
	if (l_v691) {
		goto block24;
	}
	goto block22;

    block22:
	pypy_g_trace___debug_callback2(l_self_65, l_result_4, l_self_65);
	l_v693 = (&pypy_g_ExcData)->ed_exc_type;
	l_v694 = (l_v693 == NULL);
	if (!l_v694) {
		goto block23;
	}
	goto block16_back;

    block23:
	PYPY_DEBUG_RECORD_TRACEBACK("GCBase_debug_check_consistency");
	goto block1;

    block24:
	l_v696 = RPyField(l_v625, as_inst_chunk);
	l_v697 = RPyField(l_v696, ac_next);
	l_v698 = (l_v697 != NULL);
	if (l_v698) {
		goto block25;
	}
	goto block22;

    block25:
	pypy_g_AddressStack_shrink(l_v625);
	goto block22;

    block26:
	PYPY_DEBUG_RECORD_TRACEBACK("GCBase_debug_check_consistency");
	goto block1;

    block27:
	PYPY_DEBUG_RECORD_TRACEBACK("GCBase_debug_check_consistency");
	goto block1;

    block28:
	PYPY_DEBUG_RECORD_TRACEBACK("GCBase_debug_check_consistency");
	goto block1;

    block29:
	l_v703 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v704 = RPyField(l_v703, ac_next);
	(&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list = l_v704;
	l_v710 = l_v703;
	goto block12;

    block30:
	PYPY_DEBUG_RECORD_TRACEBACK("GCBase_debug_check_consistency");
	goto block1;

    block31:
	PYPY_DEBUG_RECORD_TRACEBACK("GCBase_debug_check_consistency");
	goto block1;
}
/*/*/
Signed pypy_g_GCBase__get_size_for_typeid(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_25, void* l_obj_3, unsigned short l_typeid_4) {
	Signed l_v711; Signed l_v712; Signed l_v714; Signed l_v715;
	Signed l_v719; Signed l_v720; Signed l_v723; Signed l_v727;
	Signed l_v728; Signed l_v731; Signed l_v733; Signed l_v736;
	Signed l_v737; Signed l_v740; Signed l_v741; Signed l_v743;
	Signed l_v744; Signed l_v745; bool_t l_v716; bool_t l_v721;
	bool_t l_v724; bool_t l_v729; bool_t l_v738; bool_t l_v742;
	struct pypy_type_info0 *l_v713; struct pypy_type_info0 *l_v718;
	struct pypy_type_info0 *l_v726; struct pypy_type_info0 *l_v735;
	struct pypy_varsize_type_info0 *l_v725;
	struct pypy_varsize_type_info0 *l_v734; void* l_v732;
	goto block0;

    block0:
	l_v713 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_4);
	l_v714 = RPyField(l_v713, ti_infobits);
	OP_INT_AND(l_v714, -16777216L, l_v715);
	OP_INT_EQ(l_v715, 1509949440L, l_v716);
	RPyAssert(l_v716, "invalid type_id");
	l_v712 = RPyField(l_v713, ti_fixedsize);
	l_v718 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_4);
	l_v719 = RPyField(l_v718, ti_infobits);
	OP_INT_AND(l_v719, -16777216L, l_v720);
	OP_INT_EQ(l_v720, 1509949440L, l_v721);
	RPyAssert(l_v721, "invalid type_id");
	OP_INT_AND(l_v719, 65536L, l_v723);
	OP_INT_NE(l_v723, 0L, l_v724);
	if (l_v724) {
		goto block2;
	}
	l_v745 = l_v712;
	goto block1;

    block1:
	RPY_DEBUG_RETURN();
	return l_v745;

    block2:
	l_v725 = (struct pypy_varsize_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_4);
	l_v726 = (struct pypy_type_info0 *)l_v725;
	l_v727 = RPyField(l_v726, ti_infobits);
	OP_INT_AND(l_v727, -16711680L, l_v728);
	OP_INT_EQ(l_v728, 1510014976L, l_v729);
	RPyAssert(l_v729, "invalid varsize type_id");
	l_v731 = RPyField(l_v725, vti_ofstolength);
	OP_ADR_ADD(l_obj_3, l_v731, l_v732);
	l_v733 = ((Signed *) (((char *)l_v732) + 0))[0];
	l_v734 = (struct pypy_varsize_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_4);
	l_v735 = (struct pypy_type_info0 *)l_v734;
	l_v736 = RPyField(l_v735, ti_infobits);
	OP_INT_AND(l_v736, -16711680L, l_v737);
	OP_INT_EQ(l_v737, 1510014976L, l_v738);
	RPyAssert(l_v738, "invalid varsize type_id");
	l_v740 = RPyField(l_v734, vti_varitemsize);
	OP_INT_MUL(l_v733, l_v740, l_v741);
	OP_INT_ADD(l_v712, l_v741, l_v711);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v742);
	if (l_v742) {
		goto block4;
	}
	goto block3;

    block3:
	l_v743 = ROUND_UP_FOR_ALLOCATION(l_v711, 0L);
	l_v745 = l_v743;
	goto block1;

    block4:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v744 = (Signed)0;
	l_v745 = l_v744;
	goto block1;
}
/*/*/
void pypy_g_trace_partial___trace_drag_out(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_27, void* l_obj_4, Signed l_start_9, Signed l_stop_1, struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_callback_16) {
	void* l_addr_0; void* l_item_3; void* l_item_4;
	Signed l_itemlength_0; Signed l_j_0; Signed l_length_25;
	Signed l_length_26; void* l_newhdr_0; void* l_newhdr_1;
	struct pypy_array8 *l_offsets_0; Signed l_tid_0;
	Signed l_totalsize_3; Signed l_totalsize_4; Signed l_totalsize_5;
	Signed l_totalsize_6; Signed l_used_0; Signed l_used_1;
	Signed l_v1000; Signed l_v1004; Signed l_v1008; Signed l_v1020;
	Signed l_v1025; Signed l_v1051; Signed l_v1055; Signed l_v749;
	Signed l_v751; Signed l_v756; Signed l_v758; Signed l_v760;
	Signed l_v764; Signed l_v766; Signed l_v768; Signed l_v771;
	Signed l_v773; Signed l_v774; Signed l_v777; Signed l_v780;
	Signed l_v781; Signed l_v784; Signed l_v789; Signed l_v790;
	Signed l_v793; Signed l_v797; Signed l_v798; Signed l_v803;
	Signed l_v804; Signed l_v807; Signed l_v810; Signed l_v813;
	Signed l_v814; Signed l_v817; Signed l_v818; Signed l_v819;
	Signed l_v826; Signed l_v827; Signed l_v841; Signed l_v842;
	Signed l_v844; Signed l_v845; Signed l_v858; Signed l_v862;
	Signed l_v871; Signed l_v872; Signed l_v876; Signed l_v880;
	Signed l_v892; Signed l_v897; Signed l_v923; Signed l_v927;
	Signed l_v939; Signed l_v945; Signed l_v946; Signed l_v947;
	Signed l_v954; Signed l_v955; Signed l_v969; Signed l_v970;
	Signed l_v972; Signed l_v973; Signed l_v986; Signed l_v990;
	Signed l_v999; Unsigned l_v1067; Unsigned l_v1068; Unsigned l_v829;
	Unsigned l_v830; Unsigned l_v836; Unsigned l_v957; Unsigned l_v958;
	Unsigned l_v964; bool_t l_v1007; bool_t l_v1011; bool_t l_v1012;
	bool_t l_v1013; bool_t l_v1021; bool_t l_v1029; bool_t l_v1033;
	bool_t l_v1037; bool_t l_v1041; bool_t l_v1044; bool_t l_v1054;
	bool_t l_v1056; bool_t l_v1059; bool_t l_v1063; bool_t l_v775;
	bool_t l_v778; bool_t l_v782; bool_t l_v785; bool_t l_v791;
	bool_t l_v799; bool_t l_v805; bool_t l_v809; bool_t l_v811;
	bool_t l_v816; bool_t l_v820; bool_t l_v823; bool_t l_v825;
	bool_t l_v828; bool_t l_v831; bool_t l_v834; bool_t l_v838;
	bool_t l_v843; bool_t l_v846; bool_t l_v849; bool_t l_v853;
	bool_t l_v859; bool_t l_v860; bool_t l_v863; bool_t l_v867;
	bool_t l_v879; bool_t l_v883; bool_t l_v884; bool_t l_v885;
	bool_t l_v893; bool_t l_v901; bool_t l_v905; bool_t l_v909;
	bool_t l_v913; bool_t l_v916; bool_t l_v926; bool_t l_v928;
	bool_t l_v931; bool_t l_v935; bool_t l_v941; bool_t l_v943;
	bool_t l_v948; bool_t l_v951; bool_t l_v953; bool_t l_v956;
	bool_t l_v959; bool_t l_v962; bool_t l_v966; bool_t l_v971;
	bool_t l_v974; bool_t l_v977; bool_t l_v981; bool_t l_v987;
	bool_t l_v988; bool_t l_v991; bool_t l_v995;
	struct pypy_AddressChunk0 *l_v1022;
	struct pypy_AddressChunk0 *l_v894; struct pypy_DICT0 *l_v746;
	struct pypy_DICT0 *l_v761; struct pypy_DICT0 *l_v824;
	struct pypy_DICT0 *l_v865; struct pypy_DICT0 *l_v952;
	struct pypy_DICT0 *l_v993; struct pypy_forwarding_stub0 *l_v1017;
	struct pypy_forwarding_stub0 *l_v1046;
	struct pypy_forwarding_stub0 *l_v889;
	struct pypy_forwarding_stub0 *l_v918; struct pypy_header0 *l_v1003;
	struct pypy_header0 *l_v1015; struct pypy_header0 *l_v1050;
	struct pypy_header0 *l_v770; struct pypy_header0 *l_v840;
	struct pypy_header0 *l_v857; struct pypy_header0 *l_v870;
	struct pypy_header0 *l_v875; struct pypy_header0 *l_v887;
	struct pypy_header0 *l_v922; struct pypy_header0 *l_v968;
	struct pypy_header0 *l_v985; struct pypy_header0 *l_v998;
	struct pypy_object_vtable0 *l_v1006;
	struct pypy_object_vtable0 *l_v1028;
	struct pypy_object_vtable0 *l_v1032;
	struct pypy_object_vtable0 *l_v1036;
	struct pypy_object_vtable0 *l_v1040;
	struct pypy_object_vtable0 *l_v1053;
	struct pypy_object_vtable0 *l_v1058;
	struct pypy_object_vtable0 *l_v1062;
	struct pypy_object_vtable0 *l_v833;
	struct pypy_object_vtable0 *l_v878;
	struct pypy_object_vtable0 *l_v900;
	struct pypy_object_vtable0 *l_v904;
	struct pypy_object_vtable0 *l_v908;
	struct pypy_object_vtable0 *l_v912;
	struct pypy_object_vtable0 *l_v925;
	struct pypy_object_vtable0 *l_v930;
	struct pypy_object_vtable0 *l_v934;
	struct pypy_object_vtable0 *l_v961; struct pypy_type_info0 *l_v772;
	struct pypy_type_info0 *l_v779; struct pypy_type_info0 *l_v788;
	struct pypy_type_info0 *l_v796; struct pypy_type_info0 *l_v802;
	struct pypy_varsize_type_info0 *l_v787;
	struct pypy_varsize_type_info0 *l_v795;
	struct pypy_varsize_type_info0 *l_v801; unsigned short l_v1005;
	unsigned short l_v1052; unsigned short l_v755; unsigned short l_v877;
	unsigned short l_v924; void* *l_v1023; void* *l_v895; void* l_v1002;
	void* l_v1009; void* l_v1014; void* l_v1039; void* l_v1047;
	void* l_v1049; void* l_v1057; void* l_v1061; void* l_v747;
	void* l_v748; void* l_v750; void* l_v752; void* l_v753; void* l_v754;
	void* l_v757; void* l_v759; void* l_v762; void* l_v763; void* l_v765;
	void* l_v767; void* l_v769; void* l_v794; void* l_v808; void* l_v812;
	void* l_v815; void* l_v822; void* l_v837; void* l_v839; void* l_v848;
	void* l_v852; void* l_v856; void* l_v866; void* l_v869; void* l_v874;
	void* l_v881; void* l_v886; void* l_v911; void* l_v919; void* l_v921;
	void* l_v929; void* l_v933; void* l_v938; void* l_v940; void* l_v942;
	void* l_v944; void* l_v950; void* l_v965; void* l_v967; void* l_v976;
	void* l_v980; void* l_v984; void* l_v994; void* l_v997;
	goto block0;

    block0:
	OP_INT_SUB(l_stop_1, l_start_9, l_v758);
	OP_ADR_SUB(l_obj_4, 0, l_v769);
	l_v770 = (struct pypy_header0 *)l_v769;
	l_v771 = RPyField(l_v770, h_tid);
	OP_EXTRACT_USHORT(l_v771, l_v755);
	l_v772 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_v755);
	l_v773 = RPyField(l_v772, ti_infobits);
	OP_INT_AND(l_v773, -16777216L, l_v774);
	OP_INT_EQ(l_v774, 1509949440L, l_v775);
	RPyAssert(l_v775, "invalid type_id");
	OP_INT_AND(l_v773, 262144L, l_v777);
	OP_INT_NE(l_v777, 0L, l_v778);
	if (l_v778) {
		goto block47;
	}
	goto block1;

    block1:
	l_v779 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_v755);
	l_v780 = RPyField(l_v779, ti_infobits);
	OP_INT_AND(l_v780, -16777216L, l_v781);
	OP_INT_EQ(l_v781, 1509949440L, l_v782);
	RPyAssert(l_v782, "invalid type_id");
	OP_INT_AND(l_v780, 131072L, l_v784);
	OP_INT_NE(l_v784, 0L, l_v785);
	RPyAssert(l_v785, "trace_partial() on object without has_gcptr_in_varsize()");
	l_v787 = (struct pypy_varsize_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_v755);
	l_v788 = (struct pypy_type_info0 *)l_v787;
	l_v789 = RPyField(l_v788, ti_infobits);
	OP_INT_AND(l_v789, -16711680L, l_v790);
	OP_INT_EQ(l_v790, 1510014976L, l_v791);
	RPyAssert(l_v791, "invalid varsize type_id");
	l_v793 = RPyField(l_v787, vti_ofstovar);
	OP_ADR_ADD(l_obj_4, l_v793, l_v794);
	l_v795 = (struct pypy_varsize_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_v755);
	l_v796 = (struct pypy_type_info0 *)l_v795;
	l_v797 = RPyField(l_v796, ti_infobits);
	OP_INT_AND(l_v797, -16711680L, l_v798);
	OP_INT_EQ(l_v798, 1510014976L, l_v799);
	RPyAssert(l_v799, "invalid varsize type_id");
	l_offsets_0 = RPyField(l_v795, vti_varofstoptrs);
	l_v801 = (struct pypy_varsize_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_v755);
	l_v802 = (struct pypy_type_info0 *)l_v801;
	l_v803 = RPyField(l_v802, ti_infobits);
	OP_INT_AND(l_v803, -16711680L, l_v804);
	OP_INT_EQ(l_v804, 1510014976L, l_v805);
	RPyAssert(l_v805, "invalid varsize type_id");
	l_itemlength_0 = RPyField(l_v801, vti_varitemsize);
	OP_INT_MUL(l_itemlength_0, l_start_9, l_v807);
	OP_ADR_ADD(l_v794, l_v807, l_v808);
	l_item_4 = l_v808;
	l_length_25 = l_v758;
	goto block2;

    block2:
	OP_INT_GT(l_length_25, 0L, l_v809);
	if (l_v809) {
		l_j_0 = 0L;
		goto block4;
	}
	goto block3;

    block3:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block4:
	while (1) {
		l_v810 = l_offsets_0->length;
		OP_INT_LT(l_j_0, l_v810, l_v811);
		if (!l_v811) break;
		goto block6;
	  block4_back: ;
	}
	goto block5;

    block5:
	OP_ADR_ADD(l_item_4, l_itemlength_0, l_v812);
	OP_INT_SUB(l_length_25, 1L, l_v813);
	l_item_4 = l_v812;
	l_length_25 = l_v813;
	goto block2;

    block6:
	l_v814 = RPyItem(l_offsets_0, l_j_0);
	OP_ADR_ADD(l_item_4, l_v814, l_v748);
	l_v815 = ((void* *) (((char *)l_v748) + 0))[0];
	OP_ADR_NE(l_v815, NULL, l_v816);
	if (l_v816) {
		goto block8;
	}
	goto block7;

    block7:
	OP_INT_ADD(l_j_0, 1L, l_v817);
	l_j_0 = l_v817;
	goto block4_back;

    block8:
	l_v753 = ((void* *) (((char *)l_v748) + 0))[0];
	OP_CAST_ADR_TO_INT(l_v753, /* nothing */, l_v818);
	OP_INT_AND(l_v818, 1L, l_v819);
	OP_INT_EQ(l_v819, 0L, l_v820);
	RPyAssert(l_v820, "odd-valued (i.e. tagged) pointer unexpected here");
	l_v822 = RPyField(l_callback_16, mmgc_inst_nursery);
	OP_ADR_LE(l_v822, l_v753, l_v823);
	if (l_v823) {
		goto block16;
	}
	goto block9;

    block9:
	l_v824 = RPyField(l_callback_16, mmgc_inst_young_rawmalloced_objects);
	l_v825 = (l_v824 != NULL);
	if (l_v825) {
		goto block10;
	}
	goto block7;

    block10:
	l_v761 = RPyField(l_callback_16, mmgc_inst_young_rawmalloced_objects);
	OP_CAST_ADR_TO_INT(l_v753, /* nothing */, l_v826);
	OP_INT_RSHIFT(l_v826, 4L, l_v827);
	OP_INT_XOR(l_v826, l_v827, l_v766);
	OP_INT_IS_TRUE(0 /* we are not jitted here */, l_v828);
	if (l_v828) {
		goto block15;
	}
	goto block11;

    block11:
	l_v829 = pypy_g_ll_dict_lookup__v51___simple_call__function_ll(l_v761, l_v753, l_v766);
	l_v1067 = l_v829;
	goto block12;

    block12:
	OP_UINT_AND(l_v1067, 2147483648UL, l_v830);
	OP_UINT_IS_TRUE(l_v830, l_v831);
	if (l_v831) {
		goto block7;
	}
	goto block13;

    block13:
	pypy_g_MiniMarkGC__visit_young_rawmalloced_object(l_callback_16, l_v753);
	l_v833 = (&pypy_g_ExcData)->ed_exc_type;
	l_v834 = (l_v833 == NULL);
	if (!l_v834) {
		goto block14;
	}
	goto block7;

    block14:
	PYPY_DEBUG_RECORD_TRACEBACK("trace_partial___trace_drag_out");
	goto block3;

    block15:
	l_v836 = pypy_g_ll_dict_lookup__v60___simple_call__function_ll(l_v761, l_v753, l_v766);
	l_v1067 = l_v836;
	goto block12;

    block16:
	l_v837 = RPyField(l_callback_16, mmgc_inst_nursery_real_top);
	OP_ADR_LT(l_v753, l_v837, l_v838);
	if (l_v838) {
		goto block17;
	}
	goto block9;

    block17:
	OP_ADR_SUB(l_v753, 0, l_v839);
	l_v840 = (struct pypy_header0 *)l_v839;
	l_v841 = RPyField(l_v840, h_tid);
	OP_INT_AND(l_v841, 524288L, l_v842);
	OP_INT_EQ(l_v842, 0L, l_v843);
	if (l_v843) {
		goto block40;
	}
	goto block18;

    block18:
	OP_CAST_ADR_TO_INT(l_v753, /* nothing */, l_v844);
	OP_INT_AND(l_v844, 1L, l_v845);
	OP_INT_EQ(l_v845, 0L, l_v846);
	RPyAssert(l_v846, "odd-valued (i.e. tagged) pointer unexpected here");
	l_v848 = RPyField(l_callback_16, mmgc_inst_nursery);
	OP_ADR_LE(l_v848, l_v753, l_v849);
	if (l_v849) {
		goto block20;
	}
	goto block19;

    block19:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("trace_partial___trace_drag_out");
	goto block3;

    block20:
	l_v852 = RPyField(l_callback_16, mmgc_inst_nursery_real_top);
	OP_ADR_LT(l_v753, l_v852, l_v853);
	if (l_v853) {
		goto block22;
	}
	goto block21;

    block21:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("trace_partial___trace_drag_out");
	goto block3;

    block22:
	OP_ADR_SUB(l_v753, 0, l_v856);
	l_v857 = (struct pypy_header0 *)l_v856;
	l_tid_0 = RPyField(l_v857, h_tid);
	OP_INT_AND(l_tid_0, 1048576L, l_v858);
	OP_INT_NE(l_v858, 0L, l_v859);
	if (l_v859) {
		goto block39;
	}
	goto block23;

    block23:
	OP_INT_IS_TRUE(l_tid_0, l_v860);
	RPyAssert(l_v860, "bogus header (1)");
	OP_INT_AND(l_tid_0, -16777216L, l_v862);
	OP_INT_EQ(l_v862, 0L, l_v863);
	RPyAssert(l_v863, "bogus header (2)");
	l_v865 = RPyField(l_callback_16, mmgc_inst_nursery_objects_shadows);
	l_v866 = pypy_g_ll_get__DICTPtr_Address_Address(l_v865, l_v753, NULL);
	OP_ADR_NE(l_v866, NULL, l_v867);
	RPyAssert(l_v867, "GCFLAG_HAS_SHADOW but no shadow found");
	OP_ADR_SUB(l_v866, 0, l_v763);
	OP_ADR_SUB(l_v753, 0, l_v869);
	l_v870 = (struct pypy_header0 *)l_v869;
	l_v871 = RPyField(l_v870, h_tid);
	OP_INT_AND(l_v871, -524289L, l_v872);
	RPyField(l_v870, h_tid) = l_v872;
	OP_ADR_SUB(l_v753, 0, l_v874);
	l_v875 = (struct pypy_header0 *)l_v874;
	l_v876 = RPyField(l_v875, h_tid);
	OP_EXTRACT_USHORT(l_v876, l_v877);
	l_v764 = pypy_g_GCBase__get_size_for_typeid(l_callback_16, l_v753, l_v877);
	l_v878 = (&pypy_g_ExcData)->ed_exc_type;
	l_v879 = (l_v878 == NULL);
	if (!l_v879) {
		goto block38;
	}
	goto block24;

    block24:
	OP_INT_ADD(0, l_v764, l_v880);
	l_newhdr_1 = l_v763;
	l_totalsize_6 = l_v880;
	goto block25;

    block25:
	OP_ADR_SUB(l_v753, 0, l_v881);
	OP_RAW_MEMCOPY(l_v881, l_newhdr_1, l_totalsize_6, /* nothing */);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v883);
	if (l_v883) {
		goto block36;
	}
	l_v752 = l_v753;
	goto block26;

    block26:
	OP_ADR_SUB(l_v752, 0, l_v767);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v884);
	if (l_v884) {
		goto block34;
	}
	goto block27;

    block27:
	OP_ADR_SUB(l_v752, 0, l_v750);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v885);
	if (l_v885) {
		goto block32;
	}
	goto block28;

    block28:
	OP_ADR_SUB(l_v752, 0, l_v886);
	l_v887 = (struct pypy_header0 *)l_v886;
	RPyField(l_v887, h_tid) = -42L;
	OP_ADR_ADD(l_newhdr_1, 0, l_v757);
	l_v889 = (struct pypy_forwarding_stub0 *)l_v752;
	RPyField(l_v889, fs_forw) = l_v757;
	((void* *) (((char *)l_v748) + 0))[0] = l_v757;
	l_v892 = (&pypy_g_rpython_memory_support_AddressStack)->as_inst_used_in_last_chunk;
	OP_INT_EQ(l_v892, 1019L, l_v893);
	if (l_v893) {
		goto block30;
	}
	l_used_0 = l_v892;
	goto block29;

    block29:
	l_v894 = (&pypy_g_rpython_memory_support_AddressStack)->as_inst_chunk;
	l_v895 = RPyField(l_v894, ac_items);
	RPyFxItem(l_v895, l_used_0, 1019) = l_v757;
	OP_INT_ADD(l_used_0, 1L, l_v897);
	(&pypy_g_rpython_memory_support_AddressStack)->as_inst_used_in_last_chunk = l_v897;
	goto block7;

    block30:
	pypy_g_AddressStack_enlarge((&pypy_g_rpython_memory_support_AddressStack));
	l_v900 = (&pypy_g_ExcData)->ed_exc_type;
	l_v901 = (l_v900 == NULL);
	if (!l_v901) {
		goto block31;
	}
	l_used_0 = 0L;
	goto block29;

    block31:
	PYPY_DEBUG_RECORD_TRACEBACK("trace_partial___trace_drag_out");
	goto block3;

    block32:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v904 = (&pypy_g_ExcData)->ed_exc_type;
	l_v905 = (l_v904 == NULL);
	if (!l_v905) {
		goto block33;
	}
	goto block28;

    block33:
	PYPY_DEBUG_RECORD_TRACEBACK("trace_partial___trace_drag_out");
	goto block3;

    block34:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v908 = (&pypy_g_ExcData)->ed_exc_type;
	l_v909 = (l_v908 == NULL);
	if (!l_v909) {
		goto block35;
	}
	goto block27;

    block35:
	PYPY_DEBUG_RECORD_TRACEBACK("trace_partial___trace_drag_out");
	goto block3;

    block36:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v911 = (void*)0;
	l_v912 = (&pypy_g_ExcData)->ed_exc_type;
	l_v913 = (l_v912 == NULL);
	if (!l_v913) {
		goto block37;
	}
	l_v752 = l_v911;
	goto block26;

    block37:
	PYPY_DEBUG_RECORD_TRACEBACK("trace_partial___trace_drag_out");
	goto block3;

    block38:
	PYPY_DEBUG_RECORD_TRACEBACK("trace_partial___trace_drag_out");
	goto block3;

    block39:
	OP_INT_EQ(l_tid_0, -42L, l_v916);
	RPyAssert(l_v916, "bogus header for young obj");
	l_v918 = (struct pypy_forwarding_stub0 *)l_v753;
	l_v919 = RPyField(l_v918, fs_forw);
	((void* *) (((char *)l_v748) + 0))[0] = l_v919;
	goto block7;

    block40:
	OP_ADR_SUB(l_v753, 0, l_v921);
	l_v922 = (struct pypy_header0 *)l_v921;
	l_v923 = RPyField(l_v922, h_tid);
	OP_EXTRACT_USHORT(l_v923, l_v924);
	l_v768 = pypy_g_GCBase__get_size_for_typeid(l_callback_16, l_v753, l_v924);
	l_v925 = (&pypy_g_ExcData)->ed_exc_type;
	l_v926 = (l_v925 == NULL);
	if (!l_v926) {
		goto block46;
	}
	goto block41;

    block41:
	OP_INT_ADD(0, l_v768, l_totalsize_4);
	OP_RAW_MALLOC_USAGE(l_totalsize_4, l_v927);
	OP_INT_LE(l_v927, 140L, l_v928);
	if (l_v928) {
		goto block44;
	}
	goto block42;

    block42:
	l_v929 = pypy_g_MiniMarkGC__malloc_out_of_nursery_nonsmall(l_callback_16, l_totalsize_4);
	l_v930 = (&pypy_g_ExcData)->ed_exc_type;
	l_v931 = (l_v930 == NULL);
	if (!l_v931) {
		goto block43;
	}
	l_newhdr_1 = l_v929;
	l_totalsize_6 = l_totalsize_4;
	goto block25;

    block43:
	PYPY_DEBUG_RECORD_TRACEBACK("trace_partial___trace_drag_out");
	goto block3;

    block44:
	l_v933 = pypy_g_ArenaCollection_malloc((&pypy_g_rpython_memory_gc_minimarkpage_ArenaCollection), l_totalsize_4);
	l_v934 = (&pypy_g_ExcData)->ed_exc_type;
	l_v935 = (l_v934 == NULL);
	if (!l_v935) {
		goto block45;
	}
	l_newhdr_1 = l_v933;
	l_totalsize_6 = l_totalsize_4;
	goto block25;

    block45:
	PYPY_DEBUG_RECORD_TRACEBACK("trace_partial___trace_drag_out");
	goto block3;

    block46:
	PYPY_DEBUG_RECORD_TRACEBACK("trace_partial___trace_drag_out");
	goto block3;

    block47:
	OP_ADR_ADD(l_obj_4, offsetof(struct pypy_array12, items), l_v938);
	OP_INT_MUL(sizeof(void*), l_start_9, l_v939);
	OP_ADR_ADD(l_v938, l_v939, l_v940);
	l_item_3 = l_v940;
	l_length_26 = l_v758;
	goto block48;

    block48:
	while (1) {
		OP_INT_GT(l_length_26, 0L, l_v941);
		if (!l_v941) break;
		goto block49;
	  block48_back: ;
	}
	goto block3;

    block49:
	l_v942 = ((void* *) (((char *)l_item_3) + 0))[0];
	OP_ADR_NE(l_v942, NULL, l_v943);
	if (l_v943) {
		goto block51;
	}
	goto block50;

    block50:
	OP_ADR_ADD(l_item_3, sizeof(void*), l_v944);
	OP_INT_SUB(l_length_26, 1L, l_v945);
	l_item_3 = l_v944;
	l_length_26 = l_v945;
	goto block48_back;

    block51:
	l_addr_0 = ((void* *) (((char *)l_item_3) + 0))[0];
	OP_CAST_ADR_TO_INT(l_addr_0, /* nothing */, l_v946);
	OP_INT_AND(l_v946, 1L, l_v947);
	OP_INT_EQ(l_v947, 0L, l_v948);
	RPyAssert(l_v948, "odd-valued (i.e. tagged) pointer unexpected here");
	l_v950 = RPyField(l_callback_16, mmgc_inst_nursery);
	OP_ADR_LE(l_v950, l_addr_0, l_v951);
	if (l_v951) {
		goto block59;
	}
	goto block52;

    block52:
	l_v952 = RPyField(l_callback_16, mmgc_inst_young_rawmalloced_objects);
	l_v953 = (l_v952 != NULL);
	if (l_v953) {
		goto block53;
	}
	goto block50;

    block53:
	l_v746 = RPyField(l_callback_16, mmgc_inst_young_rawmalloced_objects);
	OP_CAST_ADR_TO_INT(l_addr_0, /* nothing */, l_v954);
	OP_INT_RSHIFT(l_v954, 4L, l_v955);
	OP_INT_XOR(l_v954, l_v955, l_v760);
	OP_INT_IS_TRUE(0 /* we are not jitted here */, l_v956);
	if (l_v956) {
		goto block58;
	}
	goto block54;

    block54:
	l_v957 = pypy_g_ll_dict_lookup__v51___simple_call__function_ll(l_v746, l_addr_0, l_v760);
	l_v1068 = l_v957;
	goto block55;

    block55:
	OP_UINT_AND(l_v1068, 2147483648UL, l_v958);
	OP_UINT_IS_TRUE(l_v958, l_v959);
	if (l_v959) {
		goto block50;
	}
	goto block56;

    block56:
	pypy_g_MiniMarkGC__visit_young_rawmalloced_object(l_callback_16, l_addr_0);
	l_v961 = (&pypy_g_ExcData)->ed_exc_type;
	l_v962 = (l_v961 == NULL);
	if (!l_v962) {
		goto block57;
	}
	goto block50;

    block57:
	PYPY_DEBUG_RECORD_TRACEBACK("trace_partial___trace_drag_out");
	goto block3;

    block58:
	l_v964 = pypy_g_ll_dict_lookup__v60___simple_call__function_ll(l_v746, l_addr_0, l_v760);
	l_v1068 = l_v964;
	goto block55;

    block59:
	l_v965 = RPyField(l_callback_16, mmgc_inst_nursery_real_top);
	OP_ADR_LT(l_addr_0, l_v965, l_v966);
	if (l_v966) {
		goto block60;
	}
	goto block52;

    block60:
	OP_ADR_SUB(l_addr_0, 0, l_v967);
	l_v968 = (struct pypy_header0 *)l_v967;
	l_v969 = RPyField(l_v968, h_tid);
	OP_INT_AND(l_v969, 524288L, l_v970);
	OP_INT_EQ(l_v970, 0L, l_v971);
	if (l_v971) {
		goto block83;
	}
	goto block61;

    block61:
	OP_CAST_ADR_TO_INT(l_addr_0, /* nothing */, l_v972);
	OP_INT_AND(l_v972, 1L, l_v973);
	OP_INT_EQ(l_v973, 0L, l_v974);
	RPyAssert(l_v974, "odd-valued (i.e. tagged) pointer unexpected here");
	l_v976 = RPyField(l_callback_16, mmgc_inst_nursery);
	OP_ADR_LE(l_v976, l_addr_0, l_v977);
	if (l_v977) {
		goto block63;
	}
	goto block62;

    block62:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("trace_partial___trace_drag_out");
	goto block3;

    block63:
	l_v980 = RPyField(l_callback_16, mmgc_inst_nursery_real_top);
	OP_ADR_LT(l_addr_0, l_v980, l_v981);
	if (l_v981) {
		goto block65;
	}
	goto block64;

    block64:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("trace_partial___trace_drag_out");
	goto block3;

    block65:
	OP_ADR_SUB(l_addr_0, 0, l_v984);
	l_v985 = (struct pypy_header0 *)l_v984;
	l_v756 = RPyField(l_v985, h_tid);
	OP_INT_AND(l_v756, 1048576L, l_v986);
	OP_INT_NE(l_v986, 0L, l_v987);
	if (l_v987) {
		goto block82;
	}
	goto block66;

    block66:
	OP_INT_IS_TRUE(l_v756, l_v988);
	RPyAssert(l_v988, "bogus header (1)");
	OP_INT_AND(l_v756, -16777216L, l_v990);
	OP_INT_EQ(l_v990, 0L, l_v991);
	RPyAssert(l_v991, "bogus header (2)");
	l_v993 = RPyField(l_callback_16, mmgc_inst_nursery_objects_shadows);
	l_v994 = pypy_g_ll_get__DICTPtr_Address_Address(l_v993, l_addr_0, NULL);
	OP_ADR_NE(l_v994, NULL, l_v995);
	RPyAssert(l_v995, "GCFLAG_HAS_SHADOW but no shadow found");
	OP_ADR_SUB(l_v994, 0, l_v747);
	OP_ADR_SUB(l_addr_0, 0, l_v997);
	l_v998 = (struct pypy_header0 *)l_v997;
	l_v999 = RPyField(l_v998, h_tid);
	OP_INT_AND(l_v999, -524289L, l_v1000);
	RPyField(l_v998, h_tid) = l_v1000;
	OP_ADR_SUB(l_addr_0, 0, l_v1002);
	l_v1003 = (struct pypy_header0 *)l_v1002;
	l_v1004 = RPyField(l_v1003, h_tid);
	OP_EXTRACT_USHORT(l_v1004, l_v1005);
	l_v749 = pypy_g_GCBase__get_size_for_typeid(l_callback_16, l_addr_0, l_v1005);
	l_v1006 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1007 = (l_v1006 == NULL);
	if (!l_v1007) {
		goto block81;
	}
	goto block67;

    block67:
	OP_INT_ADD(0, l_v749, l_v1008);
	l_newhdr_0 = l_v747;
	l_totalsize_5 = l_v1008;
	goto block68;

    block68:
	OP_ADR_SUB(l_addr_0, 0, l_v1009);
	OP_RAW_MEMCOPY(l_v1009, l_newhdr_0, l_totalsize_5, /* nothing */);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v1011);
	if (l_v1011) {
		goto block79;
	}
	l_v765 = l_addr_0;
	goto block69;

    block69:
	OP_ADR_SUB(l_v765, 0, l_v762);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v1012);
	if (l_v1012) {
		goto block77;
	}
	goto block70;

    block70:
	OP_ADR_SUB(l_v765, 0, l_v759);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v1013);
	if (l_v1013) {
		goto block75;
	}
	goto block71;

    block71:
	OP_ADR_SUB(l_v765, 0, l_v1014);
	l_v1015 = (struct pypy_header0 *)l_v1014;
	RPyField(l_v1015, h_tid) = -42L;
	OP_ADR_ADD(l_newhdr_0, 0, l_v754);
	l_v1017 = (struct pypy_forwarding_stub0 *)l_v765;
	RPyField(l_v1017, fs_forw) = l_v754;
	((void* *) (((char *)l_item_3) + 0))[0] = l_v754;
	l_v1020 = (&pypy_g_rpython_memory_support_AddressStack)->as_inst_used_in_last_chunk;
	OP_INT_EQ(l_v1020, 1019L, l_v1021);
	if (l_v1021) {
		goto block73;
	}
	l_used_1 = l_v1020;
	goto block72;

    block72:
	l_v1022 = (&pypy_g_rpython_memory_support_AddressStack)->as_inst_chunk;
	l_v1023 = RPyField(l_v1022, ac_items);
	RPyFxItem(l_v1023, l_used_1, 1019) = l_v754;
	OP_INT_ADD(l_used_1, 1L, l_v1025);
	(&pypy_g_rpython_memory_support_AddressStack)->as_inst_used_in_last_chunk = l_v1025;
	goto block50;

    block73:
	pypy_g_AddressStack_enlarge((&pypy_g_rpython_memory_support_AddressStack));
	l_v1028 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1029 = (l_v1028 == NULL);
	if (!l_v1029) {
		goto block74;
	}
	l_used_1 = 0L;
	goto block72;

    block74:
	PYPY_DEBUG_RECORD_TRACEBACK("trace_partial___trace_drag_out");
	goto block3;

    block75:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v1032 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1033 = (l_v1032 == NULL);
	if (!l_v1033) {
		goto block76;
	}
	goto block71;

    block76:
	PYPY_DEBUG_RECORD_TRACEBACK("trace_partial___trace_drag_out");
	goto block3;

    block77:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v1036 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1037 = (l_v1036 == NULL);
	if (!l_v1037) {
		goto block78;
	}
	goto block70;

    block78:
	PYPY_DEBUG_RECORD_TRACEBACK("trace_partial___trace_drag_out");
	goto block3;

    block79:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v1039 = (void*)0;
	l_v1040 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1041 = (l_v1040 == NULL);
	if (!l_v1041) {
		goto block80;
	}
	l_v765 = l_v1039;
	goto block69;

    block80:
	PYPY_DEBUG_RECORD_TRACEBACK("trace_partial___trace_drag_out");
	goto block3;

    block81:
	PYPY_DEBUG_RECORD_TRACEBACK("trace_partial___trace_drag_out");
	goto block3;

    block82:
	OP_INT_EQ(l_v756, -42L, l_v1044);
	RPyAssert(l_v1044, "bogus header for young obj");
	l_v1046 = (struct pypy_forwarding_stub0 *)l_addr_0;
	l_v1047 = RPyField(l_v1046, fs_forw);
	((void* *) (((char *)l_item_3) + 0))[0] = l_v1047;
	goto block50;

    block83:
	OP_ADR_SUB(l_addr_0, 0, l_v1049);
	l_v1050 = (struct pypy_header0 *)l_v1049;
	l_v1051 = RPyField(l_v1050, h_tid);
	OP_EXTRACT_USHORT(l_v1051, l_v1052);
	l_v751 = pypy_g_GCBase__get_size_for_typeid(l_callback_16, l_addr_0, l_v1052);
	l_v1053 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1054 = (l_v1053 == NULL);
	if (!l_v1054) {
		goto block89;
	}
	goto block84;

    block84:
	OP_INT_ADD(0, l_v751, l_totalsize_3);
	OP_RAW_MALLOC_USAGE(l_totalsize_3, l_v1055);
	OP_INT_LE(l_v1055, 140L, l_v1056);
	if (l_v1056) {
		goto block87;
	}
	goto block85;

    block85:
	l_v1057 = pypy_g_MiniMarkGC__malloc_out_of_nursery_nonsmall(l_callback_16, l_totalsize_3);
	l_v1058 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1059 = (l_v1058 == NULL);
	if (!l_v1059) {
		goto block86;
	}
	l_newhdr_0 = l_v1057;
	l_totalsize_5 = l_totalsize_3;
	goto block68;

    block86:
	PYPY_DEBUG_RECORD_TRACEBACK("trace_partial___trace_drag_out");
	goto block3;

    block87:
	l_v1061 = pypy_g_ArenaCollection_malloc((&pypy_g_rpython_memory_gc_minimarkpage_ArenaCollection), l_totalsize_3);
	l_v1062 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1063 = (l_v1062 == NULL);
	if (!l_v1063) {
		goto block88;
	}
	l_newhdr_0 = l_v1061;
	l_totalsize_5 = l_totalsize_3;
	goto block68;

    block88:
	PYPY_DEBUG_RECORD_TRACEBACK("trace_partial___trace_drag_out");
	goto block3;

    block89:
	PYPY_DEBUG_RECORD_TRACEBACK("trace_partial___trace_drag_out");
	goto block3;
}
/*/*/
void pypy_g_trace___trace_drag_out(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_68, void* l_obj_18, struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_v1069) {
	void* l_addr_1; Signed l_i_7; Signed l_length_27; void* l_newhdr_2;
	void* l_newhdr_3; void* l_obj_19; struct pypy_array8 *l_offsets_1;
	void* l_root_3; void* l_root_4; Signed l_tid_1; Signed l_totalsize_7;
	Signed l_totalsize_8; Signed l_totalsize_9; Signed l_used_2;
	Signed l_used_3; Signed l_v1072; Signed l_v1079; Signed l_v1082;
	Signed l_v1083; Signed l_v1084; Signed l_v1087; Signed l_v1089;
	Signed l_v1090; Signed l_v1093; Signed l_v1095; Signed l_v1096;
	Signed l_v1099; Signed l_v1102; Signed l_v1103; Signed l_v1106;
	Signed l_v1112; Signed l_v1113; Signed l_v1116; Signed l_v1118;
	Signed l_v1121; Signed l_v1122; Signed l_v1123; Signed l_v1130;
	Signed l_v1131; Signed l_v1145; Signed l_v1146; Signed l_v1148;
	Signed l_v1149; Signed l_v1162; Signed l_v1166; Signed l_v1175;
	Signed l_v1176; Signed l_v1180; Signed l_v1184; Signed l_v1196;
	Signed l_v1201; Signed l_v1227; Signed l_v1231; Signed l_v1244;
	Signed l_v1250; Signed l_v1251; Signed l_v1252; Signed l_v1259;
	Signed l_v1260; Signed l_v1274; Signed l_v1275; Signed l_v1277;
	Signed l_v1278; Signed l_v1291; Signed l_v1295; Signed l_v1304;
	Signed l_v1305; Signed l_v1309; Signed l_v1313; Signed l_v1325;
	Signed l_v1330; Signed l_v1356; Signed l_v1360; Unsigned l_v1133;
	Unsigned l_v1134; Unsigned l_v1140; Unsigned l_v1262;
	Unsigned l_v1263; Unsigned l_v1269; Unsigned l_v1372;
	Unsigned l_v1373; bool_t l_v1097; bool_t l_v1100; bool_t l_v1104;
	bool_t l_v1107; bool_t l_v1110; bool_t l_v1114; bool_t l_v1117;
	bool_t l_v1120; bool_t l_v1124; bool_t l_v1127; bool_t l_v1129;
	bool_t l_v1132; bool_t l_v1135; bool_t l_v1138; bool_t l_v1142;
	bool_t l_v1147; bool_t l_v1150; bool_t l_v1153; bool_t l_v1157;
	bool_t l_v1163; bool_t l_v1164; bool_t l_v1167; bool_t l_v1171;
	bool_t l_v1183; bool_t l_v1187; bool_t l_v1188; bool_t l_v1189;
	bool_t l_v1197; bool_t l_v1205; bool_t l_v1209; bool_t l_v1213;
	bool_t l_v1217; bool_t l_v1220; bool_t l_v1230; bool_t l_v1232;
	bool_t l_v1235; bool_t l_v1239; bool_t l_v1246; bool_t l_v1248;
	bool_t l_v1253; bool_t l_v1256; bool_t l_v1258; bool_t l_v1261;
	bool_t l_v1264; bool_t l_v1267; bool_t l_v1271; bool_t l_v1276;
	bool_t l_v1279; bool_t l_v1282; bool_t l_v1286; bool_t l_v1292;
	bool_t l_v1293; bool_t l_v1296; bool_t l_v1300; bool_t l_v1312;
	bool_t l_v1316; bool_t l_v1317; bool_t l_v1318; bool_t l_v1326;
	bool_t l_v1334; bool_t l_v1338; bool_t l_v1342; bool_t l_v1346;
	bool_t l_v1349; bool_t l_v1359; bool_t l_v1361; bool_t l_v1364;
	bool_t l_v1368; struct pypy_AddressChunk0 *l_v1198;
	struct pypy_AddressChunk0 *l_v1327; struct pypy_DICT0 *l_v1076;
	struct pypy_DICT0 *l_v1086; struct pypy_DICT0 *l_v1128;
	struct pypy_DICT0 *l_v1169; struct pypy_DICT0 *l_v1257;
	struct pypy_DICT0 *l_v1298; struct pypy_forwarding_stub0 *l_v1193;
	struct pypy_forwarding_stub0 *l_v1222;
	struct pypy_forwarding_stub0 *l_v1322;
	struct pypy_forwarding_stub0 *l_v1351; struct pypy_header0 *l_v1092;
	struct pypy_header0 *l_v1144; struct pypy_header0 *l_v1161;
	struct pypy_header0 *l_v1174; struct pypy_header0 *l_v1179;
	struct pypy_header0 *l_v1191; struct pypy_header0 *l_v1226;
	struct pypy_header0 *l_v1273; struct pypy_header0 *l_v1290;
	struct pypy_header0 *l_v1303; struct pypy_header0 *l_v1308;
	struct pypy_header0 *l_v1320; struct pypy_header0 *l_v1355;
	struct pypy_object_vtable0 *l_v1109;
	struct pypy_object_vtable0 *l_v1137;
	struct pypy_object_vtable0 *l_v1182;
	struct pypy_object_vtable0 *l_v1204;
	struct pypy_object_vtable0 *l_v1208;
	struct pypy_object_vtable0 *l_v1212;
	struct pypy_object_vtable0 *l_v1216;
	struct pypy_object_vtable0 *l_v1229;
	struct pypy_object_vtable0 *l_v1234;
	struct pypy_object_vtable0 *l_v1238;
	struct pypy_object_vtable0 *l_v1266;
	struct pypy_object_vtable0 *l_v1311;
	struct pypy_object_vtable0 *l_v1333;
	struct pypy_object_vtable0 *l_v1337;
	struct pypy_object_vtable0 *l_v1341;
	struct pypy_object_vtable0 *l_v1345;
	struct pypy_object_vtable0 *l_v1358;
	struct pypy_object_vtable0 *l_v1363;
	struct pypy_object_vtable0 *l_v1367; struct pypy_type_info0 *l_v1094;
	struct pypy_type_info0 *l_v1101; struct pypy_type_info0 *l_v1111;
	unsigned short l_v1074; unsigned short l_v1181;
	unsigned short l_v1228; unsigned short l_v1310;
	unsigned short l_v1357; void* *l_v1199; void* *l_v1328;
	void* l_v1070; void* l_v1071; void* l_v1073; void* l_v1075;
	void* l_v1077; void* l_v1078; void* l_v1080; void* l_v1081;
	void* l_v1085; void* l_v1088; void* l_v1091; void* l_v1119;
	void* l_v1126; void* l_v1141; void* l_v1143; void* l_v1152;
	void* l_v1156; void* l_v1160; void* l_v1170; void* l_v1173;
	void* l_v1178; void* l_v1185; void* l_v1190; void* l_v1215;
	void* l_v1223; void* l_v1225; void* l_v1233; void* l_v1237;
	void* l_v1243; void* l_v1245; void* l_v1247; void* l_v1249;
	void* l_v1255; void* l_v1270; void* l_v1272; void* l_v1281;
	void* l_v1285; void* l_v1289; void* l_v1299; void* l_v1302;
	void* l_v1307; void* l_v1314; void* l_v1319; void* l_v1344;
	void* l_v1352; void* l_v1354; void* l_v1362; void* l_v1366;
	goto block0;

    block0:
	OP_ADR_SUB(l_obj_18, 0, l_v1091);
	l_v1092 = (struct pypy_header0 *)l_v1091;
	l_v1093 = RPyField(l_v1092, h_tid);
	OP_EXTRACT_USHORT(l_v1093, l_v1074);
	l_v1094 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_v1074);
	l_v1095 = RPyField(l_v1094, ti_infobits);
	OP_INT_AND(l_v1095, -16777216L, l_v1096);
	OP_INT_EQ(l_v1096, 1509949440L, l_v1097);
	RPyAssert(l_v1097, "invalid type_id");
	OP_INT_AND(l_v1095, 4587520L, l_v1099);
	OP_INT_EQ(l_v1099, 0L, l_v1100);
	if (l_v1100) {
		goto block3;
	}
	goto block1;

    block1:
	l_v1101 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_v1074);
	l_v1102 = RPyField(l_v1101, ti_infobits);
	OP_INT_AND(l_v1102, -16777216L, l_v1103);
	OP_INT_EQ(l_v1103, 1509949440L, l_v1104);
	RPyAssert(l_v1104, "invalid type_id");
	OP_INT_AND(l_v1102, 262144L, l_v1106);
	OP_INT_NE(l_v1106, 0L, l_v1107);
	if (l_v1107) {
		goto block48;
	}
	goto block2;

    block2:
	pypy_g__trace_slow_path___trace_drag_out(l_self_68, l_obj_18, l_v1069);
	l_v1109 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1110 = (l_v1109 == NULL);
	if (!l_v1110) {
		goto block47;
	}
	goto block3;

    block3:
	l_v1111 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_v1074);
	l_v1112 = RPyField(l_v1111, ti_infobits);
	OP_INT_AND(l_v1112, -16777216L, l_v1113);
	OP_INT_EQ(l_v1113, 1509949440L, l_v1114);
	RPyAssert(l_v1114, "invalid type_id");
	l_offsets_1 = RPyField(l_v1111, ti_ofstoptrs);
	l_i_7 = 0L;
	goto block4;

    block4:
	while (1) {
		l_v1116 = l_offsets_1->length;
		OP_INT_LT(l_i_7, l_v1116, l_v1117);
		if (!l_v1117) break;
		goto block6;
	  block4_back: ;
	}
	goto block5;

    block5:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block6:
	l_v1118 = RPyItem(l_offsets_1, l_i_7);
	OP_ADR_ADD(l_obj_18, l_v1118, l_root_4);
	l_v1119 = ((void* *) (((char *)l_root_4) + 0))[0];
	OP_ADR_NE(l_v1119, NULL, l_v1120);
	if (l_v1120) {
		goto block8;
	}
	goto block7;

    block7:
	OP_INT_ADD(l_i_7, 1L, l_v1121);
	l_i_7 = l_v1121;
	goto block4_back;

    block8:
	l_addr_1 = ((void* *) (((char *)l_root_4) + 0))[0];
	OP_CAST_ADR_TO_INT(l_addr_1, /* nothing */, l_v1122);
	OP_INT_AND(l_v1122, 1L, l_v1123);
	OP_INT_EQ(l_v1123, 0L, l_v1124);
	RPyAssert(l_v1124, "odd-valued (i.e. tagged) pointer unexpected here");
	l_v1126 = RPyField(l_v1069, mmgc_inst_nursery);
	OP_ADR_LE(l_v1126, l_addr_1, l_v1127);
	if (l_v1127) {
		goto block16;
	}
	goto block9;

    block9:
	l_v1128 = RPyField(l_v1069, mmgc_inst_young_rawmalloced_objects);
	l_v1129 = (l_v1128 != NULL);
	if (l_v1129) {
		goto block10;
	}
	goto block7;

    block10:
	l_v1076 = RPyField(l_v1069, mmgc_inst_young_rawmalloced_objects);
	OP_CAST_ADR_TO_INT(l_addr_1, /* nothing */, l_v1130);
	OP_INT_RSHIFT(l_v1130, 4L, l_v1131);
	OP_INT_XOR(l_v1130, l_v1131, l_v1082);
	OP_INT_IS_TRUE(0 /* we are not jitted here */, l_v1132);
	if (l_v1132) {
		goto block15;
	}
	goto block11;

    block11:
	l_v1133 = pypy_g_ll_dict_lookup__v51___simple_call__function_ll(l_v1076, l_addr_1, l_v1082);
	l_v1372 = l_v1133;
	goto block12;

    block12:
	OP_UINT_AND(l_v1372, 2147483648UL, l_v1134);
	OP_UINT_IS_TRUE(l_v1134, l_v1135);
	if (l_v1135) {
		goto block7;
	}
	goto block13;

    block13:
	pypy_g_MiniMarkGC__visit_young_rawmalloced_object(l_v1069, l_addr_1);
	l_v1137 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1138 = (l_v1137 == NULL);
	if (!l_v1138) {
		goto block14;
	}
	goto block7;

    block14:
	PYPY_DEBUG_RECORD_TRACEBACK("trace___trace_drag_out");
	goto block5;

    block15:
	l_v1140 = pypy_g_ll_dict_lookup__v60___simple_call__function_ll(l_v1076, l_addr_1, l_v1082);
	l_v1372 = l_v1140;
	goto block12;

    block16:
	l_v1141 = RPyField(l_v1069, mmgc_inst_nursery_real_top);
	OP_ADR_LT(l_addr_1, l_v1141, l_v1142);
	if (l_v1142) {
		goto block17;
	}
	goto block9;

    block17:
	OP_ADR_SUB(l_addr_1, 0, l_v1143);
	l_v1144 = (struct pypy_header0 *)l_v1143;
	l_v1145 = RPyField(l_v1144, h_tid);
	OP_INT_AND(l_v1145, 524288L, l_v1146);
	OP_INT_EQ(l_v1146, 0L, l_v1147);
	if (l_v1147) {
		goto block40;
	}
	goto block18;

    block18:
	OP_CAST_ADR_TO_INT(l_addr_1, /* nothing */, l_v1148);
	OP_INT_AND(l_v1148, 1L, l_v1149);
	OP_INT_EQ(l_v1149, 0L, l_v1150);
	RPyAssert(l_v1150, "odd-valued (i.e. tagged) pointer unexpected here");
	l_v1152 = RPyField(l_v1069, mmgc_inst_nursery);
	OP_ADR_LE(l_v1152, l_addr_1, l_v1153);
	if (l_v1153) {
		goto block20;
	}
	goto block19;

    block19:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("trace___trace_drag_out");
	goto block5;

    block20:
	l_v1156 = RPyField(l_v1069, mmgc_inst_nursery_real_top);
	OP_ADR_LT(l_addr_1, l_v1156, l_v1157);
	if (l_v1157) {
		goto block22;
	}
	goto block21;

    block21:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("trace___trace_drag_out");
	goto block5;

    block22:
	OP_ADR_SUB(l_addr_1, 0, l_v1160);
	l_v1161 = (struct pypy_header0 *)l_v1160;
	l_tid_1 = RPyField(l_v1161, h_tid);
	OP_INT_AND(l_tid_1, 1048576L, l_v1162);
	OP_INT_NE(l_v1162, 0L, l_v1163);
	if (l_v1163) {
		goto block39;
	}
	goto block23;

    block23:
	OP_INT_IS_TRUE(l_tid_1, l_v1164);
	RPyAssert(l_v1164, "bogus header (1)");
	OP_INT_AND(l_tid_1, -16777216L, l_v1166);
	OP_INT_EQ(l_v1166, 0L, l_v1167);
	RPyAssert(l_v1167, "bogus header (2)");
	l_v1169 = RPyField(l_v1069, mmgc_inst_nursery_objects_shadows);
	l_v1170 = pypy_g_ll_get__DICTPtr_Address_Address(l_v1169, l_addr_1, NULL);
	OP_ADR_NE(l_v1170, NULL, l_v1171);
	RPyAssert(l_v1171, "GCFLAG_HAS_SHADOW but no shadow found");
	OP_ADR_SUB(l_v1170, 0, l_v1078);
	OP_ADR_SUB(l_addr_1, 0, l_v1173);
	l_v1174 = (struct pypy_header0 *)l_v1173;
	l_v1175 = RPyField(l_v1174, h_tid);
	OP_INT_AND(l_v1175, -524289L, l_v1176);
	RPyField(l_v1174, h_tid) = l_v1176;
	OP_ADR_SUB(l_addr_1, 0, l_v1178);
	l_v1179 = (struct pypy_header0 *)l_v1178;
	l_v1180 = RPyField(l_v1179, h_tid);
	OP_EXTRACT_USHORT(l_v1180, l_v1181);
	l_v1090 = pypy_g_GCBase__get_size_for_typeid(l_v1069, l_addr_1, l_v1181);
	l_v1182 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1183 = (l_v1182 == NULL);
	if (!l_v1183) {
		goto block38;
	}
	goto block24;

    block24:
	OP_INT_ADD(0, l_v1090, l_v1184);
	l_totalsize_8 = l_v1184;
	l_newhdr_3 = l_v1078;
	goto block25;

    block25:
	OP_ADR_SUB(l_addr_1, 0, l_v1185);
	OP_RAW_MEMCOPY(l_v1185, l_newhdr_3, l_totalsize_8, /* nothing */);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v1187);
	if (l_v1187) {
		goto block36;
	}
	l_v1071 = l_addr_1;
	goto block26;

    block26:
	OP_ADR_SUB(l_v1071, 0, l_v1075);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v1188);
	if (l_v1188) {
		goto block34;
	}
	goto block27;

    block27:
	OP_ADR_SUB(l_v1071, 0, l_v1085);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v1189);
	if (l_v1189) {
		goto block32;
	}
	goto block28;

    block28:
	OP_ADR_SUB(l_v1071, 0, l_v1190);
	l_v1191 = (struct pypy_header0 *)l_v1190;
	RPyField(l_v1191, h_tid) = -42L;
	OP_ADR_ADD(l_newhdr_3, 0, l_v1077);
	l_v1193 = (struct pypy_forwarding_stub0 *)l_v1071;
	RPyField(l_v1193, fs_forw) = l_v1077;
	((void* *) (((char *)l_root_4) + 0))[0] = l_v1077;
	l_v1196 = (&pypy_g_rpython_memory_support_AddressStack)->as_inst_used_in_last_chunk;
	OP_INT_EQ(l_v1196, 1019L, l_v1197);
	if (l_v1197) {
		goto block30;
	}
	l_used_2 = l_v1196;
	goto block29;

    block29:
	l_v1198 = (&pypy_g_rpython_memory_support_AddressStack)->as_inst_chunk;
	l_v1199 = RPyField(l_v1198, ac_items);
	RPyFxItem(l_v1199, l_used_2, 1019) = l_v1077;
	OP_INT_ADD(l_used_2, 1L, l_v1201);
	(&pypy_g_rpython_memory_support_AddressStack)->as_inst_used_in_last_chunk = l_v1201;
	goto block7;

    block30:
	pypy_g_AddressStack_enlarge((&pypy_g_rpython_memory_support_AddressStack));
	l_v1204 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1205 = (l_v1204 == NULL);
	if (!l_v1205) {
		goto block31;
	}
	l_used_2 = 0L;
	goto block29;

    block31:
	PYPY_DEBUG_RECORD_TRACEBACK("trace___trace_drag_out");
	goto block5;

    block32:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v1208 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1209 = (l_v1208 == NULL);
	if (!l_v1209) {
		goto block33;
	}
	goto block28;

    block33:
	PYPY_DEBUG_RECORD_TRACEBACK("trace___trace_drag_out");
	goto block5;

    block34:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v1212 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1213 = (l_v1212 == NULL);
	if (!l_v1213) {
		goto block35;
	}
	goto block27;

    block35:
	PYPY_DEBUG_RECORD_TRACEBACK("trace___trace_drag_out");
	goto block5;

    block36:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v1215 = (void*)0;
	l_v1216 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1217 = (l_v1216 == NULL);
	if (!l_v1217) {
		goto block37;
	}
	l_v1071 = l_v1215;
	goto block26;

    block37:
	PYPY_DEBUG_RECORD_TRACEBACK("trace___trace_drag_out");
	goto block5;

    block38:
	PYPY_DEBUG_RECORD_TRACEBACK("trace___trace_drag_out");
	goto block5;

    block39:
	OP_INT_EQ(l_tid_1, -42L, l_v1220);
	RPyAssert(l_v1220, "bogus header for young obj");
	l_v1222 = (struct pypy_forwarding_stub0 *)l_addr_1;
	l_v1223 = RPyField(l_v1222, fs_forw);
	((void* *) (((char *)l_root_4) + 0))[0] = l_v1223;
	goto block7;

    block40:
	OP_ADR_SUB(l_addr_1, 0, l_v1225);
	l_v1226 = (struct pypy_header0 *)l_v1225;
	l_v1227 = RPyField(l_v1226, h_tid);
	OP_EXTRACT_USHORT(l_v1227, l_v1228);
	l_v1084 = pypy_g_GCBase__get_size_for_typeid(l_v1069, l_addr_1, l_v1228);
	l_v1229 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1230 = (l_v1229 == NULL);
	if (!l_v1230) {
		goto block46;
	}
	goto block41;

    block41:
	OP_INT_ADD(0, l_v1084, l_v1087);
	OP_RAW_MALLOC_USAGE(l_v1087, l_v1231);
	OP_INT_LE(l_v1231, 140L, l_v1232);
	if (l_v1232) {
		goto block44;
	}
	goto block42;

    block42:
	l_v1233 = pypy_g_MiniMarkGC__malloc_out_of_nursery_nonsmall(l_v1069, l_v1087);
	l_v1234 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1235 = (l_v1234 == NULL);
	if (!l_v1235) {
		goto block43;
	}
	l_totalsize_8 = l_v1087;
	l_newhdr_3 = l_v1233;
	goto block25;

    block43:
	PYPY_DEBUG_RECORD_TRACEBACK("trace___trace_drag_out");
	goto block5;

    block44:
	l_v1237 = pypy_g_ArenaCollection_malloc((&pypy_g_rpython_memory_gc_minimarkpage_ArenaCollection), l_v1087);
	l_v1238 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1239 = (l_v1238 == NULL);
	if (!l_v1239) {
		goto block45;
	}
	l_totalsize_8 = l_v1087;
	l_newhdr_3 = l_v1237;
	goto block25;

    block45:
	PYPY_DEBUG_RECORD_TRACEBACK("trace___trace_drag_out");
	goto block5;

    block46:
	PYPY_DEBUG_RECORD_TRACEBACK("trace___trace_drag_out");
	goto block5;

    block47:
	PYPY_DEBUG_RECORD_TRACEBACK("trace___trace_drag_out");
	goto block5;

    block48:
	OP_ADR_ADD(l_obj_18, offsetof(struct pypy_array12, length), l_v1243);
	l_v1244 = ((Signed *) (((char *)l_v1243) + 0))[0];
	OP_ADR_ADD(l_obj_18, offsetof(struct pypy_array12, items), l_v1245);
	l_root_3 = l_v1245;
	l_length_27 = l_v1244;
	goto block49;

    block49:
	while (1) {
		OP_INT_GT(l_length_27, 0L, l_v1246);
		if (!l_v1246) break;
		goto block50;
	  block49_back: ;
	}
	goto block5;

    block50:
	l_v1247 = ((void* *) (((char *)l_root_3) + 0))[0];
	OP_ADR_NE(l_v1247, NULL, l_v1248);
	if (l_v1248) {
		goto block52;
	}
	goto block51;

    block51:
	OP_ADR_ADD(l_root_3, sizeof(void*), l_v1249);
	OP_INT_SUB(l_length_27, 1L, l_v1250);
	l_root_3 = l_v1249;
	l_length_27 = l_v1250;
	goto block49_back;

    block52:
	l_obj_19 = ((void* *) (((char *)l_root_3) + 0))[0];
	OP_CAST_ADR_TO_INT(l_obj_19, /* nothing */, l_v1251);
	OP_INT_AND(l_v1251, 1L, l_v1252);
	OP_INT_EQ(l_v1252, 0L, l_v1253);
	RPyAssert(l_v1253, "odd-valued (i.e. tagged) pointer unexpected here");
	l_v1255 = RPyField(l_v1069, mmgc_inst_nursery);
	OP_ADR_LE(l_v1255, l_obj_19, l_v1256);
	if (l_v1256) {
		goto block60;
	}
	goto block53;

    block53:
	l_v1257 = RPyField(l_v1069, mmgc_inst_young_rawmalloced_objects);
	l_v1258 = (l_v1257 != NULL);
	if (l_v1258) {
		goto block54;
	}
	goto block51;

    block54:
	l_v1086 = RPyField(l_v1069, mmgc_inst_young_rawmalloced_objects);
	OP_CAST_ADR_TO_INT(l_obj_19, /* nothing */, l_v1259);
	OP_INT_RSHIFT(l_v1259, 4L, l_v1260);
	OP_INT_XOR(l_v1259, l_v1260, l_v1083);
	OP_INT_IS_TRUE(0 /* we are not jitted here */, l_v1261);
	if (l_v1261) {
		goto block59;
	}
	goto block55;

    block55:
	l_v1262 = pypy_g_ll_dict_lookup__v51___simple_call__function_ll(l_v1086, l_obj_19, l_v1083);
	l_v1373 = l_v1262;
	goto block56;

    block56:
	OP_UINT_AND(l_v1373, 2147483648UL, l_v1263);
	OP_UINT_IS_TRUE(l_v1263, l_v1264);
	if (l_v1264) {
		goto block51;
	}
	goto block57;

    block57:
	pypy_g_MiniMarkGC__visit_young_rawmalloced_object(l_v1069, l_obj_19);
	l_v1266 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1267 = (l_v1266 == NULL);
	if (!l_v1267) {
		goto block58;
	}
	goto block51;

    block58:
	PYPY_DEBUG_RECORD_TRACEBACK("trace___trace_drag_out");
	goto block5;

    block59:
	l_v1269 = pypy_g_ll_dict_lookup__v60___simple_call__function_ll(l_v1086, l_obj_19, l_v1083);
	l_v1373 = l_v1269;
	goto block56;

    block60:
	l_v1270 = RPyField(l_v1069, mmgc_inst_nursery_real_top);
	OP_ADR_LT(l_obj_19, l_v1270, l_v1271);
	if (l_v1271) {
		goto block61;
	}
	goto block53;

    block61:
	OP_ADR_SUB(l_obj_19, 0, l_v1272);
	l_v1273 = (struct pypy_header0 *)l_v1272;
	l_v1274 = RPyField(l_v1273, h_tid);
	OP_INT_AND(l_v1274, 524288L, l_v1275);
	OP_INT_EQ(l_v1275, 0L, l_v1276);
	if (l_v1276) {
		goto block84;
	}
	goto block62;

    block62:
	OP_CAST_ADR_TO_INT(l_obj_19, /* nothing */, l_v1277);
	OP_INT_AND(l_v1277, 1L, l_v1278);
	OP_INT_EQ(l_v1278, 0L, l_v1279);
	RPyAssert(l_v1279, "odd-valued (i.e. tagged) pointer unexpected here");
	l_v1281 = RPyField(l_v1069, mmgc_inst_nursery);
	OP_ADR_LE(l_v1281, l_obj_19, l_v1282);
	if (l_v1282) {
		goto block64;
	}
	goto block63;

    block63:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("trace___trace_drag_out");
	goto block5;

    block64:
	l_v1285 = RPyField(l_v1069, mmgc_inst_nursery_real_top);
	OP_ADR_LT(l_obj_19, l_v1285, l_v1286);
	if (l_v1286) {
		goto block66;
	}
	goto block65;

    block65:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("trace___trace_drag_out");
	goto block5;

    block66:
	OP_ADR_SUB(l_obj_19, 0, l_v1289);
	l_v1290 = (struct pypy_header0 *)l_v1289;
	l_v1072 = RPyField(l_v1290, h_tid);
	OP_INT_AND(l_v1072, 1048576L, l_v1291);
	OP_INT_NE(l_v1291, 0L, l_v1292);
	if (l_v1292) {
		goto block83;
	}
	goto block67;

    block67:
	OP_INT_IS_TRUE(l_v1072, l_v1293);
	RPyAssert(l_v1293, "bogus header (1)");
	OP_INT_AND(l_v1072, -16777216L, l_v1295);
	OP_INT_EQ(l_v1295, 0L, l_v1296);
	RPyAssert(l_v1296, "bogus header (2)");
	l_v1298 = RPyField(l_v1069, mmgc_inst_nursery_objects_shadows);
	l_v1299 = pypy_g_ll_get__DICTPtr_Address_Address(l_v1298, l_obj_19, NULL);
	OP_ADR_NE(l_v1299, NULL, l_v1300);
	RPyAssert(l_v1300, "GCFLAG_HAS_SHADOW but no shadow found");
	OP_ADR_SUB(l_v1299, 0, l_v1088);
	OP_ADR_SUB(l_obj_19, 0, l_v1302);
	l_v1303 = (struct pypy_header0 *)l_v1302;
	l_v1304 = RPyField(l_v1303, h_tid);
	OP_INT_AND(l_v1304, -524289L, l_v1305);
	RPyField(l_v1303, h_tid) = l_v1305;
	OP_ADR_SUB(l_obj_19, 0, l_v1307);
	l_v1308 = (struct pypy_header0 *)l_v1307;
	l_v1309 = RPyField(l_v1308, h_tid);
	OP_EXTRACT_USHORT(l_v1309, l_v1310);
	l_v1079 = pypy_g_GCBase__get_size_for_typeid(l_v1069, l_obj_19, l_v1310);
	l_v1311 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1312 = (l_v1311 == NULL);
	if (!l_v1312) {
		goto block82;
	}
	goto block68;

    block68:
	OP_INT_ADD(0, l_v1079, l_v1313);
	l_newhdr_2 = l_v1088;
	l_totalsize_7 = l_v1313;
	goto block69;

    block69:
	OP_ADR_SUB(l_obj_19, 0, l_v1314);
	OP_RAW_MEMCOPY(l_v1314, l_newhdr_2, l_totalsize_7, /* nothing */);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v1316);
	if (l_v1316) {
		goto block80;
	}
	l_v1081 = l_obj_19;
	goto block70;

    block70:
	OP_ADR_SUB(l_v1081, 0, l_v1080);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v1317);
	if (l_v1317) {
		goto block78;
	}
	goto block71;

    block71:
	OP_ADR_SUB(l_v1081, 0, l_v1070);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v1318);
	if (l_v1318) {
		goto block76;
	}
	goto block72;

    block72:
	OP_ADR_SUB(l_v1081, 0, l_v1319);
	l_v1320 = (struct pypy_header0 *)l_v1319;
	RPyField(l_v1320, h_tid) = -42L;
	OP_ADR_ADD(l_newhdr_2, 0, l_v1073);
	l_v1322 = (struct pypy_forwarding_stub0 *)l_v1081;
	RPyField(l_v1322, fs_forw) = l_v1073;
	((void* *) (((char *)l_root_3) + 0))[0] = l_v1073;
	l_v1325 = (&pypy_g_rpython_memory_support_AddressStack)->as_inst_used_in_last_chunk;
	OP_INT_EQ(l_v1325, 1019L, l_v1326);
	if (l_v1326) {
		goto block74;
	}
	l_used_3 = l_v1325;
	goto block73;

    block73:
	l_v1327 = (&pypy_g_rpython_memory_support_AddressStack)->as_inst_chunk;
	l_v1328 = RPyField(l_v1327, ac_items);
	RPyFxItem(l_v1328, l_used_3, 1019) = l_v1073;
	OP_INT_ADD(l_used_3, 1L, l_v1330);
	(&pypy_g_rpython_memory_support_AddressStack)->as_inst_used_in_last_chunk = l_v1330;
	goto block51;

    block74:
	pypy_g_AddressStack_enlarge((&pypy_g_rpython_memory_support_AddressStack));
	l_v1333 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1334 = (l_v1333 == NULL);
	if (!l_v1334) {
		goto block75;
	}
	l_used_3 = 0L;
	goto block73;

    block75:
	PYPY_DEBUG_RECORD_TRACEBACK("trace___trace_drag_out");
	goto block5;

    block76:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v1337 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1338 = (l_v1337 == NULL);
	if (!l_v1338) {
		goto block77;
	}
	goto block72;

    block77:
	PYPY_DEBUG_RECORD_TRACEBACK("trace___trace_drag_out");
	goto block5;

    block78:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v1341 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1342 = (l_v1341 == NULL);
	if (!l_v1342) {
		goto block79;
	}
	goto block71;

    block79:
	PYPY_DEBUG_RECORD_TRACEBACK("trace___trace_drag_out");
	goto block5;

    block80:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v1344 = (void*)0;
	l_v1345 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1346 = (l_v1345 == NULL);
	if (!l_v1346) {
		goto block81;
	}
	l_v1081 = l_v1344;
	goto block70;

    block81:
	PYPY_DEBUG_RECORD_TRACEBACK("trace___trace_drag_out");
	goto block5;

    block82:
	PYPY_DEBUG_RECORD_TRACEBACK("trace___trace_drag_out");
	goto block5;

    block83:
	OP_INT_EQ(l_v1072, -42L, l_v1349);
	RPyAssert(l_v1349, "bogus header for young obj");
	l_v1351 = (struct pypy_forwarding_stub0 *)l_obj_19;
	l_v1352 = RPyField(l_v1351, fs_forw);
	((void* *) (((char *)l_root_3) + 0))[0] = l_v1352;
	goto block51;

    block84:
	OP_ADR_SUB(l_obj_19, 0, l_v1354);
	l_v1355 = (struct pypy_header0 *)l_v1354;
	l_v1356 = RPyField(l_v1355, h_tid);
	OP_EXTRACT_USHORT(l_v1356, l_v1357);
	l_v1089 = pypy_g_GCBase__get_size_for_typeid(l_v1069, l_obj_19, l_v1357);
	l_v1358 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1359 = (l_v1358 == NULL);
	if (!l_v1359) {
		goto block90;
	}
	goto block85;

    block85:
	OP_INT_ADD(0, l_v1089, l_totalsize_9);
	OP_RAW_MALLOC_USAGE(l_totalsize_9, l_v1360);
	OP_INT_LE(l_v1360, 140L, l_v1361);
	if (l_v1361) {
		goto block88;
	}
	goto block86;

    block86:
	l_v1362 = pypy_g_MiniMarkGC__malloc_out_of_nursery_nonsmall(l_v1069, l_totalsize_9);
	l_v1363 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1364 = (l_v1363 == NULL);
	if (!l_v1364) {
		goto block87;
	}
	l_newhdr_2 = l_v1362;
	l_totalsize_7 = l_totalsize_9;
	goto block69;

    block87:
	PYPY_DEBUG_RECORD_TRACEBACK("trace___trace_drag_out");
	goto block5;

    block88:
	l_v1366 = pypy_g_ArenaCollection_malloc((&pypy_g_rpython_memory_gc_minimarkpage_ArenaCollection), l_totalsize_9);
	l_v1367 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1368 = (l_v1367 == NULL);
	if (!l_v1368) {
		goto block89;
	}
	l_newhdr_2 = l_v1366;
	l_totalsize_7 = l_totalsize_9;
	goto block69;

    block89:
	PYPY_DEBUG_RECORD_TRACEBACK("trace___trace_drag_out");
	goto block5;

    block90:
	PYPY_DEBUG_RECORD_TRACEBACK("trace___trace_drag_out");
	goto block5;
}
/*/*/
void pypy_g_callback2(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_gc_0, void* l_root_1) {
	bool_t l_v1375;
	struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_v1377;
	void* l_v1374;
	goto block0;

    block0:
	l_v1374 = ((void* *) (((char *)l_root_1) + 0))[0];
	OP_ADR_NE(l_v1374, NULL, l_v1375);
	RPyAssert(l_v1375, "NULL address from walk_roots()");
	l_v1377 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst__callback2_arg4;
	pypy_g_GCBase__debug_record(l_v1377, l_v1374);
	goto block1;

    block1:
	RPY_DEBUG_RETURN();
	return /* nothing */;
}
/*/*/
void pypy_g_trace___debug_callback2(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_69, void* l_obj_20, struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_callback_17) {
	Signed l_i_8; void* l_item_5; Signed l_length_28;
	struct pypy_array8 *l_offsets_2; unsigned short l_typeid_5;
	Signed l_v1383; Signed l_v1385; Signed l_v1386; Signed l_v1389;
	Signed l_v1392; Signed l_v1393; Signed l_v1396; Signed l_v1402;
	Signed l_v1403; Signed l_v1406; Signed l_v1408; Signed l_v1411;
	Signed l_v1421; Signed l_v1427; bool_t l_v1387; bool_t l_v1390;
	bool_t l_v1394; bool_t l_v1397; bool_t l_v1400; bool_t l_v1404;
	bool_t l_v1407; bool_t l_v1410; bool_t l_v1413; bool_t l_v1417;
	bool_t l_v1423; bool_t l_v1425; bool_t l_v1429; bool_t l_v1433;
	struct pypy_header0 *l_v1382; struct pypy_object_vtable0 *l_v1399;
	struct pypy_object_vtable0 *l_v1416;
	struct pypy_object_vtable0 *l_v1432; struct pypy_type_info0 *l_v1384;
	struct pypy_type_info0 *l_v1391; struct pypy_type_info0 *l_v1401;
	void* l_v1380; void* l_v1381; void* l_v1409; void* l_v1412;
	void* l_v1420; void* l_v1422; void* l_v1424; void* l_v1426;
	void* l_v1428;
	goto block0;

    block0:
	OP_ADR_SUB(l_obj_20, 0, l_v1381);
	l_v1382 = (struct pypy_header0 *)l_v1381;
	l_v1383 = RPyField(l_v1382, h_tid);
	OP_EXTRACT_USHORT(l_v1383, l_typeid_5);
	l_v1384 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_5);
	l_v1385 = RPyField(l_v1384, ti_infobits);
	OP_INT_AND(l_v1385, -16777216L, l_v1386);
	OP_INT_EQ(l_v1386, 1509949440L, l_v1387);
	RPyAssert(l_v1387, "invalid type_id");
	OP_INT_AND(l_v1385, 4587520L, l_v1389);
	OP_INT_EQ(l_v1389, 0L, l_v1390);
	if (l_v1390) {
		goto block3;
	}
	goto block1;

    block1:
	l_v1391 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_5);
	l_v1392 = RPyField(l_v1391, ti_infobits);
	OP_INT_AND(l_v1392, -16777216L, l_v1393);
	OP_INT_EQ(l_v1393, 1509949440L, l_v1394);
	RPyAssert(l_v1394, "invalid type_id");
	OP_INT_AND(l_v1392, 262144L, l_v1396);
	OP_INT_NE(l_v1396, 0L, l_v1397);
	if (l_v1397) {
		goto block11;
	}
	goto block2;

    block2:
	pypy_g__trace_slow_path___debug_callback2(l_self_69, l_obj_20, l_callback_17);
	l_v1399 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1400 = (l_v1399 == NULL);
	if (!l_v1400) {
		goto block10;
	}
	goto block3;

    block3:
	l_v1401 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_5);
	l_v1402 = RPyField(l_v1401, ti_infobits);
	OP_INT_AND(l_v1402, -16777216L, l_v1403);
	OP_INT_EQ(l_v1403, 1509949440L, l_v1404);
	RPyAssert(l_v1404, "invalid type_id");
	l_offsets_2 = RPyField(l_v1401, ti_ofstoptrs);
	l_i_8 = 0L;
	goto block4;

    block4:
	while (1) {
		l_v1406 = l_offsets_2->length;
		OP_INT_LT(l_i_8, l_v1406, l_v1407);
		if (!l_v1407) break;
		goto block6;
	  block4_back: ;
	}
	goto block5;

    block5:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block6:
	l_v1408 = RPyItem(l_offsets_2, l_i_8);
	OP_ADR_ADD(l_obj_20, l_v1408, l_v1380);
	l_v1409 = ((void* *) (((char *)l_v1380) + 0))[0];
	OP_ADR_NE(l_v1409, NULL, l_v1410);
	if (l_v1410) {
		goto block8;
	}
	goto block7;

    block7:
	OP_INT_ADD(l_i_8, 1L, l_v1411);
	l_i_8 = l_v1411;
	goto block4_back;

    block8:
	l_v1412 = ((void* *) (((char *)l_v1380) + 0))[0];
	OP_ADR_NE(l_v1412, NULL, l_v1413);
	RPyAssert(l_v1413, "NULL address from self.trace()");
	pypy_g_GCBase__debug_record(l_callback_17, l_v1412);
	l_v1416 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1417 = (l_v1416 == NULL);
	if (!l_v1417) {
		goto block9;
	}
	goto block7;

    block9:
	PYPY_DEBUG_RECORD_TRACEBACK("trace___debug_callback2");
	goto block5;

    block10:
	PYPY_DEBUG_RECORD_TRACEBACK("trace___debug_callback2");
	goto block5;

    block11:
	OP_ADR_ADD(l_obj_20, offsetof(struct pypy_array12, length), l_v1420);
	l_v1421 = ((Signed *) (((char *)l_v1420) + 0))[0];
	OP_ADR_ADD(l_obj_20, offsetof(struct pypy_array12, items), l_v1422);
	l_item_5 = l_v1422;
	l_length_28 = l_v1421;
	goto block12;

    block12:
	while (1) {
		OP_INT_GT(l_length_28, 0L, l_v1423);
		if (!l_v1423) break;
		goto block13;
	  block12_back: ;
	}
	goto block5;

    block13:
	l_v1424 = ((void* *) (((char *)l_item_5) + 0))[0];
	OP_ADR_NE(l_v1424, NULL, l_v1425);
	if (l_v1425) {
		goto block15;
	}
	goto block14;

    block14:
	OP_ADR_ADD(l_item_5, sizeof(void*), l_v1426);
	OP_INT_SUB(l_length_28, 1L, l_v1427);
	l_item_5 = l_v1426;
	l_length_28 = l_v1427;
	goto block12_back;

    block15:
	l_v1428 = ((void* *) (((char *)l_item_5) + 0))[0];
	OP_ADR_NE(l_v1428, NULL, l_v1429);
	RPyAssert(l_v1429, "NULL address from self.trace()");
	pypy_g_GCBase__debug_record(l_callback_17, l_v1428);
	l_v1432 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1433 = (l_v1432 == NULL);
	if (!l_v1433) {
		goto block16;
	}
	goto block14;

    block16:
	PYPY_DEBUG_RECORD_TRACEBACK("trace___debug_callback2");
	goto block5;
}
/*/*/
void pypy_g_GCBase_execute_finalizers(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_70) {
	Signed l_index_7;
	struct pypy_rpython_memory_support_AddressDeque0 *l_self_71;
	Signed l_v1441; Signed l_v1442; Signed l_v1447; Signed l_v1448;
	Signed l_v1450; Signed l_v1451; Signed l_v1453; Signed l_v1458;
	Signed l_v1459; Signed l_v1462; Signed l_v1466; Signed l_v1470;
	Signed l_v1472; Signed l_v1473; Signed l_v1476; Signed l_v1486;
	Signed l_v1487; bool_t l_v1446; bool_t l_v1449; bool_t l_v1454;
	bool_t l_v1457; bool_t l_v1460; bool_t l_v1463; bool_t l_v1474;
	bool_t l_v1477; bool_t l_v1480; bool_t l_v1494;
	struct pypy_AddressChunk0 *l_v1444;
	struct pypy_AddressChunk0 *l_v1445;
	struct pypy_AddressChunk0 *l_v1455;
	struct pypy_AddressChunk0 *l_v1456;
	struct pypy_AddressChunk0 *l_v1464; struct pypy_header0 *l_v1469;
	struct pypy_object0 *l_v1481; struct pypy_object_vtable0 *l_v1479;
	struct pypy_object_vtable0 *l_v1482;
	struct pypy_rpython_memory_support_AddressDeque0 *l_v1437;
	struct pypy_type_info0 *l_v1438;
	struct pypy_type_info_extra0 *l_v1490; unsigned short l_v1471;
	void (*l_v1439)(void*); void (*l_v1440)(void*); void* *l_v1465;
	void* l_v1436; void* l_v1468;
	goto block0;

    block0:
	l_v1441 = RPyField(l_self_70, mmgc_inst_finalizer_lock_count);
	OP_INT_ADD(l_v1441, 1L, l_v1442);
	RPyField(l_self_70, mmgc_inst_finalizer_lock_count) = l_v1442;
	goto block1;

    block1:
	while (1) {
		l_v1437 = RPyField(l_self_70, mmgc_inst_run_finalizers);
		l_v1444 = RPyField(l_v1437, ad_inst_oldest_chunk);
		l_v1445 = RPyField(l_v1437, ad_inst_newest_chunk);
		l_v1446 = (l_v1444 != l_v1445);
		if (l_v1446) break;
		goto block2;
	  block1_back: ;
	}
	goto block5;

    block2:
	l_v1447 = RPyField(l_v1437, ad_inst_index_in_oldest);
	l_v1448 = RPyField(l_v1437, ad_inst_index_in_newest);
	OP_INT_LT(l_v1447, l_v1448, l_v1449);
	if (l_v1449) {
		goto block5;
	}
	goto block3;

    block3:
	l_v1450 = RPyField(l_self_70, mmgc_inst_finalizer_lock_count);
	OP_INT_SUB(l_v1450, 1L, l_v1451);
	RPyField(l_self_70, mmgc_inst_finalizer_lock_count) = l_v1451;
	goto block4;

    block4:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block5:
	l_v1453 = RPyField(l_self_70, mmgc_inst_finalizer_lock_count);
	OP_INT_GT(l_v1453, 1L, l_v1454);
	if (l_v1454) {
		goto block3;
	}
	goto block6;

    block6:
	l_self_71 = RPyField(l_self_70, mmgc_inst_run_finalizers);
	l_v1455 = RPyField(l_self_71, ad_inst_oldest_chunk);
	l_v1456 = RPyField(l_self_71, ad_inst_newest_chunk);
	l_v1457 = (l_v1455 != l_v1456);
	if (l_v1457) {
		l_v1494 = 1;
		goto block8;
	}
	goto block7;

    block7:
	l_v1458 = RPyField(l_self_71, ad_inst_index_in_oldest);
	l_v1459 = RPyField(l_self_71, ad_inst_index_in_newest);
	OP_INT_LT(l_v1458, l_v1459, l_v1460);
	l_v1494 = l_v1460;
	goto block8;

    block8:
	RPyAssert(l_v1494, "pop on empty AddressDeque");
	l_v1462 = RPyField(l_self_71, ad_inst_index_in_oldest);
	OP_INT_EQ(l_v1462, 1019L, l_v1463);
	if (l_v1463) {
		goto block15;
	}
	l_index_7 = l_v1462;
	goto block9;

    block9:
	l_v1464 = RPyField(l_self_71, ad_inst_oldest_chunk);
	l_v1465 = RPyField(l_v1464, ac_items);
	l_v1436 = RPyFxItem(l_v1465, l_index_7, 1019);
	OP_INT_ADD(l_index_7, 1L, l_v1466);
	RPyField(l_self_71, ad_inst_index_in_oldest) = l_v1466;
	OP_ADR_SUB(l_v1436, 0, l_v1468);
	l_v1469 = (struct pypy_header0 *)l_v1468;
	l_v1470 = RPyField(l_v1469, h_tid);
	OP_EXTRACT_USHORT(l_v1470, l_v1471);
	l_v1438 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_v1471);
	l_v1472 = RPyField(l_v1438, ti_infobits);
	OP_INT_AND(l_v1472, -16777216L, l_v1473);
	OP_INT_EQ(l_v1473, 1509949440L, l_v1474);
	RPyAssert(l_v1474, "invalid type_id");
	OP_INT_AND(l_v1472, 2097152L, l_v1476);
	OP_INT_IS_TRUE(l_v1476, l_v1477);
	if (l_v1477) {
		goto block13;
	}
	goto block10;

    block10:
	((void (*)(void*)) NULL)(l_v1436);
	l_v1439 = ((void (*)(void*)) NULL);
	goto block11;

    block11:
	l_v1479 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1480 = (l_v1479 == NULL);
	if (!l_v1480) {
		goto block12;
	}
	goto block1_back;

    block12:
	l_v1481 = (&pypy_g_ExcData)->ed_exc_value;
	l_v1482 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("GCBase_execute_finalizers", l_v1482, l_v1482 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_v1482 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	l_v1486 = RPyField(l_self_70, mmgc_inst_finalizer_lock_count);
	OP_INT_SUB(l_v1486, 1L, l_v1487);
	RPyField(l_self_70, mmgc_inst_finalizer_lock_count) = l_v1487;
	pypy_g_RPyReRaiseException(l_v1482, l_v1481);
	goto block4;

    block13:
	l_v1490 = RPyField(l_v1438, ti_extra);
	l_v1440 = RPyField(l_v1490, tie_finalizer);
	goto block14;

    block14:
	l_v1440(l_v1436);
	l_v1439 = l_v1440;
	goto block11;

    block15:
	pypy_g_AddressDeque_shrink(l_self_71);
	l_index_7 = 0L;
	goto block9;
}
/*/*/
void pypy_g__trace_slow_path___trace_drag_out(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_45, void* l_obj_21, struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_72) {
	void* l_addr_2; void* l_addr_3; void* (*l_generator_0)(void*, void*);
	void* l_item_6; void* l_item_7; Signed l_itemlength_1; Signed l_j_1;
	Signed l_length_29; void* l_newhdr_4; void* l_newhdr_5;
	void* l_obj_22; struct pypy_array8 *l_offsets_3; void* l_root_5;
	Signed l_tid_2; Signed l_totalsize_10; Signed l_totalsize_11;
	Signed l_totalsize_12; unsigned short l_typeid_6; Signed l_used_4;
	Signed l_used_5; Signed l_v1495; Signed l_v1496; Signed l_v1498;
	Signed l_v1499; Signed l_v1504; Signed l_v1505; Signed l_v1507;
	Signed l_v1512; Signed l_v1516; Signed l_v1518; Signed l_v1519;
	Signed l_v1522; Signed l_v1525; Signed l_v1526; Signed l_v1529;
	Signed l_v1532; Signed l_v1533; Signed l_v1536; Signed l_v1540;
	Signed l_v1541; Signed l_v1550; Signed l_v1551; Signed l_v1558;
	Signed l_v1559; Signed l_v1573; Signed l_v1574; Signed l_v1576;
	Signed l_v1577; Signed l_v1590; Signed l_v1594; Signed l_v1603;
	Signed l_v1604; Signed l_v1608; Signed l_v1612; Signed l_v1624;
	Signed l_v1629; Signed l_v1655; Signed l_v1659; Signed l_v1673;
	Signed l_v1674; Signed l_v1677; Signed l_v1681; Signed l_v1682;
	Signed l_v1685; Signed l_v1687; Signed l_v1690; Signed l_v1691;
	Signed l_v1696; Signed l_v1697; Signed l_v1701; Signed l_v1704;
	Signed l_v1705; Signed l_v1708; Signed l_v1709; Signed l_v1710;
	Signed l_v1717; Signed l_v1718; Signed l_v1732; Signed l_v1733;
	Signed l_v1735; Signed l_v1736; Signed l_v1749; Signed l_v1753;
	Signed l_v1762; Signed l_v1763; Signed l_v1767; Signed l_v1771;
	Signed l_v1783; Signed l_v1788; Signed l_v1814; Signed l_v1818;
	Unsigned l_v1561; Unsigned l_v1562; Unsigned l_v1568;
	Unsigned l_v1720; Unsigned l_v1721; Unsigned l_v1727;
	Unsigned l_v1831; Unsigned l_v1832; bool_t l_v1520; bool_t l_v1523;
	bool_t l_v1527; bool_t l_v1530; bool_t l_v1534; bool_t l_v1537;
	bool_t l_v1542; bool_t l_v1546; bool_t l_v1547; bool_t l_v1549;
	bool_t l_v1552; bool_t l_v1555; bool_t l_v1557; bool_t l_v1560;
	bool_t l_v1563; bool_t l_v1566; bool_t l_v1570; bool_t l_v1575;
	bool_t l_v1578; bool_t l_v1581; bool_t l_v1585; bool_t l_v1591;
	bool_t l_v1592; bool_t l_v1595; bool_t l_v1599; bool_t l_v1611;
	bool_t l_v1615; bool_t l_v1616; bool_t l_v1617; bool_t l_v1625;
	bool_t l_v1633; bool_t l_v1637; bool_t l_v1641; bool_t l_v1645;
	bool_t l_v1648; bool_t l_v1658; bool_t l_v1660; bool_t l_v1663;
	bool_t l_v1667; bool_t l_v1675; bool_t l_v1683; bool_t l_v1692;
	bool_t l_v1698; bool_t l_v1700; bool_t l_v1702; bool_t l_v1707;
	bool_t l_v1711; bool_t l_v1714; bool_t l_v1716; bool_t l_v1719;
	bool_t l_v1722; bool_t l_v1725; bool_t l_v1729; bool_t l_v1734;
	bool_t l_v1737; bool_t l_v1740; bool_t l_v1744; bool_t l_v1750;
	bool_t l_v1751; bool_t l_v1754; bool_t l_v1758; bool_t l_v1770;
	bool_t l_v1774; bool_t l_v1775; bool_t l_v1776; bool_t l_v1784;
	bool_t l_v1792; bool_t l_v1796; bool_t l_v1800; bool_t l_v1804;
	bool_t l_v1807; bool_t l_v1817; bool_t l_v1819; bool_t l_v1822;
	bool_t l_v1826; struct pypy_AddressChunk0 *l_v1626;
	struct pypy_AddressChunk0 *l_v1785; struct pypy_DICT0 *l_v1500;
	struct pypy_DICT0 *l_v1503; struct pypy_DICT0 *l_v1556;
	struct pypy_DICT0 *l_v1597; struct pypy_DICT0 *l_v1715;
	struct pypy_DICT0 *l_v1756; struct pypy_forwarding_stub0 *l_v1621;
	struct pypy_forwarding_stub0 *l_v1650;
	struct pypy_forwarding_stub0 *l_v1780;
	struct pypy_forwarding_stub0 *l_v1809; struct pypy_header0 *l_v1515;
	struct pypy_header0 *l_v1572; struct pypy_header0 *l_v1589;
	struct pypy_header0 *l_v1602; struct pypy_header0 *l_v1607;
	struct pypy_header0 *l_v1619; struct pypy_header0 *l_v1654;
	struct pypy_header0 *l_v1731; struct pypy_header0 *l_v1748;
	struct pypy_header0 *l_v1761; struct pypy_header0 *l_v1766;
	struct pypy_header0 *l_v1778; struct pypy_header0 *l_v1813;
	struct pypy_object_vtable0 *l_v1545;
	struct pypy_object_vtable0 *l_v1565;
	struct pypy_object_vtable0 *l_v1610;
	struct pypy_object_vtable0 *l_v1632;
	struct pypy_object_vtable0 *l_v1636;
	struct pypy_object_vtable0 *l_v1640;
	struct pypy_object_vtable0 *l_v1644;
	struct pypy_object_vtable0 *l_v1657;
	struct pypy_object_vtable0 *l_v1662;
	struct pypy_object_vtable0 *l_v1666;
	struct pypy_object_vtable0 *l_v1724;
	struct pypy_object_vtable0 *l_v1769;
	struct pypy_object_vtable0 *l_v1791;
	struct pypy_object_vtable0 *l_v1795;
	struct pypy_object_vtable0 *l_v1799;
	struct pypy_object_vtable0 *l_v1803;
	struct pypy_object_vtable0 *l_v1816;
	struct pypy_object_vtable0 *l_v1821;
	struct pypy_object_vtable0 *l_v1825; struct pypy_type_info0 *l_v1517;
	struct pypy_type_info0 *l_v1524; struct pypy_type_info0 *l_v1531;
	struct pypy_type_info0 *l_v1539; struct pypy_type_info0 *l_v1672;
	struct pypy_type_info0 *l_v1680; struct pypy_type_info0 *l_v1689;
	struct pypy_type_info0 *l_v1695;
	struct pypy_type_info_extra0 *l_v1544;
	struct pypy_varsize_type_info0 *l_v1671;
	struct pypy_varsize_type_info0 *l_v1679;
	struct pypy_varsize_type_info0 *l_v1688;
	struct pypy_varsize_type_info0 *l_v1694; unsigned short l_v1609;
	unsigned short l_v1656; unsigned short l_v1768;
	unsigned short l_v1815; void* *l_v1627; void* *l_v1786;
	void* l_v1497; void* l_v1501; void* l_v1502; void* l_v1506;
	void* l_v1508; void* l_v1509; void* l_v1510; void* l_v1511;
	void* l_v1513; void* l_v1514; void* l_v1548; void* l_v1554;
	void* l_v1569; void* l_v1571; void* l_v1580; void* l_v1584;
	void* l_v1588; void* l_v1598; void* l_v1601; void* l_v1606;
	void* l_v1613; void* l_v1618; void* l_v1643; void* l_v1651;
	void* l_v1653; void* l_v1661; void* l_v1665; void* l_v1678;
	void* l_v1686; void* l_v1703; void* l_v1706; void* l_v1713;
	void* l_v1728; void* l_v1730; void* l_v1739; void* l_v1743;
	void* l_v1747; void* l_v1757; void* l_v1760; void* l_v1765;
	void* l_v1772; void* l_v1777; void* l_v1802; void* l_v1810;
	void* l_v1812; void* l_v1820; void* l_v1824; void* l_v1830;
	goto block0;

    block0:
	OP_ADR_SUB(l_obj_21, 0, l_v1514);
	l_v1515 = (struct pypy_header0 *)l_v1514;
	l_v1516 = RPyField(l_v1515, h_tid);
	OP_EXTRACT_USHORT(l_v1516, l_typeid_6);
	l_v1517 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_6);
	l_v1518 = RPyField(l_v1517, ti_infobits);
	OP_INT_AND(l_v1518, -16777216L, l_v1519);
	OP_INT_EQ(l_v1519, 1509949440L, l_v1520);
	RPyAssert(l_v1520, "invalid type_id");
	OP_INT_AND(l_v1518, 131072L, l_v1522);
	OP_INT_NE(l_v1522, 0L, l_v1523);
	if (l_v1523) {
		goto block47;
	}
	goto block1;

    block1:
	l_v1524 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_6);
	l_v1525 = RPyField(l_v1524, ti_infobits);
	OP_INT_AND(l_v1525, -16777216L, l_v1526);
	OP_INT_EQ(l_v1526, 1509949440L, l_v1527);
	RPyAssert(l_v1527, "invalid type_id");
	OP_INT_AND(l_v1525, 4194304L, l_v1529);
	OP_INT_NE(l_v1529, 0L, l_v1530);
	if (l_v1530) {
		goto block3;
	}
	goto block2;

    block2:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block3:
	l_v1531 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_6);
	l_v1532 = RPyField(l_v1531, ti_infobits);
	OP_INT_AND(l_v1532, -16777216L, l_v1533);
	OP_INT_EQ(l_v1533, 1509949440L, l_v1534);
	RPyAssert(l_v1534, "invalid type_id");
	OP_INT_AND(l_v1532, 4194304L, l_v1536);
	OP_INT_NE(l_v1536, 0L, l_v1537);
	RPyAssert(l_v1537, "T_HAS_CUSTOM_TRACE missing");
	l_v1539 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_6);
	l_v1540 = RPyField(l_v1539, ti_infobits);
	OP_INT_AND(l_v1540, -16777216L, l_v1541);
	OP_INT_EQ(l_v1541, 1509949440L, l_v1542);
	RPyAssert(l_v1542, "invalid type_id");
	l_v1544 = RPyField(l_v1539, ti_extra);
	l_generator_0 = RPyField(l_v1544, tie_customtracer);
	l_v1830 = NULL;
	goto block4;

    block4:
	while (1) {
		l_item_6 = l_generator_0(l_obj_21, l_v1830);
		l_v1545 = (&pypy_g_ExcData)->ed_exc_type;
		l_v1546 = (l_v1545 == NULL);
		if (!l_v1546) break;
		goto block5;
	  block4_back: ;
	}
	goto block46;

    block5:
	OP_ADR_NE(l_item_6, NULL, l_v1547);
	if (l_v1547) {
		goto block6;
	}
	goto block2;

    block6:
	l_v1548 = ((void* *) (((char *)l_item_6) + 0))[0];
	OP_ADR_NE(l_v1548, NULL, l_v1549);
	if (l_v1549) {
		goto block7;
	}
	l_v1830 = l_item_6;
	goto block4_back;

    block7:
	l_obj_22 = ((void* *) (((char *)l_item_6) + 0))[0];
	OP_CAST_ADR_TO_INT(l_obj_22, /* nothing */, l_v1550);
	OP_INT_AND(l_v1550, 1L, l_v1551);
	OP_INT_EQ(l_v1551, 0L, l_v1552);
	RPyAssert(l_v1552, "odd-valued (i.e. tagged) pointer unexpected here");
	l_v1554 = RPyField(l_self_72, mmgc_inst_nursery);
	OP_ADR_LE(l_v1554, l_obj_22, l_v1555);
	if (l_v1555) {
		goto block15;
	}
	goto block8;

    block8:
	l_v1556 = RPyField(l_self_72, mmgc_inst_young_rawmalloced_objects);
	l_v1557 = (l_v1556 != NULL);
	if (l_v1557) {
		goto block9;
	}
	l_v1830 = l_item_6;
	goto block4;

    block9:
	l_v1500 = RPyField(l_self_72, mmgc_inst_young_rawmalloced_objects);
	OP_CAST_ADR_TO_INT(l_obj_22, /* nothing */, l_v1558);
	OP_INT_RSHIFT(l_v1558, 4L, l_v1559);
	OP_INT_XOR(l_v1558, l_v1559, l_v1496);
	OP_INT_IS_TRUE(0 /* we are not jitted here */, l_v1560);
	if (l_v1560) {
		goto block14;
	}
	goto block10;

    block10:
	l_v1561 = pypy_g_ll_dict_lookup__v51___simple_call__function_ll(l_v1500, l_obj_22, l_v1496);
	l_v1831 = l_v1561;
	goto block11;

    block11:
	OP_UINT_AND(l_v1831, 2147483648UL, l_v1562);
	OP_UINT_IS_TRUE(l_v1562, l_v1563);
	if (l_v1563) {
		l_v1830 = l_item_6;
		goto block4;
	}
	goto block12;

    block12:
	pypy_g_MiniMarkGC__visit_young_rawmalloced_object(l_self_72, l_obj_22);
	l_v1565 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1566 = (l_v1565 == NULL);
	if (!l_v1566) {
		goto block13;
	}
	l_v1830 = l_item_6;
	goto block4;

    block13:
	PYPY_DEBUG_RECORD_TRACEBACK("_trace_slow_path___trace_drag_out");
	goto block2;

    block14:
	l_v1568 = pypy_g_ll_dict_lookup__v60___simple_call__function_ll(l_v1500, l_obj_22, l_v1496);
	l_v1831 = l_v1568;
	goto block11;

    block15:
	l_v1569 = RPyField(l_self_72, mmgc_inst_nursery_real_top);
	OP_ADR_LT(l_obj_22, l_v1569, l_v1570);
	if (l_v1570) {
		goto block16;
	}
	goto block8;

    block16:
	OP_ADR_SUB(l_obj_22, 0, l_v1571);
	l_v1572 = (struct pypy_header0 *)l_v1571;
	l_v1573 = RPyField(l_v1572, h_tid);
	OP_INT_AND(l_v1573, 524288L, l_v1574);
	OP_INT_EQ(l_v1574, 0L, l_v1575);
	if (l_v1575) {
		goto block39;
	}
	goto block17;

    block17:
	OP_CAST_ADR_TO_INT(l_obj_22, /* nothing */, l_v1576);
	OP_INT_AND(l_v1576, 1L, l_v1577);
	OP_INT_EQ(l_v1577, 0L, l_v1578);
	RPyAssert(l_v1578, "odd-valued (i.e. tagged) pointer unexpected here");
	l_v1580 = RPyField(l_self_72, mmgc_inst_nursery);
	OP_ADR_LE(l_v1580, l_obj_22, l_v1581);
	if (l_v1581) {
		goto block19;
	}
	goto block18;

    block18:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("_trace_slow_path___trace_drag_out");
	goto block2;

    block19:
	l_v1584 = RPyField(l_self_72, mmgc_inst_nursery_real_top);
	OP_ADR_LT(l_obj_22, l_v1584, l_v1585);
	if (l_v1585) {
		goto block21;
	}
	goto block20;

    block20:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("_trace_slow_path___trace_drag_out");
	goto block2;

    block21:
	OP_ADR_SUB(l_obj_22, 0, l_v1588);
	l_v1589 = (struct pypy_header0 *)l_v1588;
	l_v1507 = RPyField(l_v1589, h_tid);
	OP_INT_AND(l_v1507, 1048576L, l_v1590);
	OP_INT_NE(l_v1590, 0L, l_v1591);
	if (l_v1591) {
		goto block38;
	}
	goto block22;

    block22:
	OP_INT_IS_TRUE(l_v1507, l_v1592);
	RPyAssert(l_v1592, "bogus header (1)");
	OP_INT_AND(l_v1507, -16777216L, l_v1594);
	OP_INT_EQ(l_v1594, 0L, l_v1595);
	RPyAssert(l_v1595, "bogus header (2)");
	l_v1597 = RPyField(l_self_72, mmgc_inst_nursery_objects_shadows);
	l_v1598 = pypy_g_ll_get__DICTPtr_Address_Address(l_v1597, l_obj_22, NULL);
	OP_ADR_NE(l_v1598, NULL, l_v1599);
	RPyAssert(l_v1599, "GCFLAG_HAS_SHADOW but no shadow found");
	OP_ADR_SUB(l_v1598, 0, l_v1513);
	OP_ADR_SUB(l_obj_22, 0, l_v1601);
	l_v1602 = (struct pypy_header0 *)l_v1601;
	l_v1603 = RPyField(l_v1602, h_tid);
	OP_INT_AND(l_v1603, -524289L, l_v1604);
	RPyField(l_v1602, h_tid) = l_v1604;
	OP_ADR_SUB(l_obj_22, 0, l_v1606);
	l_v1607 = (struct pypy_header0 *)l_v1606;
	l_v1608 = RPyField(l_v1607, h_tid);
	OP_EXTRACT_USHORT(l_v1608, l_v1609);
	l_v1495 = pypy_g_GCBase__get_size_for_typeid(l_self_72, l_obj_22, l_v1609);
	l_v1610 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1611 = (l_v1610 == NULL);
	if (!l_v1611) {
		goto block37;
	}
	goto block23;

    block23:
	OP_INT_ADD(0, l_v1495, l_v1612);
	l_totalsize_11 = l_v1612;
	l_newhdr_4 = l_v1513;
	goto block24;

    block24:
	OP_ADR_SUB(l_obj_22, 0, l_v1613);
	OP_RAW_MEMCOPY(l_v1613, l_newhdr_4, l_totalsize_11, /* nothing */);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v1615);
	if (l_v1615) {
		goto block35;
	}
	l_v1501 = l_obj_22;
	goto block25;

    block25:
	OP_ADR_SUB(l_v1501, 0, l_v1506);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v1616);
	if (l_v1616) {
		goto block33;
	}
	goto block26;

    block26:
	OP_ADR_SUB(l_v1501, 0, l_v1509);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v1617);
	if (l_v1617) {
		goto block31;
	}
	goto block27;

    block27:
	OP_ADR_SUB(l_v1501, 0, l_v1618);
	l_v1619 = (struct pypy_header0 *)l_v1618;
	RPyField(l_v1619, h_tid) = -42L;
	OP_ADR_ADD(l_newhdr_4, 0, l_v1502);
	l_v1621 = (struct pypy_forwarding_stub0 *)l_v1501;
	RPyField(l_v1621, fs_forw) = l_v1502;
	((void* *) (((char *)l_item_6) + 0))[0] = l_v1502;
	l_v1624 = (&pypy_g_rpython_memory_support_AddressStack)->as_inst_used_in_last_chunk;
	OP_INT_EQ(l_v1624, 1019L, l_v1625);
	if (l_v1625) {
		goto block29;
	}
	l_used_4 = l_v1624;
	goto block28;

    block28:
	l_v1626 = (&pypy_g_rpython_memory_support_AddressStack)->as_inst_chunk;
	l_v1627 = RPyField(l_v1626, ac_items);
	RPyFxItem(l_v1627, l_used_4, 1019) = l_v1502;
	OP_INT_ADD(l_used_4, 1L, l_v1629);
	(&pypy_g_rpython_memory_support_AddressStack)->as_inst_used_in_last_chunk = l_v1629;
	l_v1830 = l_item_6;
	goto block4;

    block29:
	pypy_g_AddressStack_enlarge((&pypy_g_rpython_memory_support_AddressStack));
	l_v1632 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1633 = (l_v1632 == NULL);
	if (!l_v1633) {
		goto block30;
	}
	l_used_4 = 0L;
	goto block28;

    block30:
	PYPY_DEBUG_RECORD_TRACEBACK("_trace_slow_path___trace_drag_out");
	goto block2;

    block31:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v1636 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1637 = (l_v1636 == NULL);
	if (!l_v1637) {
		goto block32;
	}
	goto block27;

    block32:
	PYPY_DEBUG_RECORD_TRACEBACK("_trace_slow_path___trace_drag_out");
	goto block2;

    block33:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v1640 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1641 = (l_v1640 == NULL);
	if (!l_v1641) {
		goto block34;
	}
	goto block26;

    block34:
	PYPY_DEBUG_RECORD_TRACEBACK("_trace_slow_path___trace_drag_out");
	goto block2;

    block35:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v1643 = (void*)0;
	l_v1644 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1645 = (l_v1644 == NULL);
	if (!l_v1645) {
		goto block36;
	}
	l_v1501 = l_v1643;
	goto block25;

    block36:
	PYPY_DEBUG_RECORD_TRACEBACK("_trace_slow_path___trace_drag_out");
	goto block2;

    block37:
	PYPY_DEBUG_RECORD_TRACEBACK("_trace_slow_path___trace_drag_out");
	goto block2;

    block38:
	OP_INT_EQ(l_v1507, -42L, l_v1648);
	RPyAssert(l_v1648, "bogus header for young obj");
	l_v1650 = (struct pypy_forwarding_stub0 *)l_obj_22;
	l_v1651 = RPyField(l_v1650, fs_forw);
	((void* *) (((char *)l_item_6) + 0))[0] = l_v1651;
	l_v1830 = l_item_6;
	goto block4;

    block39:
	OP_ADR_SUB(l_obj_22, 0, l_v1653);
	l_v1654 = (struct pypy_header0 *)l_v1653;
	l_v1655 = RPyField(l_v1654, h_tid);
	OP_EXTRACT_USHORT(l_v1655, l_v1656);
	l_v1498 = pypy_g_GCBase__get_size_for_typeid(l_self_72, l_obj_22, l_v1656);
	l_v1657 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1658 = (l_v1657 == NULL);
	if (!l_v1658) {
		goto block45;
	}
	goto block40;

    block40:
	OP_INT_ADD(0, l_v1498, l_totalsize_12);
	OP_RAW_MALLOC_USAGE(l_totalsize_12, l_v1659);
	OP_INT_LE(l_v1659, 140L, l_v1660);
	if (l_v1660) {
		goto block43;
	}
	goto block41;

    block41:
	l_v1661 = pypy_g_MiniMarkGC__malloc_out_of_nursery_nonsmall(l_self_72, l_totalsize_12);
	l_v1662 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1663 = (l_v1662 == NULL);
	if (!l_v1663) {
		goto block42;
	}
	l_totalsize_11 = l_totalsize_12;
	l_newhdr_4 = l_v1661;
	goto block24;

    block42:
	PYPY_DEBUG_RECORD_TRACEBACK("_trace_slow_path___trace_drag_out");
	goto block2;

    block43:
	l_v1665 = pypy_g_ArenaCollection_malloc((&pypy_g_rpython_memory_gc_minimarkpage_ArenaCollection), l_totalsize_12);
	l_v1666 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1667 = (l_v1666 == NULL);
	if (!l_v1667) {
		goto block44;
	}
	l_totalsize_11 = l_totalsize_12;
	l_newhdr_4 = l_v1665;
	goto block24;

    block44:
	PYPY_DEBUG_RECORD_TRACEBACK("_trace_slow_path___trace_drag_out");
	goto block2;

    block45:
	PYPY_DEBUG_RECORD_TRACEBACK("_trace_slow_path___trace_drag_out");
	goto block2;

    block46:
	PYPY_DEBUG_RECORD_TRACEBACK("_trace_slow_path___trace_drag_out");
	goto block2;

    block47:
	l_v1671 = (struct pypy_varsize_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_6);
	l_v1672 = (struct pypy_type_info0 *)l_v1671;
	l_v1673 = RPyField(l_v1672, ti_infobits);
	OP_INT_AND(l_v1673, -16711680L, l_v1674);
	OP_INT_EQ(l_v1674, 1510014976L, l_v1675);
	RPyAssert(l_v1675, "invalid varsize type_id");
	l_v1677 = RPyField(l_v1671, vti_ofstovar);
	OP_ADR_ADD(l_obj_21, l_v1677, l_v1678);
	l_v1679 = (struct pypy_varsize_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_6);
	l_v1680 = (struct pypy_type_info0 *)l_v1679;
	l_v1681 = RPyField(l_v1680, ti_infobits);
	OP_INT_AND(l_v1681, -16711680L, l_v1682);
	OP_INT_EQ(l_v1682, 1510014976L, l_v1683);
	RPyAssert(l_v1683, "invalid varsize type_id");
	l_v1685 = RPyField(l_v1679, vti_ofstolength);
	OP_ADR_ADD(l_obj_21, l_v1685, l_v1686);
	l_v1687 = ((Signed *) (((char *)l_v1686) + 0))[0];
	l_v1688 = (struct pypy_varsize_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_6);
	l_v1689 = (struct pypy_type_info0 *)l_v1688;
	l_v1690 = RPyField(l_v1689, ti_infobits);
	OP_INT_AND(l_v1690, -16711680L, l_v1691);
	OP_INT_EQ(l_v1691, 1510014976L, l_v1692);
	RPyAssert(l_v1692, "invalid varsize type_id");
	l_offsets_3 = RPyField(l_v1688, vti_varofstoptrs);
	l_v1694 = (struct pypy_varsize_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_6);
	l_v1695 = (struct pypy_type_info0 *)l_v1694;
	l_v1696 = RPyField(l_v1695, ti_infobits);
	OP_INT_AND(l_v1696, -16711680L, l_v1697);
	OP_INT_EQ(l_v1697, 1510014976L, l_v1698);
	RPyAssert(l_v1698, "invalid varsize type_id");
	l_itemlength_1 = RPyField(l_v1694, vti_varitemsize);
	l_item_7 = l_v1678;
	l_length_29 = l_v1687;
	goto block48;

    block48:
	OP_INT_GT(l_length_29, 0L, l_v1700);
	if (l_v1700) {
		l_j_1 = 0L;
		goto block49;
	}
	goto block1;

    block49:
	while (1) {
		l_v1701 = l_offsets_3->length;
		OP_INT_LT(l_j_1, l_v1701, l_v1702);
		if (!l_v1702) break;
		goto block51;
	  block49_back: ;
	}
	goto block50;

    block50:
	OP_ADR_ADD(l_item_7, l_itemlength_1, l_v1703);
	OP_INT_SUB(l_length_29, 1L, l_v1704);
	l_item_7 = l_v1703;
	l_length_29 = l_v1704;
	goto block48;

    block51:
	l_v1705 = RPyItem(l_offsets_3, l_j_1);
	OP_ADR_ADD(l_item_7, l_v1705, l_root_5);
	l_v1706 = ((void* *) (((char *)l_root_5) + 0))[0];
	OP_ADR_NE(l_v1706, NULL, l_v1707);
	if (l_v1707) {
		goto block53;
	}
	goto block52;

    block52:
	OP_INT_ADD(l_j_1, 1L, l_v1708);
	l_j_1 = l_v1708;
	goto block49_back;

    block53:
	l_addr_2 = ((void* *) (((char *)l_root_5) + 0))[0];
	OP_CAST_ADR_TO_INT(l_addr_2, /* nothing */, l_v1709);
	OP_INT_AND(l_v1709, 1L, l_v1710);
	OP_INT_EQ(l_v1710, 0L, l_v1711);
	RPyAssert(l_v1711, "odd-valued (i.e. tagged) pointer unexpected here");
	l_v1713 = RPyField(l_self_72, mmgc_inst_nursery);
	OP_ADR_LE(l_v1713, l_addr_2, l_v1714);
	if (l_v1714) {
		goto block61;
	}
	goto block54;

    block54:
	l_v1715 = RPyField(l_self_72, mmgc_inst_young_rawmalloced_objects);
	l_v1716 = (l_v1715 != NULL);
	if (l_v1716) {
		goto block55;
	}
	goto block52;

    block55:
	l_v1503 = RPyField(l_self_72, mmgc_inst_young_rawmalloced_objects);
	OP_CAST_ADR_TO_INT(l_addr_2, /* nothing */, l_v1717);
	OP_INT_RSHIFT(l_v1717, 4L, l_v1718);
	OP_INT_XOR(l_v1717, l_v1718, l_v1504);
	OP_INT_IS_TRUE(0 /* we are not jitted here */, l_v1719);
	if (l_v1719) {
		goto block60;
	}
	goto block56;

    block56:
	l_v1720 = pypy_g_ll_dict_lookup__v51___simple_call__function_ll(l_v1503, l_addr_2, l_v1504);
	l_v1832 = l_v1720;
	goto block57;

    block57:
	OP_UINT_AND(l_v1832, 2147483648UL, l_v1721);
	OP_UINT_IS_TRUE(l_v1721, l_v1722);
	if (l_v1722) {
		goto block52;
	}
	goto block58;

    block58:
	pypy_g_MiniMarkGC__visit_young_rawmalloced_object(l_self_72, l_addr_2);
	l_v1724 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1725 = (l_v1724 == NULL);
	if (!l_v1725) {
		goto block59;
	}
	goto block52;

    block59:
	PYPY_DEBUG_RECORD_TRACEBACK("_trace_slow_path___trace_drag_out");
	goto block2;

    block60:
	l_v1727 = pypy_g_ll_dict_lookup__v60___simple_call__function_ll(l_v1503, l_addr_2, l_v1504);
	l_v1832 = l_v1727;
	goto block57;

    block61:
	l_v1728 = RPyField(l_self_72, mmgc_inst_nursery_real_top);
	OP_ADR_LT(l_addr_2, l_v1728, l_v1729);
	if (l_v1729) {
		goto block62;
	}
	goto block54;

    block62:
	OP_ADR_SUB(l_addr_2, 0, l_v1730);
	l_v1731 = (struct pypy_header0 *)l_v1730;
	l_v1732 = RPyField(l_v1731, h_tid);
	OP_INT_AND(l_v1732, 524288L, l_v1733);
	OP_INT_EQ(l_v1733, 0L, l_v1734);
	if (l_v1734) {
		goto block85;
	}
	goto block63;

    block63:
	OP_CAST_ADR_TO_INT(l_addr_2, /* nothing */, l_v1735);
	OP_INT_AND(l_v1735, 1L, l_v1736);
	OP_INT_EQ(l_v1736, 0L, l_v1737);
	RPyAssert(l_v1737, "odd-valued (i.e. tagged) pointer unexpected here");
	l_v1739 = RPyField(l_self_72, mmgc_inst_nursery);
	OP_ADR_LE(l_v1739, l_addr_2, l_v1740);
	if (l_v1740) {
		goto block65;
	}
	goto block64;

    block64:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("_trace_slow_path___trace_drag_out");
	goto block2;

    block65:
	l_v1743 = RPyField(l_self_72, mmgc_inst_nursery_real_top);
	OP_ADR_LT(l_addr_2, l_v1743, l_v1744);
	if (l_v1744) {
		goto block67;
	}
	goto block66;

    block66:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("_trace_slow_path___trace_drag_out");
	goto block2;

    block67:
	OP_ADR_SUB(l_addr_2, 0, l_v1747);
	l_v1748 = (struct pypy_header0 *)l_v1747;
	l_tid_2 = RPyField(l_v1748, h_tid);
	OP_INT_AND(l_tid_2, 1048576L, l_v1749);
	OP_INT_NE(l_v1749, 0L, l_v1750);
	if (l_v1750) {
		goto block84;
	}
	goto block68;

    block68:
	OP_INT_IS_TRUE(l_tid_2, l_v1751);
	RPyAssert(l_v1751, "bogus header (1)");
	OP_INT_AND(l_tid_2, -16777216L, l_v1753);
	OP_INT_EQ(l_v1753, 0L, l_v1754);
	RPyAssert(l_v1754, "bogus header (2)");
	l_v1756 = RPyField(l_self_72, mmgc_inst_nursery_objects_shadows);
	l_v1757 = pypy_g_ll_get__DICTPtr_Address_Address(l_v1756, l_addr_2, NULL);
	OP_ADR_NE(l_v1757, NULL, l_v1758);
	RPyAssert(l_v1758, "GCFLAG_HAS_SHADOW but no shadow found");
	OP_ADR_SUB(l_v1757, 0, l_v1497);
	OP_ADR_SUB(l_addr_2, 0, l_v1760);
	l_v1761 = (struct pypy_header0 *)l_v1760;
	l_v1762 = RPyField(l_v1761, h_tid);
	OP_INT_AND(l_v1762, -524289L, l_v1763);
	RPyField(l_v1761, h_tid) = l_v1763;
	OP_ADR_SUB(l_addr_2, 0, l_v1765);
	l_v1766 = (struct pypy_header0 *)l_v1765;
	l_v1767 = RPyField(l_v1766, h_tid);
	OP_EXTRACT_USHORT(l_v1767, l_v1768);
	l_v1512 = pypy_g_GCBase__get_size_for_typeid(l_self_72, l_addr_2, l_v1768);
	l_v1769 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1770 = (l_v1769 == NULL);
	if (!l_v1770) {
		goto block83;
	}
	goto block69;

    block69:
	OP_INT_ADD(0, l_v1512, l_v1771);
	l_v1499 = l_v1771;
	l_newhdr_5 = l_v1497;
	goto block70;

    block70:
	OP_ADR_SUB(l_addr_2, 0, l_v1772);
	OP_RAW_MEMCOPY(l_v1772, l_newhdr_5, l_v1499, /* nothing */);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v1774);
	if (l_v1774) {
		goto block81;
	}
	l_v1508 = l_addr_2;
	goto block71;

    block71:
	OP_ADR_SUB(l_v1508, 0, l_v1510);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v1775);
	if (l_v1775) {
		goto block79;
	}
	goto block72;

    block72:
	OP_ADR_SUB(l_v1508, 0, l_v1511);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v1776);
	if (l_v1776) {
		goto block77;
	}
	goto block73;

    block73:
	OP_ADR_SUB(l_v1508, 0, l_v1777);
	l_v1778 = (struct pypy_header0 *)l_v1777;
	RPyField(l_v1778, h_tid) = -42L;
	OP_ADR_ADD(l_newhdr_5, 0, l_addr_3);
	l_v1780 = (struct pypy_forwarding_stub0 *)l_v1508;
	RPyField(l_v1780, fs_forw) = l_addr_3;
	((void* *) (((char *)l_root_5) + 0))[0] = l_addr_3;
	l_v1783 = (&pypy_g_rpython_memory_support_AddressStack)->as_inst_used_in_last_chunk;
	OP_INT_EQ(l_v1783, 1019L, l_v1784);
	if (l_v1784) {
		goto block75;
	}
	l_used_5 = l_v1783;
	goto block74;

    block74:
	l_v1785 = (&pypy_g_rpython_memory_support_AddressStack)->as_inst_chunk;
	l_v1786 = RPyField(l_v1785, ac_items);
	RPyFxItem(l_v1786, l_used_5, 1019) = l_addr_3;
	OP_INT_ADD(l_used_5, 1L, l_v1788);
	(&pypy_g_rpython_memory_support_AddressStack)->as_inst_used_in_last_chunk = l_v1788;
	goto block52;

    block75:
	pypy_g_AddressStack_enlarge((&pypy_g_rpython_memory_support_AddressStack));
	l_v1791 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1792 = (l_v1791 == NULL);
	if (!l_v1792) {
		goto block76;
	}
	l_used_5 = 0L;
	goto block74;

    block76:
	PYPY_DEBUG_RECORD_TRACEBACK("_trace_slow_path___trace_drag_out");
	goto block2;

    block77:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v1795 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1796 = (l_v1795 == NULL);
	if (!l_v1796) {
		goto block78;
	}
	goto block73;

    block78:
	PYPY_DEBUG_RECORD_TRACEBACK("_trace_slow_path___trace_drag_out");
	goto block2;

    block79:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v1799 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1800 = (l_v1799 == NULL);
	if (!l_v1800) {
		goto block80;
	}
	goto block72;

    block80:
	PYPY_DEBUG_RECORD_TRACEBACK("_trace_slow_path___trace_drag_out");
	goto block2;

    block81:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v1802 = (void*)0;
	l_v1803 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1804 = (l_v1803 == NULL);
	if (!l_v1804) {
		goto block82;
	}
	l_v1508 = l_v1802;
	goto block71;

    block82:
	PYPY_DEBUG_RECORD_TRACEBACK("_trace_slow_path___trace_drag_out");
	goto block2;

    block83:
	PYPY_DEBUG_RECORD_TRACEBACK("_trace_slow_path___trace_drag_out");
	goto block2;

    block84:
	OP_INT_EQ(l_tid_2, -42L, l_v1807);
	RPyAssert(l_v1807, "bogus header for young obj");
	l_v1809 = (struct pypy_forwarding_stub0 *)l_addr_2;
	l_v1810 = RPyField(l_v1809, fs_forw);
	((void* *) (((char *)l_root_5) + 0))[0] = l_v1810;
	goto block52;

    block85:
	OP_ADR_SUB(l_addr_2, 0, l_v1812);
	l_v1813 = (struct pypy_header0 *)l_v1812;
	l_v1814 = RPyField(l_v1813, h_tid);
	OP_EXTRACT_USHORT(l_v1814, l_v1815);
	l_v1505 = pypy_g_GCBase__get_size_for_typeid(l_self_72, l_addr_2, l_v1815);
	l_v1816 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1817 = (l_v1816 == NULL);
	if (!l_v1817) {
		goto block91;
	}
	goto block86;

    block86:
	OP_INT_ADD(0, l_v1505, l_totalsize_10);
	OP_RAW_MALLOC_USAGE(l_totalsize_10, l_v1818);
	OP_INT_LE(l_v1818, 140L, l_v1819);
	if (l_v1819) {
		goto block89;
	}
	goto block87;

    block87:
	l_v1820 = pypy_g_MiniMarkGC__malloc_out_of_nursery_nonsmall(l_self_72, l_totalsize_10);
	l_v1821 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1822 = (l_v1821 == NULL);
	if (!l_v1822) {
		goto block88;
	}
	l_v1499 = l_totalsize_10;
	l_newhdr_5 = l_v1820;
	goto block70;

    block88:
	PYPY_DEBUG_RECORD_TRACEBACK("_trace_slow_path___trace_drag_out");
	goto block2;

    block89:
	l_v1824 = pypy_g_ArenaCollection_malloc((&pypy_g_rpython_memory_gc_minimarkpage_ArenaCollection), l_totalsize_10);
	l_v1825 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1826 = (l_v1825 == NULL);
	if (!l_v1826) {
		goto block90;
	}
	l_v1499 = l_totalsize_10;
	l_newhdr_5 = l_v1824;
	goto block70;

    block90:
	PYPY_DEBUG_RECORD_TRACEBACK("_trace_slow_path___trace_drag_out");
	goto block2;

    block91:
	PYPY_DEBUG_RECORD_TRACEBACK("_trace_slow_path___trace_drag_out");
	goto block2;
}
/*/*/
void pypy_g_GCBase__debug_record(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_73, void* l_v1834) {
	Signed l_used_6; Signed l_v1835; Signed l_v1837; Signed l_v1838;
	Signed l_v1849; Signed l_v1854; Unsigned l_v1840; Unsigned l_v1841;
	Unsigned l_v1862; Unsigned l_v1864; bool_t l_v1839; bool_t l_v1842;
	bool_t l_v1845; bool_t l_v1848; bool_t l_v1850; bool_t l_v1858;
	struct pypy_AddressChunk0 *l_v1851; struct pypy_DICT0 *l_v1833;
	struct pypy_object_vtable0 *l_v1844;
	struct pypy_object_vtable0 *l_v1847;
	struct pypy_object_vtable0 *l_v1857;
	struct pypy_rpython_memory_support_AddressStack0 *l_v1836;
	void* *l_v1852;
	goto block0;

    block0:
	l_v1833 = RPyField(l_self_73, mmgc_inst__debug_seen);
	OP_CAST_ADR_TO_INT(l_v1834, /* nothing */, l_v1837);
	OP_INT_RSHIFT(l_v1837, 4L, l_v1838);
	OP_INT_XOR(l_v1837, l_v1838, l_v1835);
	OP_INT_IS_TRUE(0 /* we are not jitted here */, l_v1839);
	if (l_v1839) {
		goto block12;
	}
	goto block1;

    block1:
	l_v1840 = pypy_g_ll_dict_lookup__v51___simple_call__function_ll(l_v1833, l_v1834, l_v1835);
	l_v1864 = l_v1840;
	goto block2;

    block2:
	OP_UINT_AND(l_v1864, 2147483648UL, l_v1841);
	OP_UINT_IS_TRUE(l_v1841, l_v1842);
	if (l_v1842) {
		goto block4;
	}
	goto block3;

    block3:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block4:
	pypy_g_ll_dict_setitem__DICTPtr_Address_Address(l_v1833, l_v1834, NULL);
	l_v1844 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1845 = (l_v1844 == NULL);
	if (!l_v1845) {
		goto block11;
	}
	goto block5;

    block5:
	pypy_g_MiniMarkGC_debug_check_object(l_self_73, l_v1834);
	l_v1847 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1848 = (l_v1847 == NULL);
	if (!l_v1848) {
		goto block10;
	}
	goto block6;

    block6:
	l_v1836 = RPyField(l_self_73, mmgc_inst__debug_pending);
	l_v1849 = RPyField(l_v1836, as_inst_used_in_last_chunk);
	OP_INT_EQ(l_v1849, 1019L, l_v1850);
	if (l_v1850) {
		goto block8;
	}
	l_used_6 = l_v1849;
	goto block7;

    block7:
	l_v1851 = RPyField(l_v1836, as_inst_chunk);
	l_v1852 = RPyField(l_v1851, ac_items);
	RPyFxItem(l_v1852, l_used_6, 1019) = l_v1834;
	OP_INT_ADD(l_used_6, 1L, l_v1854);
	RPyField(l_v1836, as_inst_used_in_last_chunk) = l_v1854;
	goto block3;

    block8:
	pypy_g_AddressStack_enlarge(l_v1836);
	l_v1857 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1858 = (l_v1857 == NULL);
	if (!l_v1858) {
		goto block9;
	}
	l_used_6 = 0L;
	goto block7;

    block9:
	PYPY_DEBUG_RECORD_TRACEBACK("GCBase__debug_record");
	goto block3;

    block10:
	PYPY_DEBUG_RECORD_TRACEBACK("GCBase__debug_record");
	goto block3;

    block11:
	PYPY_DEBUG_RECORD_TRACEBACK("GCBase__debug_record");
	goto block3;

    block12:
	l_v1862 = pypy_g_ll_dict_lookup__v60___simple_call__function_ll(l_v1833, l_v1834, l_v1835);
	l_v1864 = l_v1862;
	goto block2;
}
/*/*/
void pypy_g__trace_slow_path___debug_callback2(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_47, void* l_obj_23, struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_callback_18) {
	void* (*l_generator_1)(void*, void*); void* l_item_8; void* l_item_9;
	Signed l_itemlength_2; Signed l_j_2; Signed l_length_30;
	struct pypy_array8 *l_offsets_4; unsigned short l_typeid_7;
	Signed l_v1868; Signed l_v1870; Signed l_v1871; Signed l_v1874;
	Signed l_v1877; Signed l_v1878; Signed l_v1881; Signed l_v1884;
	Signed l_v1885; Signed l_v1888; Signed l_v1892; Signed l_v1893;
	Signed l_v1912; Signed l_v1913; Signed l_v1916; Signed l_v1920;
	Signed l_v1921; Signed l_v1924; Signed l_v1926; Signed l_v1929;
	Signed l_v1930; Signed l_v1935; Signed l_v1936; Signed l_v1940;
	Signed l_v1943; Signed l_v1944; Signed l_v1947; bool_t l_v1872;
	bool_t l_v1875; bool_t l_v1879; bool_t l_v1882; bool_t l_v1886;
	bool_t l_v1889; bool_t l_v1894; bool_t l_v1898; bool_t l_v1899;
	bool_t l_v1901; bool_t l_v1903; bool_t l_v1907; bool_t l_v1914;
	bool_t l_v1922; bool_t l_v1931; bool_t l_v1937; bool_t l_v1939;
	bool_t l_v1941; bool_t l_v1946; bool_t l_v1949; bool_t l_v1953;
	struct pypy_header0 *l_v1867; struct pypy_object_vtable0 *l_v1897;
	struct pypy_object_vtable0 *l_v1906;
	struct pypy_object_vtable0 *l_v1952; struct pypy_type_info0 *l_v1869;
	struct pypy_type_info0 *l_v1876; struct pypy_type_info0 *l_v1883;
	struct pypy_type_info0 *l_v1891; struct pypy_type_info0 *l_v1911;
	struct pypy_type_info0 *l_v1919; struct pypy_type_info0 *l_v1928;
	struct pypy_type_info0 *l_v1934;
	struct pypy_type_info_extra0 *l_v1896;
	struct pypy_varsize_type_info0 *l_v1910;
	struct pypy_varsize_type_info0 *l_v1918;
	struct pypy_varsize_type_info0 *l_v1927;
	struct pypy_varsize_type_info0 *l_v1933; void* l_v1865;
	void* l_v1866; void* l_v1900; void* l_v1902; void* l_v1917;
	void* l_v1925; void* l_v1942; void* l_v1945; void* l_v1948;
	void* l_v1956;
	goto block0;

    block0:
	OP_ADR_SUB(l_obj_23, 0, l_v1866);
	l_v1867 = (struct pypy_header0 *)l_v1866;
	l_v1868 = RPyField(l_v1867, h_tid);
	OP_EXTRACT_USHORT(l_v1868, l_typeid_7);
	l_v1869 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_7);
	l_v1870 = RPyField(l_v1869, ti_infobits);
	OP_INT_AND(l_v1870, -16777216L, l_v1871);
	OP_INT_EQ(l_v1871, 1509949440L, l_v1872);
	RPyAssert(l_v1872, "invalid type_id");
	OP_INT_AND(l_v1870, 131072L, l_v1874);
	OP_INT_NE(l_v1874, 0L, l_v1875);
	if (l_v1875) {
		goto block10;
	}
	goto block1;

    block1:
	l_v1876 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_7);
	l_v1877 = RPyField(l_v1876, ti_infobits);
	OP_INT_AND(l_v1877, -16777216L, l_v1878);
	OP_INT_EQ(l_v1878, 1509949440L, l_v1879);
	RPyAssert(l_v1879, "invalid type_id");
	OP_INT_AND(l_v1877, 4194304L, l_v1881);
	OP_INT_NE(l_v1881, 0L, l_v1882);
	if (l_v1882) {
		goto block3;
	}
	goto block2;

    block2:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block3:
	l_v1883 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_7);
	l_v1884 = RPyField(l_v1883, ti_infobits);
	OP_INT_AND(l_v1884, -16777216L, l_v1885);
	OP_INT_EQ(l_v1885, 1509949440L, l_v1886);
	RPyAssert(l_v1886, "invalid type_id");
	OP_INT_AND(l_v1884, 4194304L, l_v1888);
	OP_INT_NE(l_v1888, 0L, l_v1889);
	RPyAssert(l_v1889, "T_HAS_CUSTOM_TRACE missing");
	l_v1891 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_7);
	l_v1892 = RPyField(l_v1891, ti_infobits);
	OP_INT_AND(l_v1892, -16777216L, l_v1893);
	OP_INT_EQ(l_v1893, 1509949440L, l_v1894);
	RPyAssert(l_v1894, "invalid type_id");
	l_v1896 = RPyField(l_v1891, ti_extra);
	l_generator_1 = RPyField(l_v1896, tie_customtracer);
	l_v1956 = NULL;
	goto block4;

    block4:
	while (1) {
		l_item_8 = l_generator_1(l_obj_23, l_v1956);
		l_v1897 = (&pypy_g_ExcData)->ed_exc_type;
		l_v1898 = (l_v1897 == NULL);
		if (!l_v1898) break;
		goto block5;
	  block4_back: ;
	}
	goto block9;

    block5:
	OP_ADR_NE(l_item_8, NULL, l_v1899);
	if (l_v1899) {
		goto block6;
	}
	goto block2;

    block6:
	l_v1900 = ((void* *) (((char *)l_item_8) + 0))[0];
	OP_ADR_NE(l_v1900, NULL, l_v1901);
	if (l_v1901) {
		goto block7;
	}
	l_v1956 = l_item_8;
	goto block4_back;

    block7:
	l_v1902 = ((void* *) (((char *)l_item_8) + 0))[0];
	OP_ADR_NE(l_v1902, NULL, l_v1903);
	RPyAssert(l_v1903, "NULL address from self.trace()");
	pypy_g_GCBase__debug_record(l_callback_18, l_v1902);
	l_v1906 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1907 = (l_v1906 == NULL);
	if (!l_v1907) {
		goto block8;
	}
	l_v1956 = l_item_8;
	goto block4;

    block8:
	PYPY_DEBUG_RECORD_TRACEBACK("_trace_slow_path___debug_callback2");
	goto block2;

    block9:
	PYPY_DEBUG_RECORD_TRACEBACK("_trace_slow_path___debug_callback2");
	goto block2;

    block10:
	l_v1910 = (struct pypy_varsize_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_7);
	l_v1911 = (struct pypy_type_info0 *)l_v1910;
	l_v1912 = RPyField(l_v1911, ti_infobits);
	OP_INT_AND(l_v1912, -16711680L, l_v1913);
	OP_INT_EQ(l_v1913, 1510014976L, l_v1914);
	RPyAssert(l_v1914, "invalid varsize type_id");
	l_v1916 = RPyField(l_v1910, vti_ofstovar);
	OP_ADR_ADD(l_obj_23, l_v1916, l_v1917);
	l_v1918 = (struct pypy_varsize_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_7);
	l_v1919 = (struct pypy_type_info0 *)l_v1918;
	l_v1920 = RPyField(l_v1919, ti_infobits);
	OP_INT_AND(l_v1920, -16711680L, l_v1921);
	OP_INT_EQ(l_v1921, 1510014976L, l_v1922);
	RPyAssert(l_v1922, "invalid varsize type_id");
	l_v1924 = RPyField(l_v1918, vti_ofstolength);
	OP_ADR_ADD(l_obj_23, l_v1924, l_v1925);
	l_v1926 = ((Signed *) (((char *)l_v1925) + 0))[0];
	l_v1927 = (struct pypy_varsize_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_7);
	l_v1928 = (struct pypy_type_info0 *)l_v1927;
	l_v1929 = RPyField(l_v1928, ti_infobits);
	OP_INT_AND(l_v1929, -16711680L, l_v1930);
	OP_INT_EQ(l_v1930, 1510014976L, l_v1931);
	RPyAssert(l_v1931, "invalid varsize type_id");
	l_offsets_4 = RPyField(l_v1927, vti_varofstoptrs);
	l_v1933 = (struct pypy_varsize_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_7);
	l_v1934 = (struct pypy_type_info0 *)l_v1933;
	l_v1935 = RPyField(l_v1934, ti_infobits);
	OP_INT_AND(l_v1935, -16711680L, l_v1936);
	OP_INT_EQ(l_v1936, 1510014976L, l_v1937);
	RPyAssert(l_v1937, "invalid varsize type_id");
	l_itemlength_2 = RPyField(l_v1933, vti_varitemsize);
	l_length_30 = l_v1926;
	l_item_9 = l_v1917;
	goto block11;

    block11:
	OP_INT_GT(l_length_30, 0L, l_v1939);
	if (l_v1939) {
		l_j_2 = 0L;
		goto block12;
	}
	goto block1;

    block12:
	while (1) {
		l_v1940 = l_offsets_4->length;
		OP_INT_LT(l_j_2, l_v1940, l_v1941);
		if (!l_v1941) break;
		goto block14;
	  block12_back: ;
	}
	goto block13;

    block13:
	OP_ADR_ADD(l_item_9, l_itemlength_2, l_v1942);
	OP_INT_SUB(l_length_30, 1L, l_v1943);
	l_length_30 = l_v1943;
	l_item_9 = l_v1942;
	goto block11;

    block14:
	l_v1944 = RPyItem(l_offsets_4, l_j_2);
	OP_ADR_ADD(l_item_9, l_v1944, l_v1865);
	l_v1945 = ((void* *) (((char *)l_v1865) + 0))[0];
	OP_ADR_NE(l_v1945, NULL, l_v1946);
	if (l_v1946) {
		goto block16;
	}
	goto block15;

    block15:
	OP_INT_ADD(l_j_2, 1L, l_v1947);
	l_j_2 = l_v1947;
	goto block12_back;

    block16:
	l_v1948 = ((void* *) (((char *)l_v1865) + 0))[0];
	OP_ADR_NE(l_v1948, NULL, l_v1949);
	RPyAssert(l_v1949, "NULL address from self.trace()");
	pypy_g_GCBase__debug_record(l_callback_18, l_v1948);
	l_v1952 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1953 = (l_v1952 == NULL);
	if (!l_v1953) {
		goto block17;
	}
	goto block15;

    block17:
	PYPY_DEBUG_RECORD_TRACEBACK("_trace_slow_path___debug_callback2");
	goto block2;
}
/*/*/
void pypy_g_trace___collect_ref_rec(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_51, void* l_obj_24, struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_callback_19) {
	void* l_addr_4; Signed l_i_9; void* l_item_10; Signed l_length_31;
	struct pypy_array8 *l_offsets_5;
	struct pypy_rpython_memory_support_AddressStack0 *l_self_74;
	Signed l_used_7; Signed l_used_8; Signed l_v1963; Signed l_v1965;
	Signed l_v1966; Signed l_v1969; Signed l_v1972; Signed l_v1973;
	Signed l_v1976; Signed l_v1982; Signed l_v1983; Signed l_v1986;
	Signed l_v1988; Signed l_v1991; Signed l_v1992; Signed l_v1997;
	Signed l_v2005; Signed l_v2011; Signed l_v2012; Signed l_v2017;
	bool_t l_v1967; bool_t l_v1970; bool_t l_v1974; bool_t l_v1977;
	bool_t l_v1980; bool_t l_v1984; bool_t l_v1987; bool_t l_v1990;
	bool_t l_v1993; bool_t l_v2001; bool_t l_v2007; bool_t l_v2009;
	bool_t l_v2013; bool_t l_v2021; struct pypy_AddressChunk0 *l_v1994;
	struct pypy_AddressChunk0 *l_v2014; struct pypy_header0 *l_v1962;
	struct pypy_object_vtable0 *l_v1979;
	struct pypy_object_vtable0 *l_v2000;
	struct pypy_object_vtable0 *l_v2020;
	struct pypy_rpython_memory_support_AddressStack0 *l_v1958;
	struct pypy_type_info0 *l_v1964; struct pypy_type_info0 *l_v1971;
	struct pypy_type_info0 *l_v1981; unsigned short l_v1957;
	void* *l_v1995; void* *l_v2015; void* l_v1959; void* l_v1960;
	void* l_v1961; void* l_v1989; void* l_v2004; void* l_v2006;
	void* l_v2008; void* l_v2010;
	goto block0;

    block0:
	OP_ADR_SUB(l_obj_24, 0, l_v1961);
	l_v1962 = (struct pypy_header0 *)l_v1961;
	l_v1963 = RPyField(l_v1962, h_tid);
	OP_EXTRACT_USHORT(l_v1963, l_v1957);
	l_v1964 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_v1957);
	l_v1965 = RPyField(l_v1964, ti_infobits);
	OP_INT_AND(l_v1965, -16777216L, l_v1966);
	OP_INT_EQ(l_v1966, 1509949440L, l_v1967);
	RPyAssert(l_v1967, "invalid type_id");
	OP_INT_AND(l_v1965, 4587520L, l_v1969);
	OP_INT_EQ(l_v1969, 0L, l_v1970);
	if (l_v1970) {
		goto block3;
	}
	goto block1;

    block1:
	l_v1971 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_v1957);
	l_v1972 = RPyField(l_v1971, ti_infobits);
	OP_INT_AND(l_v1972, -16777216L, l_v1973);
	OP_INT_EQ(l_v1973, 1509949440L, l_v1974);
	RPyAssert(l_v1974, "invalid type_id");
	OP_INT_AND(l_v1972, 262144L, l_v1976);
	OP_INT_NE(l_v1976, 0L, l_v1977);
	if (l_v1977) {
		goto block13;
	}
	goto block2;

    block2:
	pypy_g__trace_slow_path___collect_ref_rec(l_self_51, l_obj_24, l_callback_19);
	l_v1979 = (&pypy_g_ExcData)->ed_exc_type;
	l_v1980 = (l_v1979 == NULL);
	if (!l_v1980) {
		goto block12;
	}
	goto block3;

    block3:
	l_v1981 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_v1957);
	l_v1982 = RPyField(l_v1981, ti_infobits);
	OP_INT_AND(l_v1982, -16777216L, l_v1983);
	OP_INT_EQ(l_v1983, 1509949440L, l_v1984);
	RPyAssert(l_v1984, "invalid type_id");
	l_offsets_5 = RPyField(l_v1981, ti_ofstoptrs);
	l_i_9 = 0L;
	goto block4;

    block4:
	while (1) {
		l_v1986 = l_offsets_5->length;
		OP_INT_LT(l_i_9, l_v1986, l_v1987);
		if (!l_v1987) break;
		goto block6;
	  block4_back: ;
	}
	goto block5;

    block5:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block6:
	l_v1988 = RPyItem(l_offsets_5, l_i_9);
	OP_ADR_ADD(l_obj_24, l_v1988, l_v1959);
	l_v1989 = ((void* *) (((char *)l_v1959) + 0))[0];
	OP_ADR_NE(l_v1989, NULL, l_v1990);
	if (l_v1990) {
		goto block8;
	}
	goto block7;

    block7:
	OP_INT_ADD(l_i_9, 1L, l_v1991);
	l_i_9 = l_v1991;
	goto block4_back;

    block8:
	l_v1958 = RPyField(l_callback_19, mmgc_inst_objects_to_trace);
	l_v1960 = ((void* *) (((char *)l_v1959) + 0))[0];
	l_v1992 = RPyField(l_v1958, as_inst_used_in_last_chunk);
	OP_INT_EQ(l_v1992, 1019L, l_v1993);
	if (l_v1993) {
		goto block10;
	}
	l_used_7 = l_v1992;
	goto block9;

    block9:
	l_v1994 = RPyField(l_v1958, as_inst_chunk);
	l_v1995 = RPyField(l_v1994, ac_items);
	RPyFxItem(l_v1995, l_used_7, 1019) = l_v1960;
	OP_INT_ADD(l_used_7, 1L, l_v1997);
	RPyField(l_v1958, as_inst_used_in_last_chunk) = l_v1997;
	goto block7;

    block10:
	pypy_g_AddressStack_enlarge(l_v1958);
	l_v2000 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2001 = (l_v2000 == NULL);
	if (!l_v2001) {
		goto block11;
	}
	l_used_7 = 0L;
	goto block9;

    block11:
	PYPY_DEBUG_RECORD_TRACEBACK("trace___collect_ref_rec");
	goto block5;

    block12:
	PYPY_DEBUG_RECORD_TRACEBACK("trace___collect_ref_rec");
	goto block5;

    block13:
	OP_ADR_ADD(l_obj_24, offsetof(struct pypy_array12, length), l_v2004);
	l_v2005 = ((Signed *) (((char *)l_v2004) + 0))[0];
	OP_ADR_ADD(l_obj_24, offsetof(struct pypy_array12, items), l_v2006);
	l_length_31 = l_v2005;
	l_item_10 = l_v2006;
	goto block14;

    block14:
	while (1) {
		OP_INT_GT(l_length_31, 0L, l_v2007);
		if (!l_v2007) break;
		goto block15;
	  block14_back: ;
	}
	goto block5;

    block15:
	l_v2008 = ((void* *) (((char *)l_item_10) + 0))[0];
	OP_ADR_NE(l_v2008, NULL, l_v2009);
	if (l_v2009) {
		goto block17;
	}
	goto block16;

    block16:
	OP_ADR_ADD(l_item_10, sizeof(void*), l_v2010);
	OP_INT_SUB(l_length_31, 1L, l_v2011);
	l_length_31 = l_v2011;
	l_item_10 = l_v2010;
	goto block14_back;

    block17:
	l_self_74 = RPyField(l_callback_19, mmgc_inst_objects_to_trace);
	l_addr_4 = ((void* *) (((char *)l_item_10) + 0))[0];
	l_v2012 = RPyField(l_self_74, as_inst_used_in_last_chunk);
	OP_INT_EQ(l_v2012, 1019L, l_v2013);
	if (l_v2013) {
		goto block19;
	}
	l_used_8 = l_v2012;
	goto block18;

    block18:
	l_v2014 = RPyField(l_self_74, as_inst_chunk);
	l_v2015 = RPyField(l_v2014, ac_items);
	RPyFxItem(l_v2015, l_used_8, 1019) = l_addr_4;
	OP_INT_ADD(l_used_8, 1L, l_v2017);
	RPyField(l_self_74, as_inst_used_in_last_chunk) = l_v2017;
	goto block16;

    block19:
	pypy_g_AddressStack_enlarge(l_self_74);
	l_v2020 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2021 = (l_v2020 == NULL);
	if (!l_v2021) {
		goto block20;
	}
	l_used_8 = 0L;
	goto block18;

    block20:
	PYPY_DEBUG_RECORD_TRACEBACK("trace___collect_ref_rec");
	goto block5;
}
/*/*/
void pypy_g_trace___append_if_nonnull(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_75, void* l_obj_25, struct pypy_rpython_memory_support_AddressStack0 *l_arg_15) {
	void* l_addr_5; Signed l_i_10; void* l_item_11; Signed l_length_32;
	struct pypy_array8 *l_offsets_6; unsigned short l_typeid_8;
	Signed l_used_10; Signed l_used_9; Signed l_v2028; Signed l_v2030;
	Signed l_v2031; Signed l_v2034; Signed l_v2037; Signed l_v2038;
	Signed l_v2041; Signed l_v2047; Signed l_v2048; Signed l_v2051;
	Signed l_v2053; Signed l_v2056; Signed l_v2057; Signed l_v2062;
	Signed l_v2070; Signed l_v2076; Signed l_v2077; Signed l_v2082;
	bool_t l_v2032; bool_t l_v2035; bool_t l_v2039; bool_t l_v2042;
	bool_t l_v2045; bool_t l_v2049; bool_t l_v2052; bool_t l_v2055;
	bool_t l_v2058; bool_t l_v2066; bool_t l_v2072; bool_t l_v2074;
	bool_t l_v2078; bool_t l_v2086; struct pypy_AddressChunk0 *l_v2059;
	struct pypy_AddressChunk0 *l_v2079; struct pypy_header0 *l_v2027;
	struct pypy_object_vtable0 *l_v2044;
	struct pypy_object_vtable0 *l_v2065;
	struct pypy_object_vtable0 *l_v2085; struct pypy_type_info0 *l_v2029;
	struct pypy_type_info0 *l_v2036; struct pypy_type_info0 *l_v2046;
	void* *l_v2060; void* *l_v2080; void* l_v2024; void* l_v2025;
	void* l_v2026; void* l_v2054; void* l_v2069; void* l_v2071;
	void* l_v2073; void* l_v2075;
	goto block0;

    block0:
	OP_ADR_SUB(l_obj_25, 0, l_v2026);
	l_v2027 = (struct pypy_header0 *)l_v2026;
	l_v2028 = RPyField(l_v2027, h_tid);
	OP_EXTRACT_USHORT(l_v2028, l_typeid_8);
	l_v2029 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_8);
	l_v2030 = RPyField(l_v2029, ti_infobits);
	OP_INT_AND(l_v2030, -16777216L, l_v2031);
	OP_INT_EQ(l_v2031, 1509949440L, l_v2032);
	RPyAssert(l_v2032, "invalid type_id");
	OP_INT_AND(l_v2030, 4587520L, l_v2034);
	OP_INT_EQ(l_v2034, 0L, l_v2035);
	if (l_v2035) {
		goto block3;
	}
	goto block1;

    block1:
	l_v2036 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_8);
	l_v2037 = RPyField(l_v2036, ti_infobits);
	OP_INT_AND(l_v2037, -16777216L, l_v2038);
	OP_INT_EQ(l_v2038, 1509949440L, l_v2039);
	RPyAssert(l_v2039, "invalid type_id");
	OP_INT_AND(l_v2037, 262144L, l_v2041);
	OP_INT_NE(l_v2041, 0L, l_v2042);
	if (l_v2042) {
		goto block13;
	}
	goto block2;

    block2:
	pypy_g__trace_slow_path___append_if_nonnull(l_self_75, l_obj_25, l_arg_15);
	l_v2044 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2045 = (l_v2044 == NULL);
	if (!l_v2045) {
		goto block12;
	}
	goto block3;

    block3:
	l_v2046 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_8);
	l_v2047 = RPyField(l_v2046, ti_infobits);
	OP_INT_AND(l_v2047, -16777216L, l_v2048);
	OP_INT_EQ(l_v2048, 1509949440L, l_v2049);
	RPyAssert(l_v2049, "invalid type_id");
	l_offsets_6 = RPyField(l_v2046, ti_ofstoptrs);
	l_i_10 = 0L;
	goto block4;

    block4:
	while (1) {
		l_v2051 = l_offsets_6->length;
		OP_INT_LT(l_i_10, l_v2051, l_v2052);
		if (!l_v2052) break;
		goto block6;
	  block4_back: ;
	}
	goto block5;

    block5:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block6:
	l_v2053 = RPyItem(l_offsets_6, l_i_10);
	OP_ADR_ADD(l_obj_25, l_v2053, l_v2024);
	l_v2054 = ((void* *) (((char *)l_v2024) + 0))[0];
	OP_ADR_NE(l_v2054, NULL, l_v2055);
	if (l_v2055) {
		goto block8;
	}
	goto block7;

    block7:
	OP_INT_ADD(l_i_10, 1L, l_v2056);
	l_i_10 = l_v2056;
	goto block4_back;

    block8:
	l_addr_5 = ((void* *) (((char *)l_v2024) + 0))[0];
	l_v2057 = RPyField(l_arg_15, as_inst_used_in_last_chunk);
	OP_INT_EQ(l_v2057, 1019L, l_v2058);
	if (l_v2058) {
		goto block10;
	}
	l_used_9 = l_v2057;
	goto block9;

    block9:
	l_v2059 = RPyField(l_arg_15, as_inst_chunk);
	l_v2060 = RPyField(l_v2059, ac_items);
	RPyFxItem(l_v2060, l_used_9, 1019) = l_addr_5;
	OP_INT_ADD(l_used_9, 1L, l_v2062);
	RPyField(l_arg_15, as_inst_used_in_last_chunk) = l_v2062;
	goto block7;

    block10:
	pypy_g_AddressStack_enlarge(l_arg_15);
	l_v2065 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2066 = (l_v2065 == NULL);
	if (!l_v2066) {
		goto block11;
	}
	l_used_9 = 0L;
	goto block9;

    block11:
	PYPY_DEBUG_RECORD_TRACEBACK("trace___append_if_nonnull");
	goto block5;

    block12:
	PYPY_DEBUG_RECORD_TRACEBACK("trace___append_if_nonnull");
	goto block5;

    block13:
	OP_ADR_ADD(l_obj_25, offsetof(struct pypy_array12, length), l_v2069);
	l_v2070 = ((Signed *) (((char *)l_v2069) + 0))[0];
	OP_ADR_ADD(l_obj_25, offsetof(struct pypy_array12, items), l_v2071);
	l_length_32 = l_v2070;
	l_item_11 = l_v2071;
	goto block14;

    block14:
	while (1) {
		OP_INT_GT(l_length_32, 0L, l_v2072);
		if (!l_v2072) break;
		goto block15;
	  block14_back: ;
	}
	goto block5;

    block15:
	l_v2073 = ((void* *) (((char *)l_item_11) + 0))[0];
	OP_ADR_NE(l_v2073, NULL, l_v2074);
	if (l_v2074) {
		goto block17;
	}
	goto block16;

    block16:
	OP_ADR_ADD(l_item_11, sizeof(void*), l_v2075);
	OP_INT_SUB(l_length_32, 1L, l_v2076);
	l_length_32 = l_v2076;
	l_item_11 = l_v2075;
	goto block14_back;

    block17:
	l_v2025 = ((void* *) (((char *)l_item_11) + 0))[0];
	l_v2077 = RPyField(l_arg_15, as_inst_used_in_last_chunk);
	OP_INT_EQ(l_v2077, 1019L, l_v2078);
	if (l_v2078) {
		goto block19;
	}
	l_used_10 = l_v2077;
	goto block18;

    block18:
	l_v2079 = RPyField(l_arg_15, as_inst_chunk);
	l_v2080 = RPyField(l_v2079, ac_items);
	RPyFxItem(l_v2080, l_used_10, 1019) = l_v2025;
	OP_INT_ADD(l_used_10, 1L, l_v2082);
	RPyField(l_arg_15, as_inst_used_in_last_chunk) = l_v2082;
	goto block16;

    block19:
	pypy_g_AddressStack_enlarge(l_arg_15);
	l_v2085 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2086 = (l_v2085 == NULL);
	if (!l_v2086) {
		goto block20;
	}
	l_used_10 = 0L;
	goto block18;

    block20:
	PYPY_DEBUG_RECORD_TRACEBACK("trace___append_if_nonnull");
	goto block5;
}
/*/*/
void pypy_g__trace_slow_path___collect_ref_rec(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_59, void* l_obj_26, struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_callback_20) {
	void* (*l_generator_2)(void*, void*); void* l_item_12;
	void* l_item_13; Signed l_itemlength_3; Signed l_j_3;
	Signed l_length_33; struct pypy_array8 *l_offsets_7;
	struct pypy_rpython_memory_support_AddressStack0 *l_self_76;
	unsigned short l_typeid_9; Signed l_used_11; Signed l_used_12;
	Signed l_v2095; Signed l_v2097; Signed l_v2098; Signed l_v2101;
	Signed l_v2104; Signed l_v2105; Signed l_v2108; Signed l_v2111;
	Signed l_v2112; Signed l_v2115; Signed l_v2119; Signed l_v2120;
	Signed l_v2129; Signed l_v2134; Signed l_v2143; Signed l_v2144;
	Signed l_v2147; Signed l_v2151; Signed l_v2152; Signed l_v2155;
	Signed l_v2157; Signed l_v2160; Signed l_v2161; Signed l_v2166;
	Signed l_v2167; Signed l_v2171; Signed l_v2174; Signed l_v2175;
	Signed l_v2178; Signed l_v2179; Signed l_v2184; bool_t l_v2099;
	bool_t l_v2102; bool_t l_v2106; bool_t l_v2109; bool_t l_v2113;
	bool_t l_v2116; bool_t l_v2121; bool_t l_v2125; bool_t l_v2126;
	bool_t l_v2128; bool_t l_v2130; bool_t l_v2138; bool_t l_v2145;
	bool_t l_v2153; bool_t l_v2162; bool_t l_v2168; bool_t l_v2170;
	bool_t l_v2172; bool_t l_v2177; bool_t l_v2180; bool_t l_v2188;
	struct pypy_AddressChunk0 *l_v2131;
	struct pypy_AddressChunk0 *l_v2181; struct pypy_header0 *l_v2094;
	struct pypy_object_vtable0 *l_v2124;
	struct pypy_object_vtable0 *l_v2137;
	struct pypy_object_vtable0 *l_v2187;
	struct pypy_rpython_memory_support_AddressStack0 *l_v2090;
	struct pypy_type_info0 *l_v2096; struct pypy_type_info0 *l_v2103;
	struct pypy_type_info0 *l_v2110; struct pypy_type_info0 *l_v2118;
	struct pypy_type_info0 *l_v2142; struct pypy_type_info0 *l_v2150;
	struct pypy_type_info0 *l_v2159; struct pypy_type_info0 *l_v2165;
	struct pypy_type_info_extra0 *l_v2123;
	struct pypy_varsize_type_info0 *l_v2141;
	struct pypy_varsize_type_info0 *l_v2149;
	struct pypy_varsize_type_info0 *l_v2158;
	struct pypy_varsize_type_info0 *l_v2164; void* *l_v2132;
	void* *l_v2182; void* l_v2089; void* l_v2091; void* l_v2092;
	void* l_v2093; void* l_v2127; void* l_v2148; void* l_v2156;
	void* l_v2173; void* l_v2176; void* l_v2191;
	goto block0;

    block0:
	OP_ADR_SUB(l_obj_26, 0, l_v2093);
	l_v2094 = (struct pypy_header0 *)l_v2093;
	l_v2095 = RPyField(l_v2094, h_tid);
	OP_EXTRACT_USHORT(l_v2095, l_typeid_9);
	l_v2096 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_9);
	l_v2097 = RPyField(l_v2096, ti_infobits);
	OP_INT_AND(l_v2097, -16777216L, l_v2098);
	OP_INT_EQ(l_v2098, 1509949440L, l_v2099);
	RPyAssert(l_v2099, "invalid type_id");
	OP_INT_AND(l_v2097, 131072L, l_v2101);
	OP_INT_NE(l_v2101, 0L, l_v2102);
	if (l_v2102) {
		goto block12;
	}
	goto block1;

    block1:
	l_v2103 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_9);
	l_v2104 = RPyField(l_v2103, ti_infobits);
	OP_INT_AND(l_v2104, -16777216L, l_v2105);
	OP_INT_EQ(l_v2105, 1509949440L, l_v2106);
	RPyAssert(l_v2106, "invalid type_id");
	OP_INT_AND(l_v2104, 4194304L, l_v2108);
	OP_INT_NE(l_v2108, 0L, l_v2109);
	if (l_v2109) {
		goto block3;
	}
	goto block2;

    block2:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block3:
	l_v2110 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_9);
	l_v2111 = RPyField(l_v2110, ti_infobits);
	OP_INT_AND(l_v2111, -16777216L, l_v2112);
	OP_INT_EQ(l_v2112, 1509949440L, l_v2113);
	RPyAssert(l_v2113, "invalid type_id");
	OP_INT_AND(l_v2111, 4194304L, l_v2115);
	OP_INT_NE(l_v2115, 0L, l_v2116);
	RPyAssert(l_v2116, "T_HAS_CUSTOM_TRACE missing");
	l_v2118 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_9);
	l_v2119 = RPyField(l_v2118, ti_infobits);
	OP_INT_AND(l_v2119, -16777216L, l_v2120);
	OP_INT_EQ(l_v2120, 1509949440L, l_v2121);
	RPyAssert(l_v2121, "invalid type_id");
	l_v2123 = RPyField(l_v2118, ti_extra);
	l_generator_2 = RPyField(l_v2123, tie_customtracer);
	l_v2191 = NULL;
	goto block4;

    block4:
	while (1) {
		l_item_13 = l_generator_2(l_obj_26, l_v2191);
		l_v2124 = (&pypy_g_ExcData)->ed_exc_type;
		l_v2125 = (l_v2124 == NULL);
		if (!l_v2125) break;
		goto block5;
	  block4_back: ;
	}
	goto block11;

    block5:
	OP_ADR_NE(l_item_13, NULL, l_v2126);
	if (l_v2126) {
		goto block6;
	}
	goto block2;

    block6:
	l_v2127 = ((void* *) (((char *)l_item_13) + 0))[0];
	OP_ADR_NE(l_v2127, NULL, l_v2128);
	if (l_v2128) {
		goto block7;
	}
	l_v2191 = l_item_13;
	goto block4_back;

    block7:
	l_v2090 = RPyField(l_callback_20, mmgc_inst_objects_to_trace);
	l_v2091 = ((void* *) (((char *)l_item_13) + 0))[0];
	l_v2129 = RPyField(l_v2090, as_inst_used_in_last_chunk);
	OP_INT_EQ(l_v2129, 1019L, l_v2130);
	if (l_v2130) {
		goto block9;
	}
	l_used_11 = l_v2129;
	goto block8;

    block8:
	l_v2131 = RPyField(l_v2090, as_inst_chunk);
	l_v2132 = RPyField(l_v2131, ac_items);
	RPyFxItem(l_v2132, l_used_11, 1019) = l_v2091;
	OP_INT_ADD(l_used_11, 1L, l_v2134);
	RPyField(l_v2090, as_inst_used_in_last_chunk) = l_v2134;
	l_v2191 = l_item_13;
	goto block4;

    block9:
	pypy_g_AddressStack_enlarge(l_v2090);
	l_v2137 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2138 = (l_v2137 == NULL);
	if (!l_v2138) {
		goto block10;
	}
	l_used_11 = 0L;
	goto block8;

    block10:
	PYPY_DEBUG_RECORD_TRACEBACK("_trace_slow_path___collect_ref_rec");
	goto block2;

    block11:
	PYPY_DEBUG_RECORD_TRACEBACK("_trace_slow_path___collect_ref_rec");
	goto block2;

    block12:
	l_v2141 = (struct pypy_varsize_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_9);
	l_v2142 = (struct pypy_type_info0 *)l_v2141;
	l_v2143 = RPyField(l_v2142, ti_infobits);
	OP_INT_AND(l_v2143, -16711680L, l_v2144);
	OP_INT_EQ(l_v2144, 1510014976L, l_v2145);
	RPyAssert(l_v2145, "invalid varsize type_id");
	l_v2147 = RPyField(l_v2141, vti_ofstovar);
	OP_ADR_ADD(l_obj_26, l_v2147, l_v2148);
	l_v2149 = (struct pypy_varsize_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_9);
	l_v2150 = (struct pypy_type_info0 *)l_v2149;
	l_v2151 = RPyField(l_v2150, ti_infobits);
	OP_INT_AND(l_v2151, -16711680L, l_v2152);
	OP_INT_EQ(l_v2152, 1510014976L, l_v2153);
	RPyAssert(l_v2153, "invalid varsize type_id");
	l_v2155 = RPyField(l_v2149, vti_ofstolength);
	OP_ADR_ADD(l_obj_26, l_v2155, l_v2156);
	l_v2157 = ((Signed *) (((char *)l_v2156) + 0))[0];
	l_v2158 = (struct pypy_varsize_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_9);
	l_v2159 = (struct pypy_type_info0 *)l_v2158;
	l_v2160 = RPyField(l_v2159, ti_infobits);
	OP_INT_AND(l_v2160, -16711680L, l_v2161);
	OP_INT_EQ(l_v2161, 1510014976L, l_v2162);
	RPyAssert(l_v2162, "invalid varsize type_id");
	l_offsets_7 = RPyField(l_v2158, vti_varofstoptrs);
	l_v2164 = (struct pypy_varsize_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_9);
	l_v2165 = (struct pypy_type_info0 *)l_v2164;
	l_v2166 = RPyField(l_v2165, ti_infobits);
	OP_INT_AND(l_v2166, -16711680L, l_v2167);
	OP_INT_EQ(l_v2167, 1510014976L, l_v2168);
	RPyAssert(l_v2168, "invalid varsize type_id");
	l_itemlength_3 = RPyField(l_v2164, vti_varitemsize);
	l_item_12 = l_v2148;
	l_length_33 = l_v2157;
	goto block13;

    block13:
	OP_INT_GT(l_length_33, 0L, l_v2170);
	if (l_v2170) {
		l_j_3 = 0L;
		goto block14;
	}
	goto block1;

    block14:
	while (1) {
		l_v2171 = l_offsets_7->length;
		OP_INT_LT(l_j_3, l_v2171, l_v2172);
		if (!l_v2172) break;
		goto block16;
	  block14_back: ;
	}
	goto block15;

    block15:
	OP_ADR_ADD(l_item_12, l_itemlength_3, l_v2173);
	OP_INT_SUB(l_length_33, 1L, l_v2174);
	l_item_12 = l_v2173;
	l_length_33 = l_v2174;
	goto block13;

    block16:
	l_v2175 = RPyItem(l_offsets_7, l_j_3);
	OP_ADR_ADD(l_item_12, l_v2175, l_v2089);
	l_v2176 = ((void* *) (((char *)l_v2089) + 0))[0];
	OP_ADR_NE(l_v2176, NULL, l_v2177);
	if (l_v2177) {
		goto block18;
	}
	goto block17;

    block17:
	OP_INT_ADD(l_j_3, 1L, l_v2178);
	l_j_3 = l_v2178;
	goto block14_back;

    block18:
	l_self_76 = RPyField(l_callback_20, mmgc_inst_objects_to_trace);
	l_v2092 = ((void* *) (((char *)l_v2089) + 0))[0];
	l_v2179 = RPyField(l_self_76, as_inst_used_in_last_chunk);
	OP_INT_EQ(l_v2179, 1019L, l_v2180);
	if (l_v2180) {
		goto block20;
	}
	l_used_12 = l_v2179;
	goto block19;

    block19:
	l_v2181 = RPyField(l_self_76, as_inst_chunk);
	l_v2182 = RPyField(l_v2181, ac_items);
	RPyFxItem(l_v2182, l_used_12, 1019) = l_v2092;
	OP_INT_ADD(l_used_12, 1L, l_v2184);
	RPyField(l_self_76, as_inst_used_in_last_chunk) = l_v2184;
	goto block17;

    block20:
	pypy_g_AddressStack_enlarge(l_self_76);
	l_v2187 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2188 = (l_v2187 == NULL);
	if (!l_v2188) {
		goto block21;
	}
	l_used_12 = 0L;
	goto block19;

    block21:
	PYPY_DEBUG_RECORD_TRACEBACK("_trace_slow_path___collect_ref_rec");
	goto block2;
}
/*/*/
void pypy_g__trace_slow_path___append_if_nonnull(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_62, void* l_obj_27, struct pypy_rpython_memory_support_AddressStack0 *l_arg_16) {
	void* (*l_generator_3)(void*, void*); void* l_item_14;
	Signed l_itemlength_4; Signed l_j_4; Signed l_length_34;
	struct pypy_array8 *l_offsets_8; unsigned short l_typeid_10;
	Signed l_used_13; Signed l_used_14; Signed l_v2198; Signed l_v2200;
	Signed l_v2201; Signed l_v2204; Signed l_v2207; Signed l_v2208;
	Signed l_v2211; Signed l_v2214; Signed l_v2215; Signed l_v2218;
	Signed l_v2222; Signed l_v2223; Signed l_v2232; Signed l_v2237;
	Signed l_v2246; Signed l_v2247; Signed l_v2250; Signed l_v2254;
	Signed l_v2255; Signed l_v2258; Signed l_v2260; Signed l_v2263;
	Signed l_v2264; Signed l_v2269; Signed l_v2270; Signed l_v2274;
	Signed l_v2277; Signed l_v2278; Signed l_v2281; Signed l_v2282;
	Signed l_v2287; bool_t l_v2202; bool_t l_v2205; bool_t l_v2209;
	bool_t l_v2212; bool_t l_v2216; bool_t l_v2219; bool_t l_v2224;
	bool_t l_v2228; bool_t l_v2229; bool_t l_v2231; bool_t l_v2233;
	bool_t l_v2241; bool_t l_v2248; bool_t l_v2256; bool_t l_v2265;
	bool_t l_v2271; bool_t l_v2273; bool_t l_v2275; bool_t l_v2280;
	bool_t l_v2283; bool_t l_v2291; struct pypy_AddressChunk0 *l_v2234;
	struct pypy_AddressChunk0 *l_v2284; struct pypy_header0 *l_v2197;
	struct pypy_object_vtable0 *l_v2227;
	struct pypy_object_vtable0 *l_v2240;
	struct pypy_object_vtable0 *l_v2290; struct pypy_type_info0 *l_v2199;
	struct pypy_type_info0 *l_v2206; struct pypy_type_info0 *l_v2213;
	struct pypy_type_info0 *l_v2221; struct pypy_type_info0 *l_v2245;
	struct pypy_type_info0 *l_v2253; struct pypy_type_info0 *l_v2262;
	struct pypy_type_info0 *l_v2268;
	struct pypy_type_info_extra0 *l_v2226;
	struct pypy_varsize_type_info0 *l_v2244;
	struct pypy_varsize_type_info0 *l_v2252;
	struct pypy_varsize_type_info0 *l_v2261;
	struct pypy_varsize_type_info0 *l_v2267; void* *l_v2235;
	void* *l_v2285; void* l_v2192; void* l_v2193; void* l_v2194;
	void* l_v2195; void* l_v2196; void* l_v2230; void* l_v2251;
	void* l_v2259; void* l_v2276; void* l_v2279; void* l_v2294;
	goto block0;

    block0:
	OP_ADR_SUB(l_obj_27, 0, l_v2196);
	l_v2197 = (struct pypy_header0 *)l_v2196;
	l_v2198 = RPyField(l_v2197, h_tid);
	OP_EXTRACT_USHORT(l_v2198, l_typeid_10);
	l_v2199 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_10);
	l_v2200 = RPyField(l_v2199, ti_infobits);
	OP_INT_AND(l_v2200, -16777216L, l_v2201);
	OP_INT_EQ(l_v2201, 1509949440L, l_v2202);
	RPyAssert(l_v2202, "invalid type_id");
	OP_INT_AND(l_v2200, 131072L, l_v2204);
	OP_INT_NE(l_v2204, 0L, l_v2205);
	if (l_v2205) {
		goto block12;
	}
	goto block1;

    block1:
	l_v2206 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_10);
	l_v2207 = RPyField(l_v2206, ti_infobits);
	OP_INT_AND(l_v2207, -16777216L, l_v2208);
	OP_INT_EQ(l_v2208, 1509949440L, l_v2209);
	RPyAssert(l_v2209, "invalid type_id");
	OP_INT_AND(l_v2207, 4194304L, l_v2211);
	OP_INT_NE(l_v2211, 0L, l_v2212);
	if (l_v2212) {
		goto block3;
	}
	goto block2;

    block2:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block3:
	l_v2213 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_10);
	l_v2214 = RPyField(l_v2213, ti_infobits);
	OP_INT_AND(l_v2214, -16777216L, l_v2215);
	OP_INT_EQ(l_v2215, 1509949440L, l_v2216);
	RPyAssert(l_v2216, "invalid type_id");
	OP_INT_AND(l_v2214, 4194304L, l_v2218);
	OP_INT_NE(l_v2218, 0L, l_v2219);
	RPyAssert(l_v2219, "T_HAS_CUSTOM_TRACE missing");
	l_v2221 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_10);
	l_v2222 = RPyField(l_v2221, ti_infobits);
	OP_INT_AND(l_v2222, -16777216L, l_v2223);
	OP_INT_EQ(l_v2223, 1509949440L, l_v2224);
	RPyAssert(l_v2224, "invalid type_id");
	l_v2226 = RPyField(l_v2221, ti_extra);
	l_generator_3 = RPyField(l_v2226, tie_customtracer);
	l_v2294 = NULL;
	goto block4;

    block4:
	while (1) {
		l_item_14 = l_generator_3(l_obj_27, l_v2294);
		l_v2227 = (&pypy_g_ExcData)->ed_exc_type;
		l_v2228 = (l_v2227 == NULL);
		if (!l_v2228) break;
		goto block5;
	  block4_back: ;
	}
	goto block11;

    block5:
	OP_ADR_NE(l_item_14, NULL, l_v2229);
	if (l_v2229) {
		goto block6;
	}
	goto block2;

    block6:
	l_v2230 = ((void* *) (((char *)l_item_14) + 0))[0];
	OP_ADR_NE(l_v2230, NULL, l_v2231);
	if (l_v2231) {
		goto block7;
	}
	l_v2294 = l_item_14;
	goto block4_back;

    block7:
	l_v2193 = ((void* *) (((char *)l_item_14) + 0))[0];
	l_v2232 = RPyField(l_arg_16, as_inst_used_in_last_chunk);
	OP_INT_EQ(l_v2232, 1019L, l_v2233);
	if (l_v2233) {
		goto block9;
	}
	l_used_13 = l_v2232;
	goto block8;

    block8:
	l_v2234 = RPyField(l_arg_16, as_inst_chunk);
	l_v2235 = RPyField(l_v2234, ac_items);
	RPyFxItem(l_v2235, l_used_13, 1019) = l_v2193;
	OP_INT_ADD(l_used_13, 1L, l_v2237);
	RPyField(l_arg_16, as_inst_used_in_last_chunk) = l_v2237;
	l_v2294 = l_item_14;
	goto block4;

    block9:
	pypy_g_AddressStack_enlarge(l_arg_16);
	l_v2240 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2241 = (l_v2240 == NULL);
	if (!l_v2241) {
		goto block10;
	}
	l_used_13 = 0L;
	goto block8;

    block10:
	PYPY_DEBUG_RECORD_TRACEBACK("_trace_slow_path___append_if_nonnull");
	goto block2;

    block11:
	PYPY_DEBUG_RECORD_TRACEBACK("_trace_slow_path___append_if_nonnull");
	goto block2;

    block12:
	l_v2244 = (struct pypy_varsize_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_10);
	l_v2245 = (struct pypy_type_info0 *)l_v2244;
	l_v2246 = RPyField(l_v2245, ti_infobits);
	OP_INT_AND(l_v2246, -16711680L, l_v2247);
	OP_INT_EQ(l_v2247, 1510014976L, l_v2248);
	RPyAssert(l_v2248, "invalid varsize type_id");
	l_v2250 = RPyField(l_v2244, vti_ofstovar);
	OP_ADR_ADD(l_obj_27, l_v2250, l_v2251);
	l_v2252 = (struct pypy_varsize_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_10);
	l_v2253 = (struct pypy_type_info0 *)l_v2252;
	l_v2254 = RPyField(l_v2253, ti_infobits);
	OP_INT_AND(l_v2254, -16711680L, l_v2255);
	OP_INT_EQ(l_v2255, 1510014976L, l_v2256);
	RPyAssert(l_v2256, "invalid varsize type_id");
	l_v2258 = RPyField(l_v2252, vti_ofstolength);
	OP_ADR_ADD(l_obj_27, l_v2258, l_v2259);
	l_v2260 = ((Signed *) (((char *)l_v2259) + 0))[0];
	l_v2261 = (struct pypy_varsize_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_10);
	l_v2262 = (struct pypy_type_info0 *)l_v2261;
	l_v2263 = RPyField(l_v2262, ti_infobits);
	OP_INT_AND(l_v2263, -16711680L, l_v2264);
	OP_INT_EQ(l_v2264, 1510014976L, l_v2265);
	RPyAssert(l_v2265, "invalid varsize type_id");
	l_offsets_8 = RPyField(l_v2261, vti_varofstoptrs);
	l_v2267 = (struct pypy_varsize_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_10);
	l_v2268 = (struct pypy_type_info0 *)l_v2267;
	l_v2269 = RPyField(l_v2268, ti_infobits);
	OP_INT_AND(l_v2269, -16711680L, l_v2270);
	OP_INT_EQ(l_v2270, 1510014976L, l_v2271);
	RPyAssert(l_v2271, "invalid varsize type_id");
	l_itemlength_4 = RPyField(l_v2267, vti_varitemsize);
	l_v2192 = l_v2251;
	l_length_34 = l_v2260;
	goto block13;

    block13:
	OP_INT_GT(l_length_34, 0L, l_v2273);
	if (l_v2273) {
		l_j_4 = 0L;
		goto block14;
	}
	goto block1;

    block14:
	while (1) {
		l_v2274 = l_offsets_8->length;
		OP_INT_LT(l_j_4, l_v2274, l_v2275);
		if (!l_v2275) break;
		goto block16;
	  block14_back: ;
	}
	goto block15;

    block15:
	OP_ADR_ADD(l_v2192, l_itemlength_4, l_v2276);
	OP_INT_SUB(l_length_34, 1L, l_v2277);
	l_v2192 = l_v2276;
	l_length_34 = l_v2277;
	goto block13;

    block16:
	l_v2278 = RPyItem(l_offsets_8, l_j_4);
	OP_ADR_ADD(l_v2192, l_v2278, l_v2195);
	l_v2279 = ((void* *) (((char *)l_v2195) + 0))[0];
	OP_ADR_NE(l_v2279, NULL, l_v2280);
	if (l_v2280) {
		goto block18;
	}
	goto block17;

    block17:
	OP_INT_ADD(l_j_4, 1L, l_v2281);
	l_j_4 = l_v2281;
	goto block14_back;

    block18:
	l_v2194 = ((void* *) (((char *)l_v2195) + 0))[0];
	l_v2282 = RPyField(l_arg_16, as_inst_used_in_last_chunk);
	OP_INT_EQ(l_v2282, 1019L, l_v2283);
	if (l_v2283) {
		goto block20;
	}
	l_used_14 = l_v2282;
	goto block19;

    block19:
	l_v2284 = RPyField(l_arg_16, as_inst_chunk);
	l_v2285 = RPyField(l_v2284, ac_items);
	RPyFxItem(l_v2285, l_used_14, 1019) = l_v2194;
	OP_INT_ADD(l_used_14, 1L, l_v2287);
	RPyField(l_arg_16, as_inst_used_in_last_chunk) = l_v2287;
	goto block17;

    block20:
	pypy_g_AddressStack_enlarge(l_arg_16);
	l_v2290 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2291 = (l_v2290 == NULL);
	if (!l_v2291) {
		goto block21;
	}
	l_used_14 = 0L;
	goto block19;

    block21:
	PYPY_DEBUG_RECORD_TRACEBACK("_trace_slow_path___append_if_nonnull");
	goto block2;
}
/*/*/
/***********************************************************/
