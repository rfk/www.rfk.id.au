/***********************************************************/
/***  Implementations                                    ***/

#define PYPY_FILE_NAME "data_rpython_memory_gc_minimark_1.c"
#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"
#include "src/g_include.h"

/*/*/

/*/*/

/*/*/

/*/*/

/*/*/
/***********************************************************/
