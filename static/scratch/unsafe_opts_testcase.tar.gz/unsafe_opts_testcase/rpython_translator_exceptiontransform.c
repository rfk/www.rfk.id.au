/***********************************************************/
/***  Implementations                                    ***/

#define PYPY_FILE_NAME "rpython_translator_exceptiontransform.c"
#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"
#include "src/g_include.h"

/*/*/
bool_t pypy_g_RPyExceptionOccurred(void) {
	bool_t l_v9935; struct pypy_object_vtable0 *l_v9936;
	goto block0;

    block0:
	l_v9936 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9935 = (l_v9936 != NULL);
	goto block1;

    block1:
	return l_v9935;
}
/*/*/
struct pypy_object_vtable0 *pypy_g_RPyFetchExceptionType(void) {
	struct pypy_object_vtable0 *l_v9937;
	goto block0;

    block0:
	l_v9937 = (&pypy_g_ExcData)->ed_exc_type;
	goto block1;

    block1:
	return l_v9937;
}
/*/*/
struct pypy_object0 *pypy_g_RPyFetchExceptionValue(void) {
	struct pypy_object0 *l_v9938;
	goto block0;

    block0:
	l_v9938 = (&pypy_g_ExcData)->ed_exc_value;
	goto block1;

    block1:
	return l_v9938;
}
/*/*/
void pypy_g_RPyClearException(void) {
	goto block0;

    block0:
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	goto block1;

    block1:
	return /* nothing */;
}
/*/*/
void pypy_g_RPyRaiseException(struct pypy_object_vtable0 *l_etype_0, struct pypy_object0 *l_evalue_0) {
	bool_t l_v9942; bool_t l_v9944;
	goto block0;

    block0:
	l_v9942 = (l_etype_0 != (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super));
	RPyAssert(l_v9942, "AssertionError");
	l_v9944 = (l_etype_0 != (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	RPyAssert(l_v9944, "NotImplementedError");
	(&pypy_g_ExcData)->ed_exc_type = l_etype_0;
	(&pypy_g_ExcData)->ed_exc_value = l_evalue_0;
	OP_DEBUG_START_TRACEBACK(l_etype_0, /* nothing */);
	goto block1;

    block1:
	return /* nothing */;
}
/*/*/
void pypy_g_RPyReRaiseException(struct pypy_object_vtable0 *l_etype_1, struct pypy_object0 *l_evalue_1) {
	goto block0;

    block0:
	(&pypy_g_ExcData)->ed_exc_type = l_etype_1;
	(&pypy_g_ExcData)->ed_exc_value = l_evalue_1;
	OP_DEBUG_RERAISE_TRACEBACK(l_etype_1, /* nothing */);
	goto block1;

    block1:
	return /* nothing */;
}
/*/*/
/***********************************************************/
