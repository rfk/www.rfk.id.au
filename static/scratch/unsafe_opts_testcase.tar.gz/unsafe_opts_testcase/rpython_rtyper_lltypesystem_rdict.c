/***********************************************************/
/***  Implementations                                    ***/

#define PYPY_FILE_NAME "rpython_rtyper_lltypesystem_rdict.c"
#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"
#include "src/g_include.h"

/*/*/
struct pypy_DICT0 *pypy_g_ll_newdict_size__Struct_DICTLlT_Signed(Signed l_length_estimate_0) {
	struct pypy_array5 *l_entries_2; Signed l_i_24;
	Signed l_length_estimate_1; Signed l_n_2; Signed l_v7289;
	Signed l_v7303; Signed l_v7307; Signed l_v7310; bool_t l_v7290;
	bool_t l_v7292; bool_t l_v7296; bool_t l_v7299; bool_t l_v7300;
	struct pypy_DICT0 *l_v7288; struct pypy_DICT0 *l_v7311;
	struct pypy_ENTRY0 *l_v7305; void* l_v7291; void* l_v7297;
	void* l_v7312;
	goto block0;

    block0:
	OP_INT_FLOORDIV(l_length_estimate_0, 2L, l_v7289);
	OP_INT_MUL(l_v7289, 3L, l_length_estimate_1);
	l_n_2 = 8L;
	goto block1;

    block1:
	while (1) {
		OP_INT_LT(l_n_2, l_length_estimate_1, l_v7290);
		if (!l_v7290) break;
		goto block12;
	  block1_back: ;
	}
	goto block2;

    block2:
	OP_RAW_MALLOC(sizeof(struct pypy_DICT0), l_v7291, void *);
	OP_ADR_NE(l_v7291, NULL, l_v7292);
	if (l_v7292) {
		l_v7312 = l_v7291;
		goto block4;
	}
	goto block3;

    block3:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("ll_newdict_size__Struct_DICTLlT_Signed");
	l_v7312 = NULL;
	goto block4;

    block4:
	OP_TRACK_ALLOC_START(l_v7312, /* nothing */);
	l_v7288 = (struct pypy_DICT0 *)l_v7312;
	l_v7296 = (l_v7288 != NULL);
	if (!l_v7296) {
		goto block11;
	}
	goto block5;

    block5:
	l_v7297 = pypy_g_ll_malloc_varsize__Signed_Signed_Signed_Signed(l_n_2, (offsetof(struct pypy_array5, items) + 0), sizeof(struct pypy_ENTRY0), offsetof(struct pypy_array5, length));
	OP_TRACK_ALLOC_START(l_v7297, /* nothing */);
	l_entries_2 = (struct pypy_array5 *)l_v7297;
	l_v7299 = (l_entries_2 != NULL);
	if (!l_v7299) {
		goto block10;
	}
	l_i_24 = 0L;
	goto block6;

    block6:
	while (1) {
		OP_INT_LT(l_i_24, l_n_2, l_v7300);
		if (!l_v7300) break;
		goto block9;
	  block6_back: ;
	}
	goto block7;

    block7:
	RPyField(l_v7288, di_entries) = l_entries_2;
	RPyField(l_v7288, di_num_items) = 0L;
	OP_INT_MUL(l_n_2, 2L, l_v7303);
	RPyField(l_v7288, di_resize_counter) = l_v7303;
	l_v7311 = l_v7288;
	goto block8;

    block8:
	RPY_DEBUG_RETURN();
	return l_v7311;

    block9:
	l_v7305 = &RPyItem(l_entries_2, l_i_24);
	RPyField(l_v7305, en_key) = NULL;
	OP_INT_ADD(l_i_24, 1L, l_v7307);
	l_i_24 = l_v7307;
	goto block6_back;

    block10:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_newdict_size__Struct_DICTLlT_Signed");
	l_v7311 = ((struct pypy_DICT0 *) NULL);
	goto block8;

    block11:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_newdict_size__Struct_DICTLlT_Signed");
	l_v7311 = ((struct pypy_DICT0 *) NULL);
	goto block8;

    block12:
	OP_INT_MUL(l_n_2, 2L, l_v7310);
	l_n_2 = l_v7310;
	goto block1_back;
}
/*/*/
void pypy_g_ll_clear__DICTPtr(struct pypy_DICT0 *l_d_32) {
	struct pypy_array5 *l_entries_3; Signed l_i_25; Signed l_n_3;
	Signed l_v7315; Signed l_v7322; Signed l_v7331; bool_t l_v7316;
	bool_t l_v7319; bool_t l_v7323; bool_t l_v7332;
	struct pypy_ENTRY0 *l_v7320; struct pypy_array5 *l_v7313;
	struct pypy_array5 *l_v7314; void* l_v7317; void* l_v7327;
	goto block0;

    block0:
	l_v7314 = RPyField(l_d_32, di_entries);
	l_v7315 = l_v7314->length;
	OP_INT_EQ(l_v7315, 8L, l_v7316);
	if (l_v7316) {
		goto block6;
	}
	goto block1;

    block1:
	l_v7313 = RPyField(l_d_32, di_entries);
	l_v7317 = pypy_g_ll_malloc_varsize__Signed_Signed_Signed_Signed(8L, (offsetof(struct pypy_array5, items) + 0), sizeof(struct pypy_ENTRY0), offsetof(struct pypy_array5, length));
	OP_TRACK_ALLOC_START(l_v7317, /* nothing */);
	l_entries_3 = (struct pypy_array5 *)l_v7317;
	l_v7319 = (l_entries_3 != NULL);
	if (!l_v7319) {
		goto block5;
	}
	l_n_3 = 8L;
	l_i_25 = 0L;
	goto block2;

    block2:
	while (1) {
		l_v7320 = &RPyItem(l_entries_3, l_i_25);
		RPyField(l_v7320, en_key) = NULL;
		OP_INT_ADD(l_i_25, 1L, l_v7322);
		OP_INT_LT(l_v7322, l_n_3, l_v7323);
		if (!l_v7323) break;
		l_i_25 = l_v7322;
		goto block2_back;
	  block2_back: ;
	}
	goto block3;

    block3:
	RPyField(l_d_32, di_entries) = l_entries_3;
	RPyField(l_d_32, di_num_items) = 0L;
	RPyField(l_d_32, di_resize_counter) = 16L;
	l_v7327 = (void*)l_v7313;
	OP_TRACK_ALLOC_STOP(l_v7327, /* nothing */);
	OP_RAW_FREE(l_v7327, /* nothing */);
	goto block4;

    block4:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block5:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_clear__DICTPtr");
	goto block4;

    block6:
	l_v7331 = RPyField(l_d_32, di_resize_counter);
	OP_INT_EQ(l_v7331, 16L, l_v7332);
	if (l_v7332) {
		goto block4;
	}
	goto block1;
}
/*/*/
bool_t pypy_g_ll_contains__dicttablePtr_rpy_stringPtr(struct pypy_dicttable0 *l_d_33, struct pypy_rpy_string0 *l_s_4) {
	Signed l_i_26; Signed l_length_44; Signed l_v7334; Signed l_v7341;
	Signed l_v7345; Signed l_v7346; Signed l_v7348; Signed l_v7351;
	Signed l_v7353; Signed l_v7354; Signed l_v7355; Unsigned l_v7337;
	Unsigned l_v7338; Unsigned l_v7340; Unsigned l_v7357; bool_t l_v7335;
	bool_t l_v7336; bool_t l_v7339; bool_t l_v7342; bool_t l_v7343;
	bool_t l_v7347; bool_t l_v7349; bool_t l_v7356; char l_v7344;
	char l_v7352; Signed l_x_2; Signed l_x_3;
	goto block0;

    block0:
	l_v7335 = (l_s_4 != NULL);
	if (l_v7335) {
		goto block6;
	}
	l_v7334 = 0L;
	goto block1;

    block1:
	OP_INT_IS_TRUE(0 /* we are not jitted here */, l_v7336);
	if (l_v7336) {
		goto block5;
	}
	goto block2;

    block2:
	l_v7337 = pypy_g_ll_dict_lookup__v82___simple_call__function_ll(l_d_33, l_s_4, l_v7334);
	l_v7357 = l_v7337;
	goto block3;

    block3:
	OP_UINT_AND(l_v7357, 2147483648UL, l_v7338);
	OP_UINT_IS_TRUE(l_v7338, l_v7339);
	if (l_v7339) {
		l_v7356 = 0;
		goto block4;
	}
	l_v7356 = 1;
	goto block4;

    block4:
	RPY_DEBUG_RETURN();
	return l_v7356;

    block5:
	l_v7340 = pypy_g_ll_dict_lookup__v90___simple_call__function_ll(l_d_33, l_s_4, l_v7334);
	l_v7357 = l_v7340;
	goto block3;

    block6:
	l_v7341 = RPyField(l_s_4, rs_hash);
	OP_INT_EQ(l_v7341, 0L, l_v7342);
	if (l_v7342) {
		goto block7;
	}
	l_v7334 = l_v7341;
	goto block1;

    block7:
	l_length_44 = RPyField(l_s_4, rs_chars).length;
	OP_INT_EQ(l_length_44, 0L, l_v7343);
	if (l_v7343) {
		l_x_3 = -1L;
		goto block11;
	}
	goto block8;

    block8:
	l_v7344 = RPyField(l_s_4, rs_chars).items[0L];
	OP_CAST_CHAR_TO_INT(l_v7344, l_v7345);
	OP_INT_LSHIFT(l_v7345, 7L, l_v7346);
	l_x_2 = l_v7346;
	l_i_26 = 0L;
	goto block9;

    block9:
	while (1) {
		OP_INT_LT(l_i_26, l_length_44, l_v7347);
		if (!l_v7347) break;
		goto block12;
	  block9_back: ;
	}
	goto block10;

    block10:
	OP_INT_XOR(l_x_2, l_length_44, l_v7348);
	OP_INT_EQ(l_v7348, 0L, l_v7349);
	if (l_v7349) {
		l_x_3 = 29872897L;
		goto block11;
	}
	l_x_3 = l_v7348;
	goto block11;

    block11:
	RPyField(l_s_4, rs_hash) = l_x_3;
	l_v7334 = l_x_3;
	goto block1;

    block12:
	OP_INT_MUL(1000003L, l_x_2, l_v7351);
	l_v7352 = RPyField(l_s_4, rs_chars).items[l_i_26];
	OP_CAST_CHAR_TO_INT(l_v7352, l_v7353);
	OP_INT_XOR(l_v7351, l_v7353, l_v7354);
	OP_INT_ADD(l_i_26, 1L, l_v7355);
	l_x_2 = l_v7354;
	l_i_26 = l_v7355;
	goto block9_back;
}
/*/*/
void pypy_g_ll_dict_setitem__DICTPtr_Address_Address(struct pypy_DICT0 *l_v7359, void* l_key_23, void* l_value_2) {
	Unsigned l_i_27; Signed l_v7358; Signed l_v7360; Signed l_v7361;
	Unsigned l_v7363; Unsigned l_v7367; bool_t l_v7362; bool_t l_v7364;
	goto block0;

    block0:
	OP_CAST_ADR_TO_INT(l_key_23, /* nothing */, l_v7360);
	OP_INT_RSHIFT(l_v7360, 4L, l_v7361);
	OP_INT_XOR(l_v7360, l_v7361, l_v7358);
	OP_INT_IS_TRUE(0 /* we are not jitted here */, l_v7362);
	if (l_v7362) {
		goto block6;
	}
	goto block1;

    block1:
	l_v7363 = pypy_g_ll_dict_lookup__v51___simple_call__function_ll(l_v7359, l_key_23, l_v7358);
	l_i_27 = l_v7363;
	goto block2;

    block2:
	OP_INT_IS_TRUE(0 /* we are not jitted here */, l_v7364);
	if (l_v7364) {
		goto block5;
	}
	goto block3;

    block3:
	pypy_g__ll_dict_setitem_lookup_done__v66___simple_call_(l_v7359, l_key_23, l_value_2, l_v7358, l_i_27);
	goto block4;

    block4:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block5:
	pypy_g__ll_dict_setitem_lookup_done__v77___simple_call_(l_v7359, l_key_23, l_value_2, l_v7358, l_i_27);
	goto block4;

    block6:
	l_v7367 = pypy_g_ll_dict_lookup__v60___simple_call__function_ll(l_v7359, l_key_23, l_v7358);
	l_i_27 = l_v7367;
	goto block2;
}
/*/*/
Unsigned pypy_g_ll_dict_lookup__v141___simple_call__function_l(struct pypy_dicttable1 *l_d_19, char l_key_24, Signed l_hash_10) {
	struct pypy_array9 *l_entries_4; Signed l_freeslot_0;
	Signed l_freeslot_1; Signed l_freeslot_2; Unsigned l_i_28;
	Unsigned l_i_29; Unsigned l_i_30; Signed l_mask_0;
	Unsigned l_perturb_0; Signed l_v7369; Signed l_v7370; Signed l_v7371;
	Signed l_v7373; Signed l_v7376; Signed l_v7383; Signed l_v7388;
	Signed l_v7389; Signed l_v7393; Signed l_v7394; Signed l_v7397;
	Signed l_v7401; Unsigned l_v7375; Unsigned l_v7377; Unsigned l_v7378;
	Unsigned l_v7379; Unsigned l_v7380; Unsigned l_v7381;
	Unsigned l_v7382; Unsigned l_v7386; Unsigned l_v7387;
	Unsigned l_v7392; Unsigned l_v7400; bool_t l_v7372; bool_t l_v7374;
	bool_t l_v7384; bool_t l_v7385; bool_t l_v7390; bool_t l_v7391;
	bool_t l_v7396; bool_t l_v7399; char l_v7395; char l_v7398;
	goto block0;

    block0:
	l_entries_4 = RPyField(l_d_19, d_entries);
	l_v7369 = l_entries_4->length;
	OP_INT_SUB(l_v7369, 1L, l_mask_0);
	OP_INT_AND(l_hash_10, l_mask_0, l_v7370);
	OP_CAST_INT_TO_UINT(l_v7370, l_i_29);
	OP_CAST_UINT_TO_INT(l_i_29, l_v7371);
	l_v7372 = RPyItem(l_entries_4, l_v7371).d_f_valid;
	if (l_v7372) {
		goto block15;
	}
	goto block1;

    block1:
	OP_CAST_UINT_TO_INT(l_i_29, l_v7373);
	l_v7374 = RPyItem(l_entries_4, l_v7373).d_f_everused;
	if (l_v7374) {
		goto block4;
	}
	goto block2;

    block2:
	OP_UINT_OR(l_i_29, 2147483648UL, l_v7375);
	l_v7400 = l_v7375;
	goto block3;

    block3:
	RPY_DEBUG_RETURN();
	return l_v7400;

    block4:
	OP_CAST_UINT_TO_INT(l_i_29, l_v7376);
	l_freeslot_1 = l_v7376;
	goto block5;

    block5:
	OP_CAST_INT_TO_UINT(l_hash_10, l_v7377);
	l_freeslot_0 = l_freeslot_1;
	l_i_30 = l_i_29;
	l_perturb_0 = l_v7377;
	goto block6;

    block6:
	while (1) {
		OP_UINT_LSHIFT(l_i_30, 2L, l_v7378);
		OP_UINT_ADD(l_v7378, l_i_30, l_v7379);
		OP_UINT_ADD(l_v7379, l_perturb_0, l_v7380);
		OP_UINT_ADD(l_v7380, 1UL, l_v7381);
		OP_CAST_INT_TO_UINT(l_mask_0, l_v7382);
		OP_UINT_AND(l_v7381, l_v7382, l_i_28);
		OP_CAST_UINT_TO_INT(l_i_28, l_v7383);
		l_v7384 = RPyItem(l_entries_4, l_v7383).d_f_everused;
		if (!l_v7384) break;
		goto block10;
	  block6_back: ;
	}
	goto block7;

    block7:
	OP_INT_EQ(l_freeslot_0, -1L, l_v7385);
	if (l_v7385) {
		goto block9;
	}
	l_v7401 = l_freeslot_0;
	goto block8;

    block8:
	OP_CAST_INT_TO_UINT(l_v7401, l_v7386);
	OP_UINT_OR(l_v7386, 2147483648UL, l_v7387);
	l_v7400 = l_v7387;
	goto block3;

    block9:
	OP_CAST_UINT_TO_INT(l_i_28, l_v7388);
	l_v7401 = l_v7388;
	goto block8;

    block10:
	OP_CAST_UINT_TO_INT(l_i_28, l_v7389);
	l_v7390 = RPyItem(l_entries_4, l_v7389).d_f_valid;
	if (l_v7390) {
		goto block14;
	}
	goto block11;

    block11:
	OP_INT_EQ(l_freeslot_0, -1L, l_v7391);
	if (l_v7391) {
		goto block13;
	}
	l_freeslot_2 = l_freeslot_0;
	goto block12;

    block12:
	OP_UINT_RSHIFT(l_perturb_0, 5L, l_v7392);
	l_freeslot_0 = l_freeslot_2;
	l_i_30 = l_i_28;
	l_perturb_0 = l_v7392;
	goto block6_back;

    block13:
	OP_CAST_UINT_TO_INT(l_i_28, l_v7393);
	l_freeslot_2 = l_v7393;
	goto block12;

    block14:
	OP_CAST_UINT_TO_INT(l_i_28, l_v7394);
	l_v7395 = RPyItem(l_entries_4, l_v7394).d_key;
	OP_CHAR_EQ(l_v7395, l_key_24, l_v7396);
	if (l_v7396) {
		l_v7400 = l_i_28;
		goto block3;
	}
	l_freeslot_2 = l_freeslot_0;
	goto block12;

    block15:
	OP_CAST_UINT_TO_INT(l_i_29, l_v7397);
	l_v7398 = RPyItem(l_entries_4, l_v7397).d_key;
	OP_CHAR_EQ(l_v7398, l_key_24, l_v7399);
	if (l_v7399) {
		l_v7400 = l_i_29;
		goto block3;
	}
	l_freeslot_1 = -1L;
	goto block5;
}
/*/*/
Unsigned pypy_g_ll_dict_lookup__v150___simple_call__function_l(struct pypy_dicttable1 *l_d_20, char l_key_25, Signed l_hash_22) {
	struct pypy_array9 *l_entries_5; Signed l_freeslot_3;
	Signed l_freeslot_4; Signed l_freeslot_5; Unsigned l_i_31;
	Unsigned l_i_32; Unsigned l_i_33; Signed l_mask_1;
	Unsigned l_perturb_1; Signed l_v7402; Signed l_v7403; Signed l_v7404;
	Signed l_v7406; Signed l_v7409; Signed l_v7416; Signed l_v7421;
	Signed l_v7422; Signed l_v7426; Signed l_v7427; Signed l_v7430;
	Signed l_v7434; Unsigned l_v7408; Unsigned l_v7410; Unsigned l_v7411;
	Unsigned l_v7412; Unsigned l_v7413; Unsigned l_v7414;
	Unsigned l_v7415; Unsigned l_v7419; Unsigned l_v7420;
	Unsigned l_v7425; Unsigned l_v7433; bool_t l_v7405; bool_t l_v7407;
	bool_t l_v7417; bool_t l_v7418; bool_t l_v7423; bool_t l_v7424;
	bool_t l_v7429; bool_t l_v7432; char l_v7428; char l_v7431;
	goto block0;

    block0:
	l_entries_5 = RPyField(l_d_20, d_entries);
	l_v7402 = l_entries_5->length;
	OP_INT_SUB(l_v7402, 1L, l_mask_1);
	OP_INT_AND(l_hash_22, l_mask_1, l_v7403);
	OP_CAST_INT_TO_UINT(l_v7403, l_i_32);
	OP_CAST_UINT_TO_INT(l_i_32, l_v7404);
	l_v7405 = RPyItem(l_entries_5, l_v7404).d_f_valid;
	if (l_v7405) {
		goto block15;
	}
	goto block1;

    block1:
	OP_CAST_UINT_TO_INT(l_i_32, l_v7406);
	l_v7407 = RPyItem(l_entries_5, l_v7406).d_f_everused;
	if (l_v7407) {
		goto block4;
	}
	goto block2;

    block2:
	OP_UINT_OR(l_i_32, 2147483648UL, l_v7408);
	l_v7433 = l_v7408;
	goto block3;

    block3:
	RPY_DEBUG_RETURN();
	return l_v7433;

    block4:
	OP_CAST_UINT_TO_INT(l_i_32, l_v7409);
	l_freeslot_4 = l_v7409;
	goto block5;

    block5:
	OP_CAST_INT_TO_UINT(l_hash_22, l_v7410);
	l_freeslot_3 = l_freeslot_4;
	l_perturb_1 = l_v7410;
	l_i_33 = l_i_32;
	goto block6;

    block6:
	while (1) {
		OP_UINT_LSHIFT(l_i_33, 2L, l_v7411);
		OP_UINT_ADD(l_v7411, l_i_33, l_v7412);
		OP_UINT_ADD(l_v7412, l_perturb_1, l_v7413);
		OP_UINT_ADD(l_v7413, 1UL, l_v7414);
		OP_CAST_INT_TO_UINT(l_mask_1, l_v7415);
		OP_UINT_AND(l_v7414, l_v7415, l_i_31);
		OP_CAST_UINT_TO_INT(l_i_31, l_v7416);
		l_v7417 = RPyItem(l_entries_5, l_v7416).d_f_everused;
		if (!l_v7417) break;
		goto block10;
	  block6_back: ;
	}
	goto block7;

    block7:
	OP_INT_EQ(l_freeslot_3, -1L, l_v7418);
	if (l_v7418) {
		goto block9;
	}
	l_v7434 = l_freeslot_3;
	goto block8;

    block8:
	OP_CAST_INT_TO_UINT(l_v7434, l_v7419);
	OP_UINT_OR(l_v7419, 2147483648UL, l_v7420);
	l_v7433 = l_v7420;
	goto block3;

    block9:
	OP_CAST_UINT_TO_INT(l_i_31, l_v7421);
	l_v7434 = l_v7421;
	goto block8;

    block10:
	OP_CAST_UINT_TO_INT(l_i_31, l_v7422);
	l_v7423 = RPyItem(l_entries_5, l_v7422).d_f_valid;
	if (l_v7423) {
		goto block14;
	}
	goto block11;

    block11:
	OP_INT_EQ(l_freeslot_3, -1L, l_v7424);
	if (l_v7424) {
		goto block13;
	}
	l_freeslot_5 = l_freeslot_3;
	goto block12;

    block12:
	OP_UINT_RSHIFT(l_perturb_1, 5L, l_v7425);
	l_freeslot_3 = l_freeslot_5;
	l_perturb_1 = l_v7425;
	l_i_33 = l_i_31;
	goto block6_back;

    block13:
	OP_CAST_UINT_TO_INT(l_i_31, l_v7426);
	l_freeslot_5 = l_v7426;
	goto block12;

    block14:
	OP_CAST_UINT_TO_INT(l_i_31, l_v7427);
	l_v7428 = RPyItem(l_entries_5, l_v7427).d_key;
	OP_CHAR_EQ(l_v7428, l_key_25, l_v7429);
	if (l_v7429) {
		l_v7433 = l_i_31;
		goto block3;
	}
	l_freeslot_5 = l_freeslot_3;
	goto block12;

    block15:
	OP_CAST_UINT_TO_INT(l_i_32, l_v7430);
	l_v7431 = RPyItem(l_entries_5, l_v7430).d_key;
	OP_CHAR_EQ(l_v7431, l_key_25, l_v7432);
	if (l_v7432) {
		l_v7433 = l_i_32;
		goto block3;
	}
	l_freeslot_4 = -1L;
	goto block5;
}
/*/*/
Unsigned pypy_g_ll_dict_lookup__v51___simple_call__function_ll(struct pypy_DICT0 *l_d_21, void* l_key_26, Signed l_hash_23) {
	struct pypy_array5 *l_entries_6; Signed l_freeslot_6;
	Signed l_freeslot_7; Signed l_freeslot_8; Unsigned l_i_34;
	Unsigned l_i_35; Unsigned l_i_36; Signed l_mask_2;
	Unsigned l_perturb_2; Signed l_v7435; Signed l_v7436; Signed l_v7437;
	Signed l_v7441; Signed l_v7446; Signed l_v7453; Signed l_v7460;
	Signed l_v7461; Signed l_v7467; Signed l_v7468; Signed l_v7472;
	Signed l_v7477; Unsigned l_v7445; Unsigned l_v7447; Unsigned l_v7448;
	Unsigned l_v7449; Unsigned l_v7450; Unsigned l_v7451;
	Unsigned l_v7452; Unsigned l_v7458; Unsigned l_v7459;
	Unsigned l_v7466; Unsigned l_v7476; bool_t l_v7440; bool_t l_v7444;
	bool_t l_v7456; bool_t l_v7457; bool_t l_v7464; bool_t l_v7465;
	bool_t l_v7471; bool_t l_v7475; struct pypy_ENTRY0 *l_v7438;
	struct pypy_ENTRY0 *l_v7442; struct pypy_ENTRY0 *l_v7454;
	struct pypy_ENTRY0 *l_v7462; struct pypy_ENTRY0 *l_v7469;
	struct pypy_ENTRY0 *l_v7473; void* l_v7439; void* l_v7443;
	void* l_v7455; void* l_v7463; void* l_v7470; void* l_v7474;
	goto block0;

    block0:
	l_entries_6 = RPyField(l_d_21, di_entries);
	l_v7435 = l_entries_6->length;
	OP_INT_SUB(l_v7435, 1L, l_mask_2);
	OP_INT_AND(l_hash_23, l_mask_2, l_v7436);
	OP_CAST_INT_TO_UINT(l_v7436, l_i_35);
	OP_CAST_UINT_TO_INT(l_i_35, l_v7437);
	l_v7438 = &RPyItem(l_entries_6, l_v7437);
	l_v7439 = RPyField(l_v7438, en_key);
	OP_ADR_NE(l_v7439, NULL, l_v7440);
	if (l_v7440) {
		goto block15;
	}
	goto block1;

    block1:
	OP_CAST_UINT_TO_INT(l_i_35, l_v7441);
	l_v7442 = &RPyItem(l_entries_6, l_v7441);
	l_v7443 = RPyField(l_v7442, en_key);
	OP_ADR_NE(l_v7443, NULL, l_v7444);
	if (l_v7444) {
		goto block4;
	}
	goto block2;

    block2:
	OP_UINT_OR(l_i_35, 2147483648UL, l_v7445);
	l_v7476 = l_v7445;
	goto block3;

    block3:
	RPY_DEBUG_RETURN();
	return l_v7476;

    block4:
	OP_CAST_UINT_TO_INT(l_i_35, l_v7446);
	l_freeslot_7 = l_v7446;
	goto block5;

    block5:
	OP_CAST_INT_TO_UINT(l_hash_23, l_v7447);
	l_i_36 = l_i_35;
	l_perturb_2 = l_v7447;
	l_freeslot_6 = l_freeslot_7;
	goto block6;

    block6:
	while (1) {
		OP_UINT_LSHIFT(l_i_36, 2L, l_v7448);
		OP_UINT_ADD(l_v7448, l_i_36, l_v7449);
		OP_UINT_ADD(l_v7449, l_perturb_2, l_v7450);
		OP_UINT_ADD(l_v7450, 1UL, l_v7451);
		OP_CAST_INT_TO_UINT(l_mask_2, l_v7452);
		OP_UINT_AND(l_v7451, l_v7452, l_i_34);
		OP_CAST_UINT_TO_INT(l_i_34, l_v7453);
		l_v7454 = &RPyItem(l_entries_6, l_v7453);
		l_v7455 = RPyField(l_v7454, en_key);
		OP_ADR_NE(l_v7455, NULL, l_v7456);
		if (!l_v7456) break;
		goto block10;
	  block6_back: ;
	}
	goto block7;

    block7:
	OP_INT_EQ(l_freeslot_6, -1L, l_v7457);
	if (l_v7457) {
		goto block9;
	}
	l_v7477 = l_freeslot_6;
	goto block8;

    block8:
	OP_CAST_INT_TO_UINT(l_v7477, l_v7458);
	OP_UINT_OR(l_v7458, 2147483648UL, l_v7459);
	l_v7476 = l_v7459;
	goto block3;

    block9:
	OP_CAST_UINT_TO_INT(l_i_34, l_v7460);
	l_v7477 = l_v7460;
	goto block8;

    block10:
	OP_CAST_UINT_TO_INT(l_i_34, l_v7461);
	l_v7462 = &RPyItem(l_entries_6, l_v7461);
	l_v7463 = RPyField(l_v7462, en_key);
	OP_ADR_NE(l_v7463, NULL, l_v7464);
	if (l_v7464) {
		goto block14;
	}
	goto block11;

    block11:
	OP_INT_EQ(l_freeslot_6, -1L, l_v7465);
	if (l_v7465) {
		goto block13;
	}
	l_freeslot_8 = l_freeslot_6;
	goto block12;

    block12:
	OP_UINT_RSHIFT(l_perturb_2, 5L, l_v7466);
	l_i_36 = l_i_34;
	l_perturb_2 = l_v7466;
	l_freeslot_6 = l_freeslot_8;
	goto block6_back;

    block13:
	OP_CAST_UINT_TO_INT(l_i_34, l_v7467);
	l_freeslot_8 = l_v7467;
	goto block12;

    block14:
	OP_CAST_UINT_TO_INT(l_i_34, l_v7468);
	l_v7469 = &RPyItem(l_entries_6, l_v7468);
	l_v7470 = RPyField(l_v7469, en_key);
	OP_ADR_EQ(l_v7470, l_key_26, l_v7471);
	if (l_v7471) {
		l_v7476 = l_i_34;
		goto block3;
	}
	l_freeslot_8 = l_freeslot_6;
	goto block12;

    block15:
	OP_CAST_UINT_TO_INT(l_i_35, l_v7472);
	l_v7473 = &RPyItem(l_entries_6, l_v7472);
	l_v7474 = RPyField(l_v7473, en_key);
	OP_ADR_EQ(l_v7474, l_key_26, l_v7475);
	if (l_v7475) {
		l_v7476 = l_i_35;
		goto block3;
	}
	l_freeslot_7 = -1L;
	goto block5;
}
/*/*/
Unsigned pypy_g_ll_dict_lookup__v60___simple_call__function_ll(struct pypy_DICT0 *l_d_22, void* l_key_27, Signed l_hash_24) {
	struct pypy_array5 *l_entries_7; Signed l_freeslot_10;
	Signed l_freeslot_11; Signed l_freeslot_9; Unsigned l_i_37;
	Unsigned l_i_38; Unsigned l_i_39; Signed l_mask_3;
	Unsigned l_perturb_3; Signed l_v7478; Signed l_v7479; Signed l_v7480;
	Signed l_v7484; Signed l_v7489; Signed l_v7496; Signed l_v7503;
	Signed l_v7504; Signed l_v7510; Signed l_v7511; Signed l_v7515;
	Signed l_v7520; Unsigned l_v7488; Unsigned l_v7490; Unsigned l_v7491;
	Unsigned l_v7492; Unsigned l_v7493; Unsigned l_v7494;
	Unsigned l_v7495; Unsigned l_v7501; Unsigned l_v7502;
	Unsigned l_v7509; Unsigned l_v7519; bool_t l_v7483; bool_t l_v7487;
	bool_t l_v7499; bool_t l_v7500; bool_t l_v7507; bool_t l_v7508;
	bool_t l_v7514; bool_t l_v7518; struct pypy_ENTRY0 *l_v7481;
	struct pypy_ENTRY0 *l_v7485; struct pypy_ENTRY0 *l_v7497;
	struct pypy_ENTRY0 *l_v7505; struct pypy_ENTRY0 *l_v7512;
	struct pypy_ENTRY0 *l_v7516; void* l_v7482; void* l_v7486;
	void* l_v7498; void* l_v7506; void* l_v7513; void* l_v7517;
	goto block0;

    block0:
	l_entries_7 = RPyField(l_d_22, di_entries);
	l_v7478 = l_entries_7->length;
	OP_INT_SUB(l_v7478, 1L, l_mask_3);
	OP_INT_AND(l_hash_24, l_mask_3, l_v7479);
	OP_CAST_INT_TO_UINT(l_v7479, l_i_37);
	OP_CAST_UINT_TO_INT(l_i_37, l_v7480);
	l_v7481 = &RPyItem(l_entries_7, l_v7480);
	l_v7482 = RPyField(l_v7481, en_key);
	OP_ADR_NE(l_v7482, NULL, l_v7483);
	if (l_v7483) {
		goto block15;
	}
	goto block1;

    block1:
	OP_CAST_UINT_TO_INT(l_i_37, l_v7484);
	l_v7485 = &RPyItem(l_entries_7, l_v7484);
	l_v7486 = RPyField(l_v7485, en_key);
	OP_ADR_NE(l_v7486, NULL, l_v7487);
	if (l_v7487) {
		goto block4;
	}
	goto block2;

    block2:
	OP_UINT_OR(l_i_37, 2147483648UL, l_v7488);
	l_v7519 = l_v7488;
	goto block3;

    block3:
	RPY_DEBUG_RETURN();
	return l_v7519;

    block4:
	OP_CAST_UINT_TO_INT(l_i_37, l_v7489);
	l_freeslot_10 = l_v7489;
	goto block5;

    block5:
	OP_CAST_INT_TO_UINT(l_hash_24, l_v7490);
	l_freeslot_9 = l_freeslot_10;
	l_perturb_3 = l_v7490;
	l_i_39 = l_i_37;
	goto block6;

    block6:
	while (1) {
		OP_UINT_LSHIFT(l_i_39, 2L, l_v7491);
		OP_UINT_ADD(l_v7491, l_i_39, l_v7492);
		OP_UINT_ADD(l_v7492, l_perturb_3, l_v7493);
		OP_UINT_ADD(l_v7493, 1UL, l_v7494);
		OP_CAST_INT_TO_UINT(l_mask_3, l_v7495);
		OP_UINT_AND(l_v7494, l_v7495, l_i_38);
		OP_CAST_UINT_TO_INT(l_i_38, l_v7496);
		l_v7497 = &RPyItem(l_entries_7, l_v7496);
		l_v7498 = RPyField(l_v7497, en_key);
		OP_ADR_NE(l_v7498, NULL, l_v7499);
		if (!l_v7499) break;
		goto block10;
	  block6_back: ;
	}
	goto block7;

    block7:
	OP_INT_EQ(l_freeslot_9, -1L, l_v7500);
	if (l_v7500) {
		goto block9;
	}
	l_v7520 = l_freeslot_9;
	goto block8;

    block8:
	OP_CAST_INT_TO_UINT(l_v7520, l_v7501);
	OP_UINT_OR(l_v7501, 2147483648UL, l_v7502);
	l_v7519 = l_v7502;
	goto block3;

    block9:
	OP_CAST_UINT_TO_INT(l_i_38, l_v7503);
	l_v7520 = l_v7503;
	goto block8;

    block10:
	OP_CAST_UINT_TO_INT(l_i_38, l_v7504);
	l_v7505 = &RPyItem(l_entries_7, l_v7504);
	l_v7506 = RPyField(l_v7505, en_key);
	OP_ADR_NE(l_v7506, NULL, l_v7507);
	if (l_v7507) {
		goto block14;
	}
	goto block11;

    block11:
	OP_INT_EQ(l_freeslot_9, -1L, l_v7508);
	if (l_v7508) {
		goto block13;
	}
	l_freeslot_11 = l_freeslot_9;
	goto block12;

    block12:
	OP_UINT_RSHIFT(l_perturb_3, 5L, l_v7509);
	l_freeslot_9 = l_freeslot_11;
	l_perturb_3 = l_v7509;
	l_i_39 = l_i_38;
	goto block6_back;

    block13:
	OP_CAST_UINT_TO_INT(l_i_38, l_v7510);
	l_freeslot_11 = l_v7510;
	goto block12;

    block14:
	OP_CAST_UINT_TO_INT(l_i_38, l_v7511);
	l_v7512 = &RPyItem(l_entries_7, l_v7511);
	l_v7513 = RPyField(l_v7512, en_key);
	OP_ADR_EQ(l_v7513, l_key_27, l_v7514);
	if (l_v7514) {
		l_v7519 = l_i_38;
		goto block3;
	}
	l_freeslot_11 = l_freeslot_9;
	goto block12;

    block15:
	OP_CAST_UINT_TO_INT(l_i_37, l_v7515);
	l_v7516 = &RPyItem(l_entries_7, l_v7515);
	l_v7517 = RPyField(l_v7516, en_key);
	OP_ADR_EQ(l_v7517, l_key_27, l_v7518);
	if (l_v7518) {
		l_v7519 = l_i_37;
		goto block3;
	}
	l_freeslot_10 = -1L;
	goto block5;
}
/*/*/
void* pypy_g_ll_get__DICTPtr_Address_Address(struct pypy_DICT0 *l_v7521, void* l_key_16, void* l_default_1) {
	Signed l_v7522; Signed l_v7524; Signed l_v7525; Signed l_v7531;
	Unsigned l_v7523; Unsigned l_v7527; Unsigned l_v7528;
	Unsigned l_v7534; bool_t l_v7526; bool_t l_v7529;
	struct pypy_ENTRY0 *l_v7532; struct pypy_array5 *l_v7530;
	void* l_v7533; void* l_v7535;
	goto block0;

    block0:
	OP_CAST_ADR_TO_INT(l_key_16, /* nothing */, l_v7524);
	OP_INT_RSHIFT(l_v7524, 4L, l_v7525);
	OP_INT_XOR(l_v7524, l_v7525, l_v7522);
	OP_INT_IS_TRUE(0 /* we are not jitted here */, l_v7526);
	if (l_v7526) {
		goto block5;
	}
	goto block1;

    block1:
	l_v7527 = pypy_g_ll_dict_lookup__v51___simple_call__function_ll(l_v7521, l_key_16, l_v7522);
	l_v7523 = l_v7527;
	goto block2;

    block2:
	OP_UINT_AND(l_v7523, 2147483648UL, l_v7528);
	OP_UINT_IS_TRUE(l_v7528, l_v7529);
	if (l_v7529) {
		l_v7535 = l_default_1;
		goto block4;
	}
	goto block3;

    block3:
	l_v7530 = RPyField(l_v7521, di_entries);
	OP_CAST_UINT_TO_INT(l_v7523, l_v7531);
	l_v7532 = &RPyItem(l_v7530, l_v7531);
	l_v7533 = RPyField(l_v7532, en_value);
	l_v7535 = l_v7533;
	goto block4;

    block4:
	RPY_DEBUG_RETURN();
	return l_v7535;

    block5:
	l_v7534 = pypy_g_ll_dict_lookup__v60___simple_call__function_ll(l_v7521, l_key_16, l_v7522);
	l_v7523 = l_v7534;
	goto block2;
}
/*/*/
Unsigned pypy_g_ll_dict_lookup__v82___simple_call__function_ll(struct pypy_dicttable0 *l_d_23, struct pypy_rpy_string0 *l_key_28, Signed l_hash_25) {
	struct pypy_rpy_string0 *l_chars1_0;
	struct pypy_rpy_string0 *l_checkingkey_0;
	struct pypy_array7 *l_entries_8; Signed l_freeslot_12;
	Signed l_freeslot_13; Signed l_freeslot_14; Unsigned l_i_40;
	Unsigned l_i_41; Unsigned l_i_42; Signed l_j_8; Signed l_len1_3;
	Signed l_len1_4; Signed l_mask_4; Unsigned l_perturb_4;
	Signed l_v7536; Signed l_v7537; Signed l_v7538; Signed l_v7540;
	Signed l_v7544; Signed l_v7551; Signed l_v7557; Signed l_v7561;
	Signed l_v7562; Signed l_v7564; Signed l_v7566; Signed l_v7571;
	Signed l_v7577; Signed l_v7578; Signed l_v7580; Signed l_v7582;
	Signed l_v7587; Signed l_v7593; Signed l_v7595; Unsigned l_v7543;
	Unsigned l_v7545; Unsigned l_v7546; Unsigned l_v7547;
	Unsigned l_v7548; Unsigned l_v7549; Unsigned l_v7550;
	Unsigned l_v7555; Unsigned l_v7556; Unsigned l_v7560;
	Unsigned l_v7594; bool_t l_v7539; bool_t l_v7542; bool_t l_v7553;
	bool_t l_v7554; bool_t l_v7558; bool_t l_v7559; bool_t l_v7563;
	bool_t l_v7567; bool_t l_v7568; bool_t l_v7569; bool_t l_v7570;
	bool_t l_v7572; bool_t l_v7573; bool_t l_v7576; bool_t l_v7579;
	bool_t l_v7583; bool_t l_v7584; bool_t l_v7585; bool_t l_v7586;
	bool_t l_v7588; bool_t l_v7589; bool_t l_v7592; char l_v7574;
	char l_v7575; char l_v7590; char l_v7591;
	struct pypy_rpy_string0 *l_v7541; struct pypy_rpy_string0 *l_v7552;
	struct pypy_rpy_string0 *l_v7565; struct pypy_rpy_string0 *l_v7581;
	goto block0;

    block0:
	l_entries_8 = RPyField(l_d_23, d_entries);
	l_v7537 = l_entries_8->length;
	OP_INT_SUB(l_v7537, 1L, l_mask_4);
	OP_INT_AND(l_hash_25, l_mask_4, l_v7538);
	OP_CAST_INT_TO_UINT(l_v7538, l_i_41);
	l_v7539 = pypy_g_ll_valid_from_key__arrayPtr_Unsigned(l_entries_8, l_i_41);
	if (l_v7539) {
		goto block23;
	}
	goto block1;

    block1:
	OP_CAST_UINT_TO_INT(l_i_41, l_v7540);
	l_v7541 = RPyItem(l_entries_8, l_v7540).d_key;
	l_v7542 = (l_v7541 != NULL);
	if (l_v7542) {
		goto block4;
	}
	goto block2;

    block2:
	OP_UINT_OR(l_i_41, 2147483648UL, l_v7543);
	l_v7594 = l_v7543;
	goto block3;

    block3:
	RPY_DEBUG_RETURN();
	return l_v7594;

    block4:
	OP_CAST_UINT_TO_INT(l_i_41, l_v7544);
	l_freeslot_13 = l_v7544;
	goto block5;

    block5:
	OP_CAST_INT_TO_UINT(l_hash_25, l_v7545);
	l_freeslot_12 = l_freeslot_13;
	l_perturb_4 = l_v7545;
	l_i_42 = l_i_41;
	goto block6;

    block6:
	while (1) {
		OP_UINT_LSHIFT(l_i_42, 2L, l_v7546);
		OP_UINT_ADD(l_v7546, l_i_42, l_v7547);
		OP_UINT_ADD(l_v7547, l_perturb_4, l_v7548);
		OP_UINT_ADD(l_v7548, 1UL, l_v7549);
		OP_CAST_INT_TO_UINT(l_mask_4, l_v7550);
		OP_UINT_AND(l_v7549, l_v7550, l_i_40);
		OP_CAST_UINT_TO_INT(l_i_40, l_v7551);
		l_v7552 = RPyItem(l_entries_8, l_v7551).d_key;
		l_v7553 = (l_v7552 != NULL);
		if (!l_v7553) break;
		goto block10;
	  block6_back: ;
	}
	goto block7;

    block7:
	OP_INT_EQ(l_freeslot_12, -1L, l_v7554);
	if (l_v7554) {
		goto block9;
	}
	l_v7595 = l_freeslot_12;
	goto block8;

    block8:
	OP_CAST_INT_TO_UINT(l_v7595, l_v7555);
	OP_UINT_OR(l_v7555, 2147483648UL, l_v7556);
	l_v7594 = l_v7556;
	goto block3;

    block9:
	OP_CAST_UINT_TO_INT(l_i_40, l_v7557);
	l_v7595 = l_v7557;
	goto block8;

    block10:
	l_v7558 = pypy_g_ll_valid_from_key__arrayPtr_Unsigned(l_entries_8, l_i_40);
	if (l_v7558) {
		goto block14;
	}
	goto block11;

    block11:
	OP_INT_EQ(l_freeslot_12, -1L, l_v7559);
	if (l_v7559) {
		goto block13;
	}
	l_freeslot_14 = l_freeslot_12;
	goto block12;

    block12:
	OP_UINT_RSHIFT(l_perturb_4, 5L, l_v7560);
	l_freeslot_12 = l_freeslot_14;
	l_perturb_4 = l_v7560;
	l_i_42 = l_i_40;
	goto block6_back;

    block13:
	OP_CAST_UINT_TO_INT(l_i_40, l_v7561);
	l_freeslot_14 = l_v7561;
	goto block12;

    block14:
	OP_CAST_UINT_TO_INT(l_i_40, l_v7562);
	l_chars1_0 = RPyItem(l_entries_8, l_v7562).d_key;
	l_v7563 = (l_chars1_0 == l_key_28);
	if (l_v7563) {
		l_v7594 = l_i_40;
		goto block3;
	}
	goto block15;

    block15:
	OP_CAST_UINT_TO_INT(l_i_40, l_v7564);
	l_v7565 = RPyItem(l_entries_8, l_v7564).d_key;
	l_v7566 = RPyField(l_v7565, rs_hash);
	OP_INT_EQ(l_v7566, l_hash_25, l_v7567);
	if (l_v7567) {
		goto block16;
	}
	l_freeslot_14 = l_freeslot_12;
	goto block12;

    block16:
	l_v7568 = (l_chars1_0 == l_key_28);
	if (l_v7568) {
		l_v7594 = l_i_40;
		goto block3;
	}
	goto block17;

    block17:
	l_v7569 = (l_chars1_0 != NULL);
	if (l_v7569) {
		goto block18;
	}
	l_freeslot_14 = l_freeslot_12;
	goto block12;

    block18:
	l_v7570 = (l_key_28 != NULL);
	if (l_v7570) {
		goto block19;
	}
	l_freeslot_14 = l_freeslot_12;
	goto block12;

    block19:
	l_len1_4 = RPyField(l_chars1_0, rs_chars).length;
	l_v7571 = RPyField(l_key_28, rs_chars).length;
	OP_INT_NE(l_len1_4, l_v7571, l_v7572);
	if (l_v7572) {
		l_freeslot_14 = l_freeslot_12;
		goto block12;
	}
	l_j_8 = 0L;
	goto block20;

    block20:
	while (1) {
		OP_INT_LT(l_j_8, l_len1_4, l_v7573);
		if (!l_v7573) break;
		goto block21;
	  block20_back: ;
	}
	l_v7594 = l_i_40;
	goto block3;

    block21:
	l_v7574 = RPyField(l_chars1_0, rs_chars).items[l_j_8];
	l_v7575 = RPyField(l_key_28, rs_chars).items[l_j_8];
	OP_CHAR_NE(l_v7574, l_v7575, l_v7576);
	if (l_v7576) {
		l_freeslot_14 = l_freeslot_12;
		goto block12;
	}
	goto block22;

    block22:
	OP_INT_ADD(l_j_8, 1L, l_v7577);
	l_j_8 = l_v7577;
	goto block20_back;

    block23:
	OP_CAST_UINT_TO_INT(l_i_41, l_v7578);
	l_checkingkey_0 = RPyItem(l_entries_8, l_v7578).d_key;
	l_v7579 = (l_checkingkey_0 == l_key_28);
	if (l_v7579) {
		l_v7594 = l_i_41;
		goto block3;
	}
	goto block24;

    block24:
	OP_CAST_UINT_TO_INT(l_i_41, l_v7580);
	l_v7581 = RPyItem(l_entries_8, l_v7580).d_key;
	l_v7582 = RPyField(l_v7581, rs_hash);
	OP_INT_EQ(l_v7582, l_hash_25, l_v7583);
	if (l_v7583) {
		goto block25;
	}
	l_freeslot_13 = -1L;
	goto block5;

    block25:
	l_v7584 = (l_checkingkey_0 == l_key_28);
	if (l_v7584) {
		l_v7594 = l_i_41;
		goto block3;
	}
	goto block26;

    block26:
	l_v7585 = (l_checkingkey_0 != NULL);
	if (l_v7585) {
		goto block27;
	}
	l_freeslot_13 = -1L;
	goto block5;

    block27:
	l_v7586 = (l_key_28 != NULL);
	if (l_v7586) {
		goto block28;
	}
	l_freeslot_13 = -1L;
	goto block5;

    block28:
	l_len1_3 = RPyField(l_checkingkey_0, rs_chars).length;
	l_v7587 = RPyField(l_key_28, rs_chars).length;
	OP_INT_NE(l_len1_3, l_v7587, l_v7588);
	if (l_v7588) {
		l_freeslot_13 = -1L;
		goto block5;
	}
	l_v7536 = 0L;
	goto block29;

    block29:
	while (1) {
		OP_INT_LT(l_v7536, l_len1_3, l_v7589);
		if (!l_v7589) break;
		goto block30;
	  block29_back: ;
	}
	l_v7594 = l_i_41;
	goto block3;

    block30:
	l_v7590 = RPyField(l_checkingkey_0, rs_chars).items[l_v7536];
	l_v7591 = RPyField(l_key_28, rs_chars).items[l_v7536];
	OP_CHAR_NE(l_v7590, l_v7591, l_v7592);
	if (l_v7592) {
		l_freeslot_13 = -1L;
		goto block5;
	}
	goto block31;

    block31:
	OP_INT_ADD(l_v7536, 1L, l_v7593);
	l_v7536 = l_v7593;
	goto block29_back;
}
/*/*/
Unsigned pypy_g_ll_dict_lookup__v90___simple_call__function_ll(struct pypy_dicttable0 *l_d_24, struct pypy_rpy_string0 *l_key_29, Signed l_hash_26) {
	struct pypy_rpy_string0 *l_chars1_1; struct pypy_array7 *l_entries_9;
	Signed l_freeslot_15; Signed l_freeslot_16; Signed l_freeslot_17;
	Unsigned l_i_43; Unsigned l_i_44; Signed l_j_10; Signed l_j_9;
	Signed l_len1_5; Signed l_len1_6; Signed l_mask_5;
	Unsigned l_perturb_5; struct pypy_rpy_string0 *l_s1_7;
	Signed l_v7597; Signed l_v7598; Signed l_v7600; Signed l_v7604;
	Signed l_v7611; Signed l_v7617; Signed l_v7621; Signed l_v7622;
	Signed l_v7624; Signed l_v7626; Signed l_v7631; Signed l_v7637;
	Signed l_v7638; Signed l_v7640; Signed l_v7642; Signed l_v7647;
	Signed l_v7653; Signed l_v7655; Unsigned l_v7596; Unsigned l_v7603;
	Unsigned l_v7605; Unsigned l_v7606; Unsigned l_v7607;
	Unsigned l_v7608; Unsigned l_v7609; Unsigned l_v7610;
	Unsigned l_v7615; Unsigned l_v7616; Unsigned l_v7620;
	Unsigned l_v7654; bool_t l_v7599; bool_t l_v7602; bool_t l_v7613;
	bool_t l_v7614; bool_t l_v7618; bool_t l_v7619; bool_t l_v7623;
	bool_t l_v7627; bool_t l_v7628; bool_t l_v7629; bool_t l_v7630;
	bool_t l_v7632; bool_t l_v7633; bool_t l_v7636; bool_t l_v7639;
	bool_t l_v7643; bool_t l_v7644; bool_t l_v7645; bool_t l_v7646;
	bool_t l_v7648; bool_t l_v7649; bool_t l_v7652; char l_v7634;
	char l_v7635; char l_v7650; char l_v7651;
	struct pypy_rpy_string0 *l_v7601; struct pypy_rpy_string0 *l_v7612;
	struct pypy_rpy_string0 *l_v7625; struct pypy_rpy_string0 *l_v7641;
	goto block0;

    block0:
	l_entries_9 = RPyField(l_d_24, d_entries);
	l_v7597 = l_entries_9->length;
	OP_INT_SUB(l_v7597, 1L, l_mask_5);
	OP_INT_AND(l_hash_26, l_mask_5, l_v7598);
	OP_CAST_INT_TO_UINT(l_v7598, l_v7596);
	l_v7599 = pypy_g_ll_valid_from_key__arrayPtr_Unsigned(l_entries_9, l_v7596);
	if (l_v7599) {
		goto block23;
	}
	goto block1;

    block1:
	OP_CAST_UINT_TO_INT(l_v7596, l_v7600);
	l_v7601 = RPyItem(l_entries_9, l_v7600).d_key;
	l_v7602 = (l_v7601 != NULL);
	if (l_v7602) {
		goto block4;
	}
	goto block2;

    block2:
	OP_UINT_OR(l_v7596, 2147483648UL, l_v7603);
	l_v7654 = l_v7603;
	goto block3;

    block3:
	RPY_DEBUG_RETURN();
	return l_v7654;

    block4:
	OP_CAST_UINT_TO_INT(l_v7596, l_v7604);
	l_freeslot_16 = l_v7604;
	goto block5;

    block5:
	OP_CAST_INT_TO_UINT(l_hash_26, l_v7605);
	l_i_44 = l_v7596;
	l_perturb_5 = l_v7605;
	l_freeslot_15 = l_freeslot_16;
	goto block6;

    block6:
	while (1) {
		OP_UINT_LSHIFT(l_i_44, 2L, l_v7606);
		OP_UINT_ADD(l_v7606, l_i_44, l_v7607);
		OP_UINT_ADD(l_v7607, l_perturb_5, l_v7608);
		OP_UINT_ADD(l_v7608, 1UL, l_v7609);
		OP_CAST_INT_TO_UINT(l_mask_5, l_v7610);
		OP_UINT_AND(l_v7609, l_v7610, l_i_43);
		OP_CAST_UINT_TO_INT(l_i_43, l_v7611);
		l_v7612 = RPyItem(l_entries_9, l_v7611).d_key;
		l_v7613 = (l_v7612 != NULL);
		if (!l_v7613) break;
		goto block10;
	  block6_back: ;
	}
	goto block7;

    block7:
	OP_INT_EQ(l_freeslot_15, -1L, l_v7614);
	if (l_v7614) {
		goto block9;
	}
	l_v7655 = l_freeslot_15;
	goto block8;

    block8:
	OP_CAST_INT_TO_UINT(l_v7655, l_v7615);
	OP_UINT_OR(l_v7615, 2147483648UL, l_v7616);
	l_v7654 = l_v7616;
	goto block3;

    block9:
	OP_CAST_UINT_TO_INT(l_i_43, l_v7617);
	l_v7655 = l_v7617;
	goto block8;

    block10:
	l_v7618 = pypy_g_ll_valid_from_key__arrayPtr_Unsigned(l_entries_9, l_i_43);
	if (l_v7618) {
		goto block14;
	}
	goto block11;

    block11:
	OP_INT_EQ(l_freeslot_15, -1L, l_v7619);
	if (l_v7619) {
		goto block13;
	}
	l_freeslot_17 = l_freeslot_15;
	goto block12;

    block12:
	OP_UINT_RSHIFT(l_perturb_5, 5L, l_v7620);
	l_i_44 = l_i_43;
	l_perturb_5 = l_v7620;
	l_freeslot_15 = l_freeslot_17;
	goto block6_back;

    block13:
	OP_CAST_UINT_TO_INT(l_i_43, l_v7621);
	l_freeslot_17 = l_v7621;
	goto block12;

    block14:
	OP_CAST_UINT_TO_INT(l_i_43, l_v7622);
	l_s1_7 = RPyItem(l_entries_9, l_v7622).d_key;
	l_v7623 = (l_s1_7 == l_key_29);
	if (l_v7623) {
		l_v7654 = l_i_43;
		goto block3;
	}
	goto block15;

    block15:
	OP_CAST_UINT_TO_INT(l_i_43, l_v7624);
	l_v7625 = RPyItem(l_entries_9, l_v7624).d_key;
	l_v7626 = RPyField(l_v7625, rs_hash);
	OP_INT_EQ(l_v7626, l_hash_26, l_v7627);
	if (l_v7627) {
		goto block16;
	}
	l_freeslot_17 = l_freeslot_15;
	goto block12;

    block16:
	l_v7628 = (l_s1_7 == l_key_29);
	if (l_v7628) {
		l_v7654 = l_i_43;
		goto block3;
	}
	goto block17;

    block17:
	l_v7629 = (l_s1_7 != NULL);
	if (l_v7629) {
		goto block18;
	}
	l_freeslot_17 = l_freeslot_15;
	goto block12;

    block18:
	l_v7630 = (l_key_29 != NULL);
	if (l_v7630) {
		goto block19;
	}
	l_freeslot_17 = l_freeslot_15;
	goto block12;

    block19:
	l_len1_5 = RPyField(l_s1_7, rs_chars).length;
	l_v7631 = RPyField(l_key_29, rs_chars).length;
	OP_INT_NE(l_len1_5, l_v7631, l_v7632);
	if (l_v7632) {
		l_freeslot_17 = l_freeslot_15;
		goto block12;
	}
	l_j_9 = 0L;
	goto block20;

    block20:
	while (1) {
		OP_INT_LT(l_j_9, l_len1_5, l_v7633);
		if (!l_v7633) break;
		goto block21;
	  block20_back: ;
	}
	l_v7654 = l_i_43;
	goto block3;

    block21:
	l_v7634 = RPyField(l_s1_7, rs_chars).items[l_j_9];
	l_v7635 = RPyField(l_key_29, rs_chars).items[l_j_9];
	OP_CHAR_NE(l_v7634, l_v7635, l_v7636);
	if (l_v7636) {
		l_freeslot_17 = l_freeslot_15;
		goto block12;
	}
	goto block22;

    block22:
	OP_INT_ADD(l_j_9, 1L, l_v7637);
	l_j_9 = l_v7637;
	goto block20_back;

    block23:
	OP_CAST_UINT_TO_INT(l_v7596, l_v7638);
	l_chars1_1 = RPyItem(l_entries_9, l_v7638).d_key;
	l_v7639 = (l_chars1_1 == l_key_29);
	if (l_v7639) {
		l_v7654 = l_v7596;
		goto block3;
	}
	goto block24;

    block24:
	OP_CAST_UINT_TO_INT(l_v7596, l_v7640);
	l_v7641 = RPyItem(l_entries_9, l_v7640).d_key;
	l_v7642 = RPyField(l_v7641, rs_hash);
	OP_INT_EQ(l_v7642, l_hash_26, l_v7643);
	if (l_v7643) {
		goto block25;
	}
	l_freeslot_16 = -1L;
	goto block5;

    block25:
	l_v7644 = (l_chars1_1 == l_key_29);
	if (l_v7644) {
		l_v7654 = l_v7596;
		goto block3;
	}
	goto block26;

    block26:
	l_v7645 = (l_chars1_1 != NULL);
	if (l_v7645) {
		goto block27;
	}
	l_freeslot_16 = -1L;
	goto block5;

    block27:
	l_v7646 = (l_key_29 != NULL);
	if (l_v7646) {
		goto block28;
	}
	l_freeslot_16 = -1L;
	goto block5;

    block28:
	l_len1_6 = RPyField(l_chars1_1, rs_chars).length;
	l_v7647 = RPyField(l_key_29, rs_chars).length;
	OP_INT_NE(l_len1_6, l_v7647, l_v7648);
	if (l_v7648) {
		l_freeslot_16 = -1L;
		goto block5;
	}
	l_j_10 = 0L;
	goto block29;

    block29:
	while (1) {
		OP_INT_LT(l_j_10, l_len1_6, l_v7649);
		if (!l_v7649) break;
		goto block30;
	  block29_back: ;
	}
	l_v7654 = l_v7596;
	goto block3;

    block30:
	l_v7650 = RPyField(l_chars1_1, rs_chars).items[l_j_10];
	l_v7651 = RPyField(l_key_29, rs_chars).items[l_j_10];
	OP_CHAR_NE(l_v7650, l_v7651, l_v7652);
	if (l_v7652) {
		l_freeslot_16 = -1L;
		goto block5;
	}
	goto block31;

    block31:
	OP_INT_ADD(l_j_10, 1L, l_v7653);
	l_j_10 = l_v7653;
	goto block29_back;
}
/*/*/
Unsigned pypy_g_ll_dict_lookup__v95___simple_call__function_ll(struct pypy_dicttable2 *l_d_25, Signed l_key_30, Signed l_hash_27) {
	struct pypy_array10 *l_entries_10; Signed l_freeslot_18;
	Signed l_freeslot_19; Signed l_freeslot_20; Unsigned l_i_45;
	Unsigned l_i_46; Signed l_mask_6; Unsigned l_perturb_6;
	Signed l_v7657; Signed l_v7658; Signed l_v7659; Signed l_v7661;
	Signed l_v7664; Signed l_v7671; Signed l_v7676; Signed l_v7677;
	Signed l_v7681; Signed l_v7682; Signed l_v7683; Signed l_v7685;
	Signed l_v7686; Signed l_v7688; Signed l_v7689; Signed l_v7691;
	Signed l_v7692; Signed l_v7695; Unsigned l_v7656; Unsigned l_v7663;
	Unsigned l_v7665; Unsigned l_v7666; Unsigned l_v7667;
	Unsigned l_v7668; Unsigned l_v7669; Unsigned l_v7670;
	Unsigned l_v7674; Unsigned l_v7675; Unsigned l_v7680;
	Unsigned l_v7694; bool_t l_v7660; bool_t l_v7662; bool_t l_v7672;
	bool_t l_v7673; bool_t l_v7678; bool_t l_v7679; bool_t l_v7684;
	bool_t l_v7687; bool_t l_v7690; bool_t l_v7693;
	goto block0;

    block0:
	l_entries_10 = RPyField(l_d_25, d_entries);
	l_v7657 = l_entries_10->length;
	OP_INT_SUB(l_v7657, 1L, l_mask_6);
	OP_INT_AND(l_hash_27, l_mask_6, l_v7658);
	OP_CAST_INT_TO_UINT(l_v7658, l_i_45);
	OP_CAST_UINT_TO_INT(l_i_45, l_v7659);
	l_v7660 = RPyItem(l_entries_10, l_v7659).d_f_everused;
	if (l_v7660) {
		goto block16;
	}
	goto block1;

    block1:
	OP_CAST_UINT_TO_INT(l_i_45, l_v7661);
	l_v7662 = RPyItem(l_entries_10, l_v7661).d_f_everused;
	if (l_v7662) {
		goto block4;
	}
	goto block2;

    block2:
	OP_UINT_OR(l_i_45, 2147483648UL, l_v7663);
	l_v7694 = l_v7663;
	goto block3;

    block3:
	RPY_DEBUG_RETURN();
	return l_v7694;

    block4:
	OP_CAST_UINT_TO_INT(l_i_45, l_v7664);
	l_freeslot_19 = l_v7664;
	goto block5;

    block5:
	OP_CAST_INT_TO_UINT(l_hash_27, l_v7665);
	l_perturb_6 = l_v7665;
	l_freeslot_18 = l_freeslot_19;
	l_i_46 = l_i_45;
	goto block6;

    block6:
	while (1) {
		OP_UINT_LSHIFT(l_i_46, 2L, l_v7666);
		OP_UINT_ADD(l_v7666, l_i_46, l_v7667);
		OP_UINT_ADD(l_v7667, l_perturb_6, l_v7668);
		OP_UINT_ADD(l_v7668, 1UL, l_v7669);
		OP_CAST_INT_TO_UINT(l_mask_6, l_v7670);
		OP_UINT_AND(l_v7669, l_v7670, l_v7656);
		OP_CAST_UINT_TO_INT(l_v7656, l_v7671);
		l_v7672 = RPyItem(l_entries_10, l_v7671).d_f_everused;
		if (!l_v7672) break;
		goto block10;
	  block6_back: ;
	}
	goto block7;

    block7:
	OP_INT_EQ(l_freeslot_18, -1L, l_v7673);
	if (l_v7673) {
		goto block9;
	}
	l_v7695 = l_freeslot_18;
	goto block8;

    block8:
	OP_CAST_INT_TO_UINT(l_v7695, l_v7674);
	OP_UINT_OR(l_v7674, 2147483648UL, l_v7675);
	l_v7694 = l_v7675;
	goto block3;

    block9:
	OP_CAST_UINT_TO_INT(l_v7656, l_v7676);
	l_v7695 = l_v7676;
	goto block8;

    block10:
	OP_CAST_UINT_TO_INT(l_v7656, l_v7677);
	l_v7678 = RPyItem(l_entries_10, l_v7677).d_f_everused;
	if (l_v7678) {
		goto block14;
	}
	goto block11;

    block11:
	OP_INT_EQ(l_freeslot_18, -1L, l_v7679);
	if (l_v7679) {
		goto block13;
	}
	l_freeslot_20 = l_freeslot_18;
	goto block12;

    block12:
	OP_UINT_RSHIFT(l_perturb_6, 5L, l_v7680);
	l_perturb_6 = l_v7680;
	l_freeslot_18 = l_freeslot_20;
	l_i_46 = l_v7656;
	goto block6_back;

    block13:
	OP_CAST_UINT_TO_INT(l_v7656, l_v7681);
	l_freeslot_20 = l_v7681;
	goto block12;

    block14:
	OP_CAST_UINT_TO_INT(l_v7656, l_v7682);
	l_v7683 = RPyItem(l_entries_10, l_v7682).d_key;
	OP_INT_NE(l_v7683, -1L, l_v7684);
	if (l_v7684) {
		goto block15;
	}
	goto block11;

    block15:
	OP_CAST_UINT_TO_INT(l_v7656, l_v7685);
	l_v7686 = RPyItem(l_entries_10, l_v7685).d_key;
	OP_INT_EQ(l_v7686, l_key_30, l_v7687);
	if (l_v7687) {
		l_v7694 = l_v7656;
		goto block3;
	}
	l_freeslot_20 = l_freeslot_18;
	goto block12;

    block16:
	OP_CAST_UINT_TO_INT(l_i_45, l_v7688);
	l_v7689 = RPyItem(l_entries_10, l_v7688).d_key;
	OP_INT_NE(l_v7689, -1L, l_v7690);
	if (l_v7690) {
		goto block17;
	}
	goto block1;

    block17:
	OP_CAST_UINT_TO_INT(l_i_45, l_v7691);
	l_v7692 = RPyItem(l_entries_10, l_v7691).d_key;
	OP_INT_EQ(l_v7692, l_key_30, l_v7693);
	if (l_v7693) {
		l_v7694 = l_i_45;
		goto block3;
	}
	l_freeslot_19 = -1L;
	goto block5;
}
/*/*/
Unsigned pypy_g_ll_dict_lookup__v103___simple_call__function_l(struct pypy_dicttable2 *l_d_26, Signed l_key_31, Signed l_hash_28) {
	struct pypy_array10 *l_entries_11; Signed l_freeslot_21;
	Signed l_freeslot_22; Signed l_freeslot_23; Unsigned l_i_47;
	Unsigned l_i_48; Unsigned l_i_49; Signed l_mask_7;
	Unsigned l_perturb_7; Signed l_v7696; Signed l_v7697; Signed l_v7698;
	Signed l_v7700; Signed l_v7703; Signed l_v7710; Signed l_v7715;
	Signed l_v7716; Signed l_v7720; Signed l_v7721; Signed l_v7722;
	Signed l_v7724; Signed l_v7725; Signed l_v7727; Signed l_v7728;
	Signed l_v7730; Signed l_v7731; Signed l_v7734; Unsigned l_v7702;
	Unsigned l_v7704; Unsigned l_v7705; Unsigned l_v7706;
	Unsigned l_v7707; Unsigned l_v7708; Unsigned l_v7709;
	Unsigned l_v7713; Unsigned l_v7714; Unsigned l_v7719;
	Unsigned l_v7733; bool_t l_v7699; bool_t l_v7701; bool_t l_v7711;
	bool_t l_v7712; bool_t l_v7717; bool_t l_v7718; bool_t l_v7723;
	bool_t l_v7726; bool_t l_v7729; bool_t l_v7732;
	goto block0;

    block0:
	l_entries_11 = RPyField(l_d_26, d_entries);
	l_v7696 = l_entries_11->length;
	OP_INT_SUB(l_v7696, 1L, l_mask_7);
	OP_INT_AND(l_hash_28, l_mask_7, l_v7697);
	OP_CAST_INT_TO_UINT(l_v7697, l_i_47);
	OP_CAST_UINT_TO_INT(l_i_47, l_v7698);
	l_v7699 = RPyItem(l_entries_11, l_v7698).d_f_everused;
	if (l_v7699) {
		goto block16;
	}
	goto block1;

    block1:
	OP_CAST_UINT_TO_INT(l_i_47, l_v7700);
	l_v7701 = RPyItem(l_entries_11, l_v7700).d_f_everused;
	if (l_v7701) {
		goto block4;
	}
	goto block2;

    block2:
	OP_UINT_OR(l_i_47, 2147483648UL, l_v7702);
	l_v7733 = l_v7702;
	goto block3;

    block3:
	RPY_DEBUG_RETURN();
	return l_v7733;

    block4:
	OP_CAST_UINT_TO_INT(l_i_47, l_v7703);
	l_freeslot_22 = l_v7703;
	goto block5;

    block5:
	OP_CAST_INT_TO_UINT(l_hash_28, l_v7704);
	l_perturb_7 = l_v7704;
	l_i_49 = l_i_47;
	l_freeslot_21 = l_freeslot_22;
	goto block6;

    block6:
	while (1) {
		OP_UINT_LSHIFT(l_i_49, 2L, l_v7705);
		OP_UINT_ADD(l_v7705, l_i_49, l_v7706);
		OP_UINT_ADD(l_v7706, l_perturb_7, l_v7707);
		OP_UINT_ADD(l_v7707, 1UL, l_v7708);
		OP_CAST_INT_TO_UINT(l_mask_7, l_v7709);
		OP_UINT_AND(l_v7708, l_v7709, l_i_48);
		OP_CAST_UINT_TO_INT(l_i_48, l_v7710);
		l_v7711 = RPyItem(l_entries_11, l_v7710).d_f_everused;
		if (!l_v7711) break;
		goto block10;
	  block6_back: ;
	}
	goto block7;

    block7:
	OP_INT_EQ(l_freeslot_21, -1L, l_v7712);
	if (l_v7712) {
		goto block9;
	}
	l_v7734 = l_freeslot_21;
	goto block8;

    block8:
	OP_CAST_INT_TO_UINT(l_v7734, l_v7713);
	OP_UINT_OR(l_v7713, 2147483648UL, l_v7714);
	l_v7733 = l_v7714;
	goto block3;

    block9:
	OP_CAST_UINT_TO_INT(l_i_48, l_v7715);
	l_v7734 = l_v7715;
	goto block8;

    block10:
	OP_CAST_UINT_TO_INT(l_i_48, l_v7716);
	l_v7717 = RPyItem(l_entries_11, l_v7716).d_f_everused;
	if (l_v7717) {
		goto block14;
	}
	goto block11;

    block11:
	OP_INT_EQ(l_freeslot_21, -1L, l_v7718);
	if (l_v7718) {
		goto block13;
	}
	l_freeslot_23 = l_freeslot_21;
	goto block12;

    block12:
	OP_UINT_RSHIFT(l_perturb_7, 5L, l_v7719);
	l_perturb_7 = l_v7719;
	l_i_49 = l_i_48;
	l_freeslot_21 = l_freeslot_23;
	goto block6_back;

    block13:
	OP_CAST_UINT_TO_INT(l_i_48, l_v7720);
	l_freeslot_23 = l_v7720;
	goto block12;

    block14:
	OP_CAST_UINT_TO_INT(l_i_48, l_v7721);
	l_v7722 = RPyItem(l_entries_11, l_v7721).d_key;
	OP_INT_NE(l_v7722, -1L, l_v7723);
	if (l_v7723) {
		goto block15;
	}
	goto block11;

    block15:
	OP_CAST_UINT_TO_INT(l_i_48, l_v7724);
	l_v7725 = RPyItem(l_entries_11, l_v7724).d_key;
	OP_INT_EQ(l_v7725, l_key_31, l_v7726);
	if (l_v7726) {
		l_v7733 = l_i_48;
		goto block3;
	}
	l_freeslot_23 = l_freeslot_21;
	goto block12;

    block16:
	OP_CAST_UINT_TO_INT(l_i_47, l_v7727);
	l_v7728 = RPyItem(l_entries_11, l_v7727).d_key;
	OP_INT_NE(l_v7728, -1L, l_v7729);
	if (l_v7729) {
		goto block17;
	}
	goto block1;

    block17:
	OP_CAST_UINT_TO_INT(l_i_47, l_v7730);
	l_v7731 = RPyItem(l_entries_11, l_v7730).d_key;
	OP_INT_EQ(l_v7731, l_key_31, l_v7732);
	if (l_v7732) {
		l_v7733 = l_i_47;
		goto block3;
	}
	l_freeslot_22 = -1L;
	goto block5;
}
/*/*/
void pypy_g__ll_dict_setitem_lookup_done__v66___simple_call_(struct pypy_DICT0 *l_d_34, void* l_key_32, void* l_value_6, Signed l_hash_29, Unsigned l_i_2) {
	struct pypy_ENTRY0 *l_entry_0; struct pypy_ENTRY0 *l_entry_1;
	struct pypy_ENTRY0 *l_entry_2; Signed l_v7739; Signed l_v7740;
	Signed l_v7745; Signed l_v7746; Signed l_v7751; Signed l_v7752;
	Signed l_v7759; Signed l_v7761; Signed l_v7762; Signed l_v7769;
	Unsigned l_v7736; Unsigned l_v7737; Unsigned l_v7757; bool_t l_v7735;
	bool_t l_v7743; bool_t l_v7747; bool_t l_v7756; bool_t l_v7763;
	bool_t l_v7768; struct pypy_ENTRY0 *l_v7741;
	struct pypy_ENTRY0 *l_v7760; struct pypy_array5 *l_v7738;
	struct pypy_array5 *l_v7758; struct pypy_object_vtable0 *l_v7755;
	void* l_v7742;
	goto block0;

    block0:
	OP_UINT_AND(l_i_2, 2147483648UL, l_v7736);
	OP_UINT_EQ(l_v7736, 0UL, l_v7735);
	OP_UINT_AND(l_i_2, 2147483647UL, l_v7737);
	l_v7738 = RPyField(l_d_34, di_entries);
	OP_CAST_UINT_TO_INT(l_v7737, l_v7739);
	l_entry_0 = &RPyItem(l_v7738, l_v7739);
	OP_CAST_UINT_TO_INT(l_v7737, l_v7740);
	l_v7741 = &RPyItem(l_v7738, l_v7740);
	l_v7742 = RPyField(l_v7741, en_key);
	OP_ADR_NE(l_v7742, NULL, l_v7743);
	if (l_v7743) {
		goto block9;
	}
	goto block1;

    block1:
	if (l_v7735) {
		l_v7768 = 0;
		goto block2;
	}
	l_v7768 = 1;
	goto block2;

    block2:
	RPyAssert(l_v7768, "valid but not everused");
	l_v7745 = RPyField(l_d_34, di_resize_counter);
	OP_INT_SUB(l_v7745, 3L, l_v7746);
	OP_INT_LE(l_v7746, 0L, l_v7747);
	if (l_v7747) {
		goto block6;
	}
	l_entry_1 = l_entry_0;
	l_v7769 = l_v7746;
	goto block3;

    block3:
	RPyField(l_d_34, di_resize_counter) = l_v7769;
	RPyField(l_entry_1, en_value) = l_value_6;
	l_entry_2 = l_entry_1;
	goto block4;

    block4:
	RPyField(l_entry_2, en_key) = l_key_32;
	l_v7751 = RPyField(l_d_34, di_num_items);
	OP_INT_ADD(l_v7751, 1L, l_v7752);
	RPyField(l_d_34, di_num_items) = l_v7752;
	goto block5;

    block5:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block6:
	pypy_g_ll_dict_resize__DICTPtr(l_d_34);
	l_v7755 = (&pypy_g_ExcData)->ed_exc_type;
	l_v7756 = (l_v7755 == NULL);
	if (!l_v7756) {
		goto block8;
	}
	goto block7;

    block7:
	l_v7757 = pypy_g_ll_dict_lookup_clean__DICTPtr_Signed(l_d_34, l_hash_29);
	l_v7758 = RPyField(l_d_34, di_entries);
	OP_CAST_UINT_TO_INT(l_v7757, l_v7759);
	l_v7760 = &RPyItem(l_v7758, l_v7759);
	l_v7761 = RPyField(l_d_34, di_resize_counter);
	OP_INT_SUB(l_v7761, 3L, l_v7762);
	OP_INT_GT(l_v7762, 0L, l_v7763);
	RPyAssert(l_v7763, "ll_dict_resize failed?");
	l_entry_1 = l_v7760;
	l_v7769 = l_v7762;
	goto block3;

    block8:
	PYPY_DEBUG_RECORD_TRACEBACK("_ll_dict_setitem_lookup_done__v66___simple_call_");
	goto block5;

    block9:
	RPyField(l_entry_0, en_value) = l_value_6;
	if (l_v7735) {
		goto block5;
	}
	l_entry_2 = l_entry_0;
	goto block4;
}
/*/*/
void pypy_g__ll_dict_setitem_lookup_done__v77___simple_call_(struct pypy_DICT0 *l_d_35, void* l_key_33, void* l_value_4, Signed l_hash_30, Unsigned l_i_3) {
	struct pypy_ENTRY0 *l_entry_3; struct pypy_ENTRY0 *l_entry_4;
	Signed l_v7775; Signed l_v7776; Signed l_v7781; Signed l_v7782;
	Signed l_v7787; Signed l_v7788; Signed l_v7795; Signed l_v7797;
	Signed l_v7798; Signed l_v7805; Unsigned l_v7772; Unsigned l_v7773;
	Unsigned l_v7793; bool_t l_v7770; bool_t l_v7779; bool_t l_v7783;
	bool_t l_v7792; bool_t l_v7799; bool_t l_v7804;
	struct pypy_ENTRY0 *l_v7771; struct pypy_ENTRY0 *l_v7777;
	struct pypy_ENTRY0 *l_v7796; struct pypy_array5 *l_v7774;
	struct pypy_array5 *l_v7794; struct pypy_object_vtable0 *l_v7791;
	void* l_v7778;
	goto block0;

    block0:
	OP_UINT_AND(l_i_3, 2147483648UL, l_v7772);
	OP_UINT_EQ(l_v7772, 0UL, l_v7770);
	OP_UINT_AND(l_i_3, 2147483647UL, l_v7773);
	l_v7774 = RPyField(l_d_35, di_entries);
	OP_CAST_UINT_TO_INT(l_v7773, l_v7775);
	l_v7771 = &RPyItem(l_v7774, l_v7775);
	OP_CAST_UINT_TO_INT(l_v7773, l_v7776);
	l_v7777 = &RPyItem(l_v7774, l_v7776);
	l_v7778 = RPyField(l_v7777, en_key);
	OP_ADR_NE(l_v7778, NULL, l_v7779);
	if (l_v7779) {
		goto block9;
	}
	goto block1;

    block1:
	if (l_v7770) {
		l_v7804 = 0;
		goto block2;
	}
	l_v7804 = 1;
	goto block2;

    block2:
	RPyAssert(l_v7804, "valid but not everused");
	l_v7781 = RPyField(l_d_35, di_resize_counter);
	OP_INT_SUB(l_v7781, 3L, l_v7782);
	OP_INT_LE(l_v7782, 0L, l_v7783);
	if (l_v7783) {
		goto block6;
	}
	l_entry_3 = l_v7771;
	l_v7805 = l_v7782;
	goto block3;

    block3:
	RPyField(l_d_35, di_resize_counter) = l_v7805;
	RPyField(l_entry_3, en_value) = l_value_4;
	l_entry_4 = l_entry_3;
	goto block4;

    block4:
	RPyField(l_entry_4, en_key) = l_key_33;
	l_v7787 = RPyField(l_d_35, di_num_items);
	OP_INT_ADD(l_v7787, 1L, l_v7788);
	RPyField(l_d_35, di_num_items) = l_v7788;
	goto block5;

    block5:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block6:
	pypy_g_ll_dict_resize__DICTPtr(l_d_35);
	l_v7791 = (&pypy_g_ExcData)->ed_exc_type;
	l_v7792 = (l_v7791 == NULL);
	if (!l_v7792) {
		goto block8;
	}
	goto block7;

    block7:
	l_v7793 = pypy_g_ll_dict_lookup_clean__DICTPtr_Signed(l_d_35, l_hash_30);
	l_v7794 = RPyField(l_d_35, di_entries);
	OP_CAST_UINT_TO_INT(l_v7793, l_v7795);
	l_v7796 = &RPyItem(l_v7794, l_v7795);
	l_v7797 = RPyField(l_d_35, di_resize_counter);
	OP_INT_SUB(l_v7797, 3L, l_v7798);
	OP_INT_GT(l_v7798, 0L, l_v7799);
	RPyAssert(l_v7799, "ll_dict_resize failed?");
	l_entry_3 = l_v7796;
	l_v7805 = l_v7798;
	goto block3;

    block8:
	PYPY_DEBUG_RECORD_TRACEBACK("_ll_dict_setitem_lookup_done__v77___simple_call_");
	goto block5;

    block9:
	RPyField(l_v7771, en_value) = l_value_4;
	if (l_v7770) {
		goto block5;
	}
	l_entry_4 = l_v7771;
	goto block4;
}
/*/*/
bool_t pypy_g_ll_valid_from_key__arrayPtr_Unsigned(struct pypy_array7 *l_entries_0, Unsigned l_i_4) {
	Signed l_v7806; Signed l_v7809; bool_t l_v7808; bool_t l_v7811;
	bool_t l_v7812; struct pypy_rpy_string0 *l_v7807;
	struct pypy_rpy_string0 *l_v7810;
	goto block0;

    block0:
	OP_CAST_UINT_TO_INT(l_i_4, l_v7806);
	l_v7807 = RPyItem(l_entries_0, l_v7806).d_key;
	l_v7808 = (l_v7807 != NULL);
	if (l_v7808) {
		goto block2;
	}
	l_v7812 = 0;
	goto block1;

    block1:
	RPY_DEBUG_RETURN();
	return l_v7812;

    block2:
	OP_CAST_UINT_TO_INT(l_i_4, l_v7809);
	l_v7810 = RPyItem(l_entries_0, l_v7809).d_key;
	l_v7811 = (l_v7810 != (&pypy_g_rpy_string_60.b));
	l_v7812 = l_v7811;
	goto block1;
}
/*/*/
void pypy_g_ll_dict_resize__DICTPtr(struct pypy_DICT0 *l_d_36) {
	struct pypy_array5 *l_entries_12; Signed l_i_50; Signed l_i_51;
	Signed l_new_estimate_0; Signed l_new_size_0;
	struct pypy_array5 *l_old_entries_0; Signed l_old_size_0;
	Signed l_v7813; Signed l_v7814; Signed l_v7816; Signed l_v7824;
	Signed l_v7831; Signed l_v7835; Signed l_v7838; Signed l_v7839;
	Signed l_v7840; Signed l_v7846; Signed l_v7850; Signed l_v7851;
	Signed l_v7853; Signed l_v7854; Signed l_v7858; Signed l_v7860;
	Signed l_v7861; Unsigned l_v7830; Unsigned l_v7844; bool_t l_v7815;
	bool_t l_v7817; bool_t l_v7820; bool_t l_v7821; bool_t l_v7826;
	bool_t l_v7834; struct pypy_ENTRY0 *l_v7832;
	struct pypy_ENTRY0 *l_v7836; struct pypy_ENTRY0 *l_v7841;
	struct pypy_ENTRY0 *l_v7847; struct pypy_ENTRY0 *l_v7856;
	struct pypy_array5 *l_v7845; void* l_v7818; void* l_v7827;
	void* l_v7833; void* l_v7837; void* l_v7842; void* l_v7843;
	goto block0;

    block0:
	l_old_entries_0 = RPyField(l_d_36, di_entries);
	l_old_size_0 = l_old_entries_0->length;
	l_v7814 = RPyField(l_d_36, di_num_items);
	OP_INT_ADD(l_v7814, 1L, l_v7813);
	OP_INT_GT(l_v7813, 50000L, l_v7815);
	if (l_v7815) {
		goto block15;
	}
	goto block1;

    block1:
	OP_INT_MUL(l_v7813, 4L, l_v7816);
	l_new_size_0 = 8L;
	l_new_estimate_0 = l_v7816;
	goto block2;

    block2:
	while (1) {
		OP_INT_LE(l_new_size_0, l_new_estimate_0, l_v7817);
		if (!l_v7817) break;
		goto block14;
	  block2_back: ;
	}
	goto block3;

    block3:
	l_v7818 = pypy_g_ll_malloc_varsize__Signed_Signed_Signed_Signed(l_new_size_0, (offsetof(struct pypy_array5, items) + 0), sizeof(struct pypy_ENTRY0), offsetof(struct pypy_array5, length));
	OP_TRACK_ALLOC_START(l_v7818, /* nothing */);
	l_entries_12 = (struct pypy_array5 *)l_v7818;
	l_v7820 = (l_entries_12 != NULL);
	if (!l_v7820) {
		goto block13;
	}
	l_i_51 = 0L;
	goto block4;

    block4:
	while (1) {
		OP_INT_LT(l_i_51, l_new_size_0, l_v7821);
		if (!l_v7821) break;
		goto block12;
	  block4_back: ;
	}
	goto block5;

    block5:
	RPyField(l_d_36, di_entries) = l_entries_12;
	RPyField(l_d_36, di_num_items) = 0L;
	OP_INT_MUL(l_new_size_0, 2L, l_v7824);
	RPyField(l_d_36, di_resize_counter) = l_v7824;
	l_i_50 = 0L;
	goto block6;

    block6:
	while (1) {
		OP_INT_LT(l_i_50, l_old_size_0, l_v7826);
		if (!l_v7826) break;
		goto block9;
	  block6_back: ;
	}
	goto block7;

    block7:
	l_v7827 = (void*)l_old_entries_0;
	OP_TRACK_ALLOC_STOP(l_v7827, /* nothing */);
	OP_RAW_FREE(l_v7827, /* nothing */);
	goto block8;

    block8:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block9:
	OP_CAST_INT_TO_UINT(l_i_50, l_v7830);
	OP_CAST_UINT_TO_INT(l_v7830, l_v7831);
	l_v7832 = &RPyItem(l_old_entries_0, l_v7831);
	l_v7833 = RPyField(l_v7832, en_key);
	OP_ADR_NE(l_v7833, NULL, l_v7834);
	if (l_v7834) {
		goto block11;
	}
	goto block10;

    block10:
	OP_INT_ADD(l_i_50, 1L, l_v7835);
	l_i_50 = l_v7835;
	goto block6_back;

    block11:
	l_v7836 = &RPyItem(l_old_entries_0, l_i_50);
	l_v7837 = RPyField(l_v7836, en_key);
	OP_CAST_ADR_TO_INT(l_v7837, /* nothing */, l_v7838);
	OP_INT_RSHIFT(l_v7838, 4L, l_v7839);
	OP_INT_XOR(l_v7838, l_v7839, l_v7840);
	l_v7841 = &RPyItem(l_old_entries_0, l_i_50);
	l_v7842 = RPyField(l_v7841, en_key);
	l_v7843 = RPyField(l_v7841, en_value);
	l_v7844 = pypy_g_ll_dict_lookup_clean__DICTPtr_Signed(l_d_36, l_v7840);
	l_v7845 = RPyField(l_d_36, di_entries);
	OP_CAST_UINT_TO_INT(l_v7844, l_v7846);
	l_v7847 = &RPyItem(l_v7845, l_v7846);
	RPyField(l_v7847, en_value) = l_v7843;
	RPyField(l_v7847, en_key) = l_v7842;
	l_v7850 = RPyField(l_d_36, di_num_items);
	OP_INT_ADD(l_v7850, 1L, l_v7851);
	RPyField(l_d_36, di_num_items) = l_v7851;
	l_v7853 = RPyField(l_d_36, di_resize_counter);
	OP_INT_SUB(l_v7853, 3L, l_v7854);
	RPyField(l_d_36, di_resize_counter) = l_v7854;
	goto block10;

    block12:
	l_v7856 = &RPyItem(l_entries_12, l_i_51);
	RPyField(l_v7856, en_key) = NULL;
	OP_INT_ADD(l_i_51, 1L, l_v7858);
	l_i_51 = l_v7858;
	goto block4_back;

    block13:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_dict_resize__DICTPtr");
	goto block8;

    block14:
	OP_INT_MUL(l_new_size_0, 2L, l_v7860);
	l_new_size_0 = l_v7860;
	goto block2_back;

    block15:
	OP_INT_MUL(l_v7813, 2L, l_v7861);
	l_new_size_0 = 8L;
	l_new_estimate_0 = l_v7861;
	goto block2;
}
/*/*/
Unsigned pypy_g_ll_dict_lookup_clean__DICTPtr_Signed(struct pypy_DICT0 *l_d_30, Signed l_hash_20) {
	struct pypy_array5 *l_entries_13; Unsigned l_i_52; Signed l_mask_8;
	Unsigned l_perturb_8; Signed l_v7863; Signed l_v7864; Signed l_v7867;
	Unsigned l_v7865; Unsigned l_v7866; Unsigned l_v7871;
	Unsigned l_v7872; Unsigned l_v7873; Unsigned l_v7874;
	Unsigned l_v7875; Unsigned l_v7876; Unsigned l_v7877; bool_t l_v7870;
	struct pypy_ENTRY0 *l_v7868; void* l_v7869;
	goto block0;

    block0:
	l_entries_13 = RPyField(l_d_30, di_entries);
	l_v7863 = l_entries_13->length;
	OP_INT_SUB(l_v7863, 1L, l_mask_8);
	OP_INT_AND(l_hash_20, l_mask_8, l_v7864);
	OP_CAST_INT_TO_UINT(l_v7864, l_v7865);
	OP_CAST_INT_TO_UINT(l_hash_20, l_v7866);
	l_i_52 = l_v7865;
	l_perturb_8 = l_v7866;
	goto block1;

    block1:
	while (1) {
		OP_CAST_UINT_TO_INT(l_i_52, l_v7867);
		l_v7868 = &RPyItem(l_entries_13, l_v7867);
		l_v7869 = RPyField(l_v7868, en_key);
		OP_ADR_NE(l_v7869, NULL, l_v7870);
		if (!l_v7870) break;
		goto block3;
	  block1_back: ;
	}
	goto block2;

    block2:
	RPY_DEBUG_RETURN();
	return l_i_52;

    block3:
	OP_UINT_LSHIFT(l_i_52, 2L, l_v7871);
	OP_UINT_ADD(l_v7871, l_i_52, l_v7872);
	OP_UINT_ADD(l_v7872, l_perturb_8, l_v7873);
	OP_UINT_ADD(l_v7873, 1UL, l_v7874);
	OP_CAST_INT_TO_UINT(l_mask_8, l_v7875);
	OP_UINT_AND(l_v7874, l_v7875, l_v7876);
	OP_UINT_RSHIFT(l_perturb_8, 5L, l_v7877);
	l_i_52 = l_v7876;
	l_perturb_8 = l_v7877;
	goto block1_back;
}
/*/*/
/***********************************************************/
