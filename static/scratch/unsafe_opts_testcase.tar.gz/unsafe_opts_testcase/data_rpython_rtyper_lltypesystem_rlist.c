/***********************************************************/
/***  Non-function Implementations                       ***/

#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"

#include "src/g_include.h"

/*/*/
union pypy_array6_len0u pypy_g_array_34 = { {
{
	(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member25)+196608L),	/* gcheader.tid */
},
	0
} };
/*/*/
/***********************************************************/
