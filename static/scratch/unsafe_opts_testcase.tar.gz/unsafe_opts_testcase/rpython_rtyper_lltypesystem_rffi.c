/***********************************************************/
/***  Implementations                                    ***/

#define PYPY_FILE_NAME "rpython_rtyper_lltypesystem_rffi.c"
#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"
#include "src/g_include.h"

/*/*/
Unsigned pypy_g_write__Signed_arrayPtr_Unsigned_star_3(Signed l_stararg0_0, char *l_stararg1_0, Unsigned l_stararg2_0) {
	Unsigned l_v7878;
	goto block0;

    block0:
	l_v7878 = pypy_g_ccall_write__Signed_arrayPtr_Unsigned(l_stararg0_0, l_stararg1_0, l_stararg2_0);
	goto block1;

    block1:
	RPY_DEBUG_RETURN();
	return l_v7878;
}
/*/*/
char *pypy_g_getenv__arrayPtr_star_1(char *l_stararg0_1) {
	char *l_v7879;
	goto block0;

    block0:
	l_v7879 = getenv(l_stararg0_1);
	goto block1;

    block1:
	RPY_DEBUG_RETURN();
	return l_v7879;
}
/*/*/
struct pypy_rpy_string0 *pypy_g_charp2str(char *l_cp_1) {
	void* l_addr_struct_4; char l_char_0; Signed l_i_53;
	Signed l_length_45; Signed l_length_46;
	struct pypy_stringbuilder0 *l_ll_builder_2; Signed l_maxsize_6;
	Signed l_maxsize_7; void* l_newvalue_4; void* l_newvalue_5;
	struct pypy_rpy_string0 *l_p_2; Signed l_rawtotalsize_3;
	void* l_result_21; void* l_result_22; Unsigned l_toobig_7;
	Unsigned l_toobig_8; Signed l_totalsize_22; Signed l_totalsize_23;
	Signed l_v7883; Signed l_v7884; Signed l_v7885; Signed l_v7889;
	Signed l_v7896; Signed l_v7918; Signed l_v7920; Signed l_v7924;
	Signed l_v7926; Signed l_v7927; Signed l_v7928; Signed l_v7953;
	Signed l_v7954; Signed l_v7962; Signed l_v7975; Signed l_v7977;
	Signed l_v7981; Signed l_v7983; Signed l_v7984; Signed l_v7985;
	Signed l_v8008; Signed l_v8014; Signed l_v8020; Signed l_v8021;
	Signed l_v8034; Signed l_v8042; Signed l_v8043; Signed l_v8046;
	Signed l_v8047; Signed l_v8050; Signed l_v8052; Signed l_v8054;
	Signed l_v8079; Signed l_v8087; Signed l_v8088; Signed l_v8105;
	Unsigned l_v7922; Unsigned l_v7979; Unsigned l_v8044;
	Unsigned l_v8045; Unsigned l_v8089; Unsigned l_v8090; bool_t l_v7893;
	bool_t l_v7894; bool_t l_v7895; bool_t l_v7897; bool_t l_v7902;
	bool_t l_v7903; bool_t l_v7908; bool_t l_v7911; bool_t l_v7919;
	bool_t l_v7921; bool_t l_v7923; bool_t l_v7925; bool_t l_v7929;
	bool_t l_v7935; bool_t l_v7936; bool_t l_v7948; bool_t l_v7949;
	bool_t l_v7955; bool_t l_v7958; bool_t l_v7959; bool_t l_v7963;
	bool_t l_v7967; bool_t l_v7976; bool_t l_v7978; bool_t l_v7980;
	bool_t l_v7982; bool_t l_v7986; bool_t l_v7992; bool_t l_v7993;
	bool_t l_v8007; bool_t l_v8022; bool_t l_v8028; bool_t l_v8032;
	bool_t l_v8036; bool_t l_v8040; bool_t l_v8048; bool_t l_v8067;
	bool_t l_v8073; bool_t l_v8077; bool_t l_v8081; bool_t l_v8085;
	bool_t l_v8094; bool_t l_v8098; bool_t l_v8103; char l_v7892;
	char l_v7957; struct pypy_header0 *l_v7905;
	struct pypy_header0 *l_v7937; struct pypy_header0 *l_v7952;
	struct pypy_header0 *l_v7994; struct pypy_header0 *l_v8019;
	struct pypy_object_vtable0 *l_v8027;
	struct pypy_object_vtable0 *l_v8031;
	struct pypy_object_vtable0 *l_v8035;
	struct pypy_object_vtable0 *l_v8039;
	struct pypy_object_vtable0 *l_v8066;
	struct pypy_object_vtable0 *l_v8072;
	struct pypy_object_vtable0 *l_v8076;
	struct pypy_object_vtable0 *l_v8080;
	struct pypy_object_vtable0 *l_v8084;
	struct pypy_object_vtable0 *l_v8093;
	struct pypy_object_vtable0 *l_v8097;
	struct pypy_object_vtable0 *l_v8102;
	struct pypy_rpy_string0 *l_v7881; struct pypy_rpy_string0 *l_v7887;
	struct pypy_rpy_string0 *l_v7888; struct pypy_rpy_string0 *l_v7964;
	struct pypy_rpy_string0 *l_v8049; struct pypy_rpy_string0 *l_v8106;
	void* l_v7880; void* l_v7882; void* l_v7886; void* l_v7890;
	void* l_v7891; void* l_v7898; void* l_v7900; void* l_v7901;
	void* l_v7904; void* l_v7907; void* l_v7913; void* l_v7914;
	void* l_v7916; void* l_v7931; void* l_v7933; void* l_v7934;
	void* l_v7939; void* l_v7940; void* l_v7942; void* l_v7943;
	void* l_v7944; void* l_v7946; void* l_v7951; void* l_v7966;
	void* l_v7968; void* l_v7969; void* l_v7971; void* l_v7973;
	void* l_v7988; void* l_v7990; void* l_v7991; void* l_v7996;
	void* l_v7997; void* l_v7999; void* l_v8000; void* l_v8001;
	void* l_v8003; void* l_v8005; void* l_v8010; void* l_v8011;
	void* l_v8012; void* l_v8013; void* l_v8018; void* l_v8030;
	void* l_v8038; void* l_v8055; void* l_v8056; void* l_v8058;
	void* l_v8061; void* l_v8062; void* l_v8064; void* l_v8075;
	void* l_v8083; void* l_v8096; void* l_v8101; void* l_v8107;
	void* l_v8108; void* l_v8109; void* l_v8110; void* l_v8111;
	void* l_v8112;
	goto block0;

    block0:
	l_v7883 = 0L;
	goto block1;

    block1:
	while (1) {
		l_v7892 = RPyBareItem(l_cp_1, l_v7883);
		OP_CHAR_NE(l_v7892, ((char)0), l_v7893);
		if (!l_v7893) break;
		goto block77;
	  block1_back: ;
	}
	goto block2;

    block2:
	OP_INT_LT(l_v7883, 0L, l_v7894);
	if (l_v7894) {
		l_length_45 = 16777216L;
		goto block3;
	}
	l_length_45 = l_v7883;
	goto block3;

    block3:
	OP_RAW_MALLOC_USAGE((0 + ROUND_UP_FOR_ALLOCATION(sizeof(struct pypy_stringbuilder0), 0L)), l_rawtotalsize_3);
	OP_INT_GT(l_rawtotalsize_3, 67583L, l_v7895);
	if (l_v7895) {
		goto block75;
	}
	goto block4;

    block4:
	OP_RAW_MALLOC_USAGE((sizeof(struct pypy_header0) + sizeof(void*)), l_v7896);
	OP_INT_LT(l_rawtotalsize_3, l_v7896, l_v7897);
	if (l_v7897) {
		l_v7884 = l_v7896;
		goto block5;
	}
	l_v7884 = (0 + ROUND_UP_FOR_ALLOCATION(sizeof(struct pypy_stringbuilder0), 0L));
	goto block5;

    block5:
	l_result_21 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	OP_ADR_ADD(l_result_21, l_v7884, l_v7898);
	(&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free = l_v7898;
	l_v7900 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	l_v7901 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_top;
	OP_ADR_GT(l_v7900, l_v7901, l_v7902);
	if (l_v7902) {
		goto block73;
	}
	l_result_22 = l_result_21;
	goto block6;

    block6:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v7903);
	if (l_v7903) {
		goto block71;
	}
	goto block7;

    block7:
	OP_ADR_ADD(l_result_22, 0, l_v7904);
	l_v7905 = (struct pypy_header0 *)l_result_22;
	RPyField(l_v7905, h_tid) = (GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member26)+0L);
	l_v8107 = l_v7904;
	goto block8;

    block8:
	l_v7907 = (void*)l_v8107;
	l_v8108 = l_v7907;
	goto block9;

    block9:
	l_ll_builder_2 = (struct pypy_stringbuilder0 *)l_v8108;
	l_v7908 = (l_ll_builder_2 != NULL);
	if (!l_v7908) {
		goto block70;
	}
	goto block10;

    block10:
	RPyField(l_ll_builder_2, s_allocated) = l_length_45;
	RPyField(l_ll_builder_2, s_used) = 0L;
	OP_INT_GE(l_length_45, 0L, l_v7911);
	RPyAssert(l_v7911, "negative string length");
	l_v7913 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v7913, sizeof(void*), l_v7914);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v7914;
	l_v7916 = (void*)l_ll_builder_2;
	((void* *) (((char *)l_v7913) + 0))[0] = l_v7916;
	OP_RAW_MALLOC_USAGE((0 + offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v7918);
	OP_INT_SUB(67583L, l_v7918, l_maxsize_7);
	OP_INT_LT(l_maxsize_7, 0L, l_v7919);
	if (l_v7919) {
		l_toobig_7 = 0UL;
		goto block12;
	}
	goto block11;

    block11:
	OP_RAW_MALLOC_USAGE(sizeof(char), l_v7920);
	OP_INT_IS_TRUE(l_v7920, l_v7921);
	if (l_v7921) {
		goto block69;
	}
	l_toobig_7 = 2147483648UL;
	goto block12;

    block12:
	OP_CAST_INT_TO_UINT(l_length_45, l_v7922);
	OP_UINT_GE(l_v7922, l_toobig_7, l_v7923);
	if (l_v7923) {
		goto block67;
	}
	goto block13;

    block13:
	OP_INT_MUL(sizeof(char), l_length_45, l_v7924);
	OP_INT_ADD((0 + offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v7924, l_v7889);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v7925);
	if (l_v7925) {
		goto block65;
	}
	goto block14;

    block14:
	l_v7926 = ROUND_UP_FOR_ALLOCATION(l_v7889, 0L);
	l_totalsize_23 = l_v7926;
	goto block15;

    block15:
	OP_RAW_MALLOC_USAGE(l_totalsize_23, l_v7927);
	OP_RAW_MALLOC_USAGE((sizeof(struct pypy_header0) + sizeof(void*)), l_v7928);
	OP_INT_GE(l_v7927, l_v7928, l_v7929);
	RPyAssert(l_v7929, "malloc_varsize_clear(): totalsize < minimalsize");
	l_v7890 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	OP_ADR_ADD(l_v7890, l_totalsize_23, l_v7931);
	(&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free = l_v7931;
	l_v7933 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	l_v7934 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_top;
	OP_ADR_GT(l_v7933, l_v7934, l_v7935);
	if (l_v7935) {
		goto block63;
	}
	l_v7891 = l_v7890;
	goto block16;

    block16:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v7936);
	if (l_v7936) {
		goto block61;
	}
	goto block17;

    block17:
	l_v7937 = (struct pypy_header0 *)l_v7891;
	RPyField(l_v7937, h_tid) = (GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+0L);
	OP_ADR_ADD(l_v7891, 0, l_v7939);
	OP_ADR_ADD(l_v7939, (offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, length)), l_v7940);
	((Signed *) (((char *)l_v7940) + 0))[0] = l_length_45;
	l_v8109 = l_v7939;
	goto block18;

    block18:
	l_v7942 = (void*)l_v8109;
	l_v8110 = l_v7942;
	goto block19;

    block19:
	l_v7943 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v7943, sizeof(void*), l_v7944);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v7944;
	l_v7946 = ((void* *) (((char *)l_v7944) + 0))[0];
	l_ll_builder_2 = l_v7946; /* for moving GCs */
	l_v7881 = (struct pypy_rpy_string0 *)l_v8110;
	l_v7948 = (l_v7881 != NULL);
	if (!l_v7948) {
		goto block60;
	}
	goto block20;

    block20:
	OP_INT_IS_TRUE(MALLOC_ZERO_FILLED, l_v7949);
	if (l_v7949) {
		goto block22;
	}
	goto block21;

    block21:
	RPyField(l_v7881, rs_hash) = 0L;
	goto block22;

    block22:
	l_newvalue_4 = (void*)l_v7881;
	l_addr_struct_4 = (void*)l_ll_builder_2;
	OP_ADR_SUB(l_addr_struct_4, 0, l_v7951);
	l_v7952 = (struct pypy_header0 *)l_v7951;
	l_v7953 = RPyField(l_v7952, h_tid);
	OP_INT_AND(l_v7953, 65536L, l_v7954);
	OP_INT_IS_TRUE(l_v7954, l_v7955);
	if (l_v7955) {
		goto block59;
	}
	goto block23;

    block23:
	RPyField(l_ll_builder_2, s_buf) = l_v7881;
	l_i_53 = 0L;
	goto block24;

    block24:
	while (1) {
		l_v7957 = RPyBareItem(l_cp_1, l_i_53);
		OP_CHAR_NE(l_v7957, ((char)0), l_v7958);
		if (!l_v7958) break;
		goto block55;
	  block24_back: ;
	}
	goto block25;

    block25:
	l_length_46 = RPyField(l_ll_builder_2, s_used);
	OP_INT_GE(l_length_46, 0L, l_v7959);
	if (l_v7959) {
		goto block28;
	}
	goto block26;

    block26:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("charp2str");
	l_v8106 = ((struct pypy_rpy_string0 *) NULL);
	goto block27;

    block27:
	RPY_DEBUG_RETURN();
	return l_v8106;

    block28:
	l_v7962 = RPyField(l_ll_builder_2, s_allocated);
	OP_INT_LT(l_length_46, l_v7962, l_v7963);
	if (l_v7963) {
		goto block30;
	}
	goto block29;

    block29:
	l_v7964 = RPyField(l_ll_builder_2, s_buf);
	l_v8106 = l_v7964;
	goto block27;

    block30:
	RPyField(l_ll_builder_2, s_allocated) = l_length_46;
	l_p_2 = RPyField(l_ll_builder_2, s_buf);
	l_v7966 = (void*)l_p_2;
	l_v7967 = pypy_g_MiniMarkGC_shrink_array((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_v7966, l_length_46);
	if (l_v7967) {
		l_v7887 = l_p_2;
		goto block42;
	}
	goto block31;

    block31:
	l_v7968 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v7968, (sizeof(void*) * 2), l_v7969);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v7969;
	l_v7971 = (void*)l_p_2;
	((void* *) (((char *)l_v7968) + 0))[0] = l_v7971;
	l_v7973 = (void*)l_ll_builder_2;
	((void* *) (((char *)l_v7968) + sizeof(void*)))[0] = l_v7973;
	OP_RAW_MALLOC_USAGE((0 + offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v7975);
	OP_INT_SUB(67583L, l_v7975, l_maxsize_6);
	OP_INT_LT(l_maxsize_6, 0L, l_v7976);
	if (l_v7976) {
		l_toobig_8 = 0UL;
		goto block33;
	}
	goto block32;

    block32:
	OP_RAW_MALLOC_USAGE(sizeof(char), l_v7977);
	OP_INT_IS_TRUE(l_v7977, l_v7978);
	if (l_v7978) {
		goto block54;
	}
	l_toobig_8 = 2147483648UL;
	goto block33;

    block33:
	OP_CAST_INT_TO_UINT(l_length_46, l_v7979);
	OP_UINT_GE(l_v7979, l_toobig_8, l_v7980);
	if (l_v7980) {
		goto block52;
	}
	goto block34;

    block34:
	OP_INT_MUL(sizeof(char), l_length_46, l_v7981);
	OP_INT_ADD((0 + offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v7981, l_v7885);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v7982);
	if (l_v7982) {
		goto block50;
	}
	goto block35;

    block35:
	l_v7983 = ROUND_UP_FOR_ALLOCATION(l_v7885, 0L);
	l_totalsize_22 = l_v7983;
	goto block36;

    block36:
	OP_RAW_MALLOC_USAGE(l_totalsize_22, l_v7984);
	OP_RAW_MALLOC_USAGE((sizeof(struct pypy_header0) + sizeof(void*)), l_v7985);
	OP_INT_GE(l_v7984, l_v7985, l_v7986);
	RPyAssert(l_v7986, "malloc_varsize_clear(): totalsize < minimalsize");
	l_v7886 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	OP_ADR_ADD(l_v7886, l_totalsize_22, l_v7988);
	(&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free = l_v7988;
	l_v7990 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	l_v7991 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_top;
	OP_ADR_GT(l_v7990, l_v7991, l_v7992);
	if (l_v7992) {
		goto block48;
	}
	l_v7880 = l_v7886;
	goto block37;

    block37:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v7993);
	if (l_v7993) {
		goto block46;
	}
	goto block38;

    block38:
	l_v7994 = (struct pypy_header0 *)l_v7880;
	RPyField(l_v7994, h_tid) = (GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+0L);
	OP_ADR_ADD(l_v7880, 0, l_v7996);
	OP_ADR_ADD(l_v7996, (offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, length)), l_v7997);
	((Signed *) (((char *)l_v7997) + 0))[0] = l_length_46;
	l_v8111 = l_v7996;
	goto block39;

    block39:
	l_v7999 = (void*)l_v8111;
	l_v8112 = l_v7999;
	goto block40;

    block40:
	l_v8000 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v8000, (sizeof(void*) * 2), l_v8001);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v8001;
	l_v8003 = ((void* *) (((char *)l_v8001) + 0))[0];
	l_p_2 = l_v8003; /* for moving GCs */
	l_v8005 = ((void* *) (((char *)l_v8001) + sizeof(void*)))[0];
	l_ll_builder_2 = l_v8005; /* for moving GCs */
	l_v7888 = (struct pypy_rpy_string0 *)l_v8112;
	l_v8007 = (l_v7888 != NULL);
	if (!l_v8007) {
		goto block45;
	}
	goto block41;

    block41:
	l_v8008 = RPyField(l_p_2, rs_hash);
	RPyField(l_v7888, rs_hash) = l_v8008;
	l_v8010 = (void*)l_p_2;
	OP_ADR_ADD(l_v8010, (offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items)), l_v8011);
	l_v8012 = (void*)l_v7888;
	OP_ADR_ADD(l_v8012, (offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items)), l_v8013);
	OP_INT_MUL(sizeof(char), l_length_46, l_v8014);
	OP_RAW_MEMCOPY(l_v8011, l_v8013, l_v8014, /* nothing */);
	/* kept alive: l_p_2 */
	/* kept alive: l_v7888 */
	l_v7887 = l_v7888;
	goto block42;

    block42:
	l_newvalue_5 = (void*)l_v7887;
	l_v7882 = (void*)l_ll_builder_2;
	OP_ADR_SUB(l_v7882, 0, l_v8018);
	l_v8019 = (struct pypy_header0 *)l_v8018;
	l_v8020 = RPyField(l_v8019, h_tid);
	OP_INT_AND(l_v8020, 65536L, l_v8021);
	OP_INT_IS_TRUE(l_v8021, l_v8022);
	if (l_v8022) {
		goto block44;
	}
	goto block43;

    block43:
	RPyField(l_ll_builder_2, s_buf) = l_v7887;
	goto block29;

    block44:
	pypy_g_remember_young_pointer(l_v7882, l_newvalue_5);
	goto block43;

    block45:
	PYPY_DEBUG_RECORD_TRACEBACK("charp2str");
	l_v8106 = ((struct pypy_rpy_string0 *) NULL);
	goto block27;

    block46:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v8027 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8028 = (l_v8027 == NULL);
	if (!l_v8028) {
		goto block47;
	}
	goto block38;

    block47:
	PYPY_DEBUG_RECORD_TRACEBACK("charp2str");
	l_v8112 = NULL;
	goto block40;

    block48:
	l_v8030 = pypy_g_MiniMarkGC_collect_and_reserve((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_v7886, l_totalsize_22);
	l_v8031 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8032 = (l_v8031 == NULL);
	if (!l_v8032) {
		goto block49;
	}
	l_v7880 = l_v8030;
	goto block37;

    block49:
	PYPY_DEBUG_RECORD_TRACEBACK("charp2str");
	l_v8112 = NULL;
	goto block40;

    block50:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v8034 = (Signed)0;
	l_v8035 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8036 = (l_v8035 == NULL);
	if (!l_v8036) {
		goto block51;
	}
	l_totalsize_22 = l_v8034;
	goto block36;

    block51:
	PYPY_DEBUG_RECORD_TRACEBACK("charp2str");
	l_v8112 = NULL;
	goto block40;

    block52:
	l_v8038 = pypy_g_MiniMarkGC_external_malloc((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17), l_length_46, 1);
	l_v8039 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8040 = (l_v8039 == NULL);
	if (!l_v8040) {
		goto block53;
	}
	l_v8111 = l_v8038;
	goto block39;

    block53:
	PYPY_DEBUG_RECORD_TRACEBACK("charp2str");
	l_v8112 = NULL;
	goto block40;

    block54:
	OP_RAW_MALLOC_USAGE(sizeof(char), l_v8042);
	OP_INT_FLOORDIV(l_maxsize_6, l_v8042, l_v8043);
	OP_CAST_INT_TO_UINT(l_v8043, l_v8044);
	OP_UINT_ADD(l_v8044, 1UL, l_v8045);
	l_toobig_8 = l_v8045;
	goto block33;

    block55:
	l_char_0 = RPyBareItem(l_cp_1, l_i_53);
	l_v8046 = RPyField(l_ll_builder_2, s_used);
	l_v8047 = RPyField(l_ll_builder_2, s_allocated);
	OP_INT_EQ(l_v8046, l_v8047, l_v8048);
	if (l_v8048) {
		goto block57;
	}
	goto block56;

    block56:
	l_v8049 = RPyField(l_ll_builder_2, s_buf);
	l_v8050 = RPyField(l_ll_builder_2, s_used);
	RPyField(l_v8049, rs_chars).items[l_v8050] = l_char_0;
	OP_INT_ADD(l_v8050, 1L, l_v8052);
	RPyField(l_ll_builder_2, s_used) = l_v8052;
	OP_INT_ADD(l_i_53, 1L, l_v8054);
	l_i_53 = l_v8054;
	goto block24_back;

    block57:
	l_v8055 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v8055, sizeof(void*), l_v8056);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v8056;
	l_v8058 = (void*)l_ll_builder_2;
	((void* *) (((char *)l_v8055) + 0))[0] = l_v8058;
	pypy_g_stringbuilder_grow__stringbuilderPtr_Signed(l_ll_builder_2, 1L);
	l_v8061 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v8061, sizeof(void*), l_v8062);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v8062;
	l_v8064 = ((void* *) (((char *)l_v8062) + 0))[0];
	l_ll_builder_2 = l_v8064; /* for moving GCs */
	l_v8066 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8067 = (l_v8066 == NULL);
	if (!l_v8067) {
		goto block58;
	}
	goto block56;

    block58:
	PYPY_DEBUG_RECORD_TRACEBACK("charp2str");
	l_v8106 = ((struct pypy_rpy_string0 *) NULL);
	goto block27;

    block59:
	pypy_g_remember_young_pointer(l_addr_struct_4, l_newvalue_4);
	goto block23;

    block60:
	PYPY_DEBUG_RECORD_TRACEBACK("charp2str");
	l_v8106 = ((struct pypy_rpy_string0 *) NULL);
	goto block27;

    block61:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v8072 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8073 = (l_v8072 == NULL);
	if (!l_v8073) {
		goto block62;
	}
	goto block17;

    block62:
	PYPY_DEBUG_RECORD_TRACEBACK("charp2str");
	l_v8110 = NULL;
	goto block19;

    block63:
	l_v8075 = pypy_g_MiniMarkGC_collect_and_reserve((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_v7890, l_totalsize_23);
	l_v8076 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8077 = (l_v8076 == NULL);
	if (!l_v8077) {
		goto block64;
	}
	l_v7891 = l_v8075;
	goto block16;

    block64:
	PYPY_DEBUG_RECORD_TRACEBACK("charp2str");
	l_v8110 = NULL;
	goto block19;

    block65:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v8079 = (Signed)0;
	l_v8080 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8081 = (l_v8080 == NULL);
	if (!l_v8081) {
		goto block66;
	}
	l_totalsize_23 = l_v8079;
	goto block15;

    block66:
	PYPY_DEBUG_RECORD_TRACEBACK("charp2str");
	l_v8110 = NULL;
	goto block19;

    block67:
	l_v8083 = pypy_g_MiniMarkGC_external_malloc((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17), l_length_45, 1);
	l_v8084 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8085 = (l_v8084 == NULL);
	if (!l_v8085) {
		goto block68;
	}
	l_v8109 = l_v8083;
	goto block18;

    block68:
	PYPY_DEBUG_RECORD_TRACEBACK("charp2str");
	l_v8110 = NULL;
	goto block19;

    block69:
	OP_RAW_MALLOC_USAGE(sizeof(char), l_v8087);
	OP_INT_FLOORDIV(l_maxsize_7, l_v8087, l_v8088);
	OP_CAST_INT_TO_UINT(l_v8088, l_v8089);
	OP_UINT_ADD(l_v8089, 1UL, l_v8090);
	l_toobig_7 = l_v8090;
	goto block12;

    block70:
	PYPY_DEBUG_RECORD_TRACEBACK("charp2str");
	l_v8106 = ((struct pypy_rpy_string0 *) NULL);
	goto block27;

    block71:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v8093 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8094 = (l_v8093 == NULL);
	if (!l_v8094) {
		goto block72;
	}
	goto block7;

    block72:
	PYPY_DEBUG_RECORD_TRACEBACK("charp2str");
	l_v8108 = NULL;
	goto block9;

    block73:
	l_v8096 = pypy_g_MiniMarkGC_collect_and_reserve((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_result_21, l_v7884);
	l_v8097 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8098 = (l_v8097 == NULL);
	if (!l_v8098) {
		goto block74;
	}
	l_result_22 = l_v8096;
	goto block6;

    block74:
	PYPY_DEBUG_RECORD_TRACEBACK("charp2str");
	l_v8108 = NULL;
	goto block9;

    block75:
	RPyAssert(1, "'contains_weakptr' specified for a large object");
	l_v8101 = pypy_g_MiniMarkGC_external_malloc((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member26), 0L, 1);
	l_v8102 = (&pypy_g_ExcData)->ed_exc_type;
	l_v8103 = (l_v8102 == NULL);
	if (!l_v8103) {
		goto block76;
	}
	l_v8107 = l_v8101;
	goto block8;

    block76:
	PYPY_DEBUG_RECORD_TRACEBACK("charp2str");
	l_v8108 = NULL;
	goto block9;

    block77:
	OP_INT_ADD(l_v7883, 1L, l_v8105);
	l_v7883 = l_v8105;
	goto block1_back;
}
/*/*/
Unsigned pypy_g_read__Signed_arrayPtr_Signed_star_3(Signed l_stararg0_2, void *l_stararg1_1, Signed l_stararg2_1) {
	Unsigned l_v8113; Unsigned l_v8114;
	goto block0;

    block0:
	l_v8114 = (Unsigned)(l_stararg2_1);
	l_v8113 = pypy_g_ccall_read__Signed_arrayPtr_Unsigned(l_stararg0_2, l_stararg1_1, l_v8114);
	goto block1;

    block1:
	RPY_DEBUG_RETURN();
	return l_v8113;
}
/*/*/
char *pypy_g_str2charp(struct pypy_rpy_string0 *l_s_5, bool_t l_track_allocation_0) {
	Signed l_v8116; Signed l_v8117; Signed l_v8121; Signed l_v8126;
	bool_t l_v8120; char *l_v8115; char *l_v8131; void* l_v8118;
	void* l_v8122; void* l_v8123; void* l_v8124; void* l_v8125;
	goto block0;

    block0:
	l_v8116 = RPyField(l_s_5, rs_chars).length;
	OP_INT_ADD(l_v8116, 1L, l_v8117);
	l_v8118 = pypy_g__ll_malloc_varsize_no_length__Signed_Signed_Sign(l_v8117, (0 + 0), sizeof(char));
	OP_TRACK_ALLOC_START(l_v8118, /* nothing */);
	l_v8115 = (char *)l_v8118;
	l_v8120 = (l_v8115 != NULL);
	if (!l_v8120) {
		goto block3;
	}
	goto block1;

    block1:
	l_v8121 = RPyField(l_s_5, rs_chars).length;
	l_v8122 = (void*)l_s_5;
	OP_ADR_ADD(l_v8122, (offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v8123);
	l_v8124 = (void*)l_v8115;
	OP_ADR_ADD(l_v8124, 0, l_v8125);
	OP_INT_MUL(sizeof(char), l_v8121, l_v8126);
	OP_RAW_MEMCOPY(l_v8123, l_v8125, l_v8126, /* nothing */);
	/* kept alive: l_v8123 */
	RPyBareItem(l_v8115, l_v8121) = ((char)0);
	l_v8131 = l_v8115;
	goto block2;

    block2:
	RPY_DEBUG_RETURN();
	return l_v8131;

    block3:
	PYPY_DEBUG_RECORD_TRACEBACK("str2charp");
	l_v8131 = ((char *) NULL);
	goto block2;
}
/*/*/
double pypy_g__PyPy_dg_strtod__arrayPtr_arrayPtr_star_2(char *l_stararg0_3, char **l_stararg1_2) {
	double l_v8132;
	goto block0;

    block0:
	l_v8132 = _PyPy_dg_strtod(l_stararg0_3, l_stararg1_2);
	goto block1;

    block1:
	RPY_DEBUG_RETURN();
	return l_v8132;
}
/*/*/
/***********************************************************/
