/***********************************************************/
/***  Non-function Implementations                       ***/

#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"

#include "src/g_include.h"

/*/*/
struct pypy_tuple2_0 pypy_g_tuple2 = {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member21)+196608L),	/* gcheader.tid */
	},
	0.0,	/* item0 */
	0L,	/* item1 */
};
/*/*/
union pypy_rpy_string0_len2u pypy_g_rpy_string_17 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	-1488137272L,	/* hash */
	{
		2, {107,75}
	},
} };
/*/*/
union pypy_rpy_string0_len2u pypy_g_rpy_string_18 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	-1475813048L,	/* hash */
	{
		2, {109,77}
	},
} };
/*/*/
union pypy_rpy_string0_len2u pypy_g_rpy_string_19 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	-1512785872L,	/* hash */
	{
		2, {103,71}
	},
} };
/*/*/
union pypy_rpy_string0_len2u pypy_g_rpy_string_20 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	603887334L,	/* hash */
	{
		2, {98,66}
	},
} };
/*/*/
union pypy_rpy_string0_len11u pypy_g_rpy_string_21 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	1025753696L,	/* hash */
	{
		11, {103,99,45,104,97,114,100,119,97,114,101}
	},
} };
/*/*/
union pypy_rpy_string0_len9u pypy_g_rpy_string_22 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	1782407154L,	/* hash */
	{
		9, {77,101,109,84,111,116,97,108,58}
	},
} };
/*/*/
union pypy_rpy_string0_len25u pypy_g_rpy_string_23 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	1995870628L,	/* hash */
	{
		25, {
103,101,116,95,116,111,116,97,108,95,109,101,109,111,114,121,40,41,32,102,
97,105,108,101,100}
	},
} };
/*/*/
union pypy_rpy_string0_len10u pypy_g_rpy_string_24 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	-1003737708L,	/* hash */
	{
		10, {109,101,109,116,111,116,97,108,32,61}
	},
} };
/*/*/
union pypy_rpy_string0_len2u pypy_g_rpy_string_28 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	345078428L,	/* hash */
	{
		2, {56,54}
	},
} };
/*/*/
union pypy_rpy_string0_len13u pypy_g_rpy_string_29 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	630522309L,	/* hash */
	{
		13, {47,112,114,111,99,47,99,112,117,105,110,102,111}
	},
} };
/*/*/
union pypy_rpy_string0_len10u pypy_g_rpy_string_30 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	-297981025L,	/* hash */
	{
		10, {99,97,99,104,101,32,115,105,122,101}
	},
} };
/*/*/
union pypy_rpy_string0_len6u pypy_g_rpy_string_31 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	-281517951L,	/* hash */
	{
		6, {120,56,54,95,54,52}
	},
} };
/*/*/
struct pypy_dicttable0 pypy_g_dicttable = {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member24)+196608L),	/* gcheader.tid */
	},
	3L,	/* num_items */
	7L,	/* resize_counter */
	(&pypy_g_array_31.b),	/* entries */
};
/*/*/
union pypy_rpy_string0_len4u pypy_g_rpy_string_32 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	287969368L,	/* hash */
	{
		4, {105,97,54,52}
	},
} };
/*/*/
struct pypy_dicttable0 pypy_g_dicttable_1 = {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member24)+196608L),	/* gcheader.tid */
	},
	2L,	/* num_items */
	10L,	/* resize_counter */
	(&pypy_g_array_32.b),	/* entries */
};
/*/*/
struct pypy_dicttable0 pypy_g_dicttable_2 = {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member24)+196608L),	/* gcheader.tid */
	},
	2L,	/* num_items */
	10L,	/* resize_counter */
	(&pypy_g_array_33.b),	/* entries */
};
/*/*/
union pypy_rpy_string0_len7u pypy_g_rpy_string_33 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	-1818922022L,	/* hash */
	{
		7, {68,45,99,97,99,104,101}
	},
} };
/*/*/
union pypy_rpy_string0_len8u pypy_g_rpy_string_34 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	-1541964780L,	/* hash */
	{
		8, {76,50,32,99,97,99,104,101}
	},
} };
/*/*/
struct pypy_dicttable1 pypy_g_dicttable_3 = {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member28)+196608L),	/* gcheader.tid */
	},
	2L,	/* num_items */
	10L,	/* resize_counter */
	(&pypy_g_array_37.b),	/* entries */
};
/*/*/
union pypy_array3_len0u pypy_g_array_30 = { {
{
	(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member20)+196608L),	/* gcheader.tid */
},
	0
} };
/*/*/
struct pypy_dicttable1 pypy_g_dicttable_4 = {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member28)+196608L),	/* gcheader.tid */
	},
	2L,	/* num_items */
	10L,	/* resize_counter */
	(&pypy_g_array_38.b),	/* entries */
};
/*/*/
union pypy_rpy_string0_len9u pypy_g_rpy_string_39 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	1989740068L,	/* hash */
	{
		9, {76,50,99,97,99,104,101,32,61}
	},
} };
/*/*/
union pypy_rpy_string0_len60u pypy_g_rpy_string_40 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	-806585415L,	/* hash */
	{
		60, {
87,97,114,110,105,110,103,58,32,99,97,110,110,111,116,32,102,105,110,100,
32,121,111,117,114,32,67,80,85,32,76,50,32,99,97,99,104,101,32,115,
105,122,101,32,105,110,32,47,112,114,111,99,47,99,112,117,105,110,102,111}
	},
} };
/*/*/
union pypy_array7_len8u pypy_g_array_31 = { {
{
	(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member29)+196608L),	/* gcheader.tid */
},
	8, {
	{
		(&pypy_g_rpy_string_61.b),	/* 0.key */
		/* nothing */	/* 0.value */
	},
	{
		(&pypy_g_rpy_string_62.b),	/* 1.key */
		/* nothing */	/* 1.value */
	},
	{
		((struct pypy_rpy_string0 *) NULL),	/* 2.key */
		/* nothing */	/* 2.value */
	},
	{
		((struct pypy_rpy_string0 *) NULL),	/* 3.key */
		/* nothing */	/* 3.value */
	},
	{
		(&pypy_g_rpy_string_63.b),	/* 4.key */
		/* nothing */	/* 4.value */
	},
	{
		((struct pypy_rpy_string0 *) NULL),	/* 5.key */
		/* nothing */	/* 5.value */
	},
	{
		((struct pypy_rpy_string0 *) NULL),	/* 6.key */
		/* nothing */	/* 6.value */
	},
	{
		((struct pypy_rpy_string0 *) NULL),	/* 7.key */
		/* nothing */	/* 7.value */
	},
} } };
/*/*/
union pypy_array7_len8u pypy_g_array_32 = { {
{
	(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member29)+196608L),	/* gcheader.tid */
},
	8, {
	{
		((struct pypy_rpy_string0 *) NULL),	/* 0.key */
		/* nothing */	/* 0.value */
	},
	{
		((struct pypy_rpy_string0 *) NULL),	/* 1.key */
		/* nothing */	/* 1.value */
	},
	{
		(&pypy_g_rpy_string_64.b),	/* 2.key */
		/* nothing */	/* 2.value */
	},
	{
		((struct pypy_rpy_string0 *) NULL),	/* 3.key */
		/* nothing */	/* 3.value */
	},
	{
		((struct pypy_rpy_string0 *) NULL),	/* 4.key */
		/* nothing */	/* 4.value */
	},
	{
		(&pypy_g_rpy_string_65.b),	/* 5.key */
		/* nothing */	/* 5.value */
	},
	{
		((struct pypy_rpy_string0 *) NULL),	/* 6.key */
		/* nothing */	/* 6.value */
	},
	{
		((struct pypy_rpy_string0 *) NULL),	/* 7.key */
		/* nothing */	/* 7.value */
	},
} } };
/*/*/
union pypy_array7_len8u pypy_g_array_33 = { {
{
	(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member29)+196608L),	/* gcheader.tid */
},
	8, {
	{
		((struct pypy_rpy_string0 *) NULL),	/* 0.key */
		/* nothing */	/* 0.value */
	},
	{
		((struct pypy_rpy_string0 *) NULL),	/* 1.key */
		/* nothing */	/* 1.value */
	},
	{
		(&pypy_g_rpy_string_66.b),	/* 2.key */
		/* nothing */	/* 2.value */
	},
	{
		((struct pypy_rpy_string0 *) NULL),	/* 3.key */
		/* nothing */	/* 3.value */
	},
	{
		((struct pypy_rpy_string0 *) NULL),	/* 4.key */
		/* nothing */	/* 4.value */
	},
	{
		(&pypy_g_rpy_string_67.b),	/* 5.key */
		/* nothing */	/* 5.value */
	},
	{
		((struct pypy_rpy_string0 *) NULL),	/* 6.key */
		/* nothing */	/* 6.value */
	},
	{
		((struct pypy_rpy_string0 *) NULL),	/* 7.key */
		/* nothing */	/* 7.value */
	},
} } };
/*/*/
union pypy_rpy_string0_len1u pypy_g_rpy_string_41 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	1849051185L,	/* hash */
	{
		1, {48}
	},
} };
/*/*/
union pypy_rpy_string0_len27u pypy_g_rpy_string_42 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	1142588857L,	/* hash */
	{
		27, {
47,115,121,115,47,100,101,118,105,99,101,115,47,115,121,115,116,101,109,47,
99,112,117,47,99,112,117}
	},
} };
/*/*/
union pypy_rpy_string0_len14u pypy_g_rpy_string_43 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	-1895761272L,	/* hash */
	{
		14, {47,108,50,95,99,97,99,104,101,95,115,105,122,101}
	},
} };
/*/*/
union pypy_rpy_string0_len89u pypy_g_rpy_string_44 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	1407987622L,	/* hash */
	{
		89, {
87,97,114,110,105,110,103,58,32,99,97,110,110,111,116,32,102,105,110,100,
32,121,111,117,114,32,67,80,85,32,76,50,32,99,97,99,104,101,32,115,
105,122,101,32,105,110,32,47,115,121,115,47,100,101,118,105,99,101,115,47,
115,121,115,116,101,109,47,99,112,117,47,99,112,117,88,47,108,50,95,99,
97,99,104,101,95,115,105,122,101}
	},
} };
/*/*/
union pypy_rpy_string0_len12u pypy_g_rpy_string_45 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	-84443726L,	/* hash */
	{
		12, {47,99,97,99,104,101,47,105,110,100,101,120}
	},
} };
/*/*/
union pypy_rpy_string0_len6u pypy_g_rpy_string_46 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	-672528847L,	/* hash */
	{
		6, {47,108,101,118,101,108}
	},
} };
/*/*/
struct pypy_dicttable2 pypy_g_dicttable_5 = {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member30)+196608L),	/* gcheader.tid */
	},
	2L,	/* num_items */
	10L,	/* resize_counter */
	(&pypy_g_array_39.b),	/* entries */
};
/*/*/
union pypy_rpy_string0_len5u pypy_g_rpy_string_47 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	-2062044439L,	/* hash */
	{
		5, {47,115,105,122,101}
	},
} };
/*/*/
struct pypy_dicttable1 pypy_g_dicttable_6 = {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member28)+196608L),	/* gcheader.tid */
	},
	2L,	/* num_items */
	10L,	/* resize_counter */
	(&pypy_g_array_40.b),	/* entries */
};
/*/*/
union pypy_rpy_string0_len86u pypy_g_rpy_string_48 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	-920040103L,	/* hash */
	{
		86, {
87,97,114,110,105,110,103,58,32,99,97,110,110,111,116,32,102,105,110,100,
32,121,111,117,114,32,67,80,85,32,76,50,32,38,32,76,51,32,99,97,
99,104,101,32,115,105,122,101,32,105,110,32,47,115,121,115,47,100,101,118,
105,99,101,115,47,115,121,115,116,101,109,47,99,112,117,47,99,112,117,88,
47,99,97,99,104,101}
	},
} };
/*/*/
union pypy_array9_len8u pypy_g_array_37 = { {
{
	(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member31)+196608L),	/* gcheader.tid */
},
	8, {
	{
		' ',	/* 0.key */
		1,	/* 0.f_everused */
		1,	/* 0.f_valid */
		/* nothing */	/* 0.value */
	},
	{
		((char)9),	/* 1.key */
		1,	/* 1.f_everused */
		1,	/* 1.f_valid */
		/* nothing */	/* 1.value */
	},
	{
		((char)0),	/* 2.key */
		0,	/* 2.f_everused */
		0,	/* 2.f_valid */
		/* nothing */	/* 2.value */
	},
	{
		((char)0),	/* 3.key */
		0,	/* 3.f_everused */
		0,	/* 3.f_valid */
		/* nothing */	/* 3.value */
	},
	{
		((char)0),	/* 4.key */
		0,	/* 4.f_everused */
		0,	/* 4.f_valid */
		/* nothing */	/* 4.value */
	},
	{
		((char)0),	/* 5.key */
		0,	/* 5.f_everused */
		0,	/* 5.f_valid */
		/* nothing */	/* 5.value */
	},
	{
		((char)0),	/* 6.key */
		0,	/* 6.f_everused */
		0,	/* 6.f_valid */
		/* nothing */	/* 6.value */
	},
	{
		((char)0),	/* 7.key */
		0,	/* 7.f_everused */
		0,	/* 7.f_valid */
		/* nothing */	/* 7.value */
	},
} } };
/*/*/
union pypy_array9_len8u pypy_g_array_38 = { {
{
	(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member31)+196608L),	/* gcheader.tid */
},
	8, {
	{
		'k',	/* 0.key */
		1,	/* 0.f_everused */
		1,	/* 0.f_valid */
		/* nothing */	/* 0.value */
	},
	{
		((char)0),	/* 1.key */
		0,	/* 1.f_everused */
		0,	/* 1.f_valid */
		/* nothing */	/* 1.value */
	},
	{
		((char)0),	/* 2.key */
		0,	/* 2.f_everused */
		0,	/* 2.f_valid */
		/* nothing */	/* 2.value */
	},
	{
		'K',	/* 3.key */
		1,	/* 3.f_everused */
		1,	/* 3.f_valid */
		/* nothing */	/* 3.value */
	},
	{
		((char)0),	/* 4.key */
		0,	/* 4.f_everused */
		0,	/* 4.f_valid */
		/* nothing */	/* 4.value */
	},
	{
		((char)0),	/* 5.key */
		0,	/* 5.f_everused */
		0,	/* 5.f_valid */
		/* nothing */	/* 5.value */
	},
	{
		((char)0),	/* 6.key */
		0,	/* 6.f_everused */
		0,	/* 6.f_valid */
		/* nothing */	/* 6.value */
	},
	{
		((char)0),	/* 7.key */
		0,	/* 7.f_everused */
		0,	/* 7.f_valid */
		/* nothing */	/* 7.value */
	},
} } };
/*/*/
union pypy_array10_len8u pypy_g_array_39 = { {
{
	(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member32)+196608L),	/* gcheader.tid */
},
	8, {
	{
		0L,	/* 0.key */
		0,	/* 0.f_everused */
		/* nothing */	/* 0.value */
	},
	{
		0L,	/* 1.key */
		0,	/* 1.f_everused */
		/* nothing */	/* 1.value */
	},
	{
		2L,	/* 2.key */
		1,	/* 2.f_everused */
		/* nothing */	/* 2.value */
	},
	{
		3L,	/* 3.key */
		1,	/* 3.f_everused */
		/* nothing */	/* 3.value */
	},
	{
		0L,	/* 4.key */
		0,	/* 4.f_everused */
		/* nothing */	/* 4.value */
	},
	{
		0L,	/* 5.key */
		0,	/* 5.f_everused */
		/* nothing */	/* 5.value */
	},
	{
		0L,	/* 6.key */
		0,	/* 6.f_everused */
		/* nothing */	/* 6.value */
	},
	{
		0L,	/* 7.key */
		0,	/* 7.f_everused */
		/* nothing */	/* 7.value */
	},
} } };
/*/*/
union pypy_array9_len8u pypy_g_array_40 = { {
{
	(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member31)+196608L),	/* gcheader.tid */
},
	8, {
	{
		'k',	/* 0.key */
		1,	/* 0.f_everused */
		1,	/* 0.f_valid */
		/* nothing */	/* 0.value */
	},
	{
		((char)0),	/* 1.key */
		0,	/* 1.f_everused */
		0,	/* 1.f_valid */
		/* nothing */	/* 1.value */
	},
	{
		((char)0),	/* 2.key */
		0,	/* 2.f_everused */
		0,	/* 2.f_valid */
		/* nothing */	/* 2.value */
	},
	{
		'K',	/* 3.key */
		1,	/* 3.f_everused */
		1,	/* 3.f_valid */
		/* nothing */	/* 3.value */
	},
	{
		((char)0),	/* 4.key */
		0,	/* 4.f_everused */
		0,	/* 4.f_valid */
		/* nothing */	/* 4.value */
	},
	{
		((char)0),	/* 5.key */
		0,	/* 5.f_everused */
		0,	/* 5.f_valid */
		/* nothing */	/* 5.value */
	},
	{
		((char)0),	/* 6.key */
		0,	/* 6.f_everused */
		0,	/* 6.f_valid */
		/* nothing */	/* 6.value */
	},
	{
		((char)0),	/* 7.key */
		0,	/* 7.f_everused */
		0,	/* 7.f_valid */
		/* nothing */	/* 7.value */
	},
} } };
/*/*/
/***********************************************************/
