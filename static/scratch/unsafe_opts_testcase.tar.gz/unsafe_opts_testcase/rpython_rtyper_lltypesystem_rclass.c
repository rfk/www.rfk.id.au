/***********************************************************/
/***  Implementations                                    ***/

#define PYPY_FILE_NAME "rpython_rtyper_lltypesystem_rclass.c"
#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"
#include "src/g_include.h"

/*/*/
bool_t pypy_g_ll_issubclass__object_vtablePtr_object_vtablePtr(struct pypy_object_vtable0 *l_subcls_0, struct pypy_object_vtable0 *l_cls_0) {
	Signed l_v7283; Signed l_v7284; Signed l_v7285; bool_t l_v7282;
	goto block0;

    block0:
	l_v7283 = RPyField(l_cls_0, ov_subclassrange_min);
	l_v7284 = RPyField(l_subcls_0, ov_subclassrange_min);
	l_v7285 = RPyField(l_cls_0, ov_subclassrange_max);
	OP_INT_BETWEEN(l_v7283, l_v7284, l_v7285, l_v7282);
	goto block1;

    block1:
	RPY_DEBUG_RETURN();
	return l_v7282;
}
/*/*/
struct pypy_object_vtable0 *pypy_g_ll_type__objectPtr(struct pypy_object0 *l_obj_0) {
	struct pypy_object0 *l_v7287; struct pypy_object_vtable0 *l_v7286;
	goto block0;

    block0:
	l_v7287 = (struct pypy_object0 *)l_obj_0;
	l_v7286 = RPyField(l_v7287, o_typeptr);
	goto block1;

    block1:
	RPY_DEBUG_RETURN();
	return l_v7286;
}
/*/*/
/***********************************************************/
