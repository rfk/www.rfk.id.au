/***********************************************************/
/***  Implementations                                    ***/

#define PYPY_FILE_NAME "rpython_rtyper_exceptiondata.c"
#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"
#include "src/g_include.h"

/*/*/
void pypy_g_ll_raise_OSError__Signed(Signed l_errno_1) {
	Signed l_rawtotalsize_2; void* l_result_19; void* l_result_20;
	Signed l_v7050; Signed l_v7052; bool_t l_v7051; bool_t l_v7053;
	bool_t l_v7058; bool_t l_v7059; bool_t l_v7064; bool_t l_v7074;
	bool_t l_v7078; bool_t l_v7083;
	struct pypy_exceptions_OSError0 *l_v7049;
	struct pypy_header0 *l_v7061; struct pypy_object0 *l_v7065;
	struct pypy_object_vtable0 *l_v7068;
	struct pypy_object_vtable0 *l_v7073;
	struct pypy_object_vtable0 *l_v7077;
	struct pypy_object_vtable0 *l_v7082; void* l_v7054; void* l_v7056;
	void* l_v7057; void* l_v7060; void* l_v7063; void* l_v7076;
	void* l_v7081; void* l_v7086; void* l_v7087;
	goto block0;

    block0:
	OP_RAW_MALLOC_USAGE((0 + ROUND_UP_FOR_ALLOCATION(sizeof(struct pypy_exceptions_OSError0), 0L)), l_rawtotalsize_2);
	OP_INT_GT(l_rawtotalsize_2, 67583L, l_v7051);
	if (l_v7051) {
		goto block14;
	}
	goto block1;

    block1:
	OP_RAW_MALLOC_USAGE((sizeof(struct pypy_header0) + sizeof(void*)), l_v7052);
	OP_INT_LT(l_rawtotalsize_2, l_v7052, l_v7053);
	if (l_v7053) {
		l_v7050 = l_v7052;
		goto block2;
	}
	l_v7050 = (0 + ROUND_UP_FOR_ALLOCATION(sizeof(struct pypy_exceptions_OSError0), 0L));
	goto block2;

    block2:
	l_result_19 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	OP_ADR_ADD(l_result_19, l_v7050, l_v7054);
	(&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free = l_v7054;
	l_v7056 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	l_v7057 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_top;
	OP_ADR_GT(l_v7056, l_v7057, l_v7058);
	if (l_v7058) {
		goto block12;
	}
	l_result_20 = l_result_19;
	goto block3;

    block3:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v7059);
	if (l_v7059) {
		goto block10;
	}
	goto block4;

    block4:
	OP_ADR_ADD(l_result_20, 0, l_v7060);
	l_v7061 = (struct pypy_header0 *)l_result_20;
	RPyField(l_v7061, h_tid) = (GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member1)+0L);
	l_v7086 = l_v7060;
	goto block5;

    block5:
	l_v7063 = (void*)l_v7086;
	l_v7087 = l_v7063;
	goto block6;

    block6:
	l_v7049 = (struct pypy_exceptions_OSError0 *)l_v7087;
	l_v7064 = (l_v7049 != NULL);
	if (!l_v7064) {
		goto block9;
	}
	goto block7;

    block7:
	l_v7065 = (struct pypy_object0 *)l_v7049;
	RPyField(l_v7065, o_typeptr) = (&pypy_g_exceptions_OSError_vtable.ose_super.ee_super.se_super.e_super);
	RPyField(l_v7049, ose_inst_errno) = l_errno_1;
	l_v7068 = RPyField(l_v7065, o_typeptr);
	pypy_g_RPyRaiseException(l_v7068, l_v7065);
	PYPY_DEBUG_RECORD_TRACEBACK("ll_raise_OSError__Signed");
	goto block8;

    block8:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block9:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_raise_OSError__Signed");
	goto block8;

    block10:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v7073 = (&pypy_g_ExcData)->ed_exc_type;
	l_v7074 = (l_v7073 == NULL);
	if (!l_v7074) {
		goto block11;
	}
	goto block4;

    block11:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_raise_OSError__Signed");
	l_v7087 = NULL;
	goto block6;

    block12:
	l_v7076 = pypy_g_MiniMarkGC_collect_and_reserve((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_result_19, l_v7050);
	l_v7077 = (&pypy_g_ExcData)->ed_exc_type;
	l_v7078 = (l_v7077 == NULL);
	if (!l_v7078) {
		goto block13;
	}
	l_result_20 = l_v7076;
	goto block3;

    block13:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_raise_OSError__Signed");
	l_v7087 = NULL;
	goto block6;

    block14:
	RPyAssert(1, "'contains_weakptr' specified for a large object");
	l_v7081 = pypy_g_MiniMarkGC_external_malloc((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member1), 0L, 1);
	l_v7082 = (&pypy_g_ExcData)->ed_exc_type;
	l_v7083 = (l_v7082 == NULL);
	if (!l_v7083) {
		goto block15;
	}
	l_v7086 = l_v7081;
	goto block5;

    block15:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_raise_OSError__Signed");
	l_v7087 = NULL;
	goto block6;
}
/*/*/
/***********************************************************/
