/***********************************************************/
/***  Implementations                                    ***/

#define PYPY_FILE_NAME "rpython_rlib_entrypoint.c"
#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"
#include "src/g_include.h"

/*/*/
void pypy_g_rpython_startup_code(void) {
	goto block0;

    block0:
	RPython_StartupCode();
	goto block1;

    block1:
	RPY_DEBUG_RETURN();
	return /* nothing */;
}
/*/*/
/***********************************************************/
