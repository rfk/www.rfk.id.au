/***********************************************************/
/***  Non-function Implementations                       ***/

#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"

#include "src/g_include.h"

/*/*/
union pypy_rpy_string0_len6u pypy_g_rpy_string = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	-1316331381L,	/* hash */
	{
		6, {100,101,98,117,103,58}
	},
} };
/*/*/
union pypy_rpy_string0_len11u pypy_g_rpy_string_1 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	-1500746465L,	/* hash */
	{
		11, {104,101,108,108,111,32,119,111,114,108,100}
	},
} };
/*/*/
/***********************************************************/
