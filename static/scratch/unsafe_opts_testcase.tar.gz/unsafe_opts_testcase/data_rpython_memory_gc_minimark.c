/***********************************************************/
/***  Non-function Implementations                       ***/

#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"

#include "src/g_include.h"

/*/*/
struct pypy_rpython_memory_support_FreeList0 pypy_g_rpython_memory_support_FreeList = {
	{
		(&pypy_g_rpython_memory_support_FreeList_vtable.fl_super),	/* super.typeptr */
	},
	((struct pypy_AddressChunk0 *) NULL),	/* inst_free_list */
};
/*/*/
union pypy_rpy_string0_len15u pypy_g_rpy_string_2 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	2052763403L,	/* hash */
	{
		15, {80,89,80,89,95,71,67,95,78,85,82,83,69,82,89}
	},
} };
/*/*/
union pypy_rpy_string0_len23u pypy_g_rpy_string_3 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	1975438370L,	/* hash */
	{
		23, {
80,89,80,89,95,71,67,95,78,85,82,83,69,82,89,95,67,76,69,65,
78,85,80}
	},
} };
/*/*/
union pypy_rpy_string0_len21u pypy_g_rpy_string_4 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	1416638517L,	/* hash */
	{
		21, {
80,89,80,89,95,71,67,95,77,65,74,79,82,95,67,79,76,76,69,67,
84}
	},
} };
/*/*/
union pypy_rpy_string0_len14u pypy_g_rpy_string_5 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	83789771L,	/* hash */
	{
		14, {80,89,80,89,95,71,67,95,71,82,79,87,84,72}
	},
} };
/*/*/
union pypy_rpy_string0_len11u pypy_g_rpy_string_6 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	-1454010753L,	/* hash */
	{
		11, {80,89,80,89,95,71,67,95,77,73,78}
	},
} };
/*/*/
union pypy_rpy_string0_len11u pypy_g_rpy_string_7 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	-1462010767L,	/* hash */
	{
		11, {80,89,80,89,95,71,67,95,77,65,88}
	},
} };
/*/*/
union pypy_rpy_string0_len17u pypy_g_rpy_string_8 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	2065814400L,	/* hash */
	{
		17, {80,89,80,89,95,71,67,95,77,65,88,95,68,69,76,84,65}
	},
} };
/*/*/
union pypy_rpy_string0_len13u pypy_g_rpy_string_9 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	-593295564L,	/* hash */
	{
		13, {47,112,114,111,99,47,109,101,109,105,110,102,111}
	},
} };
/*/*/
union pypy_rpy_string0_len13u pypy_g_rpy_string_10 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	1116087008L,	/* hash */
	{
		13, {80,89,80,89,95,71,67,95,68,69,66,85,71}
	},
} };
/*/*/
union pypy_rpy_string0_len8u pypy_g_rpy_string_11 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	-1963963464L,	/* hash */
	{
		8, {103,99,45,100,101,98,117,103}
	},
} };
/*/*/
union pypy_rpy_string0_len9u pypy_g_rpy_string_12 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	691313946L,	/* hash */
	{
		9, {97,108,108,111,99,97,116,101,100}
	},
} };
/*/*/
union pypy_rpy_string0_len15u pypy_g_rpy_string_13 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	1622149153L,	/* hash */
	{
		15, {101,120,116,114,97,32,110,117,114,115,101,114,105,101,115}
	},
} };
/*/*/
union pypy_rpy_string0_len19u pypy_g_rpy_string_15 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	-923433913L,	/* hash */
	{
		19, {103,99,45,115,101,116,45,110,117,114,115,101,114,121,45,115,105,122,101}
	},
} };
/*/*/
union pypy_rpy_string0_len13u pypy_g_rpy_string_16 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	936677882L,	/* hash */
	{
		13, {110,117,114,115,101,114,121,32,115,105,122,101,58}
	},
} };
/*/*/
union pypy_rpy_string0_len8u pypy_g_rpy_string_25 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	-1107057110L,	/* hash */
	{
		8, {103,99,45,109,105,110,111,114}
	},
} };
/*/*/
union pypy_rpy_string0_len18u pypy_g_rpy_string_26 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	2120818637L,	/* hash */
	{
		18, {103,99,45,109,105,110,111,114,45,119,97,108,107,114,111,111,116,115}
	},
} };
/*/*/
union pypy_rpy_string0_len33u pypy_g_rpy_string_27 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	-2067102260L,	/* hash */
	{
		33, {
109,105,110,111,114,32,99,111,108,108,101,99,116,44,32,116,111,116,97,108,
32,109,101,109,111,114,121,32,117,115,101,100,58}
	},
} };
/*/*/
union pypy_rpy_string0_len22u pypy_g_rpy_string_36 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	-113505370L,	/* hash */
	{
		22, {
115,119,105,116,99,104,105,110,103,32,102,114,111,109,32,110,117,114,115,101,
114,121}
	},
} };
/*/*/
union pypy_rpy_string0_len10u pypy_g_rpy_string_37 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	2145015157L,	/* hash */
	{
		10, {116,111,32,110,117,114,115,101,114,121}
	},
} };
/*/*/
union pypy_rpy_string0_len4u pypy_g_rpy_string_38 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	931048223L,	/* hash */
	{
		4, {115,105,122,101}
	},
} };
/*/*/
union pypy_rpy_string0_len10u pypy_g_rpy_string_49 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	-879966903L,	/* hash */
	{
		10, {103,99,45,99,111,108,108,101,99,116}
	},
} };
/*/*/
union pypy_rpy_string0_len47u pypy_g_rpy_string_50 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	-1220411283L,	/* hash */
	{
		47, {
46,45,45,45,45,45,45,45,45,45,45,45,32,70,117,108,108,32,99,111,
108,108,101,99,116,105,111,110,32,45,45,45,45,45,45,45,45,45,45,45,
45,45,45,45,45,45,45}
	},
} };
/*/*/
union pypy_rpy_string0_len25u pypy_g_rpy_string_51 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	-46624413L,	/* hash */
	{
		25, {
124,32,117,115,101,100,32,98,101,102,111,114,101,32,99,111,108,108,101,99,
116,105,111,110,58}
	},
} };
/*/*/
union pypy_rpy_string0_len35u pypy_g_rpy_string_52 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	646320845L,	/* hash */
	{
		35, {
124,32,32,32,32,32,32,32,32,32,32,105,110,32,65,114,101,110,97,67,
111,108,108,101,99,116,105,111,110,58,32,32,32,32,32}
	},
} };
/*/*/
union pypy_rpy_string0_len5u pypy_g_rpy_string_53 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	836113516L,	/* hash */
	{
		5, {98,121,116,101,115}
	},
} };
/*/*/
union pypy_rpy_string0_len35u pypy_g_rpy_string_54 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	830657095L,	/* hash */
	{
		35, {
124,32,32,32,32,32,32,32,32,32,32,114,97,119,95,109,97,108,108,111,
99,101,100,58,32,32,32,32,32,32,32,32,32,32,32}
	},
} };
/*/*/
union pypy_rpy_string0_len24u pypy_g_rpy_string_55 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	-591912689L,	/* hash */
	{
		24, {
124,32,117,115,101,100,32,97,102,116,101,114,32,99,111,108,108,101,99,116,
105,111,110,58}
	},
} };
/*/*/
union pypy_rpy_string0_len35u pypy_g_rpy_string_56 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	1647621603L,	/* hash */
	{
		35, {
124,32,110,117,109,98,101,114,32,111,102,32,109,97,106,111,114,32,99,111,
108,108,101,99,116,115,58,32,32,32,32,32,32,32,32}
	},
} };
/*/*/
union pypy_rpy_string0_len47u pypy_g_rpy_string_57 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	1660575785L,	/* hash */
	{
		47, {
96,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,
45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,
45,45,45,45,45,45,45}
	},
} };
/*/*/
union pypy_rpy_string0_len31u pypy_g_rpy_string_58 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	1864168991L,	/* hash */
	{
		31, {
85,115,105,110,103,32,116,111,111,32,109,117,99,104,32,109,101,109,111,114,
121,44,32,97,98,111,114,116,105,110,103}
	},
} };
/*/*/
/***********************************************************/
