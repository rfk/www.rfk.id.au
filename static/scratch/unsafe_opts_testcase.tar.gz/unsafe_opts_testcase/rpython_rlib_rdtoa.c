/***********************************************************/
/***  Implementations                                    ***/

#define PYPY_FILE_NAME "rpython_rlib_rdtoa.c"
#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"
#include "src/g_include.h"

/*/*/
double pypy_g_strtod(struct pypy_rpy_string0 *l_input_1) {
	void* l_addr_array_4; char *l_ll_input_0; Signed l_maxsize_3;
	Unsigned l_toobig_4; Signed l_totalsize_19; Signed l_v6888;
	Signed l_v6894; Signed l_v6904; Signed l_v6905; Signed l_v6907;
	Signed l_v6915; Signed l_v6917; Signed l_v6920; Signed l_v6921;
	Signed l_v6922; Signed l_v6953; Signed l_v6954; Signed l_v6985;
	Signed l_v6989; Signed l_v6990; Unsigned l_v6991; bool_t l_v6897;
	bool_t l_v6900; bool_t l_v6902; bool_t l_v6906; bool_t l_v6908;
	bool_t l_v6916; bool_t l_v6918; bool_t l_v6919; bool_t l_v6923;
	bool_t l_v6929; bool_t l_v6930; bool_t l_v6937; bool_t l_v6950;
	bool_t l_v6955; bool_t l_v6957; bool_t l_v6960; bool_t l_v6972;
	bool_t l_v6979; bool_t l_v6983; bool_t l_v6987; bool_t l_v6994;
	char **l_v6889; char *l_v6903; double l_v6895; double l_v7003;
	struct pypy_array11 *l_v6896;
	struct pypy_exceptions_Exception0 *l_v7001;
	struct pypy_exceptions_Exception0 *l_v7007;
	struct pypy_header0 *l_v6931; struct pypy_header0 *l_v6952;
	struct pypy_object0 *l_v6967; struct pypy_object0 *l_v6996;
	struct pypy_object_vtable0 *l_v6901;
	struct pypy_object_vtable0 *l_v6949;
	struct pypy_object_vtable0 *l_v6959;
	struct pypy_object_vtable0 *l_v6971;
	struct pypy_object_vtable0 *l_v6978;
	struct pypy_object_vtable0 *l_v6982;
	struct pypy_object_vtable0 *l_v6986;
	struct pypy_object_vtable0 *l_v6993;
	struct pypy_object_vtable0 *l_v6997;
	struct pypy_object_vtable0 *l_v7006;
	struct pypy_rpy_string0 *l_v6890; struct pypy_rpy_string0 *l_v6958;
	struct pypy_rpy_string0 *l_v6970; void* l_v6891; void* l_v6892;
	void* l_v6893; void* l_v6898; void* l_v6909; void* l_v6912;
	void* l_v6925; void* l_v6927; void* l_v6928; void* l_v6933;
	void* l_v6934; void* l_v6936; void* l_v6939; void* l_v6940;
	void* l_v6942; void* l_v6944; void* l_v6945; void* l_v6947;
	void* l_v6951; void* l_v6961; void* l_v6964; void* l_v6981;
	void* l_v6992; void* l_v7004; void* l_v7005;
	goto block0;

    block0:
	l_v6898 = pypy_g__ll_malloc_varsize_no_length__Signed_Signed_Sign(1L, (0 + 0), sizeof(char *));
	OP_TRACK_ALLOC_START(l_v6898, /* nothing */);
	l_v6889 = (char **)l_v6898;
	l_v6900 = (l_v6889 != NULL);
	if (!l_v6900) {
		goto block40;
	}
	goto block1;

    block1:
	l_ll_input_0 = pypy_g_str2charp(l_input_1, 1);
	l_v6901 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6902 = (l_v6901 == NULL);
	if (!l_v6902) {
		goto block39;
	}
	goto block2;

    block2:
	l_v6895 = pypy_g__PyPy_dg_strtod__arrayPtr_arrayPtr_star_2(l_ll_input_0, l_v6889);
	l_v6903 = RPyBareItem(l_v6889, 0L);
	l_v6904 = (Signed)(l_v6903);
	l_v6905 = (Signed)(l_ll_input_0);
	OP_INT_SUB(l_v6904, l_v6905, l_v6888);
	OP_INT_EQ(l_v6888, 0L, l_v6906);
	if (l_v6906) {
		goto block6;
	}
	goto block3;

    block3:
	l_v6907 = RPyField(l_input_1, rs_chars).length;
	OP_INT_LT(l_v6888, l_v6907, l_v6908);
	if (l_v6908) {
		goto block6;
	}
	goto block4;

    block4:
	l_v6909 = (void*)l_ll_input_0;
	OP_TRACK_ALLOC_STOP(l_v6909, /* nothing */);
	OP_RAW_FREE(l_v6909, /* nothing */);
	l_v6912 = (void*)l_v6889;
	OP_TRACK_ALLOC_STOP(l_v6912, /* nothing */);
	OP_RAW_FREE(l_v6912, /* nothing */);
	l_v7003 = l_v6895;
	goto block5;

    block5:
	RPY_DEBUG_RETURN();
	return l_v7003;

    block6:
	OP_RAW_MALLOC_USAGE((0 + offsetof(struct pypy_array11, items) + 0), l_v6915);
	OP_INT_SUB(67583L, l_v6915, l_maxsize_3);
	OP_INT_LT(l_maxsize_3, 0L, l_v6916);
	if (l_v6916) {
		goto block37;
	}
	goto block7;

    block7:
	OP_RAW_MALLOC_USAGE(sizeof(struct pypy_rpy_string0 *), l_v6917);
	OP_INT_IS_TRUE(l_v6917, l_v6918);
	if (l_v6918) {
		goto block34;
	}
	goto block8;

    block8:
	l_v6894 = (0 + offsetof(struct pypy_array11, items) + (sizeof(struct pypy_rpy_string0 *) * 2));
	goto block9;

    block9:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v6919);
	if (l_v6919) {
		goto block32;
	}
	goto block10;

    block10:
	l_v6920 = ROUND_UP_FOR_ALLOCATION(l_v6894, 0L);
	l_totalsize_19 = l_v6920;
	goto block11;

    block11:
	OP_RAW_MALLOC_USAGE(l_totalsize_19, l_v6921);
	OP_RAW_MALLOC_USAGE((sizeof(struct pypy_header0) + sizeof(void*)), l_v6922);
	OP_INT_GE(l_v6921, l_v6922, l_v6923);
	RPyAssert(l_v6923, "malloc_varsize_clear(): totalsize < minimalsize");
	l_v6893 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	OP_ADR_ADD(l_v6893, l_totalsize_19, l_v6925);
	(&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free = l_v6925;
	l_v6927 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	l_v6928 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_top;
	OP_ADR_GT(l_v6927, l_v6928, l_v6929);
	if (l_v6929) {
		goto block30;
	}
	l_v6891 = l_v6893;
	goto block12;

    block12:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v6930);
	if (l_v6930) {
		goto block28;
	}
	goto block13;

    block13:
	l_v6931 = (struct pypy_header0 *)l_v6891;
	RPyField(l_v6931, h_tid) = (GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member27)+0L);
	OP_ADR_ADD(l_v6891, 0, l_v6933);
	OP_ADR_ADD(l_v6933, offsetof(struct pypy_array11, length), l_v6934);
	((Signed *) (((char *)l_v6934) + 0))[0] = 2L;
	l_v7004 = l_v6933;
	goto block14;

    block14:
	l_v6936 = (void*)l_v7004;
	l_v7005 = l_v6936;
	goto block15;

    block15:
	l_v6896 = (struct pypy_array11 *)l_v7005;
	l_v6937 = (l_v6896 != NULL);
	if (!l_v6937) {
		goto block27;
	}
	goto block16;

    block16:
	RPyItem(l_v6896, 0L) = (&pypy_g_rpy_string_59.b);
	l_v6939 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v6939, sizeof(void*), l_v6940);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v6940;
	l_v6942 = (void*)l_v6896;
	((void* *) (((char *)l_v6939) + 0))[0] = l_v6942;
	l_v6890 = pypy_g_ll_int2dec__Signed(l_v6888);
	l_v6944 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v6944, sizeof(void*), l_v6945);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v6945;
	l_v6947 = ((void* *) (((char *)l_v6945) + 0))[0];
	l_v6896 = l_v6947; /* for moving GCs */
	l_v6949 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6950 = (l_v6949 == NULL);
	if (!l_v6950) {
		goto block26;
	}
	goto block17;

    block17:
	l_v6892 = (void*)l_v6890;
	l_addr_array_4 = (void*)l_v6896;
	OP_ADR_SUB(l_addr_array_4, 0, l_v6951);
	l_v6952 = (struct pypy_header0 *)l_v6951;
	l_v6953 = RPyField(l_v6952, h_tid);
	OP_INT_AND(l_v6953, 65536L, l_v6954);
	OP_INT_IS_TRUE(l_v6954, l_v6955);
	if (l_v6955) {
		goto block25;
	}
	goto block18;

    block18:
	RPyItem(l_v6896, 1L) = l_v6890;
	OP_INT_IS_TRUE(0 /* we are not jitted here */, l_v6957);
	if (l_v6957) {
		goto block23;
	}
	goto block19;

    block19:
	l_v6958 = pypy_g_ll_join_strs__v153___simple_call__function_l(2L, l_v6896);
	l_v6959 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6960 = (l_v6959 == NULL);
	if (!l_v6960) {
		goto block22;
	}
	goto block20;

    block20:
	l_v6961 = (void*)l_ll_input_0;
	OP_TRACK_ALLOC_STOP(l_v6961, /* nothing */);
	OP_RAW_FREE(l_v6961, /* nothing */);
	l_v7007 = (&pypy_g_exceptions_ValueError.ve_super.se_super);
	l_v7006 = (&pypy_g_exceptions_ValueError_vtable.ve_super.se_super.e_super);
	goto block21;

    block21:
	l_v6964 = (void*)l_v6889;
	OP_TRACK_ALLOC_STOP(l_v6964, /* nothing */);
	OP_RAW_FREE(l_v6964, /* nothing */);
	l_v6967 = (struct pypy_object0 *)l_v7007;
	pypy_g_RPyReRaiseException(l_v7006, l_v6967);
	l_v7003 = -1.0;
	goto block5;

    block22:
	PYPY_DEBUG_RECORD_TRACEBACK("strtod");
	l_v7003 = -1.0;
	goto block5;

    block23:
	l_v6970 = pypy_g_ll_join_strs__v161___simple_call__function_l(2L, l_v6896);
	l_v6971 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6972 = (l_v6971 == NULL);
	if (!l_v6972) {
		goto block24;
	}
	goto block20;

    block24:
	PYPY_DEBUG_RECORD_TRACEBACK("strtod");
	l_v7003 = -1.0;
	goto block5;

    block25:
	pypy_g_remember_young_pointer_from_array2(l_addr_array_4, 1L);
	goto block18;

    block26:
	PYPY_DEBUG_RECORD_TRACEBACK("strtod");
	l_v7003 = -1.0;
	goto block5;

    block27:
	PYPY_DEBUG_RECORD_TRACEBACK("strtod");
	l_v7003 = -1.0;
	goto block5;

    block28:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v6978 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6979 = (l_v6978 == NULL);
	if (!l_v6979) {
		goto block29;
	}
	goto block13;

    block29:
	PYPY_DEBUG_RECORD_TRACEBACK("strtod");
	l_v7005 = NULL;
	goto block15;

    block30:
	l_v6981 = pypy_g_MiniMarkGC_collect_and_reserve((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_v6893, l_totalsize_19);
	l_v6982 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6983 = (l_v6982 == NULL);
	if (!l_v6983) {
		goto block31;
	}
	l_v6891 = l_v6981;
	goto block12;

    block31:
	PYPY_DEBUG_RECORD_TRACEBACK("strtod");
	l_v7005 = NULL;
	goto block15;

    block32:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v6985 = (Signed)0;
	l_v6986 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6987 = (l_v6986 == NULL);
	if (!l_v6987) {
		goto block33;
	}
	l_totalsize_19 = l_v6985;
	goto block11;

    block33:
	PYPY_DEBUG_RECORD_TRACEBACK("strtod");
	l_v7005 = NULL;
	goto block15;

    block34:
	OP_RAW_MALLOC_USAGE(sizeof(struct pypy_rpy_string0 *), l_v6989);
	OP_INT_FLOORDIV(l_maxsize_3, l_v6989, l_v6990);
	OP_CAST_INT_TO_UINT(l_v6990, l_v6991);
	OP_UINT_ADD(l_v6991, 1UL, l_toobig_4);
	goto block35;

    block35:
	OP_UINT_GE(2UL, l_toobig_4, l_v6897);
	goto block36;

    block36:
	if (l_v6897) {
		goto block37;
	}
	l_v6894 = (0 + offsetof(struct pypy_array11, items) + (sizeof(struct pypy_rpy_string0 *) * 2));
	goto block9;

    block37:
	l_v6992 = pypy_g_MiniMarkGC_external_malloc((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member27), 2L, 1);
	l_v6993 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6994 = (l_v6993 == NULL);
	if (!l_v6994) {
		goto block38;
	}
	l_v7004 = l_v6992;
	goto block14;

    block38:
	PYPY_DEBUG_RECORD_TRACEBACK("strtod");
	l_v7005 = NULL;
	goto block15;

    block39:
	l_v6996 = (&pypy_g_ExcData)->ed_exc_value;
	l_v6997 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("strtod", l_v6997, l_v6997 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_v6997 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	l_v7001 = (struct pypy_exceptions_Exception0 *)l_v6996;
	l_v7007 = l_v7001;
	l_v7006 = l_v6997;
	goto block21;

    block40:
	PYPY_DEBUG_RECORD_TRACEBACK("strtod");
	l_v7003 = -1.0;
	goto block5;
}
/*/*/
/***********************************************************/
