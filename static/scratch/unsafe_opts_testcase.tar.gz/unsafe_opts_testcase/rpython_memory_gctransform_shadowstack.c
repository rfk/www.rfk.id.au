/***********************************************************/
/***  Implementations                                    ***/

#define PYPY_FILE_NAME "rpython_memory_gctransform_shadowstack.c"
#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"
#include "src/g_include.h"

/*/*/
void* pypy_g_incr_stack(Signed l_n_0) {
	Signed l_v6637; void* l_v6636; void* l_v6638;
	goto block0;

    block0:
	l_v6636 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_INT_MUL(l_n_0, sizeof(void*), l_v6637);
	OP_ADR_ADD(l_v6636, l_v6637, l_v6638);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v6638;
	goto block1;

    block1:
	RPY_DEBUG_RETURN();
	return l_v6636;
}
/*/*/
void* pypy_g_decr_stack(Signed l_n_1) {
	Signed l_v6642; void* l_v6640; void* l_v6641;
	goto block0;

    block0:
	l_v6641 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_INT_MUL(l_n_1, sizeof(void*), l_v6642);
	OP_ADR_SUB(l_v6641, l_v6642, l_v6640);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v6640;
	goto block1;

    block1:
	RPY_DEBUG_RETURN();
	return l_v6640;
}
/*/*/
void pypy_g_walk_stack_root(void (*l_callback_21)(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *, void*), void* l_start_13, void* l_end_0) {
	void* l_addr_16; bool_t l_v6645; bool_t l_v6647; bool_t l_v6648;
	bool_t l_v6651; struct pypy_object_vtable0 *l_v6650; void* l_v6644;
	void* l_v6646;
	goto block0;

    block0:
	l_addr_16 = l_end_0;
	goto block1;

    block1:
	while (1) {
		OP_ADR_NE(l_addr_16, l_start_13, l_v6645);
		if (!l_v6645) break;
		goto block3;
	  block1_back: ;
	}
	goto block2;

    block2:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block3:
	OP_ADR_SUB(l_addr_16, sizeof(void*), l_v6644);
	l_v6646 = ((void* *) (((char *)l_v6644) + 0))[0];
	OP_ADR_NE(l_v6646, NULL, l_v6647);
	if (l_v6647) {
		goto block4;
	}
	l_addr_16 = l_v6644;
	goto block1_back;

    block4:
	OP_ADR_EQ(l_v6644, NULL, l_v6648);
	if (l_v6648) {
		goto block2;
	}
	goto block5;

    block5:
	l_callback_21((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_v6644);
	l_v6650 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6651 = (l_v6650 == NULL);
	if (!l_v6651) {
		goto block6;
	}
	l_addr_16 = l_v6644;
	goto block1;

    block6:
	PYPY_DEBUG_RECORD_TRACEBACK("walk_stack_root");
	goto block2;
}
/*/*/
/***********************************************************/
