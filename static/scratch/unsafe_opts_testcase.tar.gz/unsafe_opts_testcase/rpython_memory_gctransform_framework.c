/***********************************************************/
/***  Implementations                                    ***/

#define PYPY_FILE_NAME "rpython_memory_gctransform_framework.c"
#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"
#include "src/g_include.h"

/*/*/
void pypy_g_frameworkgc_setup(void) {
	bool_t l_v6594; bool_t l_v6601; bool_t l_v6607;
	struct pypy_object_vtable0 *l_v6600; void* l_v6593; void* l_v6595;
	void* l_v6604; void* l_v6606;
	goto block0;

    block0:
	l_v6593 = (&pypy_g_rpython_memory_gctransform_shadowstack_ShadowSta)->ssp_inst_unused_full_stack;
	OP_ADR_EQ(l_v6593, NULL, l_v6594);
	if (l_v6594) {
		goto block5;
	}
	goto block1;

    block1:
	l_v6595 = (&pypy_g_rpython_memory_gctransform_shadowstack_ShadowSta)->ssp_inst_unused_full_stack;
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_base = l_v6595;
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v6595;
	(&pypy_g_rpython_memory_gctransform_shadowstack_ShadowSta)->ssp_inst_unused_full_stack = NULL;
	pypy_g_MiniMarkGC_setup((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC));
	l_v6600 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6601 = (l_v6600 == NULL);
	if (!l_v6601) {
		goto block4;
	}
	goto block2;

    block2:
	pypy_g_MiniMarkGC_post_setup((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC));
	goto block3;

    block3:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block4:
	PYPY_DEBUG_RECORD_TRACEBACK("frameworkgc_setup");
	goto block3;

    block5:
	OP_RAW_MALLOC((sizeof(void*) * 163840), l_v6604, void *);
	(&pypy_g_rpython_memory_gctransform_shadowstack_ShadowSta)->ssp_inst_unused_full_stack = l_v6604;
	l_v6606 = (&pypy_g_rpython_memory_gctransform_shadowstack_ShadowSta)->ssp_inst_unused_full_stack;
	OP_ADR_EQ(l_v6606, NULL, l_v6607);
	if (l_v6607) {
		goto block6;
	}
	goto block1;

    block6:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("frameworkgc_setup");
	goto block3;
}
/*/*/
void pypy_g_walk_roots(void (*l_collect_stack_root_1)(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *, void*), void (*l_collect_static_in_prebuilt_nongc_1)(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *, void*), void (*l_collect_static_in_prebuilt_gc_1)(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *, void*)) {
	void* l_addr_14; void* l_addr_15; void* l_end_6; void* l_end_7;
	bool_t l_v6614; bool_t l_v6615; bool_t l_v6620; bool_t l_v6622;
	bool_t l_v6626; bool_t l_v6629; bool_t l_v6633;
	struct pypy_object_vtable0 *l_v6625;
	struct pypy_object_vtable0 *l_v6632; void* l_v6611; void* l_v6612;
	void* l_v6613; void* l_v6616; void* l_v6617; void* l_v6619;
	void* l_v6621; void* l_v6623; void* l_v6628; void* l_v6630;
	goto block0;

    block0:
	l_v6613 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_static_root_start;
	l_end_7 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_static_root_nongcend;
	l_addr_15 = l_v6613;
	goto block1;

    block1:
	while (1) {
		OP_ADR_NE(l_addr_15, l_end_7, l_v6614);
		if (!l_v6614) break;
		goto block11;
	  block1_back: ;
	}
	goto block2;

    block2:
	l_v6615 = (l_collect_static_in_prebuilt_gc_1 != NULL);
	if (l_v6615) {
		goto block5;
	}
	goto block3;

    block3:
	l_v6616 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_base;
	l_v6617 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	pypy_g_walk_stack_root(l_collect_stack_root_1, l_v6616, l_v6617);
	goto block4;

    block4:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block5:
	l_v6619 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_static_root_nongcend;
	l_end_6 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_static_root_end;
	l_addr_14 = l_v6619;
	goto block6;

    block6:
	while (1) {
		OP_ADR_NE(l_addr_14, l_end_6, l_v6620);
		if (!l_v6620) break;
		goto block7;
	  block6_back: ;
	}
	goto block3;

    block7:
	l_v6611 = ((void* *) (((char *)l_addr_14) + 0))[0];
	l_v6621 = ((void* *) (((char *)l_v6611) + 0))[0];
	OP_ADR_NE(l_v6621, NULL, l_v6622);
	if (l_v6622) {
		goto block9;
	}
	goto block8;

    block8:
	OP_ADR_ADD(l_addr_14, sizeof(void*), l_v6623);
	l_addr_14 = l_v6623;
	goto block6_back;

    block9:
	l_collect_static_in_prebuilt_gc_1((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_v6611);
	l_v6625 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6626 = (l_v6625 == NULL);
	if (!l_v6626) {
		goto block10;
	}
	goto block8;

    block10:
	PYPY_DEBUG_RECORD_TRACEBACK("walk_roots");
	goto block4;

    block11:
	l_v6612 = ((void* *) (((char *)l_addr_15) + 0))[0];
	l_v6628 = ((void* *) (((char *)l_v6612) + 0))[0];
	OP_ADR_NE(l_v6628, NULL, l_v6629);
	if (l_v6629) {
		goto block13;
	}
	goto block12;

    block12:
	OP_ADR_ADD(l_addr_15, sizeof(void*), l_v6630);
	l_addr_15 = l_v6630;
	goto block1_back;

    block13:
	l_collect_static_in_prebuilt_nongc_1((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_v6612);
	l_v6632 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6633 = (l_v6632 == NULL);
	if (!l_v6633) {
		goto block14;
	}
	goto block12;

    block14:
	PYPY_DEBUG_RECORD_TRACEBACK("walk_roots");
	goto block4;
}
/*/*/
/***********************************************************/
