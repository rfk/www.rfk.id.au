/***********************************************************/
/***  Implementations                                    ***/

#define PYPY_FILE_NAME "rpython_translator_c_extfunc.c"
#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"
#include "src/g_include.h"

/*/*/
void pypy_g__RPyListOfString_SetItem__listPtr_Signed_rpy_str(struct pypy_list0 *l_l_8, Signed l_index_0, struct pypy_rpy_string0 *l_newstring_0) {
	goto block0;

    block0:
	pypy_g_ll_setitem_nonneg__dum_nocheckConst_listPtr_Sign(l_l_8, l_index_0, l_newstring_0);
	goto block1;

    block1:
	RPY_DEBUG_RETURN();
	return /* nothing */;
}
/*/*/
struct pypy_rpy_string0 *pypy_g__RPyListOfString_GetItem__listPtr_Signed(struct pypy_list0 *l_l_9, Signed l_index_1) {
	struct pypy_rpy_string0 *l_v9931;
	goto block0;

    block0:
	l_v9931 = pypy_g_ll_getitem_fast__listPtr_Signed(l_l_9, l_index_1);
	goto block1;

    block1:
	RPY_DEBUG_RETURN();
	return l_v9931;
}
/*/*/
struct pypy_rpy_string0 *pypy_g_RPyString_New__Signed(Signed l_length_9) {
	struct pypy_rpy_string0 *l_v9932;
	goto block0;

    block0:
	l_v9932 = pypy_g_mallocstr__Signed(l_length_9);
	goto block1;

    block1:
	RPY_DEBUG_RETURN();
	return l_v9932;
}
/*/*/
struct pypy_list0 *pypy_g__RPyListOfString_New__Signed(Signed l_length_10) {
	struct pypy_list0 *l_v9933;
	goto block0;

    block0:
	l_v9933 = pypy_g_ll_newlist__GcStruct_listLlT_Signed(l_length_10);
	goto block1;

    block1:
	RPY_DEBUG_RETURN();
	return l_v9933;
}
/*/*/
Signed pypy_g__RPyListOfString_Length__listPtr(struct pypy_list0 *l_l_10) {
	Signed l_v9934;
	goto block0;

    block0:
	l_v9934 = pypy_g_ll_length__listPtr(l_l_10);
	goto block1;

    block1:
	RPY_DEBUG_RETURN();
	return l_v9934;
}
/*/*/
/***********************************************************/
