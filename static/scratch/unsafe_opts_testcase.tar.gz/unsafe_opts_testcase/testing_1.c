#include "common_header.h"

#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"

/***********************************************************/
/***  Implementations                                    ***/

#define PYPY_FILE_NAME "testing_1.c"
#include "src/g_include.h"

/* data_rpython_flowspace_specialcase.c */
/* data_rpython_memory_gc_env.c */
/* data_rpython_memory_gc_minimark.c */
/* data_rpython_memory_gctransform_framework.c */
/* data_rpython_rlib_rdtoa.c */
/* data_rpython_rtyper_lltypesystem_rdict.c */
/* data_rpython_rtyper_lltypesystem_rlist.c */
/* data_rpython_rtyper_lltypesystem_rstr.c */
/* data_rpython_translator_goal_targetnopstandalone.c */
/* nonfuncnodes.c */
/* data_rpython_memory_gc_minimark_1.c */
/* data_rpython_rlib_entrypoint.c */
/* data_rpython_rtyper_lltypesystem_rffi.c */
/* data_rpython_rtyper_module_ll_os.c */
/* implement.c */
/* rpython_flowspace_specialcase.c */
/* rpython_memory_gc_base.c */
/* rpython_memory_gc_env.c */
/* rpython_memory_gc_minimark.c */
/* rpython_memory_gc_minimarkpage.c */
/* rpython_memory_gctransform_framework.c */
/* rpython_memory_gctransform_shadowstack.c */
/* rpython_memory_gctransform_transform.c */
/* rpython_memory_lldict.c */
/* rpython_memory_support.c */
/* rpython_rlib_entrypoint.c */
/* rpython_rlib_rdtoa.c */
/* rpython_rlib_rgc.c */
/* rpython_rlib_rposix.c */
/* rpython_rtyper_exceptiondata.c */
/* rpython_rtyper_lltypesystem_ll_str.c */
/* rpython_rtyper_lltypesystem_rbuilder.c */
/* rpython_rtyper_lltypesystem_rclass.c */
/* rpython_rtyper_lltypesystem_rdict.c */
/* rpython_rtyper_lltypesystem_rffi.c */
/* rpython_rtyper_lltypesystem_rlist.c */
/* rpython_rtyper_lltypesystem_rstr.c */
/* rpython_rtyper_module_ll_os.c */
/* rpython_rtyper_module_ll_os_environ.c */
/* rpython_rtyper_rlist.c */
/* rpython_rtyper_rstr.c */
/* rpython_translator_c_extfunc.c */
/* rpython_translator_exceptiontransform.c */
/* rpython_translator_goal_targetnopstandalone.c */

char *RPython_StartupCode(void) {
	char *error = NULL;
	pypy_g_frameworkgc_setup();
	return error;
}
