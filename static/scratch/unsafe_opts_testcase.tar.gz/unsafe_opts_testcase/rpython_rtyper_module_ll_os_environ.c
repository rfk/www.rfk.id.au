/***********************************************************/
/***  Implementations                                    ***/

#define PYPY_FILE_NAME "rpython_rtyper_module_ll_os_environ.c"
#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"
#include "src/g_include.h"

/*/*/
struct pypy_rpy_string0 *pypy_g_ll_os_ll_os_getenv(struct pypy_rpy_string0 *l_name_0) {
	Signed l_v9845; Signed l_v9846; Signed l_v9850; Signed l_v9855;
	bool_t l_v9844; bool_t l_v9849; bool_t l_v9859; bool_t l_v9860;
	bool_t l_v9866; bool_t l_v9871; char *l_v9839; char *l_v9842;
	char *l_v9843; struct pypy_exceptions_Exception0 *l_v9838;
	struct pypy_object0 *l_v9867; struct pypy_object0 *l_v9872;
	struct pypy_object_vtable0 *l_v9840;
	struct pypy_object_vtable0 *l_v9865;
	struct pypy_rpy_string0 *l_v9841; struct pypy_rpy_string0 *l_v9864;
	struct pypy_rpy_string0 *l_v9878; void* l_v9847; void* l_v9851;
	void* l_v9852; void* l_v9853; void* l_v9854; void* l_v9861;
	void* l_v9874;
	goto block0;

    block0:
	l_v9844 = (l_name_0 == NULL);
	if (l_v9844) {
		l_v9839 = ((char *) NULL);
		goto block3;
	}
	goto block1;

    block1:
	l_v9845 = RPyField(l_name_0, rs_chars).length;
	OP_INT_ADD(l_v9845, 1L, l_v9846);
	l_v9847 = pypy_g__ll_malloc_varsize_no_length__Signed_Signed_Sign(l_v9846, (0 + 0), sizeof(char));
	OP_TRACK_ALLOC_START(l_v9847, /* nothing */);
	l_v9843 = (char *)l_v9847;
	l_v9849 = (l_v9843 != NULL);
	if (!l_v9849) {
		goto block11;
	}
	goto block2;

    block2:
	l_v9850 = RPyField(l_name_0, rs_chars).length;
	l_v9851 = (void*)l_name_0;
	OP_ADR_ADD(l_v9851, (offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v9852);
	l_v9853 = (void*)l_v9843;
	OP_ADR_ADD(l_v9853, 0, l_v9854);
	OP_INT_MUL(sizeof(char), l_v9850, l_v9855);
	OP_RAW_MEMCOPY(l_v9852, l_v9854, l_v9855, /* nothing */);
	/* kept alive: l_v9852 */
	RPyBareItem(l_v9843, l_v9850) = ((char)0);
	l_v9839 = l_v9843;
	goto block3;

    block3:
	l_v9842 = pypy_g_getenv__arrayPtr_star_1(l_v9839);
	l_v9859 = (l_v9842 != NULL);
	if (l_v9859) {
		goto block7;
	}
	l_v9841 = ((struct pypy_rpy_string0 *) NULL);
	goto block4;

    block4:
	l_v9860 = (l_v9839 != NULL);
	if (l_v9860) {
		goto block6;
	}
	l_v9878 = l_v9841;
	goto block5;

    block5:
	RPY_DEBUG_RETURN();
	return l_v9878;

    block6:
	l_v9861 = (void*)l_v9839;
	OP_TRACK_ALLOC_STOP(l_v9861, /* nothing */);
	OP_RAW_FREE(l_v9861, /* nothing */);
	l_v9878 = l_v9841;
	goto block5;

    block7:
	l_v9864 = pypy_g_charp2str(l_v9842);
	l_v9865 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9866 = (l_v9865 == NULL);
	if (!l_v9866) {
		goto block8;
	}
	l_v9841 = l_v9864;
	goto block4;

    block8:
	l_v9867 = (&pypy_g_ExcData)->ed_exc_value;
	l_v9840 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("ll_os_ll_os_getenv", l_v9840, l_v9840 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_v9840 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	l_v9838 = (struct pypy_exceptions_Exception0 *)l_v9867;
	l_v9871 = (l_v9839 != NULL);
	if (l_v9871) {
		goto block10;
	}
	goto block9;

    block9:
	l_v9872 = (struct pypy_object0 *)l_v9838;
	pypy_g_RPyReRaiseException(l_v9840, l_v9872);
	l_v9878 = ((struct pypy_rpy_string0 *) NULL);
	goto block5;

    block10:
	l_v9874 = (void*)l_v9839;
	OP_TRACK_ALLOC_STOP(l_v9874, /* nothing */);
	OP_RAW_FREE(l_v9874, /* nothing */);
	goto block9;

    block11:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_os_ll_os_getenv");
	l_v9878 = ((struct pypy_rpy_string0 *) NULL);
	goto block5;
}
/*/*/
/***********************************************************/
