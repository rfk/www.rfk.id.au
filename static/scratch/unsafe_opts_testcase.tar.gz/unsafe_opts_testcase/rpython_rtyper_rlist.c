/***********************************************************/
/***  Implementations                                    ***/

#define PYPY_FILE_NAME "rpython_rtyper_rlist.c"
#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"
#include "src/g_include.h"

/*/*/
void pypy_g_ll_setitem_nonneg__dum_nocheckConst_listPtr_Sign(struct pypy_list0 *l_l_11, Signed l_index_2, struct pypy_rpy_string0 *l_newitem_0) {
	bool_t l_v9879; struct pypy_list0 *l_v9881;
	goto block0;

    block0:
	OP_INT_GE(l_index_2, 0L, l_v9879);
	RPyAssert(l_v9879, "unexpectedly negative list setitem index");
	l_v9881 = l_l_11;
	pypy_g_ll_setitem_fast__listPtr_Signed_rpy_stringPtr(l_v9881, l_index_2, l_newitem_0);
	goto block1;

    block1:
	RPY_DEBUG_RETURN();
	return /* nothing */;
}
/*/*/
/***********************************************************/
