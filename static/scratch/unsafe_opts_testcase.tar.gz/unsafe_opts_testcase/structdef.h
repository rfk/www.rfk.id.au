/***********************************************************/
/***  Structure definitions                              ***/

#ifndef _PYPY_STRUCTDEF_H
#define _PYPY_STRUCTDEF_H
struct pypy_AddressChunk0;
struct pypy_ArenaReference0;
struct pypy_DICT0;
struct pypy_ENTRY0;
struct pypy_ExcData0;
struct pypy_PageHeader0;
struct pypy_header0;
struct pypy_array0;
struct pypy_array1;
struct pypy_dictentry2;
struct pypy_array10;
struct pypy_array10_len8;
struct pypy_array11;
struct pypy_array12;
struct pypy_array1_len2;
struct pypy_array2;
struct pypy_array2_len10;
struct pypy_array2_len11;
struct pypy_array2_len12;
struct pypy_array2_len13;
struct pypy_array2_len14;
struct pypy_array2_len15;
struct pypy_array2_len16;
struct pypy_array2_len18;
struct pypy_array2_len19;
struct pypy_array2_len20;
struct pypy_array2_len531;
struct pypy_array2_len7;
struct pypy_array2_len8;
struct pypy_array2_len9;
struct pypy_array3;
struct pypy_array3_len0;
struct pypy_array4;
struct pypy_array4_len0;
struct pypy_array4_len1;
struct pypy_array4_len10;
struct pypy_array4_len11;
struct pypy_array4_len12;
struct pypy_array4_len13;
struct pypy_array4_len14;
struct pypy_array4_len15;
struct pypy_array4_len17;
struct pypy_array4_len18;
struct pypy_array4_len19;
struct pypy_array4_len2;
struct pypy_array4_len21;
struct pypy_array4_len22;
struct pypy_array4_len23;
struct pypy_array4_len24;
struct pypy_array4_len25;
struct pypy_array4_len26;
struct pypy_array4_len27;
struct pypy_array4_len3;
struct pypy_array4_len31;
struct pypy_array4_len33;
struct pypy_array4_len35;
struct pypy_array4_len4;
struct pypy_array4_len47;
struct pypy_array4_len5;
struct pypy_array4_len6;
struct pypy_array4_len60;
struct pypy_array4_len7;
struct pypy_array4_len8;
struct pypy_array4_len86;
struct pypy_array4_len89;
struct pypy_array4_len9;
struct pypy_array5;
struct pypy_array6;
struct pypy_array6_len0;
struct pypy_dictentry0;
struct pypy_array7;
struct pypy_array7_len8;
struct pypy_array8;
struct pypy_array8_len0;
struct pypy_array8_len1;
struct pypy_array8_len5;
struct pypy_dictentry1;
struct pypy_array9;
struct pypy_array9_len8;
struct pypy_dicttable0;
struct pypy_dicttable1;
struct pypy_dicttable2;
struct pypy_dummy0;
struct pypy_object0;
struct pypy_exceptions_Exception0;
struct pypy_exceptions_StandardError0;
struct pypy_exceptions_ArithmeticError0;
struct pypy_object_vtable0;
struct pypy_exceptions_Exception_vtable0;
struct pypy_exceptions_StandardError_vtable0;
struct pypy_exceptions_ArithmeticError_vtable0;
struct pypy_exceptions_AssertionError0;
struct pypy_exceptions_AssertionError_vtable0;
struct pypy_exceptions_EnvironmentError0;
struct pypy_exceptions_EnvironmentError_vtable0;
struct pypy_exceptions_IOError0;
struct pypy_exceptions_IOError_vtable0;
struct pypy_exceptions_LookupError0;
struct pypy_exceptions_IndexError0;
struct pypy_exceptions_LookupError_vtable0;
struct pypy_exceptions_IndexError_vtable0;
struct pypy_exceptions_KeyError0;
struct pypy_exceptions_KeyError_vtable0;
struct pypy_exceptions_MemoryError0;
struct pypy_exceptions_MemoryError_vtable0;
struct pypy_exceptions_RuntimeError0;
struct pypy_exceptions_NotImplementedError0;
struct pypy_exceptions_RuntimeError_vtable0;
struct pypy_exceptions_NotImplementedError_vtable0;
struct pypy_exceptions_OSError0;
struct pypy_exceptions_OSError_vtable0;
struct pypy_exceptions_OverflowError0;
struct pypy_exceptions_OverflowError_vtable0;
struct pypy_exceptions_StopIteration0;
struct pypy_exceptions_StopIteration_vtable0;
struct pypy_exceptions_TypeError0;
struct pypy_exceptions_TypeError_vtable0;
struct pypy_exceptions_ValueError0;
struct pypy_exceptions_UnicodeError0;
struct pypy_exceptions_UnicodeDecodeError0;
struct pypy_exceptions_ValueError_vtable0;
struct pypy_exceptions_UnicodeError_vtable0;
struct pypy_exceptions_UnicodeDecodeError_vtable0;
struct pypy_exceptions_UnicodeEncodeError0;
struct pypy_exceptions_UnicodeEncodeError_vtable0;
struct pypy_exceptions_ZeroDivisionError0;
struct pypy_exceptions_ZeroDivisionError_vtable0;
struct pypy_forwarding_stub0;
struct pypy_list0;
struct pypy_list1;
struct pypy_nongcobject0;
struct pypy_rpy_string0;
struct pypy_rpy_string0_len0;
struct pypy_rpy_string0_len1;
struct pypy_rpy_string0_len10;
struct pypy_rpy_string0_len11;
struct pypy_rpy_string0_len12;
struct pypy_rpy_string0_len13;
struct pypy_rpy_string0_len14;
struct pypy_rpy_string0_len15;
struct pypy_rpy_string0_len17;
struct pypy_rpy_string0_len18;
struct pypy_rpy_string0_len19;
struct pypy_rpy_string0_len2;
struct pypy_rpy_string0_len21;
struct pypy_rpy_string0_len22;
struct pypy_rpy_string0_len23;
struct pypy_rpy_string0_len24;
struct pypy_rpy_string0_len25;
struct pypy_rpy_string0_len26;
struct pypy_rpy_string0_len27;
struct pypy_rpy_string0_len3;
struct pypy_rpy_string0_len31;
struct pypy_rpy_string0_len33;
struct pypy_rpy_string0_len35;
struct pypy_rpy_string0_len4;
struct pypy_rpy_string0_len47;
struct pypy_rpy_string0_len5;
struct pypy_rpy_string0_len6;
struct pypy_rpy_string0_len60;
struct pypy_rpy_string0_len7;
struct pypy_rpy_string0_len8;
struct pypy_rpy_string0_len86;
struct pypy_rpy_string0_len89;
struct pypy_rpy_string0_len9;
struct pypy_rpython_memory_gc_base_GCBase0;
struct pypy_rpython_memory_gc_base_GCBase_vtable0;
struct pypy_rpython_memory_gc_base_MovingGCBase0;
struct pypy_rpython_memory_gc_base_MovingGCBase_vtable0;
struct pypy_rpython_memory_gc_inspector_HeapDumper0;
struct pypy_rpython_memory_gc_minimark_MiniMarkGC0;
struct pypy_rpython_memory_gc_minimark_MiniMarkGC_vtable0;
struct pypy_rpython_memory_gc_minimarkpage_ArenaCollection0;
struct pypy_rpython_memory_gc_minimarkpage_ArenaCollection_vta0;
struct pypy_rpython_memory_gctransform_shadowstack_ShadowStack0;
struct pypy_rpython_memory_gctransform_shadowstack_ShadowStack1;
struct pypy_rpython_memory_gctypelayout_GCData0;
struct pypy_rpython_memory_gctypelayout_GCData_vtable0;
struct pypy_rpython_memory_support_AddressDeque0;
struct pypy_rpython_memory_support_AddressDeque_vtable0;
struct pypy_rpython_memory_support_AddressStack0;
struct pypy_rpython_memory_support_AddressStack_vtable0;
struct pypy_rpython_memory_support_FreeList0;
struct pypy_rpython_memory_support_FreeList_vtable0;
struct pypy_rpython_rlib_rstackovf_StackOverflow0;
struct pypy_rpython_rlib_rstackovf_StackOverflow_vtable0;
struct pypy_rpython_rtyper_lltypesystem_rffi_StackCounter0;
struct pypy_rpython_rtyper_lltypesystem_rffi_StackCounter_vtab0;
struct pypy_stringbuilder0;
struct pypy_tuple2_0;
struct pypy_tuple5_0;
struct pypy_type_info0;
struct pypy_type_info_extra0;
struct pypy_varsize_type_info0;
struct pypy_weakref0;

struct pypy_AddressChunk0 {
	struct pypy_AddressChunk0 *ac_next;
	void* ac_items[1019];
};
struct pypy_ArenaReference0 {
	void* ar_base;
	Signed ar_nfreepages;
	Signed ar_totalpages;
	void* ar_freepages;
	struct pypy_ArenaReference0 *ar_nextarena;
};
struct pypy_DICT0 {
	struct pypy_array5 *di_entries;
	Signed di_num_items;
	Signed di_resize_counter;
};
struct pypy_ENTRY0 {
	void* en_key;
	void* en_value;
};
struct pypy_ExcData0 {
	struct pypy_object_vtable0 *ed_exc_type;
	struct pypy_object0 *ed_exc_value;
};
struct pypy_PageHeader0 {
	struct pypy_PageHeader0 *ph_nextpage;
	struct pypy_ArenaReference0 *ph_arena;
	Signed ph_nfree;
	void* ph_freeblock;
};
struct pypy_header0 {
	Signed h_tid;
};
struct pypy_array0 {
	struct pypy_header0 _gcheader;
	long length;
	void* items[RPY_VARLENGTH];
};
struct pypy_array1 {
	long length;
	void* items[RPY_VARLENGTH];
};
struct pypy_dictentry2 {
	Signed d_key;
	bool_t d_f_everused;
	/* void d_value; */
};
struct pypy_array10 {
	struct pypy_header0 _gcheader;
	long length;
	struct pypy_dictentry2 items[RPY_VARLENGTH];
};
struct pypy_array10_len8 {
	struct pypy_header0 _gcheader;
	long length;
	struct pypy_dictentry2 items[8];
};
union pypy_array10_len8u {
  struct pypy_array10_len8 a;
  struct pypy_array10 b;
};
struct pypy_array11 {
	struct pypy_header0 _gcheader;
	long length;
	struct pypy_rpy_string0 *items[RPY_VARLENGTH];
};
struct pypy_array12 {
	struct pypy_header0 _gcheader;
	long length;
	void* items[RPY_VARLENGTH];
};
struct pypy_array1_len2 {
	long length;
	void* items[2];
};
union pypy_array1_len2u {
  struct pypy_array1_len2 a;
  struct pypy_array1 b;
};
struct pypy_array2 {
	long length;
	char items[RPY_VARLENGTH];
};
struct pypy_array2_len10 {
	long length;
	char items[10];
};
union pypy_array2_len10u {
  struct pypy_array2_len10 a;
  struct pypy_array2 b;
};
struct pypy_array2_len11 {
	long length;
	char items[11];
};
union pypy_array2_len11u {
  struct pypy_array2_len11 a;
  struct pypy_array2 b;
};
struct pypy_array2_len12 {
	long length;
	char items[12];
};
union pypy_array2_len12u {
  struct pypy_array2_len12 a;
  struct pypy_array2 b;
};
struct pypy_array2_len13 {
	long length;
	char items[13];
};
union pypy_array2_len13u {
  struct pypy_array2_len13 a;
  struct pypy_array2 b;
};
struct pypy_array2_len14 {
	long length;
	char items[14];
};
union pypy_array2_len14u {
  struct pypy_array2_len14 a;
  struct pypy_array2 b;
};
struct pypy_array2_len15 {
	long length;
	char items[15];
};
union pypy_array2_len15u {
  struct pypy_array2_len15 a;
  struct pypy_array2 b;
};
struct pypy_array2_len16 {
	long length;
	char items[16];
};
union pypy_array2_len16u {
  struct pypy_array2_len16 a;
  struct pypy_array2 b;
};
struct pypy_array2_len18 {
	long length;
	char items[18];
};
union pypy_array2_len18u {
  struct pypy_array2_len18 a;
  struct pypy_array2 b;
};
struct pypy_array2_len19 {
	long length;
	char items[19];
};
union pypy_array2_len19u {
  struct pypy_array2_len19 a;
  struct pypy_array2 b;
};
struct pypy_array2_len20 {
	long length;
	char items[20];
};
union pypy_array2_len20u {
  struct pypy_array2_len20 a;
  struct pypy_array2 b;
};
struct pypy_array2_len531 {
	long length;
	char items[531];
};
union pypy_array2_len531u {
  struct pypy_array2_len531 a;
  struct pypy_array2 b;
};
struct pypy_array2_len7 {
	long length;
	char items[7];
};
union pypy_array2_len7u {
  struct pypy_array2_len7 a;
  struct pypy_array2 b;
};
struct pypy_array2_len8 {
	long length;
	char items[8];
};
union pypy_array2_len8u {
  struct pypy_array2_len8 a;
  struct pypy_array2 b;
};
struct pypy_array2_len9 {
	long length;
	char items[9];
};
union pypy_array2_len9u {
  struct pypy_array2_len9 a;
  struct pypy_array2 b;
};
struct pypy_array3 {
	struct pypy_header0 _gcheader;
	long length;
	struct pypy_rpy_string0 *items[RPY_VARLENGTH];
};
struct pypy_array3_len0 {
	struct pypy_header0 _gcheader;
	long length;
	struct pypy_rpy_string0 *items[RPY_LENGTH0];
};
union pypy_array3_len0u {
  struct pypy_array3_len0 a;
  struct pypy_array3 b;
};
struct pypy_array4 {
	long length;
	char items[RPY_VARLENGTH];
};
struct pypy_array4_len0 {
	long length;
	char items[RPY_LENGTH0];
};
union pypy_array4_len0u {
  struct pypy_array4_len0 a;
  struct pypy_array4 b;
};
struct pypy_array4_len1 {
	long length;
	char items[1];
};
union pypy_array4_len1u {
  struct pypy_array4_len1 a;
  struct pypy_array4 b;
};
struct pypy_array4_len10 {
	long length;
	char items[10];
};
union pypy_array4_len10u {
  struct pypy_array4_len10 a;
  struct pypy_array4 b;
};
struct pypy_array4_len11 {
	long length;
	char items[11];
};
union pypy_array4_len11u {
  struct pypy_array4_len11 a;
  struct pypy_array4 b;
};
struct pypy_array4_len12 {
	long length;
	char items[12];
};
union pypy_array4_len12u {
  struct pypy_array4_len12 a;
  struct pypy_array4 b;
};
struct pypy_array4_len13 {
	long length;
	char items[13];
};
union pypy_array4_len13u {
  struct pypy_array4_len13 a;
  struct pypy_array4 b;
};
struct pypy_array4_len14 {
	long length;
	char items[14];
};
union pypy_array4_len14u {
  struct pypy_array4_len14 a;
  struct pypy_array4 b;
};
struct pypy_array4_len15 {
	long length;
	char items[15];
};
union pypy_array4_len15u {
  struct pypy_array4_len15 a;
  struct pypy_array4 b;
};
struct pypy_array4_len17 {
	long length;
	char items[17];
};
union pypy_array4_len17u {
  struct pypy_array4_len17 a;
  struct pypy_array4 b;
};
struct pypy_array4_len18 {
	long length;
	char items[18];
};
union pypy_array4_len18u {
  struct pypy_array4_len18 a;
  struct pypy_array4 b;
};
struct pypy_array4_len19 {
	long length;
	char items[19];
};
union pypy_array4_len19u {
  struct pypy_array4_len19 a;
  struct pypy_array4 b;
};
struct pypy_array4_len2 {
	long length;
	char items[2];
};
union pypy_array4_len2u {
  struct pypy_array4_len2 a;
  struct pypy_array4 b;
};
struct pypy_array4_len21 {
	long length;
	char items[21];
};
union pypy_array4_len21u {
  struct pypy_array4_len21 a;
  struct pypy_array4 b;
};
struct pypy_array4_len22 {
	long length;
	char items[22];
};
union pypy_array4_len22u {
  struct pypy_array4_len22 a;
  struct pypy_array4 b;
};
struct pypy_array4_len23 {
	long length;
	char items[23];
};
union pypy_array4_len23u {
  struct pypy_array4_len23 a;
  struct pypy_array4 b;
};
struct pypy_array4_len24 {
	long length;
	char items[24];
};
union pypy_array4_len24u {
  struct pypy_array4_len24 a;
  struct pypy_array4 b;
};
struct pypy_array4_len25 {
	long length;
	char items[25];
};
union pypy_array4_len25u {
  struct pypy_array4_len25 a;
  struct pypy_array4 b;
};
struct pypy_array4_len26 {
	long length;
	char items[26];
};
union pypy_array4_len26u {
  struct pypy_array4_len26 a;
  struct pypy_array4 b;
};
struct pypy_array4_len27 {
	long length;
	char items[27];
};
union pypy_array4_len27u {
  struct pypy_array4_len27 a;
  struct pypy_array4 b;
};
struct pypy_array4_len3 {
	long length;
	char items[3];
};
union pypy_array4_len3u {
  struct pypy_array4_len3 a;
  struct pypy_array4 b;
};
struct pypy_array4_len31 {
	long length;
	char items[31];
};
union pypy_array4_len31u {
  struct pypy_array4_len31 a;
  struct pypy_array4 b;
};
struct pypy_array4_len33 {
	long length;
	char items[33];
};
union pypy_array4_len33u {
  struct pypy_array4_len33 a;
  struct pypy_array4 b;
};
struct pypy_array4_len35 {
	long length;
	char items[35];
};
union pypy_array4_len35u {
  struct pypy_array4_len35 a;
  struct pypy_array4 b;
};
struct pypy_array4_len4 {
	long length;
	char items[4];
};
union pypy_array4_len4u {
  struct pypy_array4_len4 a;
  struct pypy_array4 b;
};
struct pypy_array4_len47 {
	long length;
	char items[47];
};
union pypy_array4_len47u {
  struct pypy_array4_len47 a;
  struct pypy_array4 b;
};
struct pypy_array4_len5 {
	long length;
	char items[5];
};
union pypy_array4_len5u {
  struct pypy_array4_len5 a;
  struct pypy_array4 b;
};
struct pypy_array4_len6 {
	long length;
	char items[6];
};
union pypy_array4_len6u {
  struct pypy_array4_len6 a;
  struct pypy_array4 b;
};
struct pypy_array4_len60 {
	long length;
	char items[60];
};
union pypy_array4_len60u {
  struct pypy_array4_len60 a;
  struct pypy_array4 b;
};
struct pypy_array4_len7 {
	long length;
	char items[7];
};
union pypy_array4_len7u {
  struct pypy_array4_len7 a;
  struct pypy_array4 b;
};
struct pypy_array4_len8 {
	long length;
	char items[8];
};
union pypy_array4_len8u {
  struct pypy_array4_len8 a;
  struct pypy_array4 b;
};
struct pypy_array4_len86 {
	long length;
	char items[86];
};
union pypy_array4_len86u {
  struct pypy_array4_len86 a;
  struct pypy_array4 b;
};
struct pypy_array4_len89 {
	long length;
	char items[89];
};
union pypy_array4_len89u {
  struct pypy_array4_len89 a;
  struct pypy_array4 b;
};
struct pypy_array4_len9 {
	long length;
	char items[9];
};
union pypy_array4_len9u {
  struct pypy_array4_len9 a;
  struct pypy_array4 b;
};
struct pypy_array5 {
	long length;
	struct pypy_ENTRY0 items[RPY_VARLENGTH];
};
struct pypy_array6 {
	struct pypy_header0 _gcheader;
	long length;
	char items[RPY_VARLENGTH];
};
struct pypy_array6_len0 {
	struct pypy_header0 _gcheader;
	long length;
	char items[RPY_LENGTH0];
};
union pypy_array6_len0u {
  struct pypy_array6_len0 a;
  struct pypy_array6 b;
};
struct pypy_dictentry0 {
	struct pypy_rpy_string0 *d_key;
	/* void d_value; */
};
struct pypy_array7 {
	struct pypy_header0 _gcheader;
	long length;
	struct pypy_dictentry0 items[RPY_VARLENGTH];
};
struct pypy_array7_len8 {
	struct pypy_header0 _gcheader;
	long length;
	struct pypy_dictentry0 items[8];
};
union pypy_array7_len8u {
  struct pypy_array7_len8 a;
  struct pypy_array7 b;
};
struct pypy_array8 {
	long length;
	Signed items[RPY_VARLENGTH];
};
struct pypy_array8_len0 {
	long length;
	Signed items[RPY_LENGTH0];
};
union pypy_array8_len0u {
  struct pypy_array8_len0 a;
  struct pypy_array8 b;
};
struct pypy_array8_len1 {
	long length;
	Signed items[1];
};
union pypy_array8_len1u {
  struct pypy_array8_len1 a;
  struct pypy_array8 b;
};
struct pypy_array8_len5 {
	long length;
	Signed items[5];
};
union pypy_array8_len5u {
  struct pypy_array8_len5 a;
  struct pypy_array8 b;
};
struct pypy_dictentry1 {
	char d_key;
	bool_t d_f_everused;
	bool_t d_f_valid;
	/* void d_value; */
};
struct pypy_array9 {
	struct pypy_header0 _gcheader;
	long length;
	struct pypy_dictentry1 items[RPY_VARLENGTH];
};
struct pypy_array9_len8 {
	struct pypy_header0 _gcheader;
	long length;
	struct pypy_dictentry1 items[8];
};
union pypy_array9_len8u {
  struct pypy_array9_len8 a;
  struct pypy_array9 b;
};
struct pypy_dicttable0 {
	struct pypy_header0 _gcheader;
	Signed d_num_items;
	Signed d_resize_counter;
	struct pypy_array7 *d_entries;
};
struct pypy_dicttable1 {
	struct pypy_header0 _gcheader;
	Signed d_num_items;
	Signed d_resize_counter;
	struct pypy_array9 *d_entries;
};
struct pypy_dicttable2 {
	struct pypy_header0 _gcheader;
	Signed d_num_items;
	Signed d_resize_counter;
	struct pypy_array10 *d_entries;
};
struct pypy_dummy0 {
	Signed d_x;
};
struct pypy_object0 {
	struct pypy_header0 _gcheader;
	struct pypy_object_vtable0 *o_typeptr;
};
struct pypy_exceptions_Exception0 {
	struct pypy_object0 e_super;
};
struct pypy_exceptions_StandardError0 {
	struct pypy_exceptions_Exception0 se_super;
};
struct pypy_exceptions_ArithmeticError0 {
	struct pypy_exceptions_StandardError0 ae_super;
};
struct pypy_object_vtable0 {
	Signed ov_subclassrange_min;
	Signed ov_subclassrange_max;
	char *ov_rtti;
	struct pypy_array2 *ov_name;
	Signed ov_hash;
	struct pypy_object0 *(*ov_instantiate)(void);
};
struct pypy_exceptions_Exception_vtable0 {
	struct pypy_object_vtable0 e_super;
};
struct pypy_exceptions_StandardError_vtable0 {
	struct pypy_exceptions_Exception_vtable0 se_super;
};
struct pypy_exceptions_ArithmeticError_vtable0 {
	struct pypy_exceptions_StandardError_vtable0 ae_super;
};
struct pypy_exceptions_AssertionError0 {
	struct pypy_exceptions_StandardError0 ae_super;
};
struct pypy_exceptions_AssertionError_vtable0 {
	struct pypy_exceptions_StandardError_vtable0 ae_super;
};
struct pypy_exceptions_EnvironmentError0 {
	struct pypy_exceptions_StandardError0 ee_super;
};
struct pypy_exceptions_EnvironmentError_vtable0 {
	struct pypy_exceptions_StandardError_vtable0 ee_super;
};
struct pypy_exceptions_IOError0 {
	struct pypy_exceptions_EnvironmentError0 ioe_super;
};
struct pypy_exceptions_IOError_vtable0 {
	struct pypy_exceptions_EnvironmentError_vtable0 ioe_super;
};
struct pypy_exceptions_LookupError0 {
	struct pypy_exceptions_StandardError0 le_super;
};
struct pypy_exceptions_IndexError0 {
	struct pypy_exceptions_LookupError0 ie_super;
};
struct pypy_exceptions_LookupError_vtable0 {
	struct pypy_exceptions_StandardError_vtable0 le_super;
};
struct pypy_exceptions_IndexError_vtable0 {
	struct pypy_exceptions_LookupError_vtable0 ie_super;
};
struct pypy_exceptions_KeyError0 {
	struct pypy_exceptions_LookupError0 ke_super;
};
struct pypy_exceptions_KeyError_vtable0 {
	struct pypy_exceptions_LookupError_vtable0 ke_super;
};
struct pypy_exceptions_MemoryError0 {
	struct pypy_exceptions_StandardError0 me_super;
};
struct pypy_exceptions_MemoryError_vtable0 {
	struct pypy_exceptions_StandardError_vtable0 me_super;
};
struct pypy_exceptions_RuntimeError0 {
	struct pypy_exceptions_StandardError0 re_super;
};
struct pypy_exceptions_NotImplementedError0 {
	struct pypy_exceptions_RuntimeError0 nie_super;
};
struct pypy_exceptions_RuntimeError_vtable0 {
	struct pypy_exceptions_StandardError_vtable0 re_super;
};
struct pypy_exceptions_NotImplementedError_vtable0 {
	struct pypy_exceptions_RuntimeError_vtable0 nie_super;
};
struct pypy_exceptions_OSError0 {
	struct pypy_exceptions_EnvironmentError0 ose_super;
	Signed ose_inst_errno;
};
struct pypy_exceptions_OSError_vtable0 {
	struct pypy_exceptions_EnvironmentError_vtable0 ose_super;
};
struct pypy_exceptions_OverflowError0 {
	struct pypy_exceptions_ArithmeticError0 oe_super;
};
struct pypy_exceptions_OverflowError_vtable0 {
	struct pypy_exceptions_ArithmeticError_vtable0 oe_super;
};
struct pypy_exceptions_StopIteration0 {
	struct pypy_exceptions_Exception0 si_super;
};
struct pypy_exceptions_StopIteration_vtable0 {
	struct pypy_exceptions_Exception_vtable0 si_super;
};
struct pypy_exceptions_TypeError0 {
	struct pypy_exceptions_StandardError0 te_super;
};
struct pypy_exceptions_TypeError_vtable0 {
	struct pypy_exceptions_StandardError_vtable0 te_super;
};
struct pypy_exceptions_ValueError0 {
	struct pypy_exceptions_StandardError0 ve_super;
};
struct pypy_exceptions_UnicodeError0 {
	struct pypy_exceptions_ValueError0 ue_super;
};
struct pypy_exceptions_UnicodeDecodeError0 {
	struct pypy_exceptions_UnicodeError0 ude_super;
};
struct pypy_exceptions_ValueError_vtable0 {
	struct pypy_exceptions_StandardError_vtable0 ve_super;
};
struct pypy_exceptions_UnicodeError_vtable0 {
	struct pypy_exceptions_ValueError_vtable0 ue_super;
};
struct pypy_exceptions_UnicodeDecodeError_vtable0 {
	struct pypy_exceptions_UnicodeError_vtable0 ude_super;
};
struct pypy_exceptions_UnicodeEncodeError0 {
	struct pypy_exceptions_UnicodeError0 uee_super;
};
struct pypy_exceptions_UnicodeEncodeError_vtable0 {
	struct pypy_exceptions_UnicodeError_vtable0 uee_super;
};
struct pypy_exceptions_ZeroDivisionError0 {
	struct pypy_exceptions_ArithmeticError0 zde_super;
};
struct pypy_exceptions_ZeroDivisionError_vtable0 {
	struct pypy_exceptions_ArithmeticError_vtable0 zde_super;
};
struct pypy_forwarding_stub0 {
	struct pypy_header0 _gcheader;
	void* fs_forw;
};
struct pypy_list0 {
	struct pypy_header0 _gcheader;
	Signed l_length;
	struct pypy_array3 *l_items;
};
struct pypy_list1 {
	struct pypy_header0 _gcheader;
	Signed l_length;
	struct pypy_array6 *l_items;
};
struct pypy_nongcobject0 {
	struct pypy_object_vtable0 *n_typeptr;
};
struct pypy_rpy_string0 {
	struct pypy_header0 _gcheader;
	Signed rs_hash;
	struct pypy_array4 rs_chars;
};
struct pypy_rpy_string0_len0 {
	struct pypy_header0 _gcheader;
	Signed rs_hash;
	struct pypy_array4_len0 rs_chars;
};
union pypy_rpy_string0_len0u {
  struct pypy_rpy_string0_len0 a;
  struct pypy_rpy_string0 b;
};
struct pypy_rpy_string0_len1 {
	struct pypy_header0 _gcheader;
	Signed rs_hash;
	struct pypy_array4_len1 rs_chars;
};
union pypy_rpy_string0_len1u {
  struct pypy_rpy_string0_len1 a;
  struct pypy_rpy_string0 b;
};
struct pypy_rpy_string0_len10 {
	struct pypy_header0 _gcheader;
	Signed rs_hash;
	struct pypy_array4_len10 rs_chars;
};
union pypy_rpy_string0_len10u {
  struct pypy_rpy_string0_len10 a;
  struct pypy_rpy_string0 b;
};
struct pypy_rpy_string0_len11 {
	struct pypy_header0 _gcheader;
	Signed rs_hash;
	struct pypy_array4_len11 rs_chars;
};
union pypy_rpy_string0_len11u {
  struct pypy_rpy_string0_len11 a;
  struct pypy_rpy_string0 b;
};
struct pypy_rpy_string0_len12 {
	struct pypy_header0 _gcheader;
	Signed rs_hash;
	struct pypy_array4_len12 rs_chars;
};
union pypy_rpy_string0_len12u {
  struct pypy_rpy_string0_len12 a;
  struct pypy_rpy_string0 b;
};
struct pypy_rpy_string0_len13 {
	struct pypy_header0 _gcheader;
	Signed rs_hash;
	struct pypy_array4_len13 rs_chars;
};
union pypy_rpy_string0_len13u {
  struct pypy_rpy_string0_len13 a;
  struct pypy_rpy_string0 b;
};
struct pypy_rpy_string0_len14 {
	struct pypy_header0 _gcheader;
	Signed rs_hash;
	struct pypy_array4_len14 rs_chars;
};
union pypy_rpy_string0_len14u {
  struct pypy_rpy_string0_len14 a;
  struct pypy_rpy_string0 b;
};
struct pypy_rpy_string0_len15 {
	struct pypy_header0 _gcheader;
	Signed rs_hash;
	struct pypy_array4_len15 rs_chars;
};
union pypy_rpy_string0_len15u {
  struct pypy_rpy_string0_len15 a;
  struct pypy_rpy_string0 b;
};
struct pypy_rpy_string0_len17 {
	struct pypy_header0 _gcheader;
	Signed rs_hash;
	struct pypy_array4_len17 rs_chars;
};
union pypy_rpy_string0_len17u {
  struct pypy_rpy_string0_len17 a;
  struct pypy_rpy_string0 b;
};
struct pypy_rpy_string0_len18 {
	struct pypy_header0 _gcheader;
	Signed rs_hash;
	struct pypy_array4_len18 rs_chars;
};
union pypy_rpy_string0_len18u {
  struct pypy_rpy_string0_len18 a;
  struct pypy_rpy_string0 b;
};
struct pypy_rpy_string0_len19 {
	struct pypy_header0 _gcheader;
	Signed rs_hash;
	struct pypy_array4_len19 rs_chars;
};
union pypy_rpy_string0_len19u {
  struct pypy_rpy_string0_len19 a;
  struct pypy_rpy_string0 b;
};
struct pypy_rpy_string0_len2 {
	struct pypy_header0 _gcheader;
	Signed rs_hash;
	struct pypy_array4_len2 rs_chars;
};
union pypy_rpy_string0_len2u {
  struct pypy_rpy_string0_len2 a;
  struct pypy_rpy_string0 b;
};
struct pypy_rpy_string0_len21 {
	struct pypy_header0 _gcheader;
	Signed rs_hash;
	struct pypy_array4_len21 rs_chars;
};
union pypy_rpy_string0_len21u {
  struct pypy_rpy_string0_len21 a;
  struct pypy_rpy_string0 b;
};
struct pypy_rpy_string0_len22 {
	struct pypy_header0 _gcheader;
	Signed rs_hash;
	struct pypy_array4_len22 rs_chars;
};
union pypy_rpy_string0_len22u {
  struct pypy_rpy_string0_len22 a;
  struct pypy_rpy_string0 b;
};
struct pypy_rpy_string0_len23 {
	struct pypy_header0 _gcheader;
	Signed rs_hash;
	struct pypy_array4_len23 rs_chars;
};
union pypy_rpy_string0_len23u {
  struct pypy_rpy_string0_len23 a;
  struct pypy_rpy_string0 b;
};
struct pypy_rpy_string0_len24 {
	struct pypy_header0 _gcheader;
	Signed rs_hash;
	struct pypy_array4_len24 rs_chars;
};
union pypy_rpy_string0_len24u {
  struct pypy_rpy_string0_len24 a;
  struct pypy_rpy_string0 b;
};
struct pypy_rpy_string0_len25 {
	struct pypy_header0 _gcheader;
	Signed rs_hash;
	struct pypy_array4_len25 rs_chars;
};
union pypy_rpy_string0_len25u {
  struct pypy_rpy_string0_len25 a;
  struct pypy_rpy_string0 b;
};
struct pypy_rpy_string0_len26 {
	struct pypy_header0 _gcheader;
	Signed rs_hash;
	struct pypy_array4_len26 rs_chars;
};
union pypy_rpy_string0_len26u {
  struct pypy_rpy_string0_len26 a;
  struct pypy_rpy_string0 b;
};
struct pypy_rpy_string0_len27 {
	struct pypy_header0 _gcheader;
	Signed rs_hash;
	struct pypy_array4_len27 rs_chars;
};
union pypy_rpy_string0_len27u {
  struct pypy_rpy_string0_len27 a;
  struct pypy_rpy_string0 b;
};
struct pypy_rpy_string0_len3 {
	struct pypy_header0 _gcheader;
	Signed rs_hash;
	struct pypy_array4_len3 rs_chars;
};
union pypy_rpy_string0_len3u {
  struct pypy_rpy_string0_len3 a;
  struct pypy_rpy_string0 b;
};
struct pypy_rpy_string0_len31 {
	struct pypy_header0 _gcheader;
	Signed rs_hash;
	struct pypy_array4_len31 rs_chars;
};
union pypy_rpy_string0_len31u {
  struct pypy_rpy_string0_len31 a;
  struct pypy_rpy_string0 b;
};
struct pypy_rpy_string0_len33 {
	struct pypy_header0 _gcheader;
	Signed rs_hash;
	struct pypy_array4_len33 rs_chars;
};
union pypy_rpy_string0_len33u {
  struct pypy_rpy_string0_len33 a;
  struct pypy_rpy_string0 b;
};
struct pypy_rpy_string0_len35 {
	struct pypy_header0 _gcheader;
	Signed rs_hash;
	struct pypy_array4_len35 rs_chars;
};
union pypy_rpy_string0_len35u {
  struct pypy_rpy_string0_len35 a;
  struct pypy_rpy_string0 b;
};
struct pypy_rpy_string0_len4 {
	struct pypy_header0 _gcheader;
	Signed rs_hash;
	struct pypy_array4_len4 rs_chars;
};
union pypy_rpy_string0_len4u {
  struct pypy_rpy_string0_len4 a;
  struct pypy_rpy_string0 b;
};
struct pypy_rpy_string0_len47 {
	struct pypy_header0 _gcheader;
	Signed rs_hash;
	struct pypy_array4_len47 rs_chars;
};
union pypy_rpy_string0_len47u {
  struct pypy_rpy_string0_len47 a;
  struct pypy_rpy_string0 b;
};
struct pypy_rpy_string0_len5 {
	struct pypy_header0 _gcheader;
	Signed rs_hash;
	struct pypy_array4_len5 rs_chars;
};
union pypy_rpy_string0_len5u {
  struct pypy_rpy_string0_len5 a;
  struct pypy_rpy_string0 b;
};
struct pypy_rpy_string0_len6 {
	struct pypy_header0 _gcheader;
	Signed rs_hash;
	struct pypy_array4_len6 rs_chars;
};
union pypy_rpy_string0_len6u {
  struct pypy_rpy_string0_len6 a;
  struct pypy_rpy_string0 b;
};
struct pypy_rpy_string0_len60 {
	struct pypy_header0 _gcheader;
	Signed rs_hash;
	struct pypy_array4_len60 rs_chars;
};
union pypy_rpy_string0_len60u {
  struct pypy_rpy_string0_len60 a;
  struct pypy_rpy_string0 b;
};
struct pypy_rpy_string0_len7 {
	struct pypy_header0 _gcheader;
	Signed rs_hash;
	struct pypy_array4_len7 rs_chars;
};
union pypy_rpy_string0_len7u {
  struct pypy_rpy_string0_len7 a;
  struct pypy_rpy_string0 b;
};
struct pypy_rpy_string0_len8 {
	struct pypy_header0 _gcheader;
	Signed rs_hash;
	struct pypy_array4_len8 rs_chars;
};
union pypy_rpy_string0_len8u {
  struct pypy_rpy_string0_len8 a;
  struct pypy_rpy_string0 b;
};
struct pypy_rpy_string0_len86 {
	struct pypy_header0 _gcheader;
	Signed rs_hash;
	struct pypy_array4_len86 rs_chars;
};
union pypy_rpy_string0_len86u {
  struct pypy_rpy_string0_len86 a;
  struct pypy_rpy_string0 b;
};
struct pypy_rpy_string0_len89 {
	struct pypy_header0 _gcheader;
	Signed rs_hash;
	struct pypy_array4_len89 rs_chars;
};
union pypy_rpy_string0_len89u {
  struct pypy_rpy_string0_len89 a;
  struct pypy_rpy_string0 b;
};
struct pypy_rpy_string0_len9 {
	struct pypy_header0 _gcheader;
	Signed rs_hash;
	struct pypy_array4_len9 rs_chars;
};
union pypy_rpy_string0_len9u {
  struct pypy_rpy_string0_len9 a;
  struct pypy_rpy_string0 b;
};
struct pypy_rpython_memory_gc_base_GCBase0 {
	struct pypy_nongcobject0 gcb_super;
};
struct pypy_rpython_memory_gc_base_GCBase_vtable0 {
	struct pypy_object_vtable0 gcb_super;
};
struct pypy_rpython_memory_gc_base_MovingGCBase0 {
	struct pypy_rpython_memory_gc_base_GCBase0 mgcb_super;
};
struct pypy_rpython_memory_gc_base_MovingGCBase_vtable0 {
	struct pypy_rpython_memory_gc_base_GCBase_vtable0 mgcb_super;
};
struct pypy_rpython_memory_gc_inspector_HeapDumper0 {
	struct pypy_nongcobject0 hd_super;
	Signed hd_inst_buf_count;
	Signed hd_inst_fd;
	struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *hd_inst_gc;
	Signed hd_inst_gcflag;
	struct pypy_rpython_memory_support_AddressStack0 *hd_inst_pending;
	struct pypy_DICT0 *hd_inst_seen;
	Signed *hd_inst_writebuffer;
};
struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 {
	struct pypy_rpython_memory_gc_base_MovingGCBase0 mmgc_super;
	/* void mmgc_inst_AddressDeque; */
	/* void mmgc_inst_AddressDict; */
	/* void mmgc_inst_AddressStack; */
	/* void mmgc_inst_config; */
	/* void mmgc_inst_gcheaderbuilder; */
	/* void mmgc_inst_jit_remember_young_pointer; */
	/* void mmgc_inst_null_address_dict; */
	/* void mmgc_inst_remember_young_pointer; */
	/* void mmgc_inst_remember_young_pointer_from_array2; */
	/* void mmgc_inst_root_walker; */
	double mmgc_inst_growth_rate_max;
	double mmgc_inst_major_collection_threshold;
	double mmgc_inst_max_delta;
	double mmgc_inst_max_heap_size;
	double mmgc_inst_min_heap_size;
	double mmgc_inst_next_major_collection_initial;
	double mmgc_inst_next_major_collection_threshold;
	Signed mmgc_inst_DEBUG;
	struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *mmgc_inst__callback2_arg0;
	struct pypy_rpython_memory_gc_inspector_HeapDumper0 *mmgc_inst__callback2_arg1;
	struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *mmgc_inst__callback2_arg2;
	struct pypy_rpython_memory_gc_inspector_HeapDumper0 *mmgc_inst__callback2_arg3;
	struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *mmgc_inst__callback2_arg4;
	Signed mmgc_inst__count_rpy;
	struct pypy_rpython_memory_support_AddressStack0 *mmgc_inst__debug_pending;
	struct pypy_DICT0 *mmgc_inst__debug_seen;
	struct pypy_array0 *mmgc_inst__list_rpy;
	struct pypy_rpython_memory_gc_minimarkpage_ArenaCollection0 *mmgc_inst_ac;
	Signed mmgc_inst_card_page_indices;
	Signed mmgc_inst_card_page_shift;
	struct pypy_array1 *mmgc_inst_debug_rotating_nurseries;
	Signed mmgc_inst_debug_tiny_nursery;
	Signed mmgc_inst_extra_threshold;
	struct pypy_rpython_memory_gctypelayout_GCData0 *mmgc_inst_fast_path_tracing;
	Signed mmgc_inst_finalizer_lock_count;
	struct pypy_rpython_memory_gctypelayout_GCData0 *mmgc_inst_fixed_size;
	struct pypy_rpython_memory_gctypelayout_GCData0 *mmgc_inst_get_custom_trace;
	struct pypy_rpython_memory_gctypelayout_GCData0 *mmgc_inst_getfinalizer;
	struct pypy_rpython_memory_gctypelayout_GCData0 *mmgc_inst_getlightfinalizer;
	struct pypy_rpython_memory_gctypelayout_GCData0 *mmgc_inst_has_custom_trace;
	struct pypy_rpython_memory_gctypelayout_GCData0 *mmgc_inst_has_gcptr_in_varsize;
	Signed mmgc_inst_initial_cleanup;
	struct pypy_rpython_memory_gctypelayout_GCData0 *mmgc_inst_is_gcarrayofgcptr;
	struct pypy_rpython_memory_gctypelayout_GCData0 *mmgc_inst_is_rpython_class;
	struct pypy_rpython_memory_gctypelayout_GCData0 *mmgc_inst_is_varsize;
	struct pypy_rpython_memory_gctypelayout_GCData0 *mmgc_inst_member_index;
	Signed mmgc_inst_nonlarge_max;
	Signed mmgc_inst_num_major_collects;
	void* mmgc_inst_nursery;
	Signed mmgc_inst_nursery_cleanup;
	void* mmgc_inst_nursery_free;
	struct pypy_DICT0 *mmgc_inst_nursery_objects_shadows;
	void* mmgc_inst_nursery_real_top;
	Signed mmgc_inst_nursery_size;
	void* mmgc_inst_nursery_top;
	struct pypy_rpython_memory_support_AddressStack0 *mmgc_inst_objects_to_trace;
	struct pypy_rpython_memory_support_AddressDeque0 *mmgc_inst_objects_with_finalizers;
	struct pypy_rpython_memory_gctypelayout_GCData0 *mmgc_inst_offsets_to_gc_pointers;
	struct pypy_rpython_memory_support_AddressStack0 *mmgc_inst_old_objects_pointing_to_young;
	struct pypy_rpython_memory_support_AddressStack0 *mmgc_inst_old_objects_with_cards_set;
	struct pypy_rpython_memory_support_AddressStack0 *mmgc_inst_old_objects_with_light_finalizers;
	struct pypy_rpython_memory_support_AddressStack0 *mmgc_inst_old_objects_with_weakrefs;
	struct pypy_rpython_memory_support_AddressStack0 *mmgc_inst_old_rawmalloced_objects;
	struct pypy_rpython_memory_support_AddressStack0 *mmgc_inst_prebuilt_root_objects;
	Unsigned mmgc_inst_rawmalloced_total_size;
	struct pypy_rpython_memory_support_AddressDeque0 *mmgc_inst_run_finalizers;
	Signed mmgc_inst_small_request_threshold;
	struct pypy_rpython_memory_support_AddressStack0 *mmgc_inst_tmpstack;
	struct pypy_rpython_memory_gctypelayout_GCData0 *mmgc_inst_varsize_item_sizes;
	struct pypy_rpython_memory_gctypelayout_GCData0 *mmgc_inst_varsize_offset_to_length;
	struct pypy_rpython_memory_gctypelayout_GCData0 *mmgc_inst_varsize_offset_to_variable_part;
	struct pypy_rpython_memory_gctypelayout_GCData0 *mmgc_inst_varsize_offsets_to_gcpointers_in_var_part;
	struct pypy_rpython_memory_gctypelayout_GCData0 *mmgc_inst_weakpointer_offset;
	struct pypy_rpython_memory_support_AddressStack0 *mmgc_inst_young_objects_with_light_finalizers;
	struct pypy_rpython_memory_support_AddressStack0 *mmgc_inst_young_objects_with_weakrefs;
	struct pypy_DICT0 *mmgc_inst_young_rawmalloced_objects;
	bool_t mmgc_inst_max_heap_size_already_raised;
	bool_t mmgc_inst_read_from_env;
	bool_t mmgc_inst_translated_to_c;
};
struct pypy_rpython_memory_gc_minimark_MiniMarkGC_vtable0 {
	struct pypy_rpython_memory_gc_base_MovingGCBase_vtable0 mmgc_super;
	/* void mmgc_cls_HDR; */
	/* void mmgc_cls__alloc_nursery; */
	/* void mmgc_cls__allocate_shadow; */
	/* void mmgc_cls__append_if_nonnull; */
	/* void mmgc_cls__bump_finalization_state_from_0_to_1; */
	/* void mmgc_cls__collect_obj; */
	/* void mmgc_cls__collect_ref_rec; */
	/* void mmgc_cls__debug_callback2; */
	/* void mmgc_cls__debug_record; */
	/* void mmgc_cls__finalization_state; */
	/* void mmgc_cls__find_shadow; */
	/* void mmgc_cls__free_if_unvisited; */
	/* void mmgc_cls__free_young_rawmalloced_obj; */
	/* void mmgc_cls__get_size_for_typeid; */
	/* void mmgc_cls__malloc_out_of_nursery; */
	/* void mmgc_cls__malloc_out_of_nursery_nonsmall; */
	/* void mmgc_cls__nursery_memory_size; */
	/* void mmgc_cls__recursively_bump_finalization_state_from_1_to_2; */
	/* void mmgc_cls__recursively_bump_finalization_state_from_2_to_3; */
	/* void mmgc_cls__reset_gcflag_visited; */
	/* void mmgc_cls__teardown; */
	/* void mmgc_cls__trace_drag_out; */
	/* void mmgc_cls__trace_slow_path; */
	/* void mmgc_cls__visit_young_rawmalloced_object; */
	/* void mmgc_cls_allocate_nursery; */
	/* void mmgc_cls_appears_to_be_young; */
	/* void mmgc_cls_card_marking_bytes_for_length; */
	/* void mmgc_cls_card_marking_words_for_length; */
	/* void mmgc_cls_collect_and_reserve; */
	/* void mmgc_cls_collect_cardrefs_to_nursery; */
	/* void mmgc_cls_collect_oldrefs_to_nursery; */
	/* void mmgc_cls_collect_roots; */
	/* void mmgc_cls_collect_roots_in_nursery; */
	/* void mmgc_cls_combine; */
	/* void mmgc_cls_deal_with_objects_with_finalizers; */
	/* void mmgc_cls_deal_with_old_objects_with_finalizers; */
	/* void mmgc_cls_deal_with_young_objects_with_finalizers; */
	/* void mmgc_cls_debug_check_consistency; */
	/* void mmgc_cls_debug_check_object; */
	/* void mmgc_cls_debug_rotate_nursery; */
	/* void mmgc_cls_enumerate_all_roots; */
	/* void mmgc_cls_execute_finalizers; */
	/* void mmgc_cls_external_malloc; */
	/* void mmgc_cls_free_rawmalloced_object_if_unvisited; */
	/* void mmgc_cls_free_unvisited_rawmalloc_objects; */
	/* void mmgc_cls_free_young_rawmalloced_objects; */
	Signed mmgc_cls_gcflag_extra;
	/* void mmgc_cls_get_card; */
	/* void mmgc_cls_get_forwarding_address; */
	/* void mmgc_cls_get_member_index; */
	/* void mmgc_cls_get_size; */
	/* void mmgc_cls_get_size_incl_hash; */
	/* void mmgc_cls_get_total_memory_used; */
	/* void mmgc_cls_get_type_id; */
	/* void mmgc_cls_header; */
	/* void mmgc_cls_id_or_identityhash; */
	/* void mmgc_cls_init_gc_object; */
	/* void mmgc_cls_invalidate_old_weakrefs; */
	/* void mmgc_cls_invalidate_young_weakrefs; */
	/* void mmgc_cls_is_forwarded; */
	/* void mmgc_cls_is_in_nursery; */
	/* void mmgc_cls_is_valid_gc_object; */
	/* void mmgc_cls_major_collection; */
	/* void mmgc_cls_manually_copy_card_bits; */
	Signed mmgc_cls_minimal_size_in_nursery;
	/* void mmgc_cls_minor_collection; */
	/* void mmgc_cls_move_nursery_top; */
	/* void mmgc_cls_points_to_valid_gc_object; */
	/* void mmgc_cls_post_setup; */
	/* void mmgc_cls_raw_malloc_memory_pressure; */
	/* void mmgc_cls_remove_young_arrays_from_old_objects_pointing_to_young; */
	/* void mmgc_cls_set_major_threshold_from; */
	/* void mmgc_cls_setup; */
	/* void mmgc_cls_trace; */
	/* void mmgc_cls_trace_and_drag_out_of_nursery; */
	/* void mmgc_cls_trace_and_drag_out_of_nursery_partial; */
	/* void mmgc_cls_trace_partial; */
	/* void mmgc_cls_visit; */
	/* void mmgc_cls_visit_all_objects; */
};
struct pypy_rpython_memory_gc_minimarkpage_ArenaCollection0 {
	struct pypy_nongcobject0 ac_super;
	Signed ac_inst_arena_size;
	struct pypy_ArenaReference0 **ac_inst_arenas_lists;
	struct pypy_ArenaReference0 *ac_inst_current_arena;
	struct pypy_PageHeader0 **ac_inst_full_page_for_size;
	Signed ac_inst_hdrsize;
	Signed ac_inst_max_pages_per_arena;
	Signed ac_inst_min_empty_nfreepages;
	Signed *ac_inst_nblocks_for_size;
	Signed ac_inst_num_uninitialized_pages;
	struct pypy_ArenaReference0 **ac_inst_old_arenas_lists;
	struct pypy_PageHeader0 **ac_inst_page_for_size;
	Signed ac_inst_page_size;
	Signed ac_inst_small_request_threshold;
	Unsigned ac_inst_total_memory_used;
};
struct pypy_rpython_memory_gc_minimarkpage_ArenaCollection_vta0 {
	struct pypy_object_vtable0 ac_super;
	/* void ac_cls_allocate_new_arena; */
	/* void ac_cls_allocate_new_page; */
	/* void ac_cls_free_page; */
	/* void ac_cls_malloc; */
	/* void ac_cls_mass_free; */
	/* void ac_cls_mass_free_in_pages; */
	/* void ac_cls_walk_page; */
};
struct pypy_rpython_memory_gctransform_shadowstack_ShadowStack0 {
	struct pypy_nongcobject0 ssp_super;
	struct pypy_rpython_memory_gctypelayout_GCData0 *ssp_inst_gcdata;
	void* ssp_inst_unused_full_stack;
};
struct pypy_rpython_memory_gctransform_shadowstack_ShadowStack1 {
	struct pypy_object_vtable0 ssp_super;
	/* void ssp_cls__prepare_unused_stack; */
	/* void ssp_cls_initial_setup; */
	Signed ssp_cls_root_stack_depth;
	/* void ssp_cls_start_fresh_new_state; */
};
struct pypy_rpython_memory_gctypelayout_GCData0 {
	struct pypy_nongcobject0 gcd_super;
	struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *gcd_inst_gc;
	Signed gcd_inst_max_type_id;
	void* gcd_inst_root_stack_base;
	void* gcd_inst_root_stack_top;
	void* gcd_inst_static_root_end;
	void* gcd_inst_static_root_nongcend;
	void* gcd_inst_static_root_start;
	/*don't use me*/ void *gcd_inst_type_info_group_ptr;
	void* gcd_inst_typeids_z;
};
struct pypy_rpython_memory_gctypelayout_GCData_vtable0 {
	struct pypy_object_vtable0 gcd_super;
	/* void gcd_cls_get; */
	/* void gcd_cls_get_varsize; */
	/* void gcd_cls_q_fast_path_tracing; */
	/* void gcd_cls_q_finalizer; */
	/* void gcd_cls_q_fixed_size; */
	/* void gcd_cls_q_get_custom_trace; */
	/* void gcd_cls_q_has_custom_trace; */
	/* void gcd_cls_q_has_gcptr_in_varsize; */
	/* void gcd_cls_q_is_gcarrayofgcptr; */
	/* void gcd_cls_q_is_rpython_class; */
	/* void gcd_cls_q_is_varsize; */
	/* void gcd_cls_q_light_finalizer; */
	/* void gcd_cls_q_member_index; */
	/* void gcd_cls_q_offsets_to_gc_pointers; */
	/* void gcd_cls_q_varsize_item_sizes; */
	/* void gcd_cls_q_varsize_offset_to_length; */
	/* void gcd_cls_q_varsize_offset_to_variable_part; */
	/* void gcd_cls_q_varsize_offsets_to_gcpointers_in_var_part; */
	/* void gcd_cls_q_weakpointer_offset; */
};
struct pypy_rpython_memory_support_AddressDeque0 {
	struct pypy_nongcobject0 ad_super;
	Signed ad_inst_index_in_newest;
	Signed ad_inst_index_in_oldest;
	struct pypy_AddressChunk0 *ad_inst_newest_chunk;
	struct pypy_AddressChunk0 *ad_inst_oldest_chunk;
};
struct pypy_rpython_memory_support_AddressDeque_vtable0 {
	struct pypy_object_vtable0 ad_super;
	/* void ad_cls_append; */
	/* void ad_cls_delete; */
	/* void ad_cls_enlarge; */
	/* void ad_cls_foreach; */
	/* void ad_cls_non_empty; */
	/* void ad_cls_popleft; */
	/* void ad_cls_shrink; */
};
struct pypy_rpython_memory_support_AddressStack0 {
	struct pypy_nongcobject0 as_super;
	struct pypy_AddressChunk0 *as_inst_chunk;
	Signed as_inst_used_in_last_chunk;
};
struct pypy_rpython_memory_support_AddressStack_vtable0 {
	struct pypy_object_vtable0 as_super;
	/* void as_cls_append; */
	/* void as_cls_delete; */
	/* void as_cls_enlarge; */
	/* void as_cls_foreach; */
	/* void as_cls_non_empty; */
	/* void as_cls_pop; */
	/* void as_cls_shrink; */
};
struct pypy_rpython_memory_support_FreeList0 {
	struct pypy_nongcobject0 fl_super;
	struct pypy_AddressChunk0 *fl_inst_free_list;
};
struct pypy_rpython_memory_support_FreeList_vtable0 {
	struct pypy_object_vtable0 fl_super;
	/* void fl_cls_get; */
	/* void fl_cls_put; */
};
struct pypy_rpython_rlib_rstackovf_StackOverflow0 {
	struct pypy_exceptions_RuntimeError0 so_super;
};
struct pypy_rpython_rlib_rstackovf_StackOverflow_vtable0 {
	struct pypy_exceptions_RuntimeError_vtable0 so_super;
};
struct pypy_rpython_rtyper_lltypesystem_rffi_StackCounter0 {
	struct pypy_object0 sc_super;
	Signed sc_inst_stacks_counter;
};
struct pypy_rpython_rtyper_lltypesystem_rffi_StackCounter_vtab0 {
	struct pypy_object_vtable0 sc_super;
};
struct pypy_stringbuilder0 {
	struct pypy_header0 _gcheader;
	Signed s_allocated;
	Signed s_used;
	struct pypy_rpy_string0 *s_buf;
};
struct pypy_tuple2_0 {
	struct pypy_header0 _gcheader;
	double t_item0;
	Signed t_item1;
};
struct pypy_tuple5_0 {
	struct pypy_header0 _gcheader;
	struct pypy_rpy_string0 *t_item0;
	struct pypy_rpy_string0 *t_item1;
	struct pypy_rpy_string0 *t_item2;
	struct pypy_rpy_string0 *t_item3;
	struct pypy_rpy_string0 *t_item4;
};
struct pypy_type_info0 {
	Signed ti_infobits;
	struct pypy_type_info_extra0 *ti_extra;
	Signed ti_fixedsize;
	struct pypy_array8 *ti_ofstoptrs;
};
struct pypy_type_info_extra0 {
	void (*tie_finalizer)(void*);
	void* (*tie_customtracer)(void*, void*);
};
struct pypy_varsize_type_info0 {
	struct pypy_type_info0 vti_header;
	Signed vti_varitemsize;
	Signed vti_ofstovar;
	Signed vti_ofstolength;
	struct pypy_array8 *vti_varofstoptrs;
};
struct pypy_weakref0 {
	struct pypy_header0 _gcheader;
	void* w_weakptr;
};
#endif
