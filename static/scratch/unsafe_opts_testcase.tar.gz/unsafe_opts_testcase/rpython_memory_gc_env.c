/***********************************************************/
/***  Implementations                                    ***/

#define PYPY_FILE_NAME "rpython_memory_gc_env.c"
#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"
#include "src/g_include.h"

/*/*/
struct pypy_tuple2_0 *pypy_g__read_float_and_factor_from_env(struct pypy_rpy_string0 *l_varname_0) {
	char l_c_0; char l_c_1; char l_c_2; char l_c_3;
	struct pypy_rpy_string0 *l_chars_3;
	struct pypy_rpy_string0 *l_chars_4;
	struct pypy_rpy_string0 *l_chars_5;
	struct pypy_rpy_string0 *l_chars_6; Signed l_i_11; Signed l_i_12;
	Signed l_i_13; void* l_result_5; void* l_result_6;
	struct pypy_rpy_string0 *l_s_3; Signed l_strlen_0; Signed l_strlen_1;
	Signed l_strlen_2; Signed l_strlen_3; Signed l_v2295; Signed l_v2296;
	Signed l_v2299; Signed l_v2300; Signed l_v2306; Signed l_v2308;
	Signed l_v2310; Signed l_v2311; Signed l_v2324; Signed l_v2325;
	Signed l_v2328; Signed l_v2333; Signed l_v2335; Signed l_v2336;
	Signed l_v2339; Signed l_v2344; Signed l_v2346; Signed l_v2347;
	Signed l_v2350; Signed l_v2355; Signed l_v2370; Signed l_v2405;
	Signed l_v2406; Signed l_v2409; Signed l_v2414; Signed l_v2416;
	Signed l_v2417; bool_t l_v2304; bool_t l_v2305; bool_t l_v2307;
	bool_t l_v2309; bool_t l_v2323; bool_t l_v2326; bool_t l_v2329;
	bool_t l_v2332; bool_t l_v2334; bool_t l_v2337; bool_t l_v2340;
	bool_t l_v2343; bool_t l_v2345; bool_t l_v2348; bool_t l_v2351;
	bool_t l_v2354; bool_t l_v2356; bool_t l_v2368; bool_t l_v2369;
	bool_t l_v2371; bool_t l_v2376; bool_t l_v2377; bool_t l_v2382;
	bool_t l_v2388; bool_t l_v2392; bool_t l_v2397; bool_t l_v2407;
	bool_t l_v2410; bool_t l_v2413; bool_t l_v2415; bool_t l_v2420;
	char l_v2331; char l_v2342; char l_v2353; char l_v2412;
	double l_v2298; struct pypy_header0 *l_v2379;
	struct pypy_object0 *l_v2399; struct pypy_object_vtable0 *l_v2303;
	struct pypy_object_vtable0 *l_v2322;
	struct pypy_object_vtable0 *l_v2367;
	struct pypy_object_vtable0 *l_v2387;
	struct pypy_object_vtable0 *l_v2391;
	struct pypy_object_vtable0 *l_v2396;
	struct pypy_object_vtable0 *l_v2400;
	struct pypy_object_vtable0 *l_v2419;
	struct pypy_rpy_string0 *l_v2297; struct pypy_rpy_string0 *l_v2301;
	struct pypy_rpy_string0 *l_v2418; struct pypy_tuple2_0 *l_v2302;
	struct pypy_tuple2_0 *l_v2423; void* l_v2312; void* l_v2313;
	void* l_v2315; void* l_v2317; void* l_v2318; void* l_v2320;
	void* l_v2357; void* l_v2358; void* l_v2360; void* l_v2362;
	void* l_v2363; void* l_v2365; void* l_v2372; void* l_v2374;
	void* l_v2375; void* l_v2378; void* l_v2381; void* l_v2390;
	void* l_v2395; void* l_v2424; void* l_v2425;
	struct pypy_rpy_string0 *l_value_5;
	goto block0;

    block0:
	l_s_3 = pypy_g_ll_os_ll_os_getenv(l_varname_0);
	l_v2303 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2304 = (l_v2303 == NULL);
	if (!l_v2304) {
		goto block38;
	}
	goto block1;

    block1:
	l_v2305 = (l_s_3 != NULL);
	if (l_v2305) {
		goto block3;
	}
	l_v2423 = (&pypy_g_tuple2);
	goto block2;

    block2:
	RPY_DEBUG_RETURN();
	return l_v2423;

    block3:
	l_v2306 = RPyField(l_s_3, rs_chars).length;
	OP_INT_NE(l_v2306, 0L, l_v2307);
	if (l_v2307) {
		goto block4;
	}
	l_v2423 = (&pypy_g_tuple2);
	goto block2;

    block4:
	l_v2308 = RPyField(l_s_3, rs_chars).length;
	OP_INT_GT(l_v2308, 1L, l_v2309);
	if (l_v2309) {
		goto block33;
	}
	l_value_5 = l_s_3;
	goto block5;

    block5:
	l_v2310 = RPyField(l_value_5, rs_chars).length;
	OP_INT_SUB(l_v2310, 1L, l_v2311);
	l_v2312 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v2312, sizeof(void*), l_v2313);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v2313;
	l_v2315 = (void*)l_value_5;
	((void* *) (((char *)l_v2312) + 0))[0] = l_v2315;
	l_v2297 = pypy_g__ll_stringslice__rpy_stringPtr_Signed_Signed(l_value_5, 0L, l_v2311);
	l_v2317 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v2317, sizeof(void*), l_v2318);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v2318;
	l_v2320 = ((void* *) (((char *)l_v2318) + 0))[0];
	l_value_5 = l_v2320; /* for moving GCs */
	l_v2322 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2323 = (l_v2322 == NULL);
	if (!l_v2323) {
		goto block32;
	}
	goto block6;

    block6:
	l_v2324 = RPyField(l_value_5, rs_chars).length;
	OP_INT_ADD(-1L, l_v2324, l_v2325);
	OP_INT_GE(l_v2325, 0L, l_v2326);
	RPyAssert(l_v2326, "negative str getitem index");
	l_v2328 = RPyField(l_value_5, rs_chars).length;
	OP_INT_LT(l_v2325, l_v2328, l_v2329);
	RPyAssert(l_v2329, "str getitem index out of bound");
	l_c_0 = RPyField(l_value_5, rs_chars).items[l_v2325];
	l_i_12 = 0L;
	l_strlen_1 = 2L;
	l_chars_5 = (&pypy_g_rpy_string_17.b);
	goto block7;

    block7:
	while (1) {
		l_v2331 = RPyField(l_chars_5, rs_chars).items[l_i_12];
		OP_CHAR_EQ(l_v2331, l_c_0, l_v2332);
		if (l_v2332) break;
		goto block8;
	  block7_back: ;
	}
	l_v2301 = l_v2297;
	l_v2295 = 1024L;
	goto block15;

    block8:
	OP_INT_ADD(l_i_12, 1L, l_v2333);
	OP_INT_LT(l_v2333, l_strlen_1, l_v2334);
	if (l_v2334) {
		l_i_12 = l_v2333;
		goto block7_back;
	}
	goto block9;

    block9:
	l_v2335 = RPyField(l_value_5, rs_chars).length;
	OP_INT_ADD(-1L, l_v2335, l_v2336);
	OP_INT_GE(l_v2336, 0L, l_v2337);
	RPyAssert(l_v2337, "negative str getitem index");
	l_v2339 = RPyField(l_value_5, rs_chars).length;
	OP_INT_LT(l_v2336, l_v2339, l_v2340);
	RPyAssert(l_v2340, "str getitem index out of bound");
	l_c_1 = RPyField(l_value_5, rs_chars).items[l_v2336];
	l_v2299 = 0L;
	l_strlen_2 = 2L;
	l_chars_4 = (&pypy_g_rpy_string_18.b);
	goto block10;

    block10:
	while (1) {
		l_v2342 = RPyField(l_chars_4, rs_chars).items[l_v2299];
		OP_CHAR_EQ(l_v2342, l_c_1, l_v2343);
		if (l_v2343) break;
		goto block11;
	  block10_back: ;
	}
	l_v2301 = l_v2297;
	l_v2295 = 1048576L;
	goto block15;

    block11:
	OP_INT_ADD(l_v2299, 1L, l_v2344);
	OP_INT_LT(l_v2344, l_strlen_2, l_v2345);
	if (l_v2345) {
		l_v2299 = l_v2344;
		goto block10_back;
	}
	goto block12;

    block12:
	l_v2346 = RPyField(l_value_5, rs_chars).length;
	OP_INT_ADD(-1L, l_v2346, l_v2347);
	OP_INT_GE(l_v2347, 0L, l_v2348);
	RPyAssert(l_v2348, "negative str getitem index");
	l_v2350 = RPyField(l_value_5, rs_chars).length;
	OP_INT_LT(l_v2347, l_v2350, l_v2351);
	RPyAssert(l_v2351, "str getitem index out of bound");
	l_c_2 = RPyField(l_value_5, rs_chars).items[l_v2347];
	l_i_13 = 0L;
	l_chars_6 = (&pypy_g_rpy_string_19.b);
	l_strlen_3 = 2L;
	goto block13;

    block13:
	while (1) {
		l_v2353 = RPyField(l_chars_6, rs_chars).items[l_i_13];
		OP_CHAR_EQ(l_v2353, l_c_2, l_v2354);
		if (l_v2354) break;
		goto block14;
	  block13_back: ;
	}
	l_v2301 = l_v2297;
	l_v2295 = 1073741824L;
	goto block15;

    block14:
	OP_INT_ADD(l_i_13, 1L, l_v2355);
	OP_INT_LT(l_v2355, l_strlen_3, l_v2356);
	if (l_v2356) {
		l_i_13 = l_v2355;
		goto block13_back;
	}
	l_v2301 = l_value_5;
	l_v2295 = 1L;
	goto block15;

    block15:
	l_v2357 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v2357, sizeof(void*), l_v2358);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v2358;
	l_v2360 = (void*)l_v2301;
	((void* *) (((char *)l_v2357) + 0))[0] = l_v2360;
	l_v2298 = pypy_g_ll_float__rpy_stringPtr(l_v2301);
	l_v2362 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v2362, sizeof(void*), l_v2363);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v2363;
	l_v2365 = ((void* *) (((char *)l_v2363) + 0))[0];
	l_v2301 = l_v2365; /* for moving GCs */
	l_v2367 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2368 = (l_v2367 == NULL);
	if (!l_v2368) {
		goto block31;
	}
	goto block16;

    block16:
	OP_RAW_MALLOC_USAGE((0 + ROUND_UP_FOR_ALLOCATION(sizeof(struct pypy_tuple2_0), 0L)), l_v2300);
	OP_INT_GT(l_v2300, 67583L, l_v2369);
	if (l_v2369) {
		goto block29;
	}
	goto block17;

    block17:
	OP_RAW_MALLOC_USAGE((sizeof(struct pypy_header0) + sizeof(void*)), l_v2370);
	OP_INT_LT(l_v2300, l_v2370, l_v2371);
	if (l_v2371) {
		l_v2296 = l_v2370;
		goto block18;
	}
	l_v2296 = (0 + ROUND_UP_FOR_ALLOCATION(sizeof(struct pypy_tuple2_0), 0L));
	goto block18;

    block18:
	l_result_6 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	OP_ADR_ADD(l_result_6, l_v2296, l_v2372);
	(&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free = l_v2372;
	l_v2374 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	l_v2375 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_top;
	OP_ADR_GT(l_v2374, l_v2375, l_v2376);
	if (l_v2376) {
		goto block27;
	}
	l_result_5 = l_result_6;
	goto block19;

    block19:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v2377);
	if (l_v2377) {
		goto block25;
	}
	goto block20;

    block20:
	OP_ADR_ADD(l_result_5, 0, l_v2378);
	l_v2379 = (struct pypy_header0 *)l_result_5;
	RPyField(l_v2379, h_tid) = (GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member21)+0L);
	l_v2424 = l_v2378;
	goto block21;

    block21:
	l_v2381 = (void*)l_v2424;
	l_v2425 = l_v2381;
	goto block22;

    block22:
	l_v2302 = (struct pypy_tuple2_0 *)l_v2425;
	l_v2382 = (l_v2302 != NULL);
	if (!l_v2382) {
		goto block24;
	}
	goto block23;

    block23:
	RPyField(l_v2302, t_item0) = l_v2298;
	RPyField(l_v2302, t_item1) = l_v2295;
	l_v2423 = l_v2302;
	goto block2;

    block24:
	PYPY_DEBUG_RECORD_TRACEBACK("_read_float_and_factor_from_env");
	l_v2423 = ((struct pypy_tuple2_0 *) NULL);
	goto block2;

    block25:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v2387 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2388 = (l_v2387 == NULL);
	if (!l_v2388) {
		goto block26;
	}
	goto block20;

    block26:
	PYPY_DEBUG_RECORD_TRACEBACK("_read_float_and_factor_from_env");
	l_v2425 = NULL;
	goto block22;

    block27:
	l_v2390 = pypy_g_MiniMarkGC_collect_and_reserve((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_result_6, l_v2296);
	l_v2391 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2392 = (l_v2391 == NULL);
	if (!l_v2392) {
		goto block28;
	}
	l_result_5 = l_v2390;
	goto block19;

    block28:
	PYPY_DEBUG_RECORD_TRACEBACK("_read_float_and_factor_from_env");
	l_v2425 = NULL;
	goto block22;

    block29:
	RPyAssert(1, "'contains_weakptr' specified for a large object");
	l_v2395 = pypy_g_MiniMarkGC_external_malloc((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member21), 0L, 1);
	l_v2396 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2397 = (l_v2396 == NULL);
	if (!l_v2397) {
		goto block30;
	}
	l_v2424 = l_v2395;
	goto block21;

    block30:
	PYPY_DEBUG_RECORD_TRACEBACK("_read_float_and_factor_from_env");
	l_v2425 = NULL;
	goto block22;

    block31:
	l_v2399 = (&pypy_g_ExcData)->ed_exc_value;
	l_v2400 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("_read_float_and_factor_from_env", l_v2400, l_v2400 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_v2400 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	l_v2423 = (&pypy_g_tuple2);
	goto block2;

    block32:
	PYPY_DEBUG_RECORD_TRACEBACK("_read_float_and_factor_from_env");
	l_v2423 = ((struct pypy_tuple2_0 *) NULL);
	goto block2;

    block33:
	l_v2405 = RPyField(l_s_3, rs_chars).length;
	OP_INT_ADD(-1L, l_v2405, l_v2406);
	OP_INT_GE(l_v2406, 0L, l_v2407);
	RPyAssert(l_v2407, "negative str getitem index");
	l_v2409 = RPyField(l_s_3, rs_chars).length;
	OP_INT_LT(l_v2406, l_v2409, l_v2410);
	RPyAssert(l_v2410, "str getitem index out of bound");
	l_c_3 = RPyField(l_s_3, rs_chars).items[l_v2406];
	l_chars_3 = (&pypy_g_rpy_string_20.b);
	l_i_11 = 0L;
	l_strlen_0 = 2L;
	goto block34;

    block34:
	while (1) {
		l_v2412 = RPyField(l_chars_3, rs_chars).items[l_i_11];
		OP_CHAR_EQ(l_v2412, l_c_3, l_v2413);
		if (l_v2413) break;
		goto block35;
	  block34_back: ;
	}
	goto block36;

    block35:
	OP_INT_ADD(l_i_11, 1L, l_v2414);
	OP_INT_LT(l_v2414, l_strlen_0, l_v2415);
	if (l_v2415) {
		l_i_11 = l_v2414;
		goto block34_back;
	}
	l_value_5 = l_s_3;
	goto block5;

    block36:
	l_v2416 = RPyField(l_s_3, rs_chars).length;
	OP_INT_SUB(l_v2416, 1L, l_v2417);
	l_v2418 = pypy_g__ll_stringslice__rpy_stringPtr_Signed_Signed(l_s_3, 0L, l_v2417);
	l_v2419 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2420 = (l_v2419 == NULL);
	if (!l_v2420) {
		goto block37;
	}
	l_value_5 = l_v2418;
	goto block5;

    block37:
	PYPY_DEBUG_RECORD_TRACEBACK("_read_float_and_factor_from_env");
	l_v2423 = ((struct pypy_tuple2_0 *) NULL);
	goto block2;

    block38:
	PYPY_DEBUG_RECORD_TRACEBACK("_read_float_and_factor_from_env");
	l_v2423 = ((struct pypy_tuple2_0 *) NULL);
	goto block2;
}
/*/*/
double pypy_g_get_total_memory_linux(struct pypy_rpy_string0 *l_filename_0) {
	struct pypy_rpy_string0 *l_chars2_0; struct pypy_object0 *l_evalue_2;
	struct pypy_object0 *l_evalue_3; Signed l_j_5; Signed l_len2_0;
	double l_result_7; struct pypy_rpy_string0 *l_s1_4;
	Signed l_start_10; Signed l_stop_2; Signed l_v2430; Signed l_v2433;
	Signed l_v2454; Signed l_v2459; Signed l_v2461; Signed l_v2467;
	Signed l_v2480; Signed l_v2481; Signed l_v2483; Signed l_v2486;
	Signed l_v2492; Signed l_v2515; Signed l_v2530; bool_t l_v2438;
	bool_t l_v2440; bool_t l_v2453; bool_t l_v2455; bool_t l_v2458;
	bool_t l_v2460; bool_t l_v2462; bool_t l_v2463; bool_t l_v2466;
	bool_t l_v2468; bool_t l_v2471; bool_t l_v2473; bool_t l_v2474;
	bool_t l_v2476; bool_t l_v2479; bool_t l_v2482; bool_t l_v2484;
	bool_t l_v2487; bool_t l_v2490; bool_t l_v2491; bool_t l_v2496;
	bool_t l_v2514; bool_t l_v2516; bool_t l_v2522; bool_t l_v2527;
	char l_v2456; char l_v2457; char l_v2489; double l_v2432;
	double l_v2434; double l_v2529;
	struct pypy_exceptions_Exception0 *l_v2429;
	struct pypy_object0 *l_v2428; struct pypy_object0 *l_v2498;
	struct pypy_object0 *l_v2517; struct pypy_object_vtable0 *l_v2426;
	struct pypy_object_vtable0 *l_v2427;
	struct pypy_object_vtable0 *l_v2431;
	struct pypy_object_vtable0 *l_v2435;
	struct pypy_object_vtable0 *l_v2437;
	struct pypy_object_vtable0 *l_v2439;
	struct pypy_object_vtable0 *l_v2452;
	struct pypy_object_vtable0 *l_v2470;
	struct pypy_object_vtable0 *l_v2472;
	struct pypy_object_vtable0 *l_v2513;
	struct pypy_rpy_string0 *l_v2469; struct pypy_rpy_string0 *l_v2531;
	void* l_v2441; void* l_v2442; void* l_v2444; void* l_v2447;
	void* l_v2448; void* l_v2450; void* l_v2502; void* l_v2503;
	void* l_v2505; void* l_v2508; void* l_v2509; void* l_v2511;
	goto block0;

    block0:
	PYPY_DEBUG_START("gc-hardware");
	l_v2430 = pypy_g_ll_os_ll_os_open((&pypy_g_rpy_string_9.b), 0L, 420L);
	l_v2437 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2438 = (l_v2437 == NULL);
	if (!l_v2438) {
		goto block34;
	}
	goto block1;

    block1:
	l_s1_4 = pypy_g_ll_os_ll_os_read(l_v2430, 4096L);
	l_v2439 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2440 = (l_v2439 == NULL);
	if (!l_v2440) {
		goto block29;
	}
	goto block2;

    block2:
	l_v2441 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v2441, sizeof(void*), l_v2442);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v2442;
	l_v2444 = (void*)l_s1_4;
	((void* *) (((char *)l_v2441) + 0))[0] = l_v2444;
	pypy_g_ll_os_ll_os_close(l_v2430);
	l_v2447 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v2447, sizeof(void*), l_v2448);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v2448;
	l_v2450 = ((void* *) (((char *)l_v2448) + 0))[0];
	l_s1_4 = l_v2450; /* for moving GCs */
	l_v2452 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2453 = (l_v2452 == NULL);
	if (!l_v2453) {
		goto block27;
	}
	goto block3;

    block3:
	l_v2454 = RPyField(l_s1_4, rs_chars).length;
	OP_INT_LT(l_v2454, 9L, l_v2455);
	if (l_v2455) {
		goto block9;
	}
	l_chars2_0 = (&pypy_g_rpy_string_22.b);
	l_j_5 = 0L;
	l_len2_0 = 9L;
	goto block4;

    block4:
	while (1) {
		l_v2456 = RPyField(l_s1_4, rs_chars).items[l_j_5];
		l_v2457 = RPyField(l_chars2_0, rs_chars).items[l_j_5];
		OP_CHAR_NE(l_v2456, l_v2457, l_v2458);
		if (l_v2458) break;
		goto block5;
	  block4_back: ;
	}
	goto block9;

    block5:
	OP_INT_ADD(l_j_5, 1L, l_v2459);
	OP_INT_LT(l_v2459, l_len2_0, l_v2460);
	if (l_v2460) {
		l_j_5 = l_v2459;
		goto block4_back;
	}
	goto block6;

    block6:
	l_start_10 = pypy_g__skipspace(l_s1_4, 9L);
	l_stop_2 = l_start_10;
	goto block7;

    block7:
	while (1) {
		l_v2461 = RPyField(l_s1_4, rs_chars).length;
		OP_INT_LT(l_stop_2, l_v2461, l_v2462);
		if (!l_v2462) break;
		goto block24;
	  block7_back: ;
	}
	goto block8;

    block8:
	OP_INT_LT(l_start_10, l_stop_2, l_v2463);
	if (l_v2463) {
		goto block12;
	}
	goto block9;

    block9:
	if (PYPY_HAVE_DEBUG_PRINTS) { fprintf(PYPY_DEBUG_FILE, "get_total_memory() failed\012"); }
	l_result_7 = 4294967296.0;
	goto block10;

    block10:
	PYPY_DEBUG_STOP("gc-hardware");
	l_v2529 = l_result_7;
	goto block11;

    block11:
	RPY_DEBUG_RETURN();
	return l_v2529;

    block12:
	OP_INT_IS_TRUE(0 /* we are not jitted here */, l_v2466);
	if (l_v2466) {
		goto block22;
	}
	goto block13;

    block13:
	l_v2467 = RPyField(l_s1_4, rs_chars).length;
	OP_INT_GE(l_stop_2, l_v2467, l_v2468);
	if (l_v2468) {
		goto block20;
	}
	l_v2530 = l_stop_2;
	goto block14;

    block14:
	l_v2469 = pypy_g__ll_stringslice__rpy_stringPtr_Signed_Signed(l_s1_4, l_start_10, l_v2530);
	l_v2470 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2471 = (l_v2470 == NULL);
	if (!l_v2471) {
		goto block19;
	}
	l_v2531 = l_v2469;
	goto block15;

    block15:
	l_v2434 = pypy_g_ll_float__rpy_stringPtr(l_v2531);
	l_v2472 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2473 = (l_v2472 == NULL);
	if (!l_v2473) {
		goto block18;
	}
	goto block16;

    block16:
	OP_FLOAT_MUL(l_v2434, 1024.0, l_v2432);
	OP_FLOAT_LT(l_v2432, 0.0, l_v2474);
	if (l_v2474) {
		goto block9;
	}
	goto block17;

    block17:
	if (PYPY_HAVE_DEBUG_PRINTS) { fprintf(PYPY_DEBUG_FILE, "memtotal = %f\012", l_v2432); }
	OP_FLOAT_GT(l_v2432, 4294967296.0, l_v2476);
	if (l_v2476) {
		l_result_7 = 4294967296.0;
		goto block10;
	}
	l_result_7 = l_v2432;
	goto block10;

    block18:
	PYPY_DEBUG_RECORD_TRACEBACK("get_total_memory_linux");
	l_v2529 = -1.0;
	goto block11;

    block19:
	PYPY_DEBUG_RECORD_TRACEBACK("get_total_memory_linux");
	l_v2529 = -1.0;
	goto block11;

    block20:
	OP_INT_EQ(l_start_10, 0L, l_v2479);
	if (l_v2479) {
		l_v2531 = l_s1_4;
		goto block15;
	}
	goto block21;

    block21:
	l_v2480 = RPyField(l_s1_4, rs_chars).length;
	l_v2530 = l_v2480;
	goto block14;

    block22:
	l_v2481 = RPyField(l_s1_4, rs_chars).length;
	OP_INT_GT(l_stop_2, l_v2481, l_v2482);
	if (l_v2482) {
		goto block23;
	}
	l_v2530 = l_stop_2;
	goto block14;

    block23:
	l_v2483 = RPyField(l_s1_4, rs_chars).length;
	l_v2530 = l_v2483;
	goto block14;

    block24:
	OP_INT_GE(l_stop_2, 0L, l_v2484);
	RPyAssert(l_v2484, "negative str getitem index");
	l_v2486 = RPyField(l_s1_4, rs_chars).length;
	OP_INT_LT(l_stop_2, l_v2486, l_v2487);
	RPyAssert(l_v2487, "str getitem index out of bound");
	l_v2489 = RPyField(l_s1_4, rs_chars).items[l_stop_2];
	OP_CAST_CHAR_TO_INT(l_v2489, l_v2433);
	OP_INT_LE(l_v2433, 57L, l_v2490);
	if (l_v2490) {
		goto block25;
	}
	goto block8;

    block25:
	OP_INT_GE(l_v2433, 48L, l_v2491);
	if (l_v2491) {
		goto block26;
	}
	goto block8;

    block26:
	OP_INT_ADD(l_stop_2, 1L, l_v2492);
	l_stop_2 = l_v2492;
	goto block7_back;

    block27:
	l_evalue_2 = (&pypy_g_ExcData)->ed_exc_value;
	l_v2426 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("get_total_memory_linux", l_v2426, l_v2426 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_v2426 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	l_v2496 = pypy_g_ll_issubclass__object_vtablePtr_object_vtablePtr(l_v2426, (&pypy_g_exceptions_OSError_vtable.ose_super.ee_super.se_super.e_super));
	if (l_v2496) {
		goto block9;
	}
	goto block28;

    block28:
	pypy_g_RPyReRaiseException(l_v2426, l_evalue_2);
	l_v2529 = -1.0;
	goto block11;

    block29:
	l_v2498 = (&pypy_g_ExcData)->ed_exc_value;
	l_v2427 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("get_total_memory_linux", l_v2427, l_v2427 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_v2427 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	l_v2429 = (struct pypy_exceptions_Exception0 *)l_v2498;
	l_v2502 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v2502, sizeof(void*), l_v2503);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v2503;
	l_v2505 = (void*)l_v2429;
	((void* *) (((char *)l_v2502) + 0))[0] = l_v2505;
	pypy_g_ll_os_ll_os_close(l_v2430);
	l_v2508 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v2508, sizeof(void*), l_v2509);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v2509;
	l_v2511 = ((void* *) (((char *)l_v2509) + 0))[0];
	l_v2429 = l_v2511; /* for moving GCs */
	l_v2513 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2514 = (l_v2513 == NULL);
	if (!l_v2514) {
		goto block32;
	}
	goto block30;

    block30:
	l_v2515 = RPyField(l_v2427, ov_subclassrange_min);
	l_v2516 = (l_v2515 == 23L);  /* was INT_BETWEEN */
	if (l_v2516) {
		goto block9;
	}
	goto block31;

    block31:
	l_v2517 = (struct pypy_object0 *)l_v2429;
	pypy_g_RPyReRaiseException(l_v2427, l_v2517);
	l_v2529 = -1.0;
	goto block11;

    block32:
	l_evalue_3 = (&pypy_g_ExcData)->ed_exc_value;
	l_v2431 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("get_total_memory_linux", l_v2431, l_v2431 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_v2431 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	l_v2522 = pypy_g_ll_issubclass__object_vtablePtr_object_vtablePtr(l_v2431, (&pypy_g_exceptions_OSError_vtable.ose_super.ee_super.se_super.e_super));
	if (l_v2522) {
		goto block9;
	}
	goto block33;

    block33:
	pypy_g_RPyReRaiseException(l_v2431, l_evalue_3);
	l_v2529 = -1.0;
	goto block11;

    block34:
	l_v2428 = (&pypy_g_ExcData)->ed_exc_value;
	l_v2435 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("get_total_memory_linux", l_v2435, l_v2435 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_v2435 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	l_v2527 = pypy_g_ll_issubclass__object_vtablePtr_object_vtablePtr(l_v2435, (&pypy_g_exceptions_OSError_vtable.ose_super.ee_super.se_super.e_super));
	if (l_v2527) {
		goto block9;
	}
	goto block35;

    block35:
	pypy_g_RPyReRaiseException(l_v2435, l_v2428);
	l_v2529 = -1.0;
	goto block11;
}
/*/*/
Signed pypy_g_get_L2cache_linux2(void) {
	struct pypy_rpy_string0 *l_chars2_1;
	struct pypy_rpy_string0 *l_chars2_2;
	struct pypy_rpy_string0 *l_chars2_3; Signed l_j_6; Signed l_len1_0;
	Signed l_len1_1; Signed l_len1_2; Signed l_len2_1; Signed l_offset_0;
	struct pypy_rpy_string0 *l_s1_5; Signed l_v2532; Signed l_v2533;
	Signed l_v2538; Signed l_v2542; Signed l_v2544; Signed l_v2552;
	Signed l_v2553; Signed l_v2556; Signed l_v2560; Signed l_v2561;
	Signed l_v2567; Signed l_v2569; bool_t l_v2536; bool_t l_v2537;
	bool_t l_v2541; bool_t l_v2543; bool_t l_v2545; bool_t l_v2546;
	bool_t l_v2547; bool_t l_v2548; bool_t l_v2549; bool_t l_v2550;
	bool_t l_v2551; bool_t l_v2554; bool_t l_v2555; bool_t l_v2559;
	bool_t l_v2562; bool_t l_v2563; bool_t l_v2566; char l_v2539;
	char l_v2540; char l_v2557; char l_v2558; char l_v2564; char l_v2565;
	struct pypy_object_vtable0 *l_v2535; struct pypy_tuple5_0 *l_v2534;
	goto block0;

    block0:
	l_v2534 = pypy_g_ll_os_ll_uname();
	l_v2535 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2536 = (l_v2535 == NULL);
	if (!l_v2536) {
		goto block26;
	}
	goto block1;

    block1:
	l_s1_5 = RPyField(l_v2534, t_item4);
	l_len1_1 = RPyField(l_s1_5, rs_chars).length;
	OP_INT_LT(l_len1_1, 2L, l_v2537);
	if (l_v2537) {
		goto block7;
	}
	goto block2;

    block2:
	OP_INT_SUB(l_len1_1, 2L, l_offset_0);
	l_chars2_3 = (&pypy_g_rpy_string_28.b);
	l_len2_1 = 2L;
	l_v2532 = 0L;
	goto block3;

    block3:
	while (1) {
		OP_INT_ADD(l_offset_0, l_v2532, l_v2538);
		l_v2539 = RPyField(l_s1_5, rs_chars).items[l_v2538];
		l_v2540 = RPyField(l_chars2_3, rs_chars).items[l_v2532];
		OP_CHAR_NE(l_v2539, l_v2540, l_v2541);
		if (l_v2541) break;
		goto block4;
	  block3_back: ;
	}
	goto block7;

    block4:
	OP_INT_ADD(l_v2532, 1L, l_v2542);
	OP_INT_LT(l_v2542, l_len2_1, l_v2543);
	if (l_v2543) {
		l_v2532 = l_v2542;
		goto block3_back;
	}
	goto block5;

    block5:
	l_v2544 = pypy_g_get_L2cache_linux2_cpuinfo((&pypy_g_rpy_string_29.b), (&pypy_g_rpy_string_30.b));
	l_v2569 = l_v2544;
	goto block6;

    block6:
	RPY_DEBUG_RETURN();
	return l_v2569;

    block7:
	l_v2545 = (l_s1_5 == (&pypy_g_rpy_string_31.b));
	if (l_v2545) {
		goto block5;
	}
	goto block8;

    block8:
	l_v2546 = (l_s1_5 != NULL);
	if (l_v2546) {
		goto block22;
	}
	goto block9;

    block9:
	l_v2547 = pypy_g_ll_contains__dicttablePtr_rpy_stringPtr((&pypy_g_dicttable), l_s1_5);
	if (l_v2547) {
		goto block21;
	}
	goto block10;

    block10:
	l_v2548 = (l_s1_5 == (&pypy_g_rpy_string_32.b));
	if (l_v2548) {
		goto block18;
	}
	goto block11;

    block11:
	l_v2549 = (l_s1_5 != NULL);
	if (l_v2549) {
		goto block16;
	}
	goto block12;

    block12:
	l_v2550 = pypy_g_ll_contains__dicttablePtr_rpy_stringPtr((&pypy_g_dicttable_1), l_s1_5);
	if (l_v2550) {
		goto block15;
	}
	goto block13;

    block13:
	l_v2551 = pypy_g_ll_contains__dicttablePtr_rpy_stringPtr((&pypy_g_dicttable_2), l_s1_5);
	if (l_v2551) {
		goto block14;
	}
	l_v2569 = -1L;
	goto block6;

    block14:
	l_v2552 = pypy_g_get_L2cache_linux2_sparc();
	l_v2569 = l_v2552;
	goto block6;

    block15:
	l_v2553 = pypy_g_get_L2cache_linux2_cpuinfo((&pypy_g_rpy_string_29.b), (&pypy_g_rpy_string_33.b));
	l_v2569 = l_v2553;
	goto block6;

    block16:
	l_len1_0 = RPyField(l_s1_5, rs_chars).length;
	OP_INT_NE(l_len1_0, 4L, l_v2554);
	if (l_v2554) {
		goto block12;
	}
	l_j_6 = 0L;
	l_chars2_1 = (&pypy_g_rpy_string_32.b);
	goto block17;

    block17:
	while (1) {
		OP_INT_LT(l_j_6, l_len1_0, l_v2555);
		if (!l_v2555) break;
		goto block19;
	  block17_back: ;
	}
	goto block18;

    block18:
	l_v2556 = pypy_g_get_L2cache_linux2_ia64();
	l_v2569 = l_v2556;
	goto block6;

    block19:
	l_v2557 = RPyField(l_s1_5, rs_chars).items[l_j_6];
	l_v2558 = RPyField(l_chars2_1, rs_chars).items[l_j_6];
	OP_CHAR_NE(l_v2557, l_v2558, l_v2559);
	if (l_v2559) {
		goto block12;
	}
	goto block20;

    block20:
	OP_INT_ADD(l_j_6, 1L, l_v2560);
	l_j_6 = l_v2560;
	goto block17_back;

    block21:
	l_v2561 = pypy_g_get_L2cache_linux2_cpuinfo((&pypy_g_rpy_string_29.b), (&pypy_g_rpy_string_34.b));
	l_v2569 = l_v2561;
	goto block6;

    block22:
	l_len1_2 = RPyField(l_s1_5, rs_chars).length;
	OP_INT_NE(l_len1_2, 6L, l_v2562);
	if (l_v2562) {
		goto block9;
	}
	l_chars2_2 = (&pypy_g_rpy_string_31.b);
	l_v2533 = 0L;
	goto block23;

    block23:
	while (1) {
		OP_INT_LT(l_v2533, l_len1_2, l_v2563);
		if (!l_v2563) break;
		goto block24;
	  block23_back: ;
	}
	goto block5;

    block24:
	l_v2564 = RPyField(l_s1_5, rs_chars).items[l_v2533];
	l_v2565 = RPyField(l_chars2_2, rs_chars).items[l_v2533];
	OP_CHAR_NE(l_v2564, l_v2565, l_v2566);
	if (l_v2566) {
		goto block9;
	}
	goto block25;

    block25:
	OP_INT_ADD(l_v2533, 1L, l_v2567);
	l_v2533 = l_v2567;
	goto block23_back;

    block26:
	PYPY_DEBUG_RECORD_TRACEBACK("get_L2cache_linux2");
	l_v2569 = -1L;
	goto block6;
}
/*/*/
Signed pypy_g__skipspace(struct pypy_rpy_string0 *l_data_2, Signed l_pos_0) {
	Signed l_v2571; Signed l_v2572; Signed l_v2575; Signed l_v2582;
	Unsigned l_v2579; Unsigned l_v2580; Unsigned l_v2583;
	Unsigned l_v2584; bool_t l_v2573; bool_t l_v2576; bool_t l_v2578;
	bool_t l_v2581; char l_v2570;
	goto block0;

    block0:
	l_v2572 = l_pos_0;
	goto block1;

    block1:
	while (1) {
		OP_INT_GE(l_v2572, 0L, l_v2573);
		RPyAssert(l_v2573, "negative str getitem index");
		l_v2575 = RPyField(l_data_2, rs_chars).length;
		OP_INT_LT(l_v2572, l_v2575, l_v2576);
		RPyAssert(l_v2576, "str getitem index out of bound");
		l_v2570 = RPyField(l_data_2, rs_chars).items[l_v2572];
		OP_CAST_CHAR_TO_INT(l_v2570, l_v2571);
		OP_INT_IS_TRUE(0 /* we are not jitted here */, l_v2578);
		if (l_v2578) break;
		goto block2;
	  block1_back: ;
	}
	goto block6;

    block2:
	l_v2579 = pypy_g_ll_dict_lookup__v141___simple_call__function_l((&pypy_g_dicttable_3), l_v2570, l_v2571);
	l_v2584 = l_v2579;
	goto block3;

    block3:
	OP_UINT_AND(l_v2584, 2147483648UL, l_v2580);
	OP_UINT_IS_TRUE(l_v2580, l_v2581);
	if (l_v2581) {
		goto block5;
	}
	goto block4;

    block4:
	OP_INT_ADD(l_v2572, 1L, l_v2582);
	l_v2572 = l_v2582;
	goto block1_back;

    block5:
	RPY_DEBUG_RETURN();
	return l_v2572;

    block6:
	l_v2583 = pypy_g_ll_dict_lookup__v150___simple_call__function_l((&pypy_g_dicttable_3), l_v2570, l_v2571);
	l_v2584 = l_v2583;
	goto block3;
}
/*/*/
Signed pypy_g_get_L2cache_linux2_cpuinfo(struct pypy_rpy_string0 *l_filename_1, struct pypy_rpy_string0 *l_label_1) {
	Signed l_L2cache_0; Signed l_L2cache_1;
	struct pypy_rpy_string0 *l_buf_0; struct pypy_list0 *l_data_4;
	struct pypy_rpy_string0 *l_data_3; Signed l_end_3;
	struct pypy_object_vtable0 *l_etype_2;
	struct pypy_object_vtable0 *l_etype_3;
	struct pypy_object_vtable0 *l_etype_4;
	struct pypy_object0 *l_evalue_4; Signed l_linepos_0;
	Signed l_linepos_1; Signed l_rawtotalsize_0; void* l_result_8;
	void* l_result_9; Signed l_start_11; Signed l_v2586; Signed l_v2588;
	Signed l_v2589; Signed l_v2593; Signed l_v2595; Signed l_v2596;
	Signed l_v2597; Signed l_v2598; Signed l_v2604; Signed l_v2605;
	Signed l_v2625; Signed l_v2709; Signed l_v2711; Signed l_v2713;
	Signed l_v2718; Signed l_v2723; Signed l_v2726; Signed l_v2732;
	Signed l_v2753; Signed l_v2756; Signed l_v2763; Signed l_v2769;
	Signed l_v2770; Signed l_v2772; Signed l_v2774; Signed l_v2800;
	Signed l_v2802; Signed l_v2824; Signed l_v2829; Signed l_v2830;
	Signed l_v2852; Signed l_v2880; Signed l_v2883; Unsigned l_v2760;
	Unsigned l_v2761; Unsigned l_v2765; Unsigned l_v2885; bool_t l_v2618;
	bool_t l_v2624; bool_t l_v2626; bool_t l_v2631; bool_t l_v2632;
	bool_t l_v2642; bool_t l_v2660; bool_t l_v2661; bool_t l_v2678;
	bool_t l_v2679; bool_t l_v2692; bool_t l_v2708; bool_t l_v2710;
	bool_t l_v2712; bool_t l_v2714; bool_t l_v2715; bool_t l_v2716;
	bool_t l_v2719; bool_t l_v2722; bool_t l_v2724; bool_t l_v2727;
	bool_t l_v2729; bool_t l_v2730; bool_t l_v2731; bool_t l_v2733;
	bool_t l_v2750; bool_t l_v2752; bool_t l_v2754; bool_t l_v2757;
	bool_t l_v2759; bool_t l_v2762; bool_t l_v2764; bool_t l_v2768;
	bool_t l_v2771; bool_t l_v2773; bool_t l_v2777; bool_t l_v2793;
	bool_t l_v2798; bool_t l_v2801; bool_t l_v2823; bool_t l_v2825;
	bool_t l_v2831; bool_t l_v2851; bool_t l_v2853; bool_t l_v2859;
	bool_t l_v2864; bool_t l_v2868; bool_t l_v2873; bool_t l_v2878;
	char l_v2585; char l_v2590; char l_v2721;
	struct pypy_array3 *l_v2592; struct pypy_array3 *l_v2594;
	struct pypy_exceptions_Exception0 *l_v2599;
	struct pypy_header0 *l_v2634; struct pypy_header0 *l_v2828;
	struct pypy_object0 *l_v2587; struct pypy_object0 *l_v2601;
	struct pypy_object0 *l_v2835; struct pypy_object0 *l_v2854;
	struct pypy_object_vtable0 *l_v2602;
	struct pypy_object_vtable0 *l_v2617;
	struct pypy_object_vtable0 *l_v2659;
	struct pypy_object_vtable0 *l_v2677;
	struct pypy_object_vtable0 *l_v2691;
	struct pypy_object_vtable0 *l_v2707;
	struct pypy_object_vtable0 *l_v2749;
	struct pypy_object_vtable0 *l_v2751;
	struct pypy_object_vtable0 *l_v2792;
	struct pypy_object_vtable0 *l_v2822;
	struct pypy_object_vtable0 *l_v2850;
	struct pypy_object_vtable0 *l_v2863;
	struct pypy_object_vtable0 *l_v2867;
	struct pypy_object_vtable0 *l_v2872;
	struct pypy_rpy_string0 *l_v2600; struct pypy_rpy_string0 *l_v2685;
	struct pypy_rpy_string0 *l_v2741; struct pypy_rpy_string0 *l_v2786;
	struct pypy_rpy_string0 *l_v2884; void* l_v2591; void* l_v2603;
	void* l_v2607; void* l_v2608; void* l_v2610; void* l_v2612;
	void* l_v2613; void* l_v2615; void* l_v2619; void* l_v2620;
	void* l_v2622; void* l_v2627; void* l_v2629; void* l_v2630;
	void* l_v2633; void* l_v2636; void* l_v2637; void* l_v2638;
	void* l_v2640; void* l_v2645; void* l_v2646; void* l_v2648;
	void* l_v2650; void* l_v2652; void* l_v2653; void* l_v2655;
	void* l_v2657; void* l_v2662; void* l_v2663; void* l_v2665;
	void* l_v2667; void* l_v2670; void* l_v2671; void* l_v2673;
	void* l_v2675; void* l_v2680; void* l_v2681; void* l_v2683;
	void* l_v2686; void* l_v2687; void* l_v2689; void* l_v2693;
	void* l_v2694; void* l_v2696; void* l_v2698; void* l_v2700;
	void* l_v2701; void* l_v2703; void* l_v2705; void* l_v2734;
	void* l_v2735; void* l_v2737; void* l_v2739; void* l_v2742;
	void* l_v2743; void* l_v2745; void* l_v2747; void* l_v2781;
	void* l_v2782; void* l_v2784; void* l_v2787; void* l_v2788;
	void* l_v2790; void* l_v2803; void* l_v2804; void* l_v2806;
	void* l_v2808; void* l_v2810; void* l_v2813; void* l_v2814;
	void* l_v2816; void* l_v2818; void* l_v2820; void* l_v2827;
	void* l_v2839; void* l_v2840; void* l_v2842; void* l_v2845;
	void* l_v2846; void* l_v2848; void* l_v2866; void* l_v2871;
	void* l_v2881; void* l_v2882;
	goto block0;

    block0:
	PYPY_DEBUG_START("gc-hardware");
	l_v2607 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v2607, sizeof(void*), l_v2608);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v2608;
	l_v2610 = (void*)l_label_1;
	((void* *) (((char *)l_v2607) + 0))[0] = l_v2610;
	l_v2586 = pypy_g_ll_os_ll_os_open((&pypy_g_rpy_string_29.b), 0L, 420L);
	l_v2612 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v2612, sizeof(void*), l_v2613);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v2613;
	l_v2615 = ((void* *) (((char *)l_v2613) + 0))[0];
	l_label_1 = l_v2615; /* for moving GCs */
	l_v2617 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2618 = (l_v2617 == NULL);
	if (!l_v2618) {
		goto block67;
	}
	goto block1;

    block1:
	l_v2619 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v2619, sizeof(void*), l_v2620);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v2620;
	l_v2622 = (void*)l_label_1;
	((void* *) (((char *)l_v2619) + 0))[0] = l_v2622;
	OP_RAW_MALLOC_USAGE((0 + ROUND_UP_FOR_ALLOCATION(sizeof(struct pypy_list0), 0L)), l_rawtotalsize_0);
	OP_INT_GT(l_rawtotalsize_0, 67583L, l_v2624);
	if (l_v2624) {
		goto block65;
	}
	goto block2;

    block2:
	OP_RAW_MALLOC_USAGE((sizeof(struct pypy_header0) + sizeof(void*)), l_v2625);
	OP_INT_LT(l_rawtotalsize_0, l_v2625, l_v2626);
	if (l_v2626) {
		l_v2598 = l_v2625;
		goto block3;
	}
	l_v2598 = (0 + ROUND_UP_FOR_ALLOCATION(sizeof(struct pypy_list0), 0L));
	goto block3;

    block3:
	l_result_9 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	OP_ADR_ADD(l_result_9, l_v2598, l_v2627);
	(&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free = l_v2627;
	l_v2629 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	l_v2630 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_top;
	OP_ADR_GT(l_v2629, l_v2630, l_v2631);
	if (l_v2631) {
		goto block63;
	}
	l_result_8 = l_result_9;
	goto block4;

    block4:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v2632);
	if (l_v2632) {
		goto block61;
	}
	goto block5;

    block5:
	OP_ADR_ADD(l_result_8, 0, l_v2633);
	l_v2634 = (struct pypy_header0 *)l_result_8;
	RPyField(l_v2634, h_tid) = (GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member19)+0L);
	l_v2881 = l_v2633;
	goto block6;

    block6:
	l_v2636 = (void*)l_v2881;
	l_v2882 = l_v2636;
	goto block7;

    block7:
	l_v2637 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v2637, sizeof(void*), l_v2638);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v2638;
	l_v2640 = ((void* *) (((char *)l_v2638) + 0))[0];
	l_label_1 = l_v2640; /* for moving GCs */
	l_data_4 = (struct pypy_list0 *)l_v2882;
	l_v2642 = (l_data_4 != NULL);
	if (!l_v2642) {
		goto block60;
	}
	goto block8;

    block8:
	RPyField(l_data_4, l_length) = 0L;
	RPyField(l_data_4, l_items) = (&pypy_g_array_30.b);
	goto block9;

    block9:
	while (1) {
		l_v2645 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
		OP_ADR_ADD(l_v2645, (sizeof(void*) * 2), l_v2646);
		(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v2646;
		l_v2648 = (void*)l_data_4;
		((void* *) (((char *)l_v2645) + 0))[0] = l_v2648;
		l_v2650 = (void*)l_label_1;
		((void* *) (((char *)l_v2645) + sizeof(void*)))[0] = l_v2650;
		l_buf_0 = pypy_g_ll_os_ll_os_read(l_v2586, 4096L);
		l_v2652 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
		OP_ADR_SUB(l_v2652, (sizeof(void*) * 2), l_v2653);
		(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v2653;
		l_v2655 = ((void* *) (((char *)l_v2653) + 0))[0];
		l_data_4 = l_v2655; /* for moving GCs */
		l_v2657 = ((void* *) (((char *)l_v2653) + sizeof(void*)))[0];
		l_label_1 = l_v2657; /* for moving GCs */
		l_v2659 = (&pypy_g_ExcData)->ed_exc_type;
		l_v2660 = (l_v2659 == NULL);
		if (!l_v2660) break;
		goto block10;
	  block9_back: ;
	}
	goto block55;

    block10:
	l_v2661 = (l_buf_0 != NULL);
	if (l_v2661) {
		goto block49;
	}
	goto block11;

    block11:
	l_v2662 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v2662, (sizeof(void*) * 2), l_v2663);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v2663;
	l_v2665 = (void*)l_data_4;
	((void* *) (((char *)l_v2662) + 0))[0] = l_v2665;
	l_v2667 = (void*)l_label_1;
	((void* *) (((char *)l_v2662) + sizeof(void*)))[0] = l_v2667;
	pypy_g_ll_os_ll_os_close(l_v2586);
	l_v2670 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v2670, (sizeof(void*) * 2), l_v2671);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v2671;
	l_v2673 = ((void* *) (((char *)l_v2671) + 0))[0];
	l_data_4 = l_v2673; /* for moving GCs */
	l_v2675 = ((void* *) (((char *)l_v2671) + sizeof(void*)))[0];
	l_label_1 = l_v2675; /* for moving GCs */
	l_v2677 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2678 = (l_v2677 == NULL);
	if (!l_v2678) {
		goto block47;
	}
	goto block12;

    block12:
	l_v2593 = RPyField(l_data_4, l_length);
	l_v2594 = RPyField(l_data_4, l_items);
	OP_INT_IS_TRUE(0 /* we are not jitted here */, l_v2679);
	if (l_v2679) {
		goto block45;
	}
	goto block13;

    block13:
	l_v2680 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v2680, sizeof(void*), l_v2681);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v2681;
	l_v2683 = (void*)l_label_1;
	((void* *) (((char *)l_v2680) + 0))[0] = l_v2683;
	l_v2685 = pypy_g_ll_join_strs__v107___simple_call__function_l(l_v2593, l_v2594);
	l_v2686 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v2686, sizeof(void*), l_v2687);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v2687;
	l_v2689 = ((void* *) (((char *)l_v2687) + 0))[0];
	l_label_1 = l_v2689; /* for moving GCs */
	l_v2691 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2692 = (l_v2691 == NULL);
	if (!l_v2692) {
		goto block44;
	}
	l_data_3 = l_v2685;
	l_linepos_1 = 0L;
	l_L2cache_0 = 2147483647L;
	goto block14;

    block14:
	while (1) {
		l_v2693 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
		OP_ADR_ADD(l_v2693, (sizeof(void*) * 2), l_v2694);
		(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v2694;
		l_v2696 = (void*)l_label_1;
		((void* *) (((char *)l_v2693) + 0))[0] = l_v2696;
		l_v2698 = (void*)l_data_3;
		((void* *) (((char *)l_v2693) + sizeof(void*)))[0] = l_v2698;
		l_v2600 = pypy_g_ll_strconcat__rpy_stringPtr_rpy_stringPtr((&pypy_g_rpy_string_14.b), l_label_1);
		l_v2700 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
		OP_ADR_SUB(l_v2700, (sizeof(void*) * 2), l_v2701);
		(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v2701;
		l_v2703 = ((void* *) (((char *)l_v2701) + 0))[0];
		l_label_1 = l_v2703; /* for moving GCs */
		l_v2705 = ((void* *) (((char *)l_v2701) + sizeof(void*)))[0];
		l_data_3 = l_v2705; /* for moving GCs */
		l_v2707 = (&pypy_g_ExcData)->ed_exc_type;
		l_v2708 = (l_v2707 == NULL);
		if (!l_v2708) break;
		goto block15;
	  block14_back: ;
	}
	goto block43;

    block15:
	l_v2709 = RPyField(l_data_3, rs_chars).length;
	l_v2604 = pypy_g_ll_find__LLHelpersConst_rpy_stringPtr_rpy_string(l_data_3, l_v2600, l_linepos_1, l_v2709);
	OP_INT_LT(l_v2604, 0L, l_v2710);
	if (l_v2710) {
		l_L2cache_1 = l_L2cache_0;
		goto block41;
	}
	goto block16;

    block16:
	l_v2711 = RPyField(l_v2600, rs_chars).length;
	OP_INT_ADD(l_v2604, l_v2711, l_v2596);
	OP_INT_LT(l_v2596, 0L, l_v2712);
	if (l_v2712) {
		l_L2cache_1 = l_L2cache_0;
		goto block41;
	}
	goto block17;

    block17:
	l_v2713 = RPyField(l_data_3, rs_chars).length;
	l_v2605 = pypy_g_ll_find__LLHelpersConst_rpy_stringPtr_rpy_string(l_data_3, (&pypy_g_rpy_string_14.b), l_v2596, l_v2713);
	OP_INT_LT(l_v2605, 0L, l_v2714);
	if (l_v2714) {
		l_L2cache_1 = l_L2cache_0;
		goto block41;
	}
	goto block18;

    block18:
	OP_INT_ADD(l_v2605, 1L, l_linepos_0);
	OP_INT_LT(l_linepos_0, 0L, l_v2715);
	if (l_v2715) {
		l_L2cache_1 = l_L2cache_0;
		goto block41;
	}
	goto block19;

    block19:
	l_v2597 = pypy_g__skipspace(l_data_3, l_v2596);
	OP_INT_GE(l_v2597, 0L, l_v2716);
	RPyAssert(l_v2716, "negative str getitem index");
	l_v2718 = RPyField(l_data_3, rs_chars).length;
	OP_INT_LT(l_v2597, l_v2718, l_v2719);
	RPyAssert(l_v2719, "str getitem index out of bound");
	l_v2721 = RPyField(l_data_3, rs_chars).items[l_v2597];
	OP_CHAR_NE(l_v2721, ':', l_v2722);
	if (l_v2722) {
		l_linepos_1 = l_linepos_0;
		goto block14_back;
	}
	goto block20;

    block20:
	OP_INT_ADD(l_v2597, 1L, l_v2723);
	l_start_11 = pypy_g__skipspace(l_data_3, l_v2723);
	l_end_3 = l_start_11;
	goto block21;

    block21:
	while (1) {
		OP_INT_GE(l_end_3, 0L, l_v2724);
		RPyAssert(l_v2724, "negative str getitem index");
		l_v2726 = RPyField(l_data_3, rs_chars).length;
		OP_INT_LT(l_end_3, l_v2726, l_v2727);
		RPyAssert(l_v2727, "str getitem index out of bound");
		l_v2585 = RPyField(l_data_3, rs_chars).items[l_end_3];
		OP_CHAR_LE('0', l_v2585, l_v2729);
		if (!l_v2729) break;
		goto block39;
	  block21_back: ;
	}
	goto block22;

    block22:
	OP_INT_EQ(l_start_11, l_end_3, l_v2730);
	if (l_v2730) {
		l_linepos_1 = l_linepos_0;
		goto block14;
	}
	goto block23;

    block23:
	OP_INT_IS_TRUE(0 /* we are not jitted here */, l_v2731);
	if (l_v2731) {
		goto block37;
	}
	goto block24;

    block24:
	l_v2732 = RPyField(l_data_3, rs_chars).length;
	OP_INT_GE(l_end_3, l_v2732, l_v2733);
	if (l_v2733) {
		goto block35;
	}
	l_v2883 = l_end_3;
	goto block25;

    block25:
	l_v2734 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v2734, (sizeof(void*) * 2), l_v2735);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v2735;
	l_v2737 = (void*)l_data_3;
	((void* *) (((char *)l_v2734) + 0))[0] = l_v2737;
	l_v2739 = (void*)l_label_1;
	((void* *) (((char *)l_v2734) + sizeof(void*)))[0] = l_v2739;
	l_v2741 = pypy_g__ll_stringslice__rpy_stringPtr_Signed_Signed(l_data_3, l_start_11, l_v2883);
	l_v2742 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v2742, (sizeof(void*) * 2), l_v2743);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v2743;
	l_v2745 = ((void* *) (((char *)l_v2743) + 0))[0];
	l_data_3 = l_v2745; /* for moving GCs */
	l_v2747 = ((void* *) (((char *)l_v2743) + sizeof(void*)))[0];
	l_label_1 = l_v2747; /* for moving GCs */
	l_v2749 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2750 = (l_v2749 == NULL);
	if (!l_v2750) {
		goto block34;
	}
	l_v2884 = l_v2741;
	goto block26;

    block26:
	l_v2595 = pypy_g_ll_int__rpy_stringPtr_Signed(l_v2884, 10L);
	l_v2751 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2752 = (l_v2751 == NULL);
	if (!l_v2752) {
		goto block32;
	}
	goto block27;

    block27:
	l_v2753 = pypy_g__skipspace(l_data_3, l_end_3);
	OP_INT_GE(l_v2753, 0L, l_v2754);
	RPyAssert(l_v2754, "negative str getitem index");
	l_v2756 = RPyField(l_data_3, rs_chars).length;
	OP_INT_LT(l_v2753, l_v2756, l_v2757);
	RPyAssert(l_v2757, "str getitem index out of bound");
	l_v2590 = RPyField(l_data_3, rs_chars).items[l_v2753];
	OP_CAST_CHAR_TO_INT(l_v2590, l_v2589);
	OP_INT_IS_TRUE(0 /* we are not jitted here */, l_v2759);
	if (l_v2759) {
		goto block31;
	}
	goto block28;

    block28:
	l_v2760 = pypy_g_ll_dict_lookup__v141___simple_call__function_l((&pypy_g_dicttable_4), l_v2590, l_v2589);
	l_v2885 = l_v2760;
	goto block29;

    block29:
	OP_UINT_AND(l_v2885, 2147483648UL, l_v2761);
	OP_UINT_IS_TRUE(l_v2761, l_v2762);
	if (l_v2762) {
		l_linepos_1 = l_linepos_0;
		goto block14;
	}
	goto block30;

    block30:
	OP_INT_MUL(l_v2595, 1024L, l_v2763);
	OP_INT_LT(l_v2763, l_L2cache_0, l_v2764);
	if (l_v2764) {
		l_linepos_1 = l_linepos_0;
		l_L2cache_0 = l_v2763;
		goto block14;
	}
	l_linepos_1 = l_linepos_0;
	goto block14;

    block31:
	l_v2765 = pypy_g_ll_dict_lookup__v150___simple_call__function_l((&pypy_g_dicttable_4), l_v2590, l_v2589);
	l_v2885 = l_v2765;
	goto block29;

    block32:
	PYPY_DEBUG_RECORD_TRACEBACK("get_L2cache_linux2_cpuinfo");
	l_v2880 = -1L;
	goto block33;

    block33:
	RPY_DEBUG_RETURN();
	return l_v2880;

    block34:
	PYPY_DEBUG_RECORD_TRACEBACK("get_L2cache_linux2_cpuinfo");
	l_v2880 = -1L;
	goto block33;

    block35:
	OP_INT_EQ(l_start_11, 0L, l_v2768);
	if (l_v2768) {
		l_v2884 = l_data_3;
		goto block26;
	}
	goto block36;

    block36:
	l_v2769 = RPyField(l_data_3, rs_chars).length;
	l_v2883 = l_v2769;
	goto block25;

    block37:
	l_v2770 = RPyField(l_data_3, rs_chars).length;
	OP_INT_GT(l_end_3, l_v2770, l_v2771);
	if (l_v2771) {
		goto block38;
	}
	l_v2883 = l_end_3;
	goto block25;

    block38:
	l_v2772 = RPyField(l_data_3, rs_chars).length;
	l_v2883 = l_v2772;
	goto block25;

    block39:
	OP_CHAR_LE(l_v2585, '9', l_v2773);
	if (l_v2773) {
		goto block40;
	}
	goto block22;

    block40:
	OP_INT_ADD(l_end_3, 1L, l_v2774);
	l_end_3 = l_v2774;
	goto block21_back;

    block41:
	if (PYPY_HAVE_DEBUG_PRINTS) { fprintf(PYPY_DEBUG_FILE, "L2cache = %ld\012", l_L2cache_1); }
	PYPY_DEBUG_STOP("gc-hardware");
	OP_INT_LT(l_L2cache_1, 2147483647L, l_v2777);
	if (l_v2777) {
		l_v2880 = l_L2cache_1;
		goto block33;
	}
	goto block42;

    block42:
	if (PYPY_HAVE_DEBUG_PRINTS) { fprintf(PYPY_DEBUG_FILE, "Warning: cannot find your CPU L2 cache size in /proc/cpuinfo\012"); }
	l_v2880 = -1L;
	goto block33;

    block43:
	PYPY_DEBUG_RECORD_TRACEBACK("get_L2cache_linux2_cpuinfo");
	l_v2880 = -1L;
	goto block33;

    block44:
	PYPY_DEBUG_RECORD_TRACEBACK("get_L2cache_linux2_cpuinfo");
	l_v2880 = -1L;
	goto block33;

    block45:
	l_v2781 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v2781, sizeof(void*), l_v2782);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v2782;
	l_v2784 = (void*)l_label_1;
	((void* *) (((char *)l_v2781) + 0))[0] = l_v2784;
	l_v2786 = pypy_g_ll_join_strs__v114___simple_call__function_l(l_v2593, l_v2594);
	l_v2787 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v2787, sizeof(void*), l_v2788);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v2788;
	l_v2790 = ((void* *) (((char *)l_v2788) + 0))[0];
	l_label_1 = l_v2790; /* for moving GCs */
	l_v2792 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2793 = (l_v2792 == NULL);
	if (!l_v2793) {
		goto block46;
	}
	l_data_3 = l_v2786;
	l_linepos_1 = 0L;
	l_L2cache_0 = 2147483647L;
	goto block14;

    block46:
	PYPY_DEBUG_RECORD_TRACEBACK("get_L2cache_linux2_cpuinfo");
	l_v2880 = -1L;
	goto block33;

    block47:
	l_v2601 = (&pypy_g_ExcData)->ed_exc_value;
	l_etype_2 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("get_L2cache_linux2_cpuinfo", l_etype_2, l_etype_2 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_etype_2 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	l_v2798 = pypy_g_ll_issubclass__object_vtablePtr_object_vtablePtr(l_etype_2, (&pypy_g_exceptions_OSError_vtable.ose_super.ee_super.se_super.e_super));
	if (l_v2798) {
		l_L2cache_1 = 2147483647L;
		goto block41;
	}
	goto block48;

    block48:
	pypy_g_RPyReRaiseException(l_etype_2, l_v2601);
	l_v2880 = -1L;
	goto block33;

    block49:
	l_v2800 = RPyField(l_buf_0, rs_chars).length;
	OP_INT_NE(l_v2800, 0L, l_v2801);
	if (l_v2801) {
		goto block50;
	}
	goto block11;

    block50:
	l_v2588 = RPyField(l_data_4, l_length);
	OP_INT_ADD(l_v2588, 1L, l_v2802);
	l_v2803 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v2803, (sizeof(void*) * 3), l_v2804);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v2804;
	l_v2806 = (void*)l_label_1;
	((void* *) (((char *)l_v2803) + 0))[0] = l_v2806;
	l_v2808 = (void*)l_data_4;
	((void* *) (((char *)l_v2803) + sizeof(void*)))[0] = l_v2808;
	l_v2810 = (void*)l_buf_0;
	((void* *) (((char *)l_v2803) + (sizeof(void*) * 2)))[0] = l_v2810;
	pypy_g__ll_list_resize_ge_look_inside_iff__listPtr_Sign_1(l_data_4, l_v2802);
	l_v2813 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v2813, (sizeof(void*) * 3), l_v2814);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v2814;
	l_v2816 = ((void* *) (((char *)l_v2814) + 0))[0];
	l_label_1 = l_v2816; /* for moving GCs */
	l_v2818 = ((void* *) (((char *)l_v2814) + sizeof(void*)))[0];
	l_data_4 = l_v2818; /* for moving GCs */
	l_v2820 = ((void* *) (((char *)l_v2814) + (sizeof(void*) * 2)))[0];
	l_buf_0 = l_v2820; /* for moving GCs */
	l_v2822 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2823 = (l_v2822 == NULL);
	if (!l_v2823) {
		goto block54;
	}
	goto block51;

    block51:
	l_v2824 = RPyField(l_data_4, l_length);
	OP_INT_LT(l_v2588, l_v2824, l_v2825);
	RPyAssert(l_v2825, "setitem out of bounds");
	l_v2592 = RPyField(l_data_4, l_items);
	l_v2591 = (void*)l_buf_0;
	l_v2603 = (void*)l_v2592;
	OP_ADR_SUB(l_v2603, 0, l_v2827);
	l_v2828 = (struct pypy_header0 *)l_v2827;
	l_v2829 = RPyField(l_v2828, h_tid);
	OP_INT_AND(l_v2829, 65536L, l_v2830);
	OP_INT_IS_TRUE(l_v2830, l_v2831);
	if (l_v2831) {
		goto block53;
	}
	goto block52;

    block52:
	RPyItem(l_v2592, l_v2588) = l_buf_0;
	goto block9_back;

    block53:
	pypy_g_remember_young_pointer_from_array2(l_v2603, l_v2588);
	goto block52;

    block54:
	PYPY_DEBUG_RECORD_TRACEBACK("get_L2cache_linux2_cpuinfo");
	l_v2880 = -1L;
	goto block33;

    block55:
	l_v2835 = (&pypy_g_ExcData)->ed_exc_value;
	l_v2602 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("get_L2cache_linux2_cpuinfo", l_v2602, l_v2602 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_v2602 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	l_v2599 = (struct pypy_exceptions_Exception0 *)l_v2835;
	l_v2839 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v2839, sizeof(void*), l_v2840);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v2840;
	l_v2842 = (void*)l_v2599;
	((void* *) (((char *)l_v2839) + 0))[0] = l_v2842;
	pypy_g_ll_os_ll_os_close(l_v2586);
	l_v2845 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v2845, sizeof(void*), l_v2846);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v2846;
	l_v2848 = ((void* *) (((char *)l_v2846) + 0))[0];
	l_v2599 = l_v2848; /* for moving GCs */
	l_v2850 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2851 = (l_v2850 == NULL);
	if (!l_v2851) {
		goto block58;
	}
	goto block56;

    block56:
	l_v2852 = RPyField(l_v2602, ov_subclassrange_min);
	l_v2853 = (l_v2852 == 23L);  /* was INT_BETWEEN */
	if (l_v2853) {
		l_L2cache_1 = 2147483647L;
		goto block41;
	}
	goto block57;

    block57:
	l_v2854 = (struct pypy_object0 *)l_v2599;
	pypy_g_RPyReRaiseException(l_v2602, l_v2854);
	l_v2880 = -1L;
	goto block33;

    block58:
	l_evalue_4 = (&pypy_g_ExcData)->ed_exc_value;
	l_etype_4 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("get_L2cache_linux2_cpuinfo", l_etype_4, l_etype_4 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_etype_4 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	l_v2859 = pypy_g_ll_issubclass__object_vtablePtr_object_vtablePtr(l_etype_4, (&pypy_g_exceptions_OSError_vtable.ose_super.ee_super.se_super.e_super));
	if (l_v2859) {
		l_L2cache_1 = 2147483647L;
		goto block41;
	}
	goto block59;

    block59:
	pypy_g_RPyReRaiseException(l_etype_4, l_evalue_4);
	l_v2880 = -1L;
	goto block33;

    block60:
	PYPY_DEBUG_RECORD_TRACEBACK("get_L2cache_linux2_cpuinfo");
	l_v2880 = -1L;
	goto block33;

    block61:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v2863 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2864 = (l_v2863 == NULL);
	if (!l_v2864) {
		goto block62;
	}
	goto block5;

    block62:
	PYPY_DEBUG_RECORD_TRACEBACK("get_L2cache_linux2_cpuinfo");
	l_v2882 = NULL;
	goto block7;

    block63:
	l_v2866 = pypy_g_MiniMarkGC_collect_and_reserve((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_result_9, l_v2598);
	l_v2867 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2868 = (l_v2867 == NULL);
	if (!l_v2868) {
		goto block64;
	}
	l_result_8 = l_v2866;
	goto block4;

    block64:
	PYPY_DEBUG_RECORD_TRACEBACK("get_L2cache_linux2_cpuinfo");
	l_v2882 = NULL;
	goto block7;

    block65:
	RPyAssert(1, "'contains_weakptr' specified for a large object");
	l_v2871 = pypy_g_MiniMarkGC_external_malloc((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member19), 0L, 1);
	l_v2872 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2873 = (l_v2872 == NULL);
	if (!l_v2873) {
		goto block66;
	}
	l_v2881 = l_v2871;
	goto block6;

    block66:
	PYPY_DEBUG_RECORD_TRACEBACK("get_L2cache_linux2_cpuinfo");
	l_v2882 = NULL;
	goto block7;

    block67:
	l_v2587 = (&pypy_g_ExcData)->ed_exc_value;
	l_etype_3 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("get_L2cache_linux2_cpuinfo", l_etype_3, l_etype_3 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_etype_3 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	l_v2878 = pypy_g_ll_issubclass__object_vtablePtr_object_vtablePtr(l_etype_3, (&pypy_g_exceptions_OSError_vtable.ose_super.ee_super.se_super.e_super));
	if (l_v2878) {
		l_L2cache_1 = 2147483647L;
		goto block41;
	}
	goto block68;

    block68:
	pypy_g_RPyReRaiseException(l_etype_3, l_v2587);
	l_v2880 = -1L;
	goto block33;
}
/*/*/
Signed pypy_g_get_L2cache_linux2_sparc(void) {
	Signed l_L2cache_2; Signed l_L2cache_3; Signed l_cpu_0;
	struct pypy_object_vtable0 *l_etype_5;
	struct pypy_object_vtable0 *l_etype_6;
	struct pypy_rpy_string0 *l_line_0; Signed l_stop_3; Signed l_v2886;
	Signed l_v2893; Signed l_v2928; Signed l_v2933; Signed l_v2941;
	Signed l_v2948; Signed l_v2950; Signed l_v2977; Signed l_v2993;
	Signed l_v2995; bool_t l_v2898; bool_t l_v2900; bool_t l_v2912;
	bool_t l_v2914; bool_t l_v2927; bool_t l_v2929; bool_t l_v2932;
	bool_t l_v2934; bool_t l_v2937; bool_t l_v2939; bool_t l_v2940;
	bool_t l_v2944; bool_t l_v2949; bool_t l_v2954; bool_t l_v2958;
	bool_t l_v2976; bool_t l_v2978; bool_t l_v2984; bool_t l_v2989;
	struct pypy_exceptions_Exception0 *l_v2887;
	struct pypy_object0 *l_v2892; struct pypy_object0 *l_v2894;
	struct pypy_object0 *l_v2895; struct pypy_object0 *l_v2960;
	struct pypy_object0 *l_v2979; struct pypy_object_vtable0 *l_v2888;
	struct pypy_object_vtable0 *l_v2890;
	struct pypy_object_vtable0 *l_v2897;
	struct pypy_object_vtable0 *l_v2899;
	struct pypy_object_vtable0 *l_v2911;
	struct pypy_object_vtable0 *l_v2913;
	struct pypy_object_vtable0 *l_v2926;
	struct pypy_object_vtable0 *l_v2936;
	struct pypy_object_vtable0 *l_v2938;
	struct pypy_object_vtable0 *l_v2943;
	struct pypy_object_vtable0 *l_v2975;
	struct pypy_rpy_string0 *l_v2889; struct pypy_rpy_string0 *l_v2891;
	struct pypy_rpy_string0 *l_v2935; struct pypy_rpy_string0 *l_v2942;
	struct pypy_rpy_string0 *l_v2994; struct pypy_rpy_string0 *l_v2996;
	void* l_v2901; void* l_v2902; void* l_v2904; void* l_v2906;
	void* l_v2907; void* l_v2909; void* l_v2915; void* l_v2916;
	void* l_v2918; void* l_v2921; void* l_v2922; void* l_v2924;
	void* l_v2964; void* l_v2965; void* l_v2967; void* l_v2970;
	void* l_v2971; void* l_v2973;
	goto block0;

    block0:
	PYPY_DEBUG_START("gc-hardware");
	l_cpu_0 = 0L;
	l_v2994 = (&pypy_g_rpy_string_41.b);
	l_L2cache_2 = 2147483647L;
	goto block1;

    block1:
	while (1) {
		l_v2889 = pypy_g_ll_strconcat__rpy_stringPtr_rpy_stringPtr((&pypy_g_rpy_string_42.b), l_v2994);
		l_v2897 = (&pypy_g_ExcData)->ed_exc_type;
		l_v2898 = (l_v2897 == NULL);
		if (!l_v2898) break;
		goto block2;
	  block1_back: ;
	}
	goto block32;

    block2:
	l_v2891 = pypy_g_ll_strconcat__rpy_stringPtr_rpy_stringPtr(l_v2889, (&pypy_g_rpy_string_43.b));
	l_v2899 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2900 = (l_v2899 == NULL);
	if (!l_v2900) {
		goto block31;
	}
	goto block3;

    block3:
	l_v2901 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v2901, sizeof(void*), l_v2902);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v2902;
	l_v2904 = (void*)l_v2891;
	((void* *) (((char *)l_v2901) + 0))[0] = l_v2904;
	l_v2893 = pypy_g_ll_os_ll_os_open(l_v2891, 0L, 420L);
	l_v2906 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v2906, sizeof(void*), l_v2907);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v2907;
	l_v2909 = ((void* *) (((char *)l_v2907) + 0))[0];
	l_v2891 = l_v2909; /* for moving GCs */
	l_v2911 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2912 = (l_v2911 == NULL);
	if (!l_v2912) {
		goto block29;
	}
	goto block4;

    block4:
	l_line_0 = pypy_g_ll_os_ll_os_read(l_v2893, 4096L);
	l_v2913 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2914 = (l_v2913 == NULL);
	if (!l_v2914) {
		goto block24;
	}
	goto block5;

    block5:
	l_v2915 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v2915, sizeof(void*), l_v2916);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v2916;
	l_v2918 = (void*)l_line_0;
	((void* *) (((char *)l_v2915) + 0))[0] = l_v2918;
	pypy_g_ll_os_ll_os_close(l_v2893);
	l_v2921 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v2921, sizeof(void*), l_v2922);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v2922;
	l_v2924 = ((void* *) (((char *)l_v2922) + 0))[0];
	l_line_0 = l_v2924; /* for moving GCs */
	l_v2926 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2927 = (l_v2926 == NULL);
	if (!l_v2927) {
		goto block20;
	}
	goto block6;

    block6:
	l_v2928 = RPyField(l_line_0, rs_chars).length;
	OP_INT_SUB(l_v2928, 1L, l_stop_3);
	OP_INT_GT(l_stop_3, 0L, l_v2929);
	if (l_v2929) {
		goto block9;
	}
	goto block7;

    block7:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("get_L2cache_linux2_sparc");
	l_v2993 = -1L;
	goto block8;

    block8:
	RPY_DEBUG_RETURN();
	return l_v2993;

    block9:
	OP_INT_IS_TRUE(0 /* we are not jitted here */, l_v2932);
	if (l_v2932) {
		goto block18;
	}
	goto block10;

    block10:
	l_v2933 = RPyField(l_line_0, rs_chars).length;
	OP_INT_GE(l_stop_3, l_v2933, l_v2934);
	if (l_v2934) {
		l_v2996 = l_line_0;
		goto block12;
	}
	l_v2995 = l_stop_3;
	goto block11;

    block11:
	l_v2935 = pypy_g__ll_stringslice__rpy_stringPtr_Signed_Signed(l_line_0, 0L, l_v2995);
	l_v2936 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2937 = (l_v2936 == NULL);
	if (!l_v2937) {
		goto block17;
	}
	l_v2996 = l_v2935;
	goto block12;

    block12:
	l_v2886 = pypy_g_ll_int__rpy_stringPtr_Signed(l_v2996, 10L);
	l_v2938 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2939 = (l_v2938 == NULL);
	if (!l_v2939) {
		goto block16;
	}
	goto block13;

    block13:
	OP_INT_LT(l_v2886, l_L2cache_2, l_v2940);
	if (l_v2940) {
		l_L2cache_3 = l_v2886;
		goto block14;
	}
	l_L2cache_3 = l_L2cache_2;
	goto block14;

    block14:
	OP_INT_ADD(l_cpu_0, 1L, l_v2941);
	l_v2942 = pypy_g_ll_int2dec__Signed(l_v2941);
	l_v2943 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2944 = (l_v2943 == NULL);
	if (!l_v2944) {
		goto block15;
	}
	l_cpu_0 = l_v2941;
	l_v2994 = l_v2942;
	l_L2cache_2 = l_L2cache_3;
	goto block1_back;

    block15:
	PYPY_DEBUG_RECORD_TRACEBACK("get_L2cache_linux2_sparc");
	l_v2993 = -1L;
	goto block8;

    block16:
	PYPY_DEBUG_RECORD_TRACEBACK("get_L2cache_linux2_sparc");
	l_v2993 = -1L;
	goto block8;

    block17:
	PYPY_DEBUG_RECORD_TRACEBACK("get_L2cache_linux2_sparc");
	l_v2993 = -1L;
	goto block8;

    block18:
	l_v2948 = RPyField(l_line_0, rs_chars).length;
	OP_INT_GT(l_stop_3, l_v2948, l_v2949);
	if (l_v2949) {
		goto block19;
	}
	l_v2995 = l_stop_3;
	goto block11;

    block19:
	l_v2950 = RPyField(l_line_0, rs_chars).length;
	l_v2995 = l_v2950;
	goto block11;

    block20:
	l_v2894 = (&pypy_g_ExcData)->ed_exc_value;
	l_v2888 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("get_L2cache_linux2_sparc", l_v2888, l_v2888 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_v2888 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	l_v2954 = pypy_g_ll_issubclass__object_vtablePtr_object_vtablePtr(l_v2888, (&pypy_g_exceptions_OSError_vtable.ose_super.ee_super.se_super.e_super));
	if (l_v2954) {
		goto block22;
	}
	goto block21;

    block21:
	pypy_g_RPyReRaiseException(l_v2888, l_v2894);
	l_v2993 = -1L;
	goto block8;

    block22:
	if (PYPY_HAVE_DEBUG_PRINTS) { fprintf(PYPY_DEBUG_FILE, "L2cache = %ld\012", l_L2cache_2); }
	PYPY_DEBUG_STOP("gc-hardware");
	OP_INT_LT(l_L2cache_2, 2147483647L, l_v2958);
	if (l_v2958) {
		l_v2993 = l_L2cache_2;
		goto block8;
	}
	goto block23;

    block23:
	if (PYPY_HAVE_DEBUG_PRINTS) { fprintf(PYPY_DEBUG_FILE, "Warning: cannot find your CPU L2 cache size in /sys/devices/syst"
	"em/cpu/cpuX/l2_cache_size\012"); }
	l_v2993 = -1L;
	goto block8;

    block24:
	l_v2960 = (&pypy_g_ExcData)->ed_exc_value;
	l_v2890 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("get_L2cache_linux2_sparc", l_v2890, l_v2890 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_v2890 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	l_v2887 = (struct pypy_exceptions_Exception0 *)l_v2960;
	l_v2964 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v2964, sizeof(void*), l_v2965);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v2965;
	l_v2967 = (void*)l_v2887;
	((void* *) (((char *)l_v2964) + 0))[0] = l_v2967;
	pypy_g_ll_os_ll_os_close(l_v2893);
	l_v2970 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v2970, sizeof(void*), l_v2971);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v2971;
	l_v2973 = ((void* *) (((char *)l_v2971) + 0))[0];
	l_v2887 = l_v2973; /* for moving GCs */
	l_v2975 = (&pypy_g_ExcData)->ed_exc_type;
	l_v2976 = (l_v2975 == NULL);
	if (!l_v2976) {
		goto block27;
	}
	goto block25;

    block25:
	l_v2977 = RPyField(l_v2890, ov_subclassrange_min);
	l_v2978 = (l_v2977 == 23L);  /* was INT_BETWEEN */
	if (l_v2978) {
		goto block22;
	}
	goto block26;

    block26:
	l_v2979 = (struct pypy_object0 *)l_v2887;
	pypy_g_RPyReRaiseException(l_v2890, l_v2979);
	l_v2993 = -1L;
	goto block8;

    block27:
	l_v2892 = (&pypy_g_ExcData)->ed_exc_value;
	l_etype_6 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("get_L2cache_linux2_sparc", l_etype_6, l_etype_6 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_etype_6 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	l_v2984 = pypy_g_ll_issubclass__object_vtablePtr_object_vtablePtr(l_etype_6, (&pypy_g_exceptions_OSError_vtable.ose_super.ee_super.se_super.e_super));
	if (l_v2984) {
		goto block22;
	}
	goto block28;

    block28:
	pypy_g_RPyReRaiseException(l_etype_6, l_v2892);
	l_v2993 = -1L;
	goto block8;

    block29:
	l_v2895 = (&pypy_g_ExcData)->ed_exc_value;
	l_etype_5 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("get_L2cache_linux2_sparc", l_etype_5, l_etype_5 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_etype_5 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	l_v2989 = pypy_g_ll_issubclass__object_vtablePtr_object_vtablePtr(l_etype_5, (&pypy_g_exceptions_OSError_vtable.ose_super.ee_super.se_super.e_super));
	if (l_v2989) {
		goto block22;
	}
	goto block30;

    block30:
	pypy_g_RPyReRaiseException(l_etype_5, l_v2895);
	l_v2993 = -1L;
	goto block8;

    block31:
	PYPY_DEBUG_RECORD_TRACEBACK("get_L2cache_linux2_sparc");
	l_v2993 = -1L;
	goto block8;

    block32:
	PYPY_DEBUG_RECORD_TRACEBACK("get_L2cache_linux2_sparc");
	l_v2993 = -1L;
	goto block8;
}
/*/*/
Signed pypy_g_get_L2cache_linux2_ia64(void) {
	Signed l_L2cache_4; Signed l_L2cache_5; Signed l_L2cache_6;
	Signed l_L3cache_0; Signed l_L3cache_1; Signed l_L3cache_2;
	struct pypy_rpy_string0 *l_cachedir_0; Signed l_cpu_1;
	struct pypy_rpy_string0 *l_cpudir_0; Signed l_end_4;
	struct pypy_object_vtable0 *l_etype_7;
	struct pypy_object_vtable0 *l_etype_8;
	struct pypy_object0 *l_evalue_5; Signed l_fd_3; Signed l_index_8;
	Signed l_level_0; Signed l_number_0; struct pypy_rpy_string0 *l_s1_6;
	Signed l_v2997; Signed l_v3010; Signed l_v3017; Signed l_v3116;
	Signed l_v3117; Signed l_v3215; Signed l_v3222; Signed l_v3230;
	Signed l_v3249; Signed l_v3254; Signed l_v3256; Signed l_v3257;
	Signed l_v3259; Signed l_v3261; Signed l_v3269; Signed l_v3274;
	Signed l_v3296; Signed l_v3311; Signed l_v3337; Signed l_v3363;
	Signed l_v3368; Unsigned l_v3154; Unsigned l_v3155; Unsigned l_v3226;
	Unsigned l_v3227; Unsigned l_v3258; Unsigned l_v3312;
	Unsigned l_v3365; Unsigned l_v3367; bool_t l_v3023; bool_t l_v3035;
	bool_t l_v3051; bool_t l_v3063; bool_t l_v3079; bool_t l_v3099;
	bool_t l_v3115; bool_t l_v3133; bool_t l_v3135; bool_t l_v3152;
	bool_t l_v3153; bool_t l_v3156; bool_t l_v3168; bool_t l_v3184;
	bool_t l_v3196; bool_t l_v3213; bool_t l_v3216; bool_t l_v3218;
	bool_t l_v3219; bool_t l_v3220; bool_t l_v3223; bool_t l_v3225;
	bool_t l_v3228; bool_t l_v3229; bool_t l_v3231; bool_t l_v3244;
	bool_t l_v3246; bool_t l_v3247; bool_t l_v3248; bool_t l_v3250;
	bool_t l_v3251; bool_t l_v3255; bool_t l_v3260; bool_t l_v3262;
	bool_t l_v3266; bool_t l_v3268; bool_t l_v3272; bool_t l_v3277;
	bool_t l_v3295; bool_t l_v3297; bool_t l_v3303; bool_t l_v3308;
	bool_t l_v3316; bool_t l_v3336; bool_t l_v3338; bool_t l_v3344;
	bool_t l_v3356; bool_t l_v3366; char l_v2999; char l_v3007;
	struct pypy_exceptions_Exception0 *l_v2998;
	struct pypy_exceptions_Exception0 *l_v3006;
	struct pypy_exceptions_Exception0 *l_v3323;
	struct pypy_exceptions_Exception0 *l_v3352;
	struct pypy_object0 *l_v3009; struct pypy_object0 *l_v3013;
	struct pypy_object0 *l_v3014; struct pypy_object0 *l_v3016;
	struct pypy_object0 *l_v3020; struct pypy_object0 *l_v3279;
	struct pypy_object0 *l_v3298; struct pypy_object0 *l_v3318;
	struct pypy_object0 *l_v3339; struct pypy_object0 *l_v3347;
	struct pypy_object_vtable0 *l_v3004;
	struct pypy_object_vtable0 *l_v3008;
	struct pypy_object_vtable0 *l_v3011;
	struct pypy_object_vtable0 *l_v3012;
	struct pypy_object_vtable0 *l_v3018;
	struct pypy_object_vtable0 *l_v3019;
	struct pypy_object_vtable0 *l_v3022;
	struct pypy_object_vtable0 *l_v3034;
	struct pypy_object_vtable0 *l_v3050;
	struct pypy_object_vtable0 *l_v3062;
	struct pypy_object_vtable0 *l_v3078;
	struct pypy_object_vtable0 *l_v3098;
	struct pypy_object_vtable0 *l_v3114;
	struct pypy_object_vtable0 *l_v3132;
	struct pypy_object_vtable0 *l_v3134;
	struct pypy_object_vtable0 *l_v3151;
	struct pypy_object_vtable0 *l_v3167;
	struct pypy_object_vtable0 *l_v3183;
	struct pypy_object_vtable0 *l_v3195;
	struct pypy_object_vtable0 *l_v3212;
	struct pypy_object_vtable0 *l_v3243;
	struct pypy_object_vtable0 *l_v3245;
	struct pypy_object_vtable0 *l_v3271;
	struct pypy_object_vtable0 *l_v3294;
	struct pypy_object_vtable0 *l_v3319;
	struct pypy_object_vtable0 *l_v3335;
	struct pypy_object_vtable0 *l_v3348;
	struct pypy_rpy_string0 *l_v3000; struct pypy_rpy_string0 *l_v3001;
	struct pypy_rpy_string0 *l_v3002; struct pypy_rpy_string0 *l_v3003;
	struct pypy_rpy_string0 *l_v3005; struct pypy_rpy_string0 *l_v3015;
	struct pypy_rpy_string0 *l_v3237; struct pypy_rpy_string0 *l_v3270;
	struct pypy_rpy_string0 *l_v3364; struct pypy_rpy_string0 *l_v3369;
	void* l_v3024; void* l_v3025; void* l_v3027; void* l_v3029;
	void* l_v3030; void* l_v3032; void* l_v3036; void* l_v3037;
	void* l_v3039; void* l_v3041; void* l_v3043; void* l_v3044;
	void* l_v3046; void* l_v3048; void* l_v3052; void* l_v3053;
	void* l_v3055; void* l_v3057; void* l_v3058; void* l_v3060;
	void* l_v3064; void* l_v3065; void* l_v3067; void* l_v3069;
	void* l_v3071; void* l_v3072; void* l_v3074; void* l_v3076;
	void* l_v3080; void* l_v3081; void* l_v3083; void* l_v3085;
	void* l_v3087; void* l_v3089; void* l_v3090; void* l_v3092;
	void* l_v3094; void* l_v3096; void* l_v3100; void* l_v3101;
	void* l_v3103; void* l_v3105; void* l_v3107; void* l_v3108;
	void* l_v3110; void* l_v3112; void* l_v3118; void* l_v3119;
	void* l_v3121; void* l_v3123; void* l_v3125; void* l_v3126;
	void* l_v3128; void* l_v3130; void* l_v3136; void* l_v3137;
	void* l_v3139; void* l_v3141; void* l_v3144; void* l_v3145;
	void* l_v3147; void* l_v3149; void* l_v3157; void* l_v3158;
	void* l_v3160; void* l_v3162; void* l_v3163; void* l_v3165;
	void* l_v3169; void* l_v3170; void* l_v3172; void* l_v3174;
	void* l_v3176; void* l_v3177; void* l_v3179; void* l_v3181;
	void* l_v3185; void* l_v3186; void* l_v3188; void* l_v3190;
	void* l_v3191; void* l_v3193; void* l_v3197; void* l_v3198;
	void* l_v3200; void* l_v3202; void* l_v3205; void* l_v3206;
	void* l_v3208; void* l_v3210; void* l_v3232; void* l_v3233;
	void* l_v3235; void* l_v3238; void* l_v3239; void* l_v3241;
	void* l_v3283; void* l_v3284; void* l_v3286; void* l_v3289;
	void* l_v3290; void* l_v3292; void* l_v3324; void* l_v3325;
	void* l_v3327; void* l_v3330; void* l_v3331; void* l_v3333;
	goto block0;

    block0:
	PYPY_DEBUG_START("gc-hardware");
	l_cpu_1 = 0L;
	l_L2cache_6 = 2147483647L;
	l_v3364 = (&pypy_g_rpy_string_41.b);
	l_L3cache_1 = 2147483647L;
	goto block1;

    block1:
	l_cpudir_0 = pypy_g_ll_strconcat__rpy_stringPtr_rpy_stringPtr((&pypy_g_rpy_string_42.b), l_v3364);
	l_v3022 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3023 = (l_v3022 == NULL);
	if (!l_v3023) {
		goto block75;
	}
	l_L3cache_0 = l_L3cache_1;
	l_index_8 = 0L;
	l_L2cache_4 = l_L2cache_6;
	goto block2;

    block2:
	while (1) {
		l_v3024 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
		OP_ADR_ADD(l_v3024, sizeof(void*), l_v3025);
		(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v3025;
		l_v3027 = (void*)l_cpudir_0;
		((void* *) (((char *)l_v3024) + 0))[0] = l_v3027;
		l_v3000 = pypy_g_ll_strconcat__rpy_stringPtr_rpy_stringPtr(l_cpudir_0, (&pypy_g_rpy_string_45.b));
		l_v3029 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
		OP_ADR_SUB(l_v3029, sizeof(void*), l_v3030);
		(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v3030;
		l_v3032 = ((void* *) (((char *)l_v3030) + 0))[0];
		l_cpudir_0 = l_v3032; /* for moving GCs */
		l_v3034 = (&pypy_g_ExcData)->ed_exc_type;
		l_v3035 = (l_v3034 == NULL);
		if (!l_v3035) break;
		goto block3;
	  block2_back: ;
	}
	goto block74;

    block3:
	l_v3036 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v3036, (sizeof(void*) * 2), l_v3037);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v3037;
	l_v3039 = (void*)l_cpudir_0;
	((void* *) (((char *)l_v3036) + 0))[0] = l_v3039;
	l_v3041 = (void*)l_v3000;
	((void* *) (((char *)l_v3036) + sizeof(void*)))[0] = l_v3041;
	l_v3005 = pypy_g_ll_int2dec__Signed(l_index_8);
	l_v3043 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v3043, (sizeof(void*) * 2), l_v3044);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v3044;
	l_v3046 = ((void* *) (((char *)l_v3044) + 0))[0];
	l_cpudir_0 = l_v3046; /* for moving GCs */
	l_v3048 = ((void* *) (((char *)l_v3044) + sizeof(void*)))[0];
	l_v3000 = l_v3048; /* for moving GCs */
	l_v3050 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3051 = (l_v3050 == NULL);
	if (!l_v3051) {
		goto block73;
	}
	goto block4;

    block4:
	l_v3052 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v3052, sizeof(void*), l_v3053);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v3053;
	l_v3055 = (void*)l_cpudir_0;
	((void* *) (((char *)l_v3052) + 0))[0] = l_v3055;
	l_cachedir_0 = pypy_g_ll_strconcat__rpy_stringPtr_rpy_stringPtr(l_v3000, l_v3005);
	l_v3057 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v3057, sizeof(void*), l_v3058);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v3058;
	l_v3060 = ((void* *) (((char *)l_v3058) + 0))[0];
	l_cpudir_0 = l_v3060; /* for moving GCs */
	l_v3062 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3063 = (l_v3062 == NULL);
	if (!l_v3063) {
		goto block72;
	}
	goto block5;

    block5:
	l_v3064 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v3064, (sizeof(void*) * 2), l_v3065);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v3065;
	l_v3067 = (void*)l_cpudir_0;
	((void* *) (((char *)l_v3064) + 0))[0] = l_v3067;
	l_v3069 = (void*)l_cachedir_0;
	((void* *) (((char *)l_v3064) + sizeof(void*)))[0] = l_v3069;
	l_v3015 = pypy_g_ll_strconcat__rpy_stringPtr_rpy_stringPtr(l_cachedir_0, (&pypy_g_rpy_string_46.b));
	l_v3071 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v3071, (sizeof(void*) * 2), l_v3072);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v3072;
	l_v3074 = ((void* *) (((char *)l_v3072) + 0))[0];
	l_cpudir_0 = l_v3074; /* for moving GCs */
	l_v3076 = ((void* *) (((char *)l_v3072) + sizeof(void*)))[0];
	l_cachedir_0 = l_v3076; /* for moving GCs */
	l_v3078 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3079 = (l_v3078 == NULL);
	if (!l_v3079) {
		goto block71;
	}
	goto block6;

    block6:
	l_v3080 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v3080, (sizeof(void*) * 3), l_v3081);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v3081;
	l_v3083 = (void*)l_v3015;
	((void* *) (((char *)l_v3080) + 0))[0] = l_v3083;
	l_v3085 = (void*)l_cpudir_0;
	((void* *) (((char *)l_v3080) + sizeof(void*)))[0] = l_v3085;
	l_v3087 = (void*)l_cachedir_0;
	((void* *) (((char *)l_v3080) + (sizeof(void*) * 2)))[0] = l_v3087;
	l_fd_3 = pypy_g_ll_os_ll_os_open(l_v3015, 0L, 420L);
	l_v3089 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v3089, (sizeof(void*) * 3), l_v3090);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v3090;
	l_v3092 = ((void* *) (((char *)l_v3090) + 0))[0];
	l_v3015 = l_v3092; /* for moving GCs */
	l_v3094 = ((void* *) (((char *)l_v3090) + sizeof(void*)))[0];
	l_cpudir_0 = l_v3094; /* for moving GCs */
	l_v3096 = ((void* *) (((char *)l_v3090) + (sizeof(void*) * 2)))[0];
	l_cachedir_0 = l_v3096; /* for moving GCs */
	l_v3098 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3099 = (l_v3098 == NULL);
	if (!l_v3099) {
		goto block69;
	}
	goto block7;

    block7:
	l_v3100 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v3100, (sizeof(void*) * 2), l_v3101);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v3101;
	l_v3103 = (void*)l_cpudir_0;
	((void* *) (((char *)l_v3100) + 0))[0] = l_v3103;
	l_v3105 = (void*)l_cachedir_0;
	((void* *) (((char *)l_v3100) + sizeof(void*)))[0] = l_v3105;
	l_v3003 = pypy_g_ll_os_ll_os_read(l_fd_3, 4096L);
	l_v3107 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v3107, (sizeof(void*) * 2), l_v3108);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v3108;
	l_v3110 = ((void* *) (((char *)l_v3108) + 0))[0];
	l_cpudir_0 = l_v3110; /* for moving GCs */
	l_v3112 = ((void* *) (((char *)l_v3108) + sizeof(void*)))[0];
	l_cachedir_0 = l_v3112; /* for moving GCs */
	l_v3114 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3115 = (l_v3114 == NULL);
	if (!l_v3115) {
		goto block68;
	}
	goto block8;

    block8:
	l_v3116 = RPyField(l_v3003, rs_chars).length;
	OP_INT_SUB(l_v3116, 1L, l_v3117);
	l_v3118 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v3118, (sizeof(void*) * 2), l_v3119);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v3119;
	l_v3121 = (void*)l_cpudir_0;
	((void* *) (((char *)l_v3118) + 0))[0] = l_v3121;
	l_v3123 = (void*)l_cachedir_0;
	((void* *) (((char *)l_v3118) + sizeof(void*)))[0] = l_v3123;
	l_v3002 = pypy_g__ll_stringslice__rpy_stringPtr_Signed_Signed(l_v3003, 0L, l_v3117);
	l_v3125 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v3125, (sizeof(void*) * 2), l_v3126);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v3126;
	l_v3128 = ((void* *) (((char *)l_v3126) + 0))[0];
	l_cpudir_0 = l_v3128; /* for moving GCs */
	l_v3130 = ((void* *) (((char *)l_v3126) + sizeof(void*)))[0];
	l_cachedir_0 = l_v3130; /* for moving GCs */
	l_v3132 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3133 = (l_v3132 == NULL);
	if (!l_v3133) {
		goto block67;
	}
	goto block9;

    block9:
	l_level_0 = pypy_g_ll_int__rpy_stringPtr_Signed(l_v3002, 10L);
	l_v3134 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3135 = (l_v3134 == NULL);
	if (!l_v3135) {
		goto block61;
	}
	goto block10;

    block10:
	l_v3136 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v3136, (sizeof(void*) * 2), l_v3137);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v3137;
	l_v3139 = (void*)l_cpudir_0;
	((void* *) (((char *)l_v3136) + 0))[0] = l_v3139;
	l_v3141 = (void*)l_cachedir_0;
	((void* *) (((char *)l_v3136) + sizeof(void*)))[0] = l_v3141;
	pypy_g_ll_os_ll_os_close(l_fd_3);
	l_v3144 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v3144, (sizeof(void*) * 2), l_v3145);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v3145;
	l_v3147 = ((void* *) (((char *)l_v3145) + 0))[0];
	l_cpudir_0 = l_v3147; /* for moving GCs */
	l_v3149 = ((void* *) (((char *)l_v3145) + sizeof(void*)))[0];
	l_cachedir_0 = l_v3149; /* for moving GCs */
	l_v3151 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3152 = (l_v3151 == NULL);
	if (!l_v3152) {
		goto block59;
	}
	goto block11;

    block11:
	OP_INT_IS_TRUE(0 /* we are not jitted here */, l_v3153);
	if (l_v3153) {
		goto block58;
	}
	goto block12;

    block12:
	l_v3154 = pypy_g_ll_dict_lookup__v95___simple_call__function_ll((&pypy_g_dicttable_5), l_level_0, l_level_0);
	l_v3365 = l_v3154;
	goto block13;

    block13:
	OP_UINT_AND(l_v3365, 2147483648UL, l_v3155);
	OP_UINT_IS_TRUE(l_v3155, l_v3156);
	if (l_v3156) {
		goto block57;
	}
	goto block14;

    block14:
	l_v3157 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v3157, sizeof(void*), l_v3158);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v3158;
	l_v3160 = (void*)l_cpudir_0;
	((void* *) (((char *)l_v3157) + 0))[0] = l_v3160;
	l_v3001 = pypy_g_ll_strconcat__rpy_stringPtr_rpy_stringPtr(l_cachedir_0, (&pypy_g_rpy_string_47.b));
	l_v3162 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v3162, sizeof(void*), l_v3163);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v3163;
	l_v3165 = ((void* *) (((char *)l_v3163) + 0))[0];
	l_cpudir_0 = l_v3165; /* for moving GCs */
	l_v3167 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3168 = (l_v3167 == NULL);
	if (!l_v3168) {
		goto block56;
	}
	goto block15;

    block15:
	l_v3169 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v3169, (sizeof(void*) * 2), l_v3170);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v3170;
	l_v3172 = (void*)l_v3001;
	((void* *) (((char *)l_v3169) + 0))[0] = l_v3172;
	l_v3174 = (void*)l_cpudir_0;
	((void* *) (((char *)l_v3169) + sizeof(void*)))[0] = l_v3174;
	l_v2997 = pypy_g_ll_os_ll_os_open(l_v3001, 0L, 420L);
	l_v3176 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v3176, (sizeof(void*) * 2), l_v3177);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v3177;
	l_v3179 = ((void* *) (((char *)l_v3177) + 0))[0];
	l_v3001 = l_v3179; /* for moving GCs */
	l_v3181 = ((void* *) (((char *)l_v3177) + sizeof(void*)))[0];
	l_cpudir_0 = l_v3181; /* for moving GCs */
	l_v3183 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3184 = (l_v3183 == NULL);
	if (!l_v3184) {
		goto block54;
	}
	goto block16;

    block16:
	l_v3185 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v3185, sizeof(void*), l_v3186);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v3186;
	l_v3188 = (void*)l_cpudir_0;
	((void* *) (((char *)l_v3185) + 0))[0] = l_v3188;
	l_s1_6 = pypy_g_ll_os_ll_os_read(l_v2997, 4096L);
	l_v3190 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v3190, sizeof(void*), l_v3191);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v3191;
	l_v3193 = ((void* *) (((char *)l_v3191) + 0))[0];
	l_cpudir_0 = l_v3193; /* for moving GCs */
	l_v3195 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3196 = (l_v3195 == NULL);
	if (!l_v3196) {
		goto block49;
	}
	goto block17;

    block17:
	l_v3197 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v3197, (sizeof(void*) * 2), l_v3198);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v3198;
	l_v3200 = (void*)l_cpudir_0;
	((void* *) (((char *)l_v3197) + 0))[0] = l_v3200;
	l_v3202 = (void*)l_s1_6;
	((void* *) (((char *)l_v3197) + sizeof(void*)))[0] = l_v3202;
	pypy_g_ll_os_ll_os_close(l_v2997);
	l_v3205 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v3205, (sizeof(void*) * 2), l_v3206);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v3206;
	l_v3208 = ((void* *) (((char *)l_v3206) + 0))[0];
	l_cpudir_0 = l_v3208; /* for moving GCs */
	l_v3210 = ((void* *) (((char *)l_v3206) + sizeof(void*)))[0];
	l_s1_6 = l_v3210; /* for moving GCs */
	l_v3212 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3213 = (l_v3212 == NULL);
	if (!l_v3213) {
		goto block42;
	}
	l_end_4 = 0L;
	l_v3366 = 1;
	goto block18;

    block18:
	while (1) {
		RPyAssert(l_v3366, "negative str getitem index");
		l_v3215 = RPyField(l_s1_6, rs_chars).length;
		OP_INT_LT(l_end_4, l_v3215, l_v3216);
		RPyAssert(l_v3216, "str getitem index out of bound");
		l_v2999 = RPyField(l_s1_6, rs_chars).items[l_end_4];
		OP_CHAR_LE('0', l_v2999, l_v3218);
		if (!l_v3218) break;
		goto block40;
	  block18_back: ;
	}
	goto block19;

    block19:
	OP_INT_EQ(l_end_4, 0L, l_v3219);
	if (l_v3219) {
		goto block39;
	}
	goto block20;

    block20:
	OP_INT_GE(l_end_4, 0L, l_v3220);
	RPyAssert(l_v3220, "negative str getitem index");
	l_v3222 = RPyField(l_s1_6, rs_chars).length;
	OP_INT_LT(l_end_4, l_v3222, l_v3223);
	RPyAssert(l_v3223, "str getitem index out of bound");
	l_v3007 = RPyField(l_s1_6, rs_chars).items[l_end_4];
	OP_CAST_CHAR_TO_INT(l_v3007, l_v3010);
	OP_INT_IS_TRUE(0 /* we are not jitted here */, l_v3225);
	if (l_v3225) {
		goto block38;
	}
	goto block21;

    block21:
	l_v3226 = pypy_g_ll_dict_lookup__v141___simple_call__function_l((&pypy_g_dicttable_6), l_v3007, l_v3010);
	l_v3367 = l_v3226;
	goto block22;

    block22:
	OP_UINT_AND(l_v3367, 2147483648UL, l_v3227);
	OP_UINT_IS_TRUE(l_v3227, l_v3228);
	if (l_v3228) {
		goto block37;
	}
	goto block23;

    block23:
	OP_INT_IS_TRUE(0 /* we are not jitted here */, l_v3229);
	if (l_v3229) {
		goto block35;
	}
	goto block24;

    block24:
	l_v3230 = RPyField(l_s1_6, rs_chars).length;
	OP_INT_GE(l_end_4, l_v3230, l_v3231);
	if (l_v3231) {
		l_v3369 = l_s1_6;
		goto block26;
	}
	l_v3368 = l_end_4;
	goto block25;

    block25:
	l_v3232 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v3232, sizeof(void*), l_v3233);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v3233;
	l_v3235 = (void*)l_cpudir_0;
	((void* *) (((char *)l_v3232) + 0))[0] = l_v3235;
	l_v3237 = pypy_g__ll_stringslice__rpy_stringPtr_Signed_Signed(l_s1_6, 0L, l_v3368);
	l_v3238 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v3238, sizeof(void*), l_v3239);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v3239;
	l_v3241 = ((void* *) (((char *)l_v3239) + 0))[0];
	l_cpudir_0 = l_v3241; /* for moving GCs */
	l_v3243 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3244 = (l_v3243 == NULL);
	if (!l_v3244) {
		goto block34;
	}
	l_v3369 = l_v3237;
	goto block26;

    block26:
	l_v3017 = pypy_g_ll_int__rpy_stringPtr_Signed(l_v3369, 10L);
	l_v3245 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3246 = (l_v3245 == NULL);
	if (!l_v3246) {
		goto block32;
	}
	goto block27;

    block27:
	OP_INT_MUL(l_v3017, 1024L, l_number_0);
	OP_INT_EQ(l_level_0, 2L, l_v3247);
	if (l_v3247) {
		goto block31;
	}
	l_L2cache_5 = l_L2cache_4;
	goto block28;

    block28:
	OP_INT_EQ(l_level_0, 3L, l_v3248);
	if (l_v3248) {
		goto block30;
	}
	l_L3cache_2 = l_L3cache_0;
	goto block29;

    block29:
	OP_INT_ADD(l_index_8, 1L, l_v3249);
	l_L3cache_0 = l_L3cache_2;
	l_index_8 = l_v3249;
	l_L2cache_4 = l_L2cache_5;
	goto block2;

    block30:
	OP_INT_LT(l_number_0, l_L3cache_0, l_v3250);
	if (l_v3250) {
		l_L3cache_2 = l_number_0;
		goto block29;
	}
	l_L3cache_2 = l_L3cache_0;
	goto block29;

    block31:
	OP_INT_LT(l_number_0, l_L2cache_4, l_v3251);
	if (l_v3251) {
		l_L2cache_5 = l_number_0;
		goto block28;
	}
	l_L2cache_5 = l_L2cache_4;
	goto block28;

    block32:
	PYPY_DEBUG_RECORD_TRACEBACK("get_L2cache_linux2_ia64");
	l_v3363 = -1L;
	goto block33;

    block33:
	RPY_DEBUG_RETURN();
	return l_v3363;

    block34:
	PYPY_DEBUG_RECORD_TRACEBACK("get_L2cache_linux2_ia64");
	l_v3363 = -1L;
	goto block33;

    block35:
	l_v3254 = RPyField(l_s1_6, rs_chars).length;
	OP_INT_GT(l_end_4, l_v3254, l_v3255);
	if (l_v3255) {
		goto block36;
	}
	l_v3368 = l_end_4;
	goto block25;

    block36:
	l_v3256 = RPyField(l_s1_6, rs_chars).length;
	l_v3368 = l_v3256;
	goto block25;

    block37:
	OP_INT_ADD(l_index_8, 1L, l_v3257);
	l_index_8 = l_v3257;
	goto block2;

    block38:
	l_v3258 = pypy_g_ll_dict_lookup__v150___simple_call__function_l((&pypy_g_dicttable_6), l_v3007, l_v3010);
	l_v3367 = l_v3258;
	goto block22;

    block39:
	OP_INT_ADD(l_index_8, 1L, l_v3259);
	l_index_8 = l_v3259;
	goto block2;

    block40:
	OP_CHAR_LE(l_v2999, '9', l_v3260);
	if (l_v3260) {
		goto block41;
	}
	goto block19;

    block41:
	OP_INT_ADD(l_end_4, 1L, l_v3261);
	OP_INT_GE(l_v3261, 0L, l_v3262);
	l_end_4 = l_v3261;
	l_v3366 = l_v3262;
	goto block18_back;

    block42:
	l_v3016 = (&pypy_g_ExcData)->ed_exc_value;
	l_v3018 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("get_L2cache_linux2_ia64", l_v3018, l_v3018 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_v3018 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	l_v3266 = pypy_g_ll_issubclass__object_vtablePtr_object_vtablePtr(l_v3018, (&pypy_g_exceptions_OSError_vtable.ose_super.ee_super.se_super.e_super));
	if (l_v3266) {
		goto block44;
	}
	goto block43;

    block43:
	pypy_g_RPyReRaiseException(l_v3018, l_v3016);
	l_v3363 = -1L;
	goto block33;

    block44:
	OP_INT_EQ(l_index_8, 0L, l_v3268);
	if (l_v3268) {
		goto block47;
	}
	goto block45;

    block45:
	OP_INT_ADD(l_cpu_1, 1L, l_v3269);
	l_v3270 = pypy_g_ll_int2dec__Signed(l_v3269);
	l_v3271 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3272 = (l_v3271 == NULL);
	if (!l_v3272) {
		goto block46;
	}
	l_cpu_1 = l_v3269;
	l_L2cache_6 = l_L2cache_4;
	l_v3364 = l_v3270;
	l_L3cache_1 = l_L3cache_0;
	goto block1;

    block46:
	PYPY_DEBUG_RECORD_TRACEBACK("get_L2cache_linux2_ia64");
	l_v3363 = -1L;
	goto block33;

    block47:
	OP_INT_ADD(l_L2cache_4, l_L3cache_0, l_v3274);
	if (PYPY_HAVE_DEBUG_PRINTS) { fprintf(PYPY_DEBUG_FILE, "L2cache = %ld\012", l_v3274); }
	PYPY_DEBUG_STOP("gc-hardware");
	OP_INT_GT(l_v3274, 0L, l_v3277);
	if (l_v3277) {
		l_v3363 = l_v3274;
		goto block33;
	}
	goto block48;

    block48:
	if (PYPY_HAVE_DEBUG_PRINTS) { fprintf(PYPY_DEBUG_FILE, "Warning: cannot find your CPU L2 & L3 cache size in /sys/devices"
	"/system/cpu/cpuX/cache\012"); }
	l_v3363 = -1L;
	goto block33;

    block49:
	l_v3279 = (&pypy_g_ExcData)->ed_exc_value;
	l_v3011 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("get_L2cache_linux2_ia64", l_v3011, l_v3011 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_v3011 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	l_v3006 = (struct pypy_exceptions_Exception0 *)l_v3279;
	l_v3283 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v3283, sizeof(void*), l_v3284);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v3284;
	l_v3286 = (void*)l_v3006;
	((void* *) (((char *)l_v3283) + 0))[0] = l_v3286;
	pypy_g_ll_os_ll_os_close(l_v2997);
	l_v3289 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v3289, sizeof(void*), l_v3290);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v3290;
	l_v3292 = ((void* *) (((char *)l_v3290) + 0))[0];
	l_v3006 = l_v3292; /* for moving GCs */
	l_v3294 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3295 = (l_v3294 == NULL);
	if (!l_v3295) {
		goto block52;
	}
	goto block50;

    block50:
	l_v3296 = RPyField(l_v3011, ov_subclassrange_min);
	l_v3297 = (l_v3296 == 23L);  /* was INT_BETWEEN */
	if (l_v3297) {
		goto block44;
	}
	goto block51;

    block51:
	l_v3298 = (struct pypy_object0 *)l_v3006;
	pypy_g_RPyReRaiseException(l_v3011, l_v3298);
	l_v3363 = -1L;
	goto block33;

    block52:
	l_evalue_5 = (&pypy_g_ExcData)->ed_exc_value;
	l_etype_8 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("get_L2cache_linux2_ia64", l_etype_8, l_etype_8 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_etype_8 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	l_v3303 = pypy_g_ll_issubclass__object_vtablePtr_object_vtablePtr(l_etype_8, (&pypy_g_exceptions_OSError_vtable.ose_super.ee_super.se_super.e_super));
	if (l_v3303) {
		goto block44;
	}
	goto block53;

    block53:
	pypy_g_RPyReRaiseException(l_etype_8, l_evalue_5);
	l_v3363 = -1L;
	goto block33;

    block54:
	l_v3020 = (&pypy_g_ExcData)->ed_exc_value;
	l_v3019 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("get_L2cache_linux2_ia64", l_v3019, l_v3019 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_v3019 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	l_v3308 = pypy_g_ll_issubclass__object_vtablePtr_object_vtablePtr(l_v3019, (&pypy_g_exceptions_OSError_vtable.ose_super.ee_super.se_super.e_super));
	if (l_v3308) {
		goto block44;
	}
	goto block55;

    block55:
	pypy_g_RPyReRaiseException(l_v3019, l_v3020);
	l_v3363 = -1L;
	goto block33;

    block56:
	PYPY_DEBUG_RECORD_TRACEBACK("get_L2cache_linux2_ia64");
	l_v3363 = -1L;
	goto block33;

    block57:
	OP_INT_ADD(l_index_8, 1L, l_v3311);
	l_index_8 = l_v3311;
	goto block2_back;

    block58:
	l_v3312 = pypy_g_ll_dict_lookup__v103___simple_call__function_l((&pypy_g_dicttable_5), l_level_0, l_level_0);
	l_v3365 = l_v3312;
	goto block13;

    block59:
	l_v3014 = (&pypy_g_ExcData)->ed_exc_value;
	l_etype_7 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("get_L2cache_linux2_ia64", l_etype_7, l_etype_7 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_etype_7 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	l_v3316 = pypy_g_ll_issubclass__object_vtablePtr_object_vtablePtr(l_etype_7, (&pypy_g_exceptions_OSError_vtable.ose_super.ee_super.se_super.e_super));
	if (l_v3316) {
		goto block44;
	}
	goto block60;

    block60:
	pypy_g_RPyReRaiseException(l_etype_7, l_v3014);
	l_v3363 = -1L;
	goto block33;

    block61:
	l_v3318 = (&pypy_g_ExcData)->ed_exc_value;
	l_v3319 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("get_L2cache_linux2_ia64", l_v3319, l_v3319 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_v3319 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	l_v3323 = (struct pypy_exceptions_Exception0 *)l_v3318;
	l_v2998 = l_v3323;
	l_v3004 = (&pypy_g_exceptions_ValueError_vtable.ve_super.se_super.e_super);
	goto block62;

    block62:
	l_v3324 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v3324, sizeof(void*), l_v3325);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v3325;
	l_v3327 = (void*)l_v2998;
	((void* *) (((char *)l_v3324) + 0))[0] = l_v3327;
	pypy_g_ll_os_ll_os_close(l_fd_3);
	l_v3330 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v3330, sizeof(void*), l_v3331);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v3331;
	l_v3333 = ((void* *) (((char *)l_v3331) + 0))[0];
	l_v2998 = l_v3333; /* for moving GCs */
	l_v3335 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3336 = (l_v3335 == NULL);
	if (!l_v3336) {
		goto block65;
	}
	goto block63;

    block63:
	l_v3337 = RPyField(l_v3004, ov_subclassrange_min);
	l_v3338 = (l_v3337 == 23L);  /* was INT_BETWEEN */
	if (l_v3338) {
		goto block44;
	}
	goto block64;

    block64:
	l_v3339 = (struct pypy_object0 *)l_v2998;
	pypy_g_RPyReRaiseException(l_v3004, l_v3339);
	l_v3363 = -1L;
	goto block33;

    block65:
	l_v3009 = (&pypy_g_ExcData)->ed_exc_value;
	l_v3008 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("get_L2cache_linux2_ia64", l_v3008, l_v3008 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_v3008 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	l_v3344 = pypy_g_ll_issubclass__object_vtablePtr_object_vtablePtr(l_v3008, (&pypy_g_exceptions_OSError_vtable.ose_super.ee_super.se_super.e_super));
	if (l_v3344) {
		goto block44;
	}
	goto block66;

    block66:
	pypy_g_RPyReRaiseException(l_v3008, l_v3009);
	l_v3363 = -1L;
	goto block33;

    block67:
	PYPY_DEBUG_RECORD_TRACEBACK("get_L2cache_linux2_ia64");
	l_v3363 = -1L;
	goto block33;

    block68:
	l_v3347 = (&pypy_g_ExcData)->ed_exc_value;
	l_v3348 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("get_L2cache_linux2_ia64", l_v3348, l_v3348 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_v3348 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	l_v3352 = (struct pypy_exceptions_Exception0 *)l_v3347;
	l_v2998 = l_v3352;
	l_v3004 = l_v3348;
	goto block62;

    block69:
	l_v3013 = (&pypy_g_ExcData)->ed_exc_value;
	l_v3012 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("get_L2cache_linux2_ia64", l_v3012, l_v3012 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_v3012 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	l_v3356 = pypy_g_ll_issubclass__object_vtablePtr_object_vtablePtr(l_v3012, (&pypy_g_exceptions_OSError_vtable.ose_super.ee_super.se_super.e_super));
	if (l_v3356) {
		goto block44;
	}
	goto block70;

    block70:
	pypy_g_RPyReRaiseException(l_v3012, l_v3013);
	l_v3363 = -1L;
	goto block33;

    block71:
	PYPY_DEBUG_RECORD_TRACEBACK("get_L2cache_linux2_ia64");
	l_v3363 = -1L;
	goto block33;

    block72:
	PYPY_DEBUG_RECORD_TRACEBACK("get_L2cache_linux2_ia64");
	l_v3363 = -1L;
	goto block33;

    block73:
	PYPY_DEBUG_RECORD_TRACEBACK("get_L2cache_linux2_ia64");
	l_v3363 = -1L;
	goto block33;

    block74:
	PYPY_DEBUG_RECORD_TRACEBACK("get_L2cache_linux2_ia64");
	l_v3363 = -1L;
	goto block33;

    block75:
	PYPY_DEBUG_RECORD_TRACEBACK("get_L2cache_linux2_ia64");
	l_v3363 = -1L;
	goto block33;
}
/*/*/
/***********************************************************/
