
/* Define on Darwin to activate all library features */
#define _DARWIN_C_SOURCE 1
/* This must be set to 64 on some systems to enable large file support. */
#define _FILE_OFFSET_BITS 64
/* Define on Linux to activate all library features */
#define _GNU_SOURCE 1
/* This must be defined on some systems to enable large file support. */
#define _LARGEFILE_SOURCE 1
/* Define on NetBSD to activate all library features */
#define _NETBSD_SOURCE 1
/* Define to activate features from IEEE Stds 1003.1-2001 */
#ifndef _POSIX_C_SOURCE
#  define _POSIX_C_SOURCE 200112L
#endif
/* Define on FreeBSD to activate all library features */
#define __BSD_VISIBLE 1
#define __XSI_VISIBLE 700
/* Windows: winsock/winsock2 mess */
#define WIN32_LEAN_AND_MEAN
#ifdef _WIN64
   typedef          __int64 Signed;
   typedef unsigned __int64 Unsigned;
#  define SIGNED_MIN LLONG_MIN 
#else
   typedef          long Signed;
   typedef unsigned long Unsigned;
#  define SIGNED_MIN LONG_MIN
#endif

/* using ShadowStackFrameworkGCTransformer */
#define MALLOC_ZERO_FILLED 1
#include <sys/mman.h>
#include <errno.h>
#include <stdio.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/times.h>
#include <utime.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <sys/utsname.h>
#include <src/dtoa.h>
int get_errno ();
void set_errno (int v);
int pypy_macro_wrapper_WCOREDUMP (int status);
int pypy_macro_wrapper_WIFCONTINUED (int status);
int pypy_macro_wrapper_WIFSTOPPED (int status);
int pypy_macro_wrapper_WIFSIGNALED (int status);
int pypy_macro_wrapper_WIFEXITED (int status);
int pypy_macro_wrapper_WEXITSTATUS (int status);
int pypy_macro_wrapper_WSTOPSIG (int status);
int pypy_macro_wrapper_WTERMSIG (int status);
#include <errno.h>
#include <stdio.h>
extern int errno;
int get_errno () { return errno; }
void set_errno (int v) { errno = v; }
