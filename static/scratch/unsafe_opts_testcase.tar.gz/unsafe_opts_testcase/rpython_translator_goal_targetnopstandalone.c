/***********************************************************/
/***  Implementations                                    ***/

#define PYPY_FILE_NAME "rpython_translator_goal_targetnopstandalone.c"
#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"
#include "src/g_include.h"

/*/*/
Signed pypy_g_entry_point(struct pypy_list0 *l_argv_0) {
	Signed l_v9966; bool_t l_v9956; bool_t l_v9959; bool_t l_v9962;
	struct pypy_object_vtable0 *l_v9955;
	struct pypy_object_vtable0 *l_v9958;
	struct pypy_object_vtable0 *l_v9961;
	goto block0;

    block0:
	pypy_g_rpython_print_item((&pypy_g_rpy_string.b));
	l_v9955 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9956 = (l_v9955 == NULL);
	if (!l_v9956) {
		goto block6;
	}
	goto block1;

    block1:
	pypy_g_rpython_print_item((&pypy_g_rpy_string_1.b));
	l_v9958 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9959 = (l_v9958 == NULL);
	if (!l_v9959) {
		goto block5;
	}
	goto block2;

    block2:
	pypy_g_rpython_print_newline();
	l_v9961 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9962 = (l_v9961 == NULL);
	if (!l_v9962) {
		goto block4;
	}
	l_v9966 = 0L;
	goto block3;

    block3:
	RPY_DEBUG_RETURN();
	return l_v9966;

    block4:
	PYPY_DEBUG_RECORD_TRACEBACK("entry_point");
	l_v9966 = -1L;
	goto block3;

    block5:
	PYPY_DEBUG_RECORD_TRACEBACK("entry_point");
	l_v9966 = -1L;
	goto block3;

    block6:
	PYPY_DEBUG_RECORD_TRACEBACK("entry_point");
	l_v9966 = -1L;
	goto block3;
}
/*/*/
/***********************************************************/
