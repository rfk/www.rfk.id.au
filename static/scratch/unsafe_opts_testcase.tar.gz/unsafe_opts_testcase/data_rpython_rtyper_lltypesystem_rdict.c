/***********************************************************/
/***  Non-function Implementations                       ***/

#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"

#include "src/g_include.h"

/*/*/
union pypy_rpy_string0_len1u pypy_g_rpy_string_60 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	0L,	/* hash */
	{
		1, {0}
	},
} };
/*/*/
/***********************************************************/
