/***********************************************************/
/***  Non-function Implementations                       ***/

#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"

#include "src/g_include.h"

/*/*/
union pypy_rpy_string0_len26u pypy_g_rpy_string_59 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	-304281295L,	/* hash */
	{
		26, {
105,110,118,97,108,105,100,32,105,110,112,117,116,32,97,116,32,112,111,115,
105,116,105,111,110,32}
	},
} };
/*/*/
/***********************************************************/
