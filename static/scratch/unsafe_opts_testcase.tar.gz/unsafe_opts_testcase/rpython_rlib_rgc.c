/***********************************************************/
/***  Implementations                                    ***/

#define PYPY_FILE_NAME "rpython_rlib_rgc.c"
#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"
#include "src/g_include.h"

/*/*/
void pypy_g_ll_arraycopy__arrayPtr_arrayPtr_Signed_Signed_Si(struct pypy_array3 *l_source_0, struct pypy_array3 *l_dest_1, Signed l_source_start_3, Signed l_dest_start_3, Signed l_length_41) {
	void* l_addr_array_5; void* l_addr_array_6; Signed l_i_22;
	Signed l_v7012; Signed l_v7018; Signed l_v7021; Signed l_v7022;
	Signed l_v7025; Signed l_v7030; Signed l_v7033; Signed l_v7035;
	Signed l_v7042; Signed l_v7043; bool_t l_v7013; bool_t l_v7016;
	bool_t l_v7017; bool_t l_v7023; bool_t l_v7039; bool_t l_v7044;
	struct pypy_header0 *l_v7020; struct pypy_header0 *l_v7041;
	struct pypy_rpy_string0 *l_v7008; struct pypy_rpy_string0 *l_v7010;
	void* l_v7009; void* l_v7011; void* l_v7014; void* l_v7015;
	void* l_v7019; void* l_v7027; void* l_v7028; void* l_v7029;
	void* l_v7031; void* l_v7032; void* l_v7034; void* l_v7040;
	goto block0;

    block0:
	OP_INT_LE(l_length_41, 1L, l_v7013);
	if (l_v7013) {
		goto block8;
	}
	goto block1;

    block1:
	l_v7014 = (void*)l_source_0;
	l_v7015 = (void*)l_dest_1;
	l_v7016 = pypy_g_MiniMarkGC_writebarrier_before_copy((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_v7014, l_v7015, l_source_start_3, l_dest_start_3, l_length_41);
	if (l_v7016) {
		goto block7;
	}
	l_i_22 = 0L;
	goto block2;

    block2:
	while (1) {
		OP_INT_LT(l_i_22, l_length_41, l_v7017);
		if (!l_v7017) break;
		goto block4;
	  block2_back: ;
	}
	goto block3;

    block3:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block4:
	OP_INT_ADD(l_i_22, l_source_start_3, l_v7018);
	OP_INT_ADD(l_i_22, l_dest_start_3, l_v7012);
	l_v7010 = RPyItem(l_source_0, l_v7018);
	l_v7011 = (void*)l_v7010;
	l_addr_array_6 = (void*)l_dest_1;
	OP_ADR_SUB(l_addr_array_6, 0, l_v7019);
	l_v7020 = (struct pypy_header0 *)l_v7019;
	l_v7021 = RPyField(l_v7020, h_tid);
	OP_INT_AND(l_v7021, 65536L, l_v7022);
	OP_INT_IS_TRUE(l_v7022, l_v7023);
	if (l_v7023) {
		goto block6;
	}
	goto block5;

    block5:
	RPyItem(l_dest_1, l_v7012) = l_v7010;
	OP_INT_ADD(l_i_22, 1L, l_v7025);
	l_i_22 = l_v7025;
	goto block2_back;

    block6:
	pypy_g_remember_young_pointer_from_array2(l_addr_array_6, l_v7012);
	goto block5;

    block7:
	l_v7027 = (void*)l_source_0;
	l_v7028 = (void*)l_dest_1;
	OP_ADR_ADD(l_v7027, offsetof(struct pypy_array3, items), l_v7029);
	OP_INT_MUL(sizeof(struct pypy_rpy_string0 *), l_source_start_3, l_v7030);
	OP_ADR_ADD(l_v7029, l_v7030, l_v7031);
	OP_ADR_ADD(l_v7028, offsetof(struct pypy_array3, items), l_v7032);
	OP_INT_MUL(sizeof(struct pypy_rpy_string0 *), l_dest_start_3, l_v7033);
	OP_ADR_ADD(l_v7032, l_v7033, l_v7034);
	OP_INT_MUL(sizeof(struct pypy_rpy_string0 *), l_length_41, l_v7035);
	OP_RAW_MEMCOPY(l_v7031, l_v7034, l_v7035, /* nothing */);
	/* kept alive: l_source_0 */
	/* kept alive: l_dest_1 */
	goto block3;

    block8:
	OP_INT_EQ(l_length_41, 1L, l_v7039);
	if (l_v7039) {
		goto block9;
	}
	goto block3;

    block9:
	l_v7008 = RPyItem(l_source_0, l_source_start_3);
	l_v7009 = (void*)l_v7008;
	l_addr_array_5 = (void*)l_dest_1;
	OP_ADR_SUB(l_addr_array_5, 0, l_v7040);
	l_v7041 = (struct pypy_header0 *)l_v7040;
	l_v7042 = RPyField(l_v7041, h_tid);
	OP_INT_AND(l_v7042, 65536L, l_v7043);
	OP_INT_IS_TRUE(l_v7043, l_v7044);
	if (l_v7044) {
		goto block11;
	}
	goto block10;

    block10:
	RPyItem(l_dest_1, l_dest_start_3) = l_v7008;
	goto block3;

    block11:
	pypy_g_remember_young_pointer_from_array2(l_addr_array_5, l_dest_start_3);
	goto block10;
}
/*/*/
/***********************************************************/
