/***********************************************************/
/***  Implementations                                    ***/

#define PYPY_FILE_NAME "rpython_memory_gc_minimark.c"
#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"
#include "src/g_include.h"

/*/*/
void pypy_g_MiniMarkGC_setup(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_77) {
	Signed l_newsize_11;
	struct pypy_rpython_memory_support_AddressDeque0 *l_self_79;
	struct pypy_rpython_memory_support_AddressStack0 *l_self_78;
	struct pypy_rpython_memory_support_AddressStack0 *l_self_80;
	Signed l_v3372; Signed l_v3375; Signed l_v3393; Signed l_v3402;
	Signed l_v3562; Signed l_v3565; Signed l_v3571; Signed l_v3577;
	Signed l_v3582; Signed l_v3588; Signed l_v3592; Signed l_v3598;
	Signed l_v3605; Signed l_v3622; Signed l_v3624; Signed l_v3625;
	Signed l_v3626; Signed l_v3627; Signed l_v3629; Signed l_v3633;
	Signed l_v3635; Signed l_v3660; Signed l_v3665; Unsigned l_v3394;
	Unsigned l_v3399; Unsigned l_v3413; Unsigned l_v3630;
	Unsigned l_v3631; bool_t l_v3371; bool_t l_v3379; bool_t l_v3383;
	bool_t l_v3384; bool_t l_v3397; bool_t l_v3403; bool_t l_v3408;
	bool_t l_v3416; bool_t l_v3420; bool_t l_v3424; bool_t l_v3425;
	bool_t l_v3437; bool_t l_v3441; bool_t l_v3445; bool_t l_v3446;
	bool_t l_v3457; bool_t l_v3461; bool_t l_v3465; bool_t l_v3466;
	bool_t l_v3477; bool_t l_v3481; bool_t l_v3485; bool_t l_v3486;
	bool_t l_v3496; bool_t l_v3500; bool_t l_v3504; bool_t l_v3505;
	bool_t l_v3515; bool_t l_v3519; bool_t l_v3523; bool_t l_v3524;
	bool_t l_v3534; bool_t l_v3538; bool_t l_v3542; bool_t l_v3543;
	bool_t l_v3553; bool_t l_v3558; bool_t l_v3560; bool_t l_v3566;
	bool_t l_v3567; bool_t l_v3569; bool_t l_v3574; bool_t l_v3576;
	bool_t l_v3578; bool_t l_v3579; bool_t l_v3581; bool_t l_v3583;
	bool_t l_v3584; bool_t l_v3586; bool_t l_v3591; bool_t l_v3596;
	bool_t l_v3601; bool_t l_v3603; bool_t l_v3608; bool_t l_v3610;
	bool_t l_v3615; bool_t l_v3616; bool_t l_v3621; bool_t l_v3623;
	bool_t l_v3632; bool_t l_v3634; bool_t l_v3641; bool_t l_v3663;
	bool_t l_v3664; bool_t l_v3666; double l_v3380; double l_v3382;
	double l_v3391; double l_v3561; double l_v3563; double l_v3564;
	double l_v3570; double l_v3572; double l_v3573; double l_v3587;
	double l_v3589; double l_v3590; double l_v3593; double l_v3597;
	double l_v3599; double l_v3600; double l_v3604; double l_v3606;
	double l_v3607; double l_v3611; double l_v3645; double l_v3648;
	double l_v3651; struct pypy_AddressChunk0 *l_v3388;
	struct pypy_AddressChunk0 *l_v3390;
	struct pypy_AddressChunk0 *l_v3395;
	struct pypy_AddressChunk0 *l_v3400;
	struct pypy_AddressChunk0 *l_v3404;
	struct pypy_AddressChunk0 *l_v3407;
	struct pypy_AddressChunk0 *l_v3411;
	struct pypy_AddressChunk0 *l_v3423;
	struct pypy_AddressChunk0 *l_v3444;
	struct pypy_AddressChunk0 *l_v3451;
	struct pypy_AddressChunk0 *l_v3464;
	struct pypy_AddressChunk0 *l_v3484;
	struct pypy_AddressChunk0 *l_v3491;
	struct pypy_AddressChunk0 *l_v3503;
	struct pypy_AddressChunk0 *l_v3510;
	struct pypy_AddressChunk0 *l_v3522;
	struct pypy_AddressChunk0 *l_v3529;
	struct pypy_AddressChunk0 *l_v3541;
	struct pypy_AddressChunk0 *l_v3548;
	struct pypy_AddressChunk0 *l_v3671;
	struct pypy_AddressChunk0 *l_v3672;
	struct pypy_AddressChunk0 *l_v3675;
	struct pypy_AddressChunk0 *l_v3676;
	struct pypy_AddressChunk0 *l_v3679;
	struct pypy_AddressChunk0 *l_v3680;
	struct pypy_AddressChunk0 *l_v3683;
	struct pypy_AddressChunk0 *l_v3684;
	struct pypy_AddressChunk0 *l_v3687;
	struct pypy_AddressChunk0 *l_v3688;
	struct pypy_AddressChunk0 *l_v3691;
	struct pypy_AddressChunk0 *l_v3692;
	struct pypy_AddressChunk0 *l_v3695;
	struct pypy_AddressChunk0 *l_v3696;
	struct pypy_AddressChunk0 *l_v3701;
	struct pypy_AddressChunk0 *l_v3703;
	struct pypy_AddressChunk0 *l_v3705;
	struct pypy_AddressChunk0 *l_v3707;
	struct pypy_AddressChunk0 *l_v3709;
	struct pypy_AddressChunk0 *l_v3711;
	struct pypy_AddressChunk0 *l_v3713; struct pypy_DICT0 *l_v3381;
	struct pypy_nongcobject0 *l_v3421; struct pypy_nongcobject0 *l_v3442;
	struct pypy_nongcobject0 *l_v3462; struct pypy_nongcobject0 *l_v3482;
	struct pypy_nongcobject0 *l_v3501; struct pypy_nongcobject0 *l_v3520;
	struct pypy_nongcobject0 *l_v3539;
	struct pypy_object_vtable0 *l_v3552;
	struct pypy_object_vtable0 *l_v3557;
	struct pypy_object_vtable0 *l_v3559;
	struct pypy_object_vtable0 *l_v3568;
	struct pypy_object_vtable0 *l_v3575;
	struct pypy_object_vtable0 *l_v3580;
	struct pypy_object_vtable0 *l_v3585;
	struct pypy_object_vtable0 *l_v3595;
	struct pypy_object_vtable0 *l_v3602;
	struct pypy_object_vtable0 *l_v3609;
	struct pypy_object_vtable0 *l_v3614;
	struct pypy_object_vtable0 *l_v3620;
	struct pypy_object_vtable0 *l_v3640;
	struct pypy_object_vtable0 *l_v3662;
	struct pypy_rpython_memory_support_AddressDeque0 *l_v3370;
	struct pypy_rpython_memory_support_AddressStack0 *l_v3376;
	struct pypy_rpython_memory_support_AddressStack0 *l_v3378;
	struct pypy_rpython_memory_support_AddressStack0 *l_v3386;
	struct pypy_tuple2_0 *l_v3373; struct pypy_tuple2_0 *l_v3385;
	struct pypy_tuple2_0 *l_v3387; struct pypy_tuple2_0 *l_v3401;
	struct pypy_tuple2_0 *l_v3405; struct pypy_tuple2_0 *l_v3406;
	struct pypy_tuple2_0 *l_v3410; void* l_v3374; void* l_v3377;
	void* l_v3389; void* l_v3392; void* l_v3396; void* l_v3398;
	void* l_v3409; void* l_v3412; void* l_v3415; void* l_v3436;
	void* l_v3456; void* l_v3476; void* l_v3495; void* l_v3514;
	void* l_v3533; void* l_v3700; void* l_v3702; void* l_v3704;
	void* l_v3706; void* l_v3708; void* l_v3710; void* l_v3712;
	goto block0;

    block0:
	RPyField(l_self_77, mmgc_inst_finalizer_lock_count) = 0L;
	OP_RAW_MALLOC(sizeof(struct pypy_rpython_memory_support_AddressDeque0), l_v3415, void *);
	OP_ADR_NE(l_v3415, NULL, l_v3416);
	if (l_v3416) {
		l_v3700 = l_v3415;
		goto block2;
	}
	goto block1;

    block1:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	l_v3700 = NULL;
	goto block2;

    block2:
	OP_TRACK_ALLOC_START(l_v3700, /* nothing */);
	l_v3370 = (struct pypy_rpython_memory_support_AddressDeque0 *)l_v3700;
	l_v3420 = (l_v3370 != NULL);
	if (!l_v3420) {
		goto block133;
	}
	goto block3;

    block3:
	l_v3421 = (struct pypy_nongcobject0 *)l_v3370;
	RPyField(l_v3421, n_typeptr) = (&pypy_g_rpython_memory_support_AddressDeque_vtable.ad_super);
	l_v3423 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v3424 = (l_v3423 != NULL);
	if (l_v3424) {
		goto block132;
	}
	goto block4;

    block4:
	OP_RAW_MALLOC(sizeof(struct pypy_AddressChunk0), l_v3409, void *);
	OP_ADR_NE(l_v3409, NULL, l_v3425);
	if (l_v3425) {
		goto block8;
	}
	goto block5;

    block5:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	goto block6;

    block6:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	goto block7;

    block7:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block8:
	l_v3411 = (struct pypy_AddressChunk0 *)l_v3409;
	l_v3379 = (l_v3411 != NULL);
	goto block9;

    block9:
	if (!l_v3379) {
		goto block6;
	}
	l_v3701 = l_v3411;
	goto block10;

    block10:
	RPyField(l_v3701, ac_next) = ((struct pypy_AddressChunk0 *) NULL);
	RPyField(l_v3370, ad_inst_oldest_chunk) = l_v3701;
	RPyField(l_v3370, ad_inst_newest_chunk) = l_v3701;
	RPyField(l_v3370, ad_inst_index_in_oldest) = 0L;
	RPyField(l_v3370, ad_inst_index_in_newest) = 0L;
	RPyField(l_self_77, mmgc_inst_run_finalizers) = l_v3370;
	RPyField(l_self_77, mmgc_inst_young_rawmalloced_objects) = ((struct pypy_DICT0 *) NULL);
	OP_RAW_MALLOC(sizeof(struct pypy_rpython_memory_support_AddressStack0), l_v3436, void *);
	OP_ADR_NE(l_v3436, NULL, l_v3437);
	if (l_v3437) {
		l_v3702 = l_v3436;
		goto block12;
	}
	goto block11;

    block11:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	l_v3702 = NULL;
	goto block12;

    block12:
	OP_TRACK_ALLOC_START(l_v3702, /* nothing */);
	l_self_78 = (struct pypy_rpython_memory_support_AddressStack0 *)l_v3702;
	l_v3441 = (l_self_78 != NULL);
	if (!l_v3441) {
		goto block131;
	}
	goto block13;

    block13:
	l_v3442 = (struct pypy_nongcobject0 *)l_self_78;
	RPyField(l_v3442, n_typeptr) = (&pypy_g_rpython_memory_support_AddressStack_vtable.as_super);
	l_v3444 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v3445 = (l_v3444 != NULL);
	if (l_v3445) {
		goto block130;
	}
	goto block14;

    block14:
	OP_RAW_MALLOC(sizeof(struct pypy_AddressChunk0), l_v3377, void *);
	OP_ADR_NE(l_v3377, NULL, l_v3446);
	if (l_v3446) {
		goto block17;
	}
	goto block15;

    block15:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	goto block16;

    block16:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	goto block7;

    block17:
	l_v3395 = (struct pypy_AddressChunk0 *)l_v3377;
	l_v3408 = (l_v3395 != NULL);
	goto block18;

    block18:
	if (!l_v3408) {
		goto block16;
	}
	l_v3703 = l_v3395;
	goto block19;

    block19:
	RPyField(l_self_78, as_inst_chunk) = l_v3703;
	l_v3451 = RPyField(l_self_78, as_inst_chunk);
	RPyField(l_v3451, ac_next) = ((struct pypy_AddressChunk0 *) NULL);
	RPyField(l_self_78, as_inst_used_in_last_chunk) = 0L;
	RPyField(l_self_77, mmgc_inst_old_rawmalloced_objects) = l_self_78;
	RPyField(l_self_77, mmgc_inst_rawmalloced_total_size) = 0UL;
	OP_RAW_MALLOC(sizeof(struct pypy_rpython_memory_support_AddressDeque0), l_v3456, void *);
	OP_ADR_NE(l_v3456, NULL, l_v3457);
	if (l_v3457) {
		l_v3704 = l_v3456;
		goto block21;
	}
	goto block20;

    block20:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	l_v3704 = NULL;
	goto block21;

    block21:
	OP_TRACK_ALLOC_START(l_v3704, /* nothing */);
	l_self_79 = (struct pypy_rpython_memory_support_AddressDeque0 *)l_v3704;
	l_v3461 = (l_self_79 != NULL);
	if (!l_v3461) {
		goto block129;
	}
	goto block22;

    block22:
	l_v3462 = (struct pypy_nongcobject0 *)l_self_79;
	RPyField(l_v3462, n_typeptr) = (&pypy_g_rpython_memory_support_AddressDeque_vtable.ad_super);
	l_v3464 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v3465 = (l_v3464 != NULL);
	if (l_v3465) {
		goto block128;
	}
	goto block23;

    block23:
	OP_RAW_MALLOC(sizeof(struct pypy_AddressChunk0), l_v3396, void *);
	OP_ADR_NE(l_v3396, NULL, l_v3466);
	if (l_v3466) {
		goto block26;
	}
	goto block24;

    block24:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	goto block25;

    block25:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	goto block7;

    block26:
	l_v3400 = (struct pypy_AddressChunk0 *)l_v3396;
	l_v3384 = (l_v3400 != NULL);
	goto block27;

    block27:
	if (!l_v3384) {
		goto block25;
	}
	l_v3705 = l_v3400;
	goto block28;

    block28:
	RPyField(l_v3705, ac_next) = ((struct pypy_AddressChunk0 *) NULL);
	RPyField(l_self_79, ad_inst_oldest_chunk) = l_v3705;
	RPyField(l_self_79, ad_inst_newest_chunk) = l_v3705;
	RPyField(l_self_79, ad_inst_index_in_oldest) = 0L;
	RPyField(l_self_79, ad_inst_index_in_newest) = 0L;
	RPyField(l_self_77, mmgc_inst_objects_with_finalizers) = l_self_79;
	OP_RAW_MALLOC(sizeof(struct pypy_rpython_memory_support_AddressStack0), l_v3476, void *);
	OP_ADR_NE(l_v3476, NULL, l_v3477);
	if (l_v3477) {
		l_v3706 = l_v3476;
		goto block30;
	}
	goto block29;

    block29:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	l_v3706 = NULL;
	goto block30;

    block30:
	OP_TRACK_ALLOC_START(l_v3706, /* nothing */);
	l_v3376 = (struct pypy_rpython_memory_support_AddressStack0 *)l_v3706;
	l_v3481 = (l_v3376 != NULL);
	if (!l_v3481) {
		goto block127;
	}
	goto block31;

    block31:
	l_v3482 = (struct pypy_nongcobject0 *)l_v3376;
	RPyField(l_v3482, n_typeptr) = (&pypy_g_rpython_memory_support_AddressStack_vtable.as_super);
	l_v3484 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v3485 = (l_v3484 != NULL);
	if (l_v3485) {
		goto block126;
	}
	goto block32;

    block32:
	OP_RAW_MALLOC(sizeof(struct pypy_AddressChunk0), l_v3374, void *);
	OP_ADR_NE(l_v3374, NULL, l_v3486);
	if (l_v3486) {
		goto block35;
	}
	goto block33;

    block33:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	goto block34;

    block34:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	goto block7;

    block35:
	l_v3390 = (struct pypy_AddressChunk0 *)l_v3374;
	l_v3403 = (l_v3390 != NULL);
	goto block36;

    block36:
	if (!l_v3403) {
		goto block34;
	}
	l_v3707 = l_v3390;
	goto block37;

    block37:
	RPyField(l_v3376, as_inst_chunk) = l_v3707;
	l_v3491 = RPyField(l_v3376, as_inst_chunk);
	RPyField(l_v3491, ac_next) = ((struct pypy_AddressChunk0 *) NULL);
	RPyField(l_v3376, as_inst_used_in_last_chunk) = 0L;
	RPyField(l_self_77, mmgc_inst_young_objects_with_light_finalizers) = l_v3376;
	OP_RAW_MALLOC(sizeof(struct pypy_rpython_memory_support_AddressStack0), l_v3495, void *);
	OP_ADR_NE(l_v3495, NULL, l_v3496);
	if (l_v3496) {
		l_v3708 = l_v3495;
		goto block39;
	}
	goto block38;

    block38:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	l_v3708 = NULL;
	goto block39;

    block39:
	OP_TRACK_ALLOC_START(l_v3708, /* nothing */);
	l_self_80 = (struct pypy_rpython_memory_support_AddressStack0 *)l_v3708;
	l_v3500 = (l_self_80 != NULL);
	if (!l_v3500) {
		goto block125;
	}
	goto block40;

    block40:
	l_v3501 = (struct pypy_nongcobject0 *)l_self_80;
	RPyField(l_v3501, n_typeptr) = (&pypy_g_rpython_memory_support_AddressStack_vtable.as_super);
	l_v3503 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v3504 = (l_v3503 != NULL);
	if (l_v3504) {
		goto block124;
	}
	goto block41;

    block41:
	OP_RAW_MALLOC(sizeof(struct pypy_AddressChunk0), l_v3389, void *);
	OP_ADR_NE(l_v3389, NULL, l_v3505);
	if (l_v3505) {
		goto block44;
	}
	goto block42;

    block42:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	goto block43;

    block43:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	goto block7;

    block44:
	l_v3404 = (struct pypy_AddressChunk0 *)l_v3389;
	l_v3383 = (l_v3404 != NULL);
	goto block45;

    block45:
	if (!l_v3383) {
		goto block43;
	}
	l_v3709 = l_v3404;
	goto block46;

    block46:
	RPyField(l_self_80, as_inst_chunk) = l_v3709;
	l_v3510 = RPyField(l_self_80, as_inst_chunk);
	RPyField(l_v3510, ac_next) = ((struct pypy_AddressChunk0 *) NULL);
	RPyField(l_self_80, as_inst_used_in_last_chunk) = 0L;
	RPyField(l_self_77, mmgc_inst_old_objects_with_light_finalizers) = l_self_80;
	OP_RAW_MALLOC(sizeof(struct pypy_rpython_memory_support_AddressStack0), l_v3514, void *);
	OP_ADR_NE(l_v3514, NULL, l_v3515);
	if (l_v3515) {
		l_v3710 = l_v3514;
		goto block48;
	}
	goto block47;

    block47:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	l_v3710 = NULL;
	goto block48;

    block48:
	OP_TRACK_ALLOC_START(l_v3710, /* nothing */);
	l_v3378 = (struct pypy_rpython_memory_support_AddressStack0 *)l_v3710;
	l_v3519 = (l_v3378 != NULL);
	if (!l_v3519) {
		goto block123;
	}
	goto block49;

    block49:
	l_v3520 = (struct pypy_nongcobject0 *)l_v3378;
	RPyField(l_v3520, n_typeptr) = (&pypy_g_rpython_memory_support_AddressStack_vtable.as_super);
	l_v3522 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v3523 = (l_v3522 != NULL);
	if (l_v3523) {
		goto block122;
	}
	goto block50;

    block50:
	OP_RAW_MALLOC(sizeof(struct pypy_AddressChunk0), l_v3392, void *);
	OP_ADR_NE(l_v3392, NULL, l_v3524);
	if (l_v3524) {
		goto block53;
	}
	goto block51;

    block51:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	goto block52;

    block52:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	goto block7;

    block53:
	l_v3407 = (struct pypy_AddressChunk0 *)l_v3392;
	l_v3397 = (l_v3407 != NULL);
	goto block54;

    block54:
	if (!l_v3397) {
		goto block52;
	}
	l_v3711 = l_v3407;
	goto block55;

    block55:
	RPyField(l_v3378, as_inst_chunk) = l_v3711;
	l_v3529 = RPyField(l_v3378, as_inst_chunk);
	RPyField(l_v3529, ac_next) = ((struct pypy_AddressChunk0 *) NULL);
	RPyField(l_v3378, as_inst_used_in_last_chunk) = 0L;
	RPyField(l_self_77, mmgc_inst_young_objects_with_weakrefs) = l_v3378;
	OP_RAW_MALLOC(sizeof(struct pypy_rpython_memory_support_AddressStack0), l_v3533, void *);
	OP_ADR_NE(l_v3533, NULL, l_v3534);
	if (l_v3534) {
		l_v3712 = l_v3533;
		goto block57;
	}
	goto block56;

    block56:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	l_v3712 = NULL;
	goto block57;

    block57:
	OP_TRACK_ALLOC_START(l_v3712, /* nothing */);
	l_v3386 = (struct pypy_rpython_memory_support_AddressStack0 *)l_v3712;
	l_v3538 = (l_v3386 != NULL);
	if (!l_v3538) {
		goto block121;
	}
	goto block58;

    block58:
	l_v3539 = (struct pypy_nongcobject0 *)l_v3386;
	RPyField(l_v3539, n_typeptr) = (&pypy_g_rpython_memory_support_AddressStack_vtable.as_super);
	l_v3541 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v3542 = (l_v3541 != NULL);
	if (l_v3542) {
		goto block120;
	}
	goto block59;

    block59:
	OP_RAW_MALLOC(sizeof(struct pypy_AddressChunk0), l_v3412, void *);
	OP_ADR_NE(l_v3412, NULL, l_v3543);
	if (l_v3543) {
		goto block62;
	}
	goto block60;

    block60:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	goto block61;

    block61:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	goto block7;

    block62:
	l_v3388 = (struct pypy_AddressChunk0 *)l_v3412;
	l_v3371 = (l_v3388 != NULL);
	goto block63;

    block63:
	if (!l_v3371) {
		goto block61;
	}
	l_v3713 = l_v3388;
	goto block64;

    block64:
	RPyField(l_v3386, as_inst_chunk) = l_v3713;
	l_v3548 = RPyField(l_v3386, as_inst_chunk);
	RPyField(l_v3548, ac_next) = ((struct pypy_AddressChunk0 *) NULL);
	RPyField(l_v3386, as_inst_used_in_last_chunk) = 0L;
	RPyField(l_self_77, mmgc_inst_old_objects_with_weakrefs) = l_v3386;
	l_v3381 = pypy_g_ll_newdict_size__Struct_DICTLlT_Signed(0L);
	l_v3552 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3553 = (l_v3552 == NULL);
	if (!l_v3553) {
		goto block119;
	}
	goto block65;

    block65:
	RPyField(l_self_77, mmgc_inst_nursery_objects_shadows) = l_v3381;
	l_v3375 = RPyField(l_self_77, mmgc_inst_nursery_size);
	RPyField(l_self_77, mmgc_inst_nursery_size) = 135168L;
	pypy_g_MiniMarkGC_allocate_nursery(l_self_77);
	l_v3557 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3558 = (l_v3557 == NULL);
	if (!l_v3558) {
		goto block118;
	}
	goto block66;

    block66:
	l_v3387 = pypy_g__read_float_and_factor_from_env((&pypy_g_rpy_string_2.b));
	l_v3559 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3560 = (l_v3559 == NULL);
	if (!l_v3560) {
		goto block117;
	}
	goto block67;

    block67:
	l_v3561 = RPyField(l_v3387, t_item0);
	l_v3562 = RPyField(l_v3387, t_item1);
	OP_CAST_INT_TO_FLOAT(l_v3562, l_v3563);
	OP_FLOAT_MUL(l_v3561, l_v3563, l_v3564);
	OP_CAST_FLOAT_TO_INT(l_v3564, l_v3565);
	OP_INT_LE(l_v3565, 0L, l_v3566);
	if (l_v3566) {
		goto block113;
	}
	l_v3402 = l_v3565;
	goto block68;

    block68:
	OP_INT_LT(l_v3402, 135168L, l_v3567);
	if (l_v3567) {
		goto block112;
	}
	l_newsize_11 = l_v3402;
	goto block69;

    block69:
	l_v3410 = pypy_g__read_float_and_factor_from_env((&pypy_g_rpy_string_3.b));
	l_v3568 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3569 = (l_v3568 == NULL);
	if (!l_v3569) {
		goto block111;
	}
	goto block70;

    block70:
	l_v3570 = RPyField(l_v3410, t_item0);
	l_v3571 = RPyField(l_v3410, t_item1);
	OP_CAST_INT_TO_FLOAT(l_v3571, l_v3572);
	OP_FLOAT_MUL(l_v3570, l_v3572, l_v3573);
	OP_CAST_FLOAT_TO_INT(l_v3573, l_v3372);
	OP_INT_GT(l_v3372, 0L, l_v3574);
	if (l_v3574) {
		goto block110;
	}
	goto block71;

    block71:
	l_v3401 = pypy_g__read_float_and_factor_from_env((&pypy_g_rpy_string_4.b));
	l_v3575 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3576 = (l_v3575 == NULL);
	if (!l_v3576) {
		goto block109;
	}
	goto block72;

    block72:
	l_v3380 = RPyField(l_v3401, t_item0);
	l_v3577 = RPyField(l_v3401, t_item1);
	OP_INT_NE(l_v3577, 1L, l_v3578);
	if (l_v3578) {
		goto block74;
	}
	goto block73;

    block73:
	OP_FLOAT_GT(l_v3380, 1.0, l_v3579);
	if (l_v3579) {
		goto block108;
	}
	goto block74;

    block74:
	l_v3405 = pypy_g__read_float_and_factor_from_env((&pypy_g_rpy_string_5.b));
	l_v3580 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3581 = (l_v3580 == NULL);
	if (!l_v3581) {
		goto block107;
	}
	goto block75;

    block75:
	l_v3382 = RPyField(l_v3405, t_item0);
	l_v3582 = RPyField(l_v3405, t_item1);
	OP_INT_NE(l_v3582, 1L, l_v3583);
	if (l_v3583) {
		goto block77;
	}
	goto block76;

    block76:
	OP_FLOAT_GT(l_v3382, 1.0, l_v3584);
	if (l_v3584) {
		goto block106;
	}
	goto block77;

    block77:
	l_v3406 = pypy_g__read_float_and_factor_from_env((&pypy_g_rpy_string_6.b));
	l_v3585 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3586 = (l_v3585 == NULL);
	if (!l_v3586) {
		goto block105;
	}
	goto block78;

    block78:
	l_v3587 = RPyField(l_v3406, t_item0);
	l_v3588 = RPyField(l_v3406, t_item1);
	OP_CAST_INT_TO_FLOAT(l_v3588, l_v3589);
	OP_FLOAT_MUL(l_v3587, l_v3589, l_v3590);
	OP_CAST_FLOAT_TO_UINT(l_v3590, l_v3413);
	OP_UINT_GT(l_v3413, 0UL, l_v3591);
	if (l_v3591) {
		goto block104;
	}
	goto block79;

    block79:
	OP_INT_MUL(l_newsize_11, 8L, l_v3592);
	OP_CAST_INT_TO_FLOAT(l_v3592, l_v3593);
	RPyField(l_self_77, mmgc_inst_min_heap_size) = l_v3593;
	goto block80;

    block80:
	l_v3385 = pypy_g__read_float_and_factor_from_env((&pypy_g_rpy_string_7.b));
	l_v3595 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3596 = (l_v3595 == NULL);
	if (!l_v3596) {
		goto block103;
	}
	goto block81;

    block81:
	l_v3597 = RPyField(l_v3385, t_item0);
	l_v3598 = RPyField(l_v3385, t_item1);
	OP_CAST_INT_TO_FLOAT(l_v3598, l_v3599);
	OP_FLOAT_MUL(l_v3597, l_v3599, l_v3600);
	OP_CAST_FLOAT_TO_UINT(l_v3600, l_v3399);
	OP_UINT_GT(l_v3399, 0UL, l_v3601);
	if (l_v3601) {
		goto block102;
	}
	goto block82;

    block82:
	l_v3373 = pypy_g__read_float_and_factor_from_env((&pypy_g_rpy_string_8.b));
	l_v3602 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3603 = (l_v3602 == NULL);
	if (!l_v3603) {
		goto block101;
	}
	goto block83;

    block83:
	l_v3604 = RPyField(l_v3373, t_item0);
	l_v3605 = RPyField(l_v3373, t_item1);
	OP_CAST_INT_TO_FLOAT(l_v3605, l_v3606);
	OP_FLOAT_MUL(l_v3604, l_v3606, l_v3607);
	OP_CAST_FLOAT_TO_UINT(l_v3607, l_v3394);
	OP_UINT_GT(l_v3394, 0UL, l_v3608);
	if (l_v3608) {
		goto block100;
	}
	goto block84;

    block84:
	l_v3391 = pypy_g_get_total_memory_linux((&pypy_g_rpy_string_9.b));
	l_v3609 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3610 = (l_v3609 == NULL);
	if (!l_v3610) {
		goto block99;
	}
	goto block85;

    block85:
	OP_FLOAT_MUL(0.125, l_v3391, l_v3611);
	RPyField(l_self_77, mmgc_inst_max_delta) = l_v3611;
	goto block86;

    block86:
	pypy_g_MiniMarkGC_minor_collection(l_self_77);
	l_v3614 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3615 = (l_v3614 == NULL);
	if (!l_v3615) {
		goto block98;
	}
	goto block87;

    block87:
	l_v3398 = RPyField(l_self_77, mmgc_inst_nursery);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v3616);
	if (l_v3616) {
		goto block96;
	}
	goto block88;

    block88:
	free(l_v3398);
	goto block89;

    block89:
	RPyField(l_self_77, mmgc_inst_nursery_size) = l_newsize_11;
	pypy_g_MiniMarkGC_allocate_nursery(l_self_77);
	l_v3620 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3621 = (l_v3620 == NULL);
	if (!l_v3621) {
		goto block95;
	}
	goto block90;

    block90:
	l_v3622 = RPyField(l_self_77, mmgc_inst_nursery_cleanup);
	OP_INT_LT(l_v3622, 67584L, l_v3623);
	if (l_v3623) {
		goto block94;
	}
	goto block91;

    block91:
	l_v3624 = RPyField(l_self_77, mmgc_inst_nursery_cleanup);
	l_v3625 = RPyField(l_self_77, mmgc_inst_nursery_size);
	OP_INT_MOD(l_v3625, l_v3624, l_v3626);
	OP_INT_ADD(l_v3624, l_v3626, l_v3627);
	RPyField(l_self_77, mmgc_inst_initial_cleanup) = l_v3627;
	l_v3629 = RPyField(l_self_77, mmgc_inst_initial_cleanup);
	OP_CAST_INT_TO_UINT(l_v3629, l_v3630);
	OP_CAST_INT_TO_UINT(l_v3625, l_v3631);
	OP_UINT_GT(l_v3630, l_v3631, l_v3632);
	if (l_v3632) {
		goto block93;
	}
	goto block92;

    block92:
	l_v3633 = RPyField(l_self_77, mmgc_inst_debug_tiny_nursery);
	OP_INT_GE(l_v3633, 0L, l_v3634);
	if (l_v3634) {
		goto block93;
	}
	goto block7;

    block93:
	l_v3635 = RPyField(l_self_77, mmgc_inst_nursery_size);
	RPyField(l_self_77, mmgc_inst_initial_cleanup) = l_v3635;
	goto block7;

    block94:
	RPyField(l_self_77, mmgc_inst_nursery_cleanup) = 67584L;
	goto block91;

    block95:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	goto block7;

    block96:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v3640 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3641 = (l_v3640 == NULL);
	if (!l_v3641) {
		goto block97;
	}
	goto block89;

    block97:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	goto block7;

    block98:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	goto block7;

    block99:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	goto block7;

    block100:
	OP_CAST_UINT_TO_FLOAT(l_v3394, l_v3645);
	RPyField(l_self_77, mmgc_inst_max_delta) = l_v3645;
	goto block86;

    block101:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	goto block7;

    block102:
	OP_CAST_UINT_TO_FLOAT(l_v3399, l_v3648);
	RPyField(l_self_77, mmgc_inst_max_heap_size) = l_v3648;
	goto block82;

    block103:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	goto block7;

    block104:
	OP_CAST_UINT_TO_FLOAT(l_v3413, l_v3651);
	RPyField(l_self_77, mmgc_inst_min_heap_size) = l_v3651;
	goto block80;

    block105:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	goto block7;

    block106:
	RPyField(l_self_77, mmgc_inst_growth_rate_max) = l_v3382;
	goto block77;

    block107:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	goto block7;

    block108:
	RPyField(l_self_77, mmgc_inst_major_collection_threshold) = l_v3380;
	goto block74;

    block109:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	goto block7;

    block110:
	RPyField(l_self_77, mmgc_inst_nursery_cleanup) = l_v3372;
	goto block71;

    block111:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	goto block7;

    block112:
	OP_INT_AND(l_v3402, -4L, l_v3660);
	RPyField(l_self_77, mmgc_inst_debug_tiny_nursery) = l_v3660;
	l_newsize_11 = 135168L;
	goto block69;

    block113:
	l_v3393 = pypy_g_get_L2cache_linux2();
	l_v3662 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3663 = (l_v3662 == NULL);
	if (!l_v3663) {
		goto block116;
	}
	goto block114;

    block114:
	OP_INT_GT(l_v3393, 2097152L, l_v3664);
	if (l_v3664) {
		goto block115;
	}
	l_newsize_11 = 1048576L;
	goto block69;

    block115:
	OP_INT_FLOORDIV(l_v3393, 2L, l_v3665);
	OP_INT_LE(l_v3665, 0L, l_v3666);
	if (l_v3666) {
		l_v3402 = l_v3375;
		goto block68;
	}
	l_v3402 = l_v3665;
	goto block68;

    block116:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	goto block7;

    block117:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	goto block7;

    block118:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	goto block7;

    block119:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	goto block7;

    block120:
	l_v3671 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v3672 = RPyField(l_v3671, ac_next);
	(&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list = l_v3672;
	l_v3713 = l_v3671;
	goto block64;

    block121:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	goto block7;

    block122:
	l_v3675 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v3676 = RPyField(l_v3675, ac_next);
	(&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list = l_v3676;
	l_v3711 = l_v3675;
	goto block55;

    block123:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	goto block7;

    block124:
	l_v3679 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v3680 = RPyField(l_v3679, ac_next);
	(&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list = l_v3680;
	l_v3709 = l_v3679;
	goto block46;

    block125:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	goto block7;

    block126:
	l_v3683 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v3684 = RPyField(l_v3683, ac_next);
	(&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list = l_v3684;
	l_v3707 = l_v3683;
	goto block37;

    block127:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	goto block7;

    block128:
	l_v3687 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v3688 = RPyField(l_v3687, ac_next);
	(&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list = l_v3688;
	l_v3705 = l_v3687;
	goto block28;

    block129:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	goto block7;

    block130:
	l_v3691 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v3692 = RPyField(l_v3691, ac_next);
	(&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list = l_v3692;
	l_v3703 = l_v3691;
	goto block19;

    block131:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	goto block7;

    block132:
	l_v3695 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v3696 = RPyField(l_v3695, ac_next);
	(&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list = l_v3696;
	l_v3701 = l_v3695;
	goto block10;

    block133:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_setup");
	goto block7;
}
/*/*/
void pypy_g_MiniMarkGC_post_setup(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_81) {
	Signed l_i_14; Signed l_size_8; Signed l_v3715; Signed l_v3717;
	Signed l_v3718; Signed l_v3724; Signed l_v3727; Signed l_v3729;
	Signed l_v3735; Signed l_v3741; Signed l_v3743; Signed l_v3744;
	Signed l_v3745; Signed l_v3749; Signed l_v3752; Signed l_v3756;
	Signed l_v3758; Signed l_v3759; Unsigned l_v3757; bool_t l_v3722;
	bool_t l_v3730; bool_t l_v3733; bool_t l_v3736; bool_t l_v3737;
	bool_t l_v3738; bool_t l_v3742; bool_t l_v3746; bool_t l_v3750;
	bool_t l_v3762; bool_t l_v3767; double l_v3723; double l_v3725;
	double l_v3726; struct pypy_array1 *l_v3716;
	struct pypy_array1 *l_v3747; struct pypy_array1 *l_v3751;
	struct pypy_object_vtable0 *l_v3721;
	struct pypy_object_vtable0 *l_v3761;
	struct pypy_object_vtable0 *l_v3766; struct pypy_tuple2_0 *l_v3719;
	void* l_v3714; void* l_v3720; void* l_v3732; void* l_v3755;
	void* l_v3765;
	goto block0;

    block0:
	l_v3719 = pypy_g__read_float_and_factor_from_env((&pypy_g_rpy_string_10.b));
	l_v3721 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3722 = (l_v3721 == NULL);
	if (!l_v3722) {
		goto block20;
	}
	goto block1;

    block1:
	l_v3723 = RPyField(l_v3719, t_item0);
	l_v3724 = RPyField(l_v3719, t_item1);
	OP_CAST_INT_TO_FLOAT(l_v3724, l_v3725);
	OP_FLOAT_MUL(l_v3723, l_v3725, l_v3726);
	OP_CAST_FLOAT_TO_INT(l_v3726, l_v3727);
	RPyField(l_self_81, mmgc_inst_DEBUG) = l_v3727;
	l_v3729 = RPyField(l_self_81, mmgc_inst_DEBUG);
	OP_INT_IS_TRUE(l_v3729, l_v3730);
	if (l_v3730) {
		goto block3;
	}
	goto block2;

    block2:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block3:
	PYPY_DEBUG_START("gc-debug");
	l_v3732 = pypy_g_ll_malloc_varsize__Signed_Signed_Signed_Signed(22L, (offsetof(struct pypy_array1, items) + 0), sizeof(void*), offsetof(struct pypy_array1, length));
	l_v3716 = (struct pypy_array1 *)l_v3732;
	l_v3733 = (l_v3716 != NULL);
	if (!l_v3733) {
		goto block19;
	}
	goto block4;

    block4:
	RPyField(l_self_81, mmgc_inst_debug_rotating_nurseries) = l_v3716;
	l_i_14 = 0L;
	goto block5;

    block5:
	while (1) {
		l_v3735 = RPyField(l_self_81, mmgc_inst_nursery_size);
		OP_INT_ADD(l_v3735, 67584L, l_v3715);
		OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v3736);
		if (l_v3736) break;
		goto block6;
	  block5_back: ;
	}
	goto block17;

    block6:
	l_v3720 = malloc(l_v3715);
	OP_ADR_NE(l_v3720, NULL, l_v3737);
	if (l_v3737) {
		goto block16;
	}
	l_v3714 = l_v3720;
	goto block7;

    block7:
	OP_ADR_NE(l_v3714, NULL, l_v3738);
	if (l_v3738) {
		goto block9;
	}
	goto block8;

    block8:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_post_setup");
	goto block2;

    block9:
	l_v3741 = RPyField(l_self_81, mmgc_inst_nursery_size);
	OP_INT_ADD(l_v3741, 67584L, l_size_8);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v3742);
	if (l_v3742) {
		goto block14;
	}
	goto block10;

    block10:
	l_v3743 = (Signed)(l_v3714);
	OP_INT_ADD(l_v3743, l_size_8, l_v3744);
	OP_INT_ADD(l_v3743, 4095L, l_v3745);
	OP_INT_AND(l_v3745, -4096L, l_v3717);
	OP_INT_AND(l_v3744, -4096L, l_v3718);
	OP_INT_GT(l_v3718, l_v3717, l_v3746);
	if (l_v3746) {
		goto block13;
	}
	goto block11;

    block11:
	l_v3747 = RPyField(l_self_81, mmgc_inst_debug_rotating_nurseries);
	RPyItem(l_v3747, l_i_14) = l_v3714;
	OP_INT_ADD(l_i_14, 1L, l_v3749);
	OP_INT_LT(l_v3749, 22L, l_v3750);
	if (l_v3750) {
		l_i_14 = l_v3749;
		goto block5_back;
	}
	goto block12;

    block12:
	l_v3751 = RPyField(l_self_81, mmgc_inst_debug_rotating_nurseries);
	l_v3752 = l_v3751->length;
	if (PYPY_HAVE_DEBUG_PRINTS) { fprintf(PYPY_DEBUG_FILE, "allocated %ld extra nurseries\012", l_v3752); }
	PYPY_DEBUG_STOP("gc-debug");
	goto block2;

    block13:
	l_v3755 = (void*)(l_v3717);
	OP_INT_SUB(l_v3718, l_v3717, l_v3756);
	l_v3757 = (Unsigned)(l_v3756);
	l_v3758 = (Signed)(0L);
	l_v3759 = mprotect(l_v3755, l_v3757, l_v3758);
	goto block11;

    block14:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v3761 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3762 = (l_v3761 == NULL);
	if (!l_v3762) {
		goto block15;
	}
	goto block11;

    block15:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_post_setup");
	goto block2;

    block16:
	OP_RAW_MEMCLEAR(l_v3720, l_v3715, /* nothing */);
	l_v3714 = l_v3720;
	goto block7;

    block17:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v3765 = (void*)0;
	l_v3766 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3767 = (l_v3766 == NULL);
	if (!l_v3767) {
		goto block18;
	}
	l_v3714 = l_v3765;
	goto block7;

    block18:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_post_setup");
	goto block2;

    block19:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_post_setup");
	goto block2;

    block20:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_post_setup");
	goto block2;
}
/*/*/
void* pypy_g_MiniMarkGC_malloc_fast(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_82, unsigned short l_typeid_11, Signed l_size_2, bool_t l_needs_finalizer_0, bool_t l_is_finalizer_light_0, bool_t l_contains_weakptr_0) {
	Signed l_rawtotalsize_1; void* l_result_10; void* l_result_11;
	Signed l_v3772; Signed l_v3773; Signed l_v3775; Signed l_v3785;
	bool_t l_v3774; bool_t l_v3776; bool_t l_v3781; bool_t l_v3782;
	bool_t l_v3790; bool_t l_v3794; bool_t l_v3799;
	struct pypy_header0 *l_v3784; struct pypy_object_vtable0 *l_v3789;
	struct pypy_object_vtable0 *l_v3793;
	struct pypy_object_vtable0 *l_v3798; void* l_v3777; void* l_v3779;
	void* l_v3780; void* l_v3783; void* l_v3787; void* l_v3792;
	void* l_v3797; void* l_v3801; void* l_v3802;
	goto block0;

    block0:
	OP_INT_ADD(0, l_size_2, l_v3772);
	OP_RAW_MALLOC_USAGE(l_v3772, l_rawtotalsize_1);
	OP_INT_GT(l_rawtotalsize_1, 67583L, l_v3774);
	if (l_v3774) {
		goto block11;
	}
	goto block1;

    block1:
	OP_RAW_MALLOC_USAGE((sizeof(struct pypy_header0) + sizeof(void*)), l_v3775);
	OP_INT_LT(l_rawtotalsize_1, l_v3775, l_v3776);
	if (l_v3776) {
		l_v3773 = l_v3775;
		goto block2;
	}
	l_v3773 = l_v3772;
	goto block2;

    block2:
	l_result_11 = RPyField(l_self_82, mmgc_inst_nursery_free);
	OP_ADR_ADD(l_result_11, l_v3773, l_v3777);
	RPyField(l_self_82, mmgc_inst_nursery_free) = l_v3777;
	l_v3779 = RPyField(l_self_82, mmgc_inst_nursery_free);
	l_v3780 = RPyField(l_self_82, mmgc_inst_nursery_top);
	OP_ADR_GT(l_v3779, l_v3780, l_v3781);
	if (l_v3781) {
		goto block9;
	}
	l_result_10 = l_result_11;
	goto block3;

    block3:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v3782);
	if (l_v3782) {
		goto block7;
	}
	goto block4;

    block4:
	OP_ADR_ADD(l_result_10, 0, l_v3783);
	l_v3784 = (struct pypy_header0 *)l_result_10;
	OP_COMBINE_USHORT(l_typeid_11, 0L, l_v3785);
	RPyField(l_v3784, h_tid) = l_v3785;
	l_v3802 = l_v3783;
	goto block5;

    block5:
	l_v3787 = (void*)l_v3802;
	l_v3801 = l_v3787;
	goto block6;

    block6:
	RPY_DEBUG_RETURN();
	return l_v3801;

    block7:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v3789 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3790 = (l_v3789 == NULL);
	if (!l_v3790) {
		goto block8;
	}
	goto block4;

    block8:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_malloc_fast");
	l_v3801 = NULL;
	goto block6;

    block9:
	l_v3792 = pypy_g_MiniMarkGC_collect_and_reserve(l_self_82, l_result_11, l_v3773);
	l_v3793 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3794 = (l_v3793 == NULL);
	if (!l_v3794) {
		goto block10;
	}
	l_result_10 = l_v3792;
	goto block3;

    block10:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_malloc_fast");
	l_v3801 = NULL;
	goto block6;

    block11:
	RPyAssert(1, "'contains_weakptr' specified for a large object");
	l_v3797 = pypy_g_MiniMarkGC_external_malloc(l_self_82, l_typeid_11, 0L, 1);
	l_v3798 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3799 = (l_v3798 == NULL);
	if (!l_v3799) {
		goto block12;
	}
	l_v3802 = l_v3797;
	goto block5;

    block12:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_malloc_fast");
	l_v3801 = NULL;
	goto block6;
}
/*/*/
void pypy_g_MiniMarkGC_allocate_nursery(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_3) {
	Signed l_v3803; Signed l_v3807; Signed l_v3809; Signed l_v3818;
	Signed l_v3834; bool_t l_v3810; bool_t l_v3811; bool_t l_v3812;
	bool_t l_v3827; bool_t l_v3832; bool_t l_v3840; double l_v3823;
	double l_v3824; double l_v3825; double l_v3826; double l_v3829;
	double l_v3843; struct pypy_object_vtable0 *l_v3839; void* l_v3804;
	void* l_v3805; void* l_v3816; void* l_v3819; void* l_v3821;
	void* l_v3838;
	goto block0;

    block0:
	PYPY_DEBUG_START("gc-set-nursery-size");
	l_v3807 = RPyField(l_self_3, mmgc_inst_nursery_size);
	if (PYPY_HAVE_DEBUG_PRINTS) { fprintf(PYPY_DEBUG_FILE, "nursery size: %ld\012", l_v3807); }
	l_v3809 = RPyField(l_self_3, mmgc_inst_nursery_size);
	OP_INT_ADD(l_v3809, 67584L, l_v3803);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v3810);
	if (l_v3810) {
		goto block8;
	}
	goto block1;

    block1:
	l_v3804 = malloc(l_v3803);
	OP_ADR_NE(l_v3804, NULL, l_v3811);
	if (l_v3811) {
		goto block7;
	}
	l_v3805 = l_v3804;
	goto block2;

    block2:
	OP_ADR_NE(l_v3805, NULL, l_v3812);
	if (l_v3812) {
		goto block5;
	}
	goto block3;

    block3:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_allocate_nursery");
	goto block4;

    block4:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block5:
	RPyField(l_self_3, mmgc_inst_nursery) = l_v3805;
	l_v3816 = RPyField(l_self_3, mmgc_inst_nursery);
	RPyField(l_self_3, mmgc_inst_nursery_free) = l_v3816;
	l_v3818 = RPyField(l_self_3, mmgc_inst_nursery_size);
	OP_ADR_ADD(l_v3816, l_v3818, l_v3819);
	RPyField(l_self_3, mmgc_inst_nursery_top) = l_v3819;
	l_v3821 = RPyField(l_self_3, mmgc_inst_nursery_top);
	RPyField(l_self_3, mmgc_inst_nursery_real_top) = l_v3821;
	l_v3823 = RPyField(l_self_3, mmgc_inst_min_heap_size);
	l_v3824 = RPyField(l_self_3, mmgc_inst_major_collection_threshold);
	OP_CAST_INT_TO_FLOAT(l_v3818, l_v3825);
	OP_FLOAT_MUL(l_v3825, l_v3824, l_v3826);
	OP_FLOAT_GT(l_v3823, l_v3826, l_v3827);
	if (l_v3827) {
		l_v3843 = l_v3823;
		goto block6;
	}
	l_v3843 = l_v3826;
	goto block6;

    block6:
	RPyField(l_self_3, mmgc_inst_min_heap_size) = l_v3843;
	l_v3829 = RPyField(l_self_3, mmgc_inst_min_heap_size);
	RPyField(l_self_3, mmgc_inst_next_major_collection_initial) = l_v3829;
	RPyField(l_self_3, mmgc_inst_next_major_collection_threshold) = l_v3829;
	l_v3832 = pypy_g_MiniMarkGC_set_major_threshold_from(l_self_3, 0.0, 0L);
	RPyAssert(1, "extra_threshold set too early");
	l_v3834 = RPyField(l_self_3, mmgc_inst_nursery_size);
	RPyField(l_self_3, mmgc_inst_initial_cleanup) = l_v3834;
	PYPY_DEBUG_STOP("gc-set-nursery-size");
	goto block4;

    block7:
	OP_RAW_MEMCLEAR(l_v3804, l_v3803, /* nothing */);
	l_v3805 = l_v3804;
	goto block2;

    block8:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v3838 = (void*)0;
	l_v3839 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3840 = (l_v3839 == NULL);
	if (!l_v3840) {
		goto block9;
	}
	l_v3805 = l_v3838;
	goto block2;

    block9:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_allocate_nursery");
	goto block4;
}
/*/*/
void pypy_g_MiniMarkGC_minor_collection(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_83) {
	Signed l_v3844; Signed l_v3847; Signed l_v3862; Signed l_v3865;
	Signed l_v3868; Signed l_v3871; Signed l_v3883; Signed l_v3886;
	Signed l_v3893; Signed l_v3896; Signed l_v3902; Unsigned l_v3889;
	Unsigned l_v3890; Unsigned l_v3891; bool_t l_v3850; bool_t l_v3854;
	bool_t l_v3858; bool_t l_v3861; bool_t l_v3863; bool_t l_v3866;
	bool_t l_v3869; bool_t l_v3872; bool_t l_v3874; bool_t l_v3875;
	bool_t l_v3876; bool_t l_v3880; bool_t l_v3894; bool_t l_v3897;
	bool_t l_v3899; bool_t l_v3903; bool_t l_v3907; bool_t l_v3912;
	bool_t l_v3916; bool_t l_v3921; bool_t l_v3935; bool_t l_v3939;
	bool_t l_v3943; bool_t l_v3950; bool_t l_v3953; bool_t l_v3954;
	struct pypy_DICT0 *l_v3849; struct pypy_DICT0 *l_v3870;
	struct pypy_DICT0 *l_v3873; struct pypy_DICT0 *l_v3898;
	struct pypy_DICT0 *l_v3918; struct pypy_DICT0 *l_v3922;
	struct pypy_DICT0 *l_v3932; struct pypy_array5 *l_v3923;
	struct pypy_object_vtable0 *l_v3853;
	struct pypy_object_vtable0 *l_v3857;
	struct pypy_object_vtable0 *l_v3860;
	struct pypy_object_vtable0 *l_v3879;
	struct pypy_object_vtable0 *l_v3906;
	struct pypy_object_vtable0 *l_v3911;
	struct pypy_object_vtable0 *l_v3915;
	struct pypy_object_vtable0 *l_v3920;
	struct pypy_object_vtable0 *l_v3934;
	struct pypy_object_vtable0 *l_v3938;
	struct pypy_object_vtable0 *l_v3942;
	struct pypy_object_vtable0 *l_v3949;
	struct pypy_rpython_memory_support_AddressStack0 *l_v3864;
	struct pypy_rpython_memory_support_AddressStack0 *l_v3867;
	struct pypy_rpython_memory_support_AddressStack0 *l_v3901;
	void* l_v3845; void* l_v3846; void* l_v3881; void* l_v3884;
	void* l_v3887; void* l_v3924; void* l_v3927;
	goto block0;

    block0:
	PYPY_DEBUG_START("gc-minor");
	l_v3849 = RPyField(l_self_83, mmgc_inst_young_rawmalloced_objects);
	l_v3850 = (l_v3849 != NULL);
	if (l_v3850) {
		goto block39;
	}
	goto block1;

    block1:
	PYPY_DEBUG_START("gc-minor-walkroots");
	pypy_g_walk_roots(pypy_g_MiniMarkGC__trace_drag_out1, pypy_g_MiniMarkGC__trace_drag_out1, ((void (*)(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *, void*)) NULL));
	l_v3853 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3854 = (l_v3853 == NULL);
	if (!l_v3854) {
		goto block38;
	}
	goto block2;

    block2:
	PYPY_DEBUG_STOP("gc-minor-walkroots");
	goto block3;

    block3:
	while (1) {
		pypy_g_MiniMarkGC_collect_cardrefs_to_nursery(l_self_83);
		l_v3857 = (&pypy_g_ExcData)->ed_exc_type;
		l_v3858 = (l_v3857 == NULL);
		if (!l_v3858) break;
		goto block4;
	  block3_back: ;
	}
	goto block37;

    block4:
	pypy_g_MiniMarkGC_collect_oldrefs_to_nursery(l_self_83);
	l_v3860 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3861 = (l_v3860 == NULL);
	if (!l_v3861) {
		goto block36;
	}
	goto block5;

    block5:
	l_v3862 = (&pypy_g_rpython_memory_support_AddressStack_1)->as_inst_used_in_last_chunk;
	OP_INT_NE(l_v3862, 0L, l_v3863);
	if (l_v3863) {
		goto block3_back;
	}
	goto block6;

    block6:
	l_v3864 = RPyField(l_self_83, mmgc_inst_young_objects_with_weakrefs);
	l_v3865 = RPyField(l_v3864, as_inst_used_in_last_chunk);
	OP_INT_NE(l_v3865, 0L, l_v3866);
	if (l_v3866) {
		goto block34;
	}
	goto block7;

    block7:
	l_v3867 = RPyField(l_self_83, mmgc_inst_young_objects_with_light_finalizers);
	l_v3868 = RPyField(l_v3867, as_inst_used_in_last_chunk);
	OP_INT_NE(l_v3868, 0L, l_v3869);
	if (l_v3869) {
		goto block32;
	}
	goto block8;

    block8:
	l_v3870 = RPyField(l_self_83, mmgc_inst_nursery_objects_shadows);
	l_v3871 = RPyField(l_v3870, di_num_items);
	OP_INT_GT(l_v3871, 0L, l_v3872);
	if (l_v3872) {
		goto block30;
	}
	goto block9;

    block9:
	l_v3873 = RPyField(l_self_83, mmgc_inst_young_rawmalloced_objects);
	l_v3874 = (l_v3873 != NULL);
	if (l_v3874) {
		goto block27;
	}
	goto block10;

    block10:
	l_v3845 = RPyField(l_self_83, mmgc_inst_nursery);
	l_v3844 = RPyField(l_self_83, mmgc_inst_nursery_size);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v3875);
	if (l_v3875) {
		goto block25;
	}
	goto block11;

    block11:
	l_v3846 = RPyField(l_self_83, mmgc_inst_nursery);
	l_v3847 = RPyField(l_self_83, mmgc_inst_initial_cleanup);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v3876);
	if (l_v3876) {
		goto block23;
	}
	goto block12;

    block12:
	OP_RAW_MEMCLEAR(l_v3846, l_v3847, /* nothing */);
	goto block13;

    block13:
	pypy_g_MiniMarkGC_debug_rotate_nursery(l_self_83);
	l_v3879 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3880 = (l_v3879 == NULL);
	if (!l_v3880) {
		goto block22;
	}
	goto block14;

    block14:
	l_v3881 = RPyField(l_self_83, mmgc_inst_nursery);
	RPyField(l_self_83, mmgc_inst_nursery_free) = l_v3881;
	l_v3883 = RPyField(l_self_83, mmgc_inst_initial_cleanup);
	OP_ADR_ADD(l_v3881, l_v3883, l_v3884);
	RPyField(l_self_83, mmgc_inst_nursery_top) = l_v3884;
	l_v3886 = RPyField(l_self_83, mmgc_inst_nursery_size);
	OP_ADR_ADD(l_v3881, l_v3886, l_v3887);
	RPyField(l_self_83, mmgc_inst_nursery_real_top) = l_v3887;
	l_v3889 = (&pypy_g_rpython_memory_gc_minimarkpage_ArenaCollection)->ac_inst_total_memory_used;
	l_v3890 = RPyField(l_self_83, mmgc_inst_rawmalloced_total_size);
	OP_UINT_ADD(l_v3889, l_v3890, l_v3891);
	if (PYPY_HAVE_DEBUG_PRINTS) { fprintf(PYPY_DEBUG_FILE, "minor collect, total memory used: %lu\012", l_v3891); }
	l_v3893 = RPyField(l_self_83, mmgc_inst_DEBUG);
	OP_INT_GE(l_v3893, 2L, l_v3894);
	if (l_v3894) {
		goto block17;
	}
	goto block15;

    block15:
	PYPY_DEBUG_STOP("gc-minor");
	goto block16;

    block16:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block17:
	l_v3896 = RPyField(l_self_83, mmgc_inst_DEBUG);
	OP_INT_IS_TRUE(l_v3896, l_v3897);
	if (l_v3897) {
		goto block18;
	}
	goto block15;

    block18:
	l_v3898 = RPyField(l_self_83, mmgc_inst_young_rawmalloced_objects);
	l_v3899 = (l_v3898 != NULL);
	if (l_v3899) {
		l_v3953 = 0;
		goto block19;
	}
	l_v3953 = 1;
	goto block19;

    block19:
	RPyAssert(l_v3953, "young raw-malloced objects in a major collection");
	l_v3901 = RPyField(l_self_83, mmgc_inst_young_objects_with_weakrefs);
	l_v3902 = RPyField(l_v3901, as_inst_used_in_last_chunk);
	OP_INT_NE(l_v3902, 0L, l_v3903);
	if (l_v3903) {
		l_v3954 = 0;
		goto block20;
	}
	l_v3954 = 1;
	goto block20;

    block20:
	RPyAssert(l_v3954, "young objects with weakrefs in a major collection");
	pypy_g_GCBase_debug_check_consistency(l_self_83);
	l_v3906 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3907 = (l_v3906 == NULL);
	if (!l_v3907) {
		goto block21;
	}
	goto block15;

    block21:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_minor_collection");
	goto block16;

    block22:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_minor_collection");
	goto block16;

    block23:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v3911 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3912 = (l_v3911 == NULL);
	if (!l_v3912) {
		goto block24;
	}
	goto block13;

    block24:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_minor_collection");
	goto block16;

    block25:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v3915 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3916 = (l_v3915 == NULL);
	if (!l_v3916) {
		goto block26;
	}
	goto block11;

    block26:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_minor_collection");
	goto block16;

    block27:
	l_v3918 = RPyField(l_self_83, mmgc_inst_young_rawmalloced_objects);
	pypy_g_dict_foreach___free_young_rawmalloced_obj(l_v3918, l_self_83);
	l_v3920 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3921 = (l_v3920 == NULL);
	if (!l_v3921) {
		goto block29;
	}
	goto block28;

    block28:
	l_v3922 = RPyField(l_self_83, mmgc_inst_young_rawmalloced_objects);
	l_v3923 = RPyField(l_v3922, di_entries);
	l_v3924 = (void*)l_v3923;
	OP_TRACK_ALLOC_STOP(l_v3924, /* nothing */);
	OP_RAW_FREE(l_v3924, /* nothing */);
	l_v3927 = (void*)l_v3922;
	OP_TRACK_ALLOC_STOP(l_v3927, /* nothing */);
	OP_RAW_FREE(l_v3927, /* nothing */);
	RPyField(l_self_83, mmgc_inst_young_rawmalloced_objects) = ((struct pypy_DICT0 *) NULL);
	goto block10;

    block29:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_minor_collection");
	goto block16;

    block30:
	l_v3932 = RPyField(l_self_83, mmgc_inst_nursery_objects_shadows);
	pypy_g_ll_clear__DICTPtr(l_v3932);
	l_v3934 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3935 = (l_v3934 == NULL);
	if (!l_v3935) {
		goto block31;
	}
	goto block9;

    block31:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_minor_collection");
	goto block16;

    block32:
	pypy_g_MiniMarkGC_deal_with_young_objects_with_finalize(l_self_83);
	l_v3938 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3939 = (l_v3938 == NULL);
	if (!l_v3939) {
		goto block33;
	}
	goto block8;

    block33:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_minor_collection");
	goto block16;

    block34:
	pypy_g_MiniMarkGC_invalidate_young_weakrefs(l_self_83);
	l_v3942 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3943 = (l_v3942 == NULL);
	if (!l_v3943) {
		goto block35;
	}
	goto block7;

    block35:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_minor_collection");
	goto block16;

    block36:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_minor_collection");
	goto block16;

    block37:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_minor_collection");
	goto block16;

    block38:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_minor_collection");
	goto block16;

    block39:
	pypy_g_MiniMarkGC_remove_young_arrays_from_old_objects_(l_self_83);
	l_v3949 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3950 = (l_v3949 == NULL);
	if (!l_v3950) {
		goto block40;
	}
	goto block1;

    block40:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_minor_collection");
	goto block16;
}
/*/*/
void* pypy_g_MiniMarkGC_malloc_varsize_clear_fast(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_84, unsigned short l_typeid_12, Signed l_length_35, Signed l_size_3, Signed l_itemsize_3, Signed l_offset_to_length_1) {
	Signed l_maxsize_2; Signed l_nonvarsize_0; Unsigned l_toobig_3;
	Signed l_totalsize_13; Signed l_v3955; Signed l_v3958;
	Signed l_v3960; Signed l_v3964; Signed l_v3966; Signed l_v3967;
	Signed l_v3968; Signed l_v3978; Signed l_v3992; Signed l_v4000;
	Signed l_v4001; Unsigned l_v3962; Unsigned l_v4002; Unsigned l_v4003;
	bool_t l_v3959; bool_t l_v3961; bool_t l_v3963; bool_t l_v3965;
	bool_t l_v3969; bool_t l_v3975; bool_t l_v3976; bool_t l_v3986;
	bool_t l_v3990; bool_t l_v3994; bool_t l_v3998;
	struct pypy_header0 *l_v3977; struct pypy_object_vtable0 *l_v3985;
	struct pypy_object_vtable0 *l_v3989;
	struct pypy_object_vtable0 *l_v3993;
	struct pypy_object_vtable0 *l_v3997; void* l_v3956; void* l_v3957;
	void* l_v3971; void* l_v3973; void* l_v3974; void* l_v3980;
	void* l_v3981; void* l_v3983; void* l_v3988; void* l_v3996;
	void* l_v4004; void* l_v4005;
	goto block0;

    block0:
	OP_INT_ADD(0, l_size_3, l_nonvarsize_0);
	OP_RAW_MALLOC_USAGE(l_nonvarsize_0, l_v3958);
	OP_INT_SUB(67583L, l_v3958, l_maxsize_2);
	OP_INT_LT(l_maxsize_2, 0L, l_v3959);
	if (l_v3959) {
		l_toobig_3 = 0UL;
		goto block2;
	}
	goto block1;

    block1:
	OP_RAW_MALLOC_USAGE(l_itemsize_3, l_v3960);
	OP_INT_IS_TRUE(l_v3960, l_v3961);
	if (l_v3961) {
		goto block18;
	}
	l_toobig_3 = 2147483648UL;
	goto block2;

    block2:
	OP_CAST_INT_TO_UINT(l_length_35, l_v3962);
	OP_UINT_GE(l_v3962, l_toobig_3, l_v3963);
	if (l_v3963) {
		goto block16;
	}
	goto block3;

    block3:
	OP_INT_MUL(l_itemsize_3, l_length_35, l_v3964);
	OP_INT_ADD(l_nonvarsize_0, l_v3964, l_v3955);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v3965);
	if (l_v3965) {
		goto block14;
	}
	goto block4;

    block4:
	l_v3966 = ROUND_UP_FOR_ALLOCATION(l_v3955, 0L);
	l_totalsize_13 = l_v3966;
	goto block5;

    block5:
	OP_RAW_MALLOC_USAGE(l_totalsize_13, l_v3967);
	OP_RAW_MALLOC_USAGE((sizeof(struct pypy_header0) + sizeof(void*)), l_v3968);
	OP_INT_GE(l_v3967, l_v3968, l_v3969);
	RPyAssert(l_v3969, "malloc_varsize_clear(): totalsize < minimalsize");
	l_v3956 = RPyField(l_self_84, mmgc_inst_nursery_free);
	OP_ADR_ADD(l_v3956, l_totalsize_13, l_v3971);
	RPyField(l_self_84, mmgc_inst_nursery_free) = l_v3971;
	l_v3973 = RPyField(l_self_84, mmgc_inst_nursery_free);
	l_v3974 = RPyField(l_self_84, mmgc_inst_nursery_top);
	OP_ADR_GT(l_v3973, l_v3974, l_v3975);
	if (l_v3975) {
		goto block12;
	}
	l_v3957 = l_v3956;
	goto block6;

    block6:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v3976);
	if (l_v3976) {
		goto block10;
	}
	goto block7;

    block7:
	l_v3977 = (struct pypy_header0 *)l_v3957;
	OP_COMBINE_USHORT(l_typeid_12, 0L, l_v3978);
	RPyField(l_v3977, h_tid) = l_v3978;
	OP_ADR_ADD(l_v3957, 0, l_v3980);
	OP_ADR_ADD(l_v3980, l_offset_to_length_1, l_v3981);
	((Signed *) (((char *)l_v3981) + 0))[0] = l_length_35;
	l_v4005 = l_v3980;
	goto block8;

    block8:
	l_v3983 = (void*)l_v4005;
	l_v4004 = l_v3983;
	goto block9;

    block9:
	RPY_DEBUG_RETURN();
	return l_v4004;

    block10:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v3985 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3986 = (l_v3985 == NULL);
	if (!l_v3986) {
		goto block11;
	}
	goto block7;

    block11:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_malloc_varsize_clear_fast");
	l_v4004 = NULL;
	goto block9;

    block12:
	l_v3988 = pypy_g_MiniMarkGC_collect_and_reserve(l_self_84, l_v3956, l_totalsize_13);
	l_v3989 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3990 = (l_v3989 == NULL);
	if (!l_v3990) {
		goto block13;
	}
	l_v3957 = l_v3988;
	goto block6;

    block13:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_malloc_varsize_clear_fast");
	l_v4004 = NULL;
	goto block9;

    block14:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v3992 = (Signed)0;
	l_v3993 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3994 = (l_v3993 == NULL);
	if (!l_v3994) {
		goto block15;
	}
	l_totalsize_13 = l_v3992;
	goto block5;

    block15:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_malloc_varsize_clear_fast");
	l_v4004 = NULL;
	goto block9;

    block16:
	l_v3996 = pypy_g_MiniMarkGC_external_malloc(l_self_84, l_typeid_12, l_length_35, 1);
	l_v3997 = (&pypy_g_ExcData)->ed_exc_type;
	l_v3998 = (l_v3997 == NULL);
	if (!l_v3998) {
		goto block17;
	}
	l_v4005 = l_v3996;
	goto block8;

    block17:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_malloc_varsize_clear_fast");
	l_v4004 = NULL;
	goto block9;

    block18:
	OP_RAW_MALLOC_USAGE(l_itemsize_3, l_v4000);
	OP_INT_FLOORDIV(l_maxsize_2, l_v4000, l_v4001);
	OP_CAST_INT_TO_UINT(l_v4001, l_v4002);
	OP_UINT_ADD(l_v4002, 1UL, l_v4003);
	l_toobig_3 = l_v4003;
	goto block2;
}
/*/*/
void pypy_g_MiniMarkGC_write_barrier(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_6, void* l_newvalue_3, void* l_addr_struct_2) {
	Signed l_v4008; Signed l_v4009; bool_t l_v4010;
	struct pypy_header0 *l_v4007; void* l_v4006;
	goto block0;

    block0:
	OP_ADR_SUB(l_addr_struct_2, 0, l_v4006);
	l_v4007 = (struct pypy_header0 *)l_v4006;
	l_v4008 = RPyField(l_v4007, h_tid);
	OP_INT_AND(l_v4008, 65536L, l_v4009);
	OP_INT_IS_TRUE(l_v4009, l_v4010);
	if (l_v4010) {
		goto block2;
	}
	goto block1;

    block1:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block2:
	pypy_g_remember_young_pointer(l_addr_struct_2, l_newvalue_3);
	goto block1;
}
/*/*/
void* pypy_g_MiniMarkGC_collect_and_reserve(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_85, void* l_prev_result_1, Signed l_totalsize_14) {
	void* l_result_12; Signed l_v4013; Signed l_v4015; Signed l_v4035;
	Signed l_v4039; Signed l_v4040; Signed l_v4043; Signed l_v4058;
	Signed l_v4061; Signed l_v4080; Signed l_v4083; Unsigned l_v4023;
	Unsigned l_v4024; Unsigned l_v4025; bool_t l_v4019; bool_t l_v4022;
	bool_t l_v4028; bool_t l_v4033; bool_t l_v4036; bool_t l_v4041;
	bool_t l_v4048; bool_t l_v4052; bool_t l_v4056; bool_t l_v4059;
	bool_t l_v4062; bool_t l_v4064; bool_t l_v4071; bool_t l_v4075;
	bool_t l_v4081; bool_t l_v4084; bool_t l_v4086; bool_t l_v4093;
	double l_v4026; double l_v4027; struct pypy_object_vtable0 *l_v4021;
	struct pypy_object_vtable0 *l_v4047;
	struct pypy_object_vtable0 *l_v4070;
	struct pypy_object_vtable0 *l_v4074;
	struct pypy_object_vtable0 *l_v4092; void* l_v4014; void* l_v4016;
	void* l_v4017; void* l_v4018; void* l_v4029; void* l_v4031;
	void* l_v4032; void* l_v4037; void* l_v4038; void* l_v4042;
	void* l_v4044; void* l_v4049; void* l_v4050; void* l_v4051;
	void* l_v4053; void* l_v4054; void* l_v4055; void* l_v4057;
	void* l_v4066; void* l_v4067; void* l_v4079; void* l_v4088;
	void* l_v4089; void* l_v4095;
	goto block0;

    block0:
	l_v4017 = RPyField(l_self_85, mmgc_inst_nursery_top);
	l_v4018 = RPyField(l_self_85, mmgc_inst_nursery_real_top);
	OP_ADR_LT(l_v4017, l_v4018, l_v4019);
	if (l_v4019) {
		goto block19;
	}
	goto block1;

    block1:
	pypy_g_MiniMarkGC_minor_collection(l_self_85);
	l_v4021 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4022 = (l_v4021 == NULL);
	if (!l_v4022) {
		goto block18;
	}
	goto block2;

    block2:
	l_v4023 = (&pypy_g_rpython_memory_gc_minimarkpage_ArenaCollection)->ac_inst_total_memory_used;
	l_v4024 = RPyField(l_self_85, mmgc_inst_rawmalloced_total_size);
	OP_UINT_ADD(l_v4023, l_v4024, l_v4025);
	l_v4026 = RPyField(l_self_85, mmgc_inst_next_major_collection_threshold);
	OP_CAST_UINT_TO_FLOAT(l_v4025, l_v4027);
	OP_FLOAT_GT(l_v4027, l_v4026, l_v4028);
	if (l_v4028) {
		goto block7;
	}
	goto block3;

    block3:
	l_result_12 = RPyField(l_self_85, mmgc_inst_nursery_free);
	OP_ADR_ADD(l_result_12, l_totalsize_14, l_v4029);
	RPyField(l_self_85, mmgc_inst_nursery_free) = l_v4029;
	l_v4031 = RPyField(l_self_85, mmgc_inst_nursery_free);
	l_v4032 = RPyField(l_self_85, mmgc_inst_nursery_top);
	OP_ADR_LE(l_v4031, l_v4032, l_v4033);
	RPyAssert(l_v4033, "nursery overflow");
	l_v4035 = RPyField(l_self_85, mmgc_inst_debug_tiny_nursery);
	OP_INT_GE(l_v4035, 0L, l_v4036);
	if (l_v4036) {
		goto block5;
	}
	l_v4095 = l_result_12;
	goto block4;

    block4:
	RPY_DEBUG_RETURN();
	return l_v4095;

    block5:
	l_v4037 = RPyField(l_self_85, mmgc_inst_nursery_top);
	l_v4038 = RPyField(l_self_85, mmgc_inst_nursery_free);
	OP_ADR_DELTA(l_v4037, l_v4038, l_v4039);
	l_v4040 = RPyField(l_self_85, mmgc_inst_debug_tiny_nursery);
	OP_INT_GT(l_v4039, l_v4040, l_v4041);
	if (l_v4041) {
		goto block6;
	}
	l_v4095 = l_result_12;
	goto block4;

    block6:
	l_v4042 = RPyField(l_self_85, mmgc_inst_nursery_top);
	l_v4043 = RPyField(l_self_85, mmgc_inst_debug_tiny_nursery);
	OP_ADR_SUB(l_v4042, l_v4043, l_v4044);
	RPyField(l_self_85, mmgc_inst_nursery_free) = l_v4044;
	l_v4095 = l_result_12;
	goto block4;

    block7:
	pypy_g_MiniMarkGC_major_collection(l_self_85, 0L);
	l_v4047 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4048 = (l_v4047 == NULL);
	if (!l_v4048) {
		goto block17;
	}
	goto block8;

    block8:
	l_v4049 = RPyField(l_self_85, mmgc_inst_nursery_free);
	OP_ADR_ADD(l_v4049, l_totalsize_14, l_v4050);
	l_v4051 = RPyField(l_self_85, mmgc_inst_nursery_top);
	OP_ADR_GT(l_v4050, l_v4051, l_v4052);
	if (l_v4052) {
		goto block9;
	}
	goto block3;

    block9:
	l_v4053 = RPyField(l_self_85, mmgc_inst_nursery_free);
	OP_ADR_ADD(l_v4053, l_totalsize_14, l_v4054);
	l_v4055 = RPyField(l_self_85, mmgc_inst_nursery_real_top);
	OP_ADR_GT(l_v4054, l_v4055, l_v4056);
	if (l_v4056) {
		goto block15;
	}
	goto block10;

    block10:
	l_v4015 = RPyField(l_self_85, mmgc_inst_nursery_cleanup);
	l_v4057 = RPyField(l_self_85, mmgc_inst_nursery_real_top);
	l_v4014 = RPyField(l_self_85, mmgc_inst_nursery_top);
	OP_ADR_DELTA(l_v4057, l_v4014, l_v4058);
	OP_INT_GE(l_v4058, l_v4015, l_v4059);
	RPyAssert(l_v4059, "nursery_cleanup not a divisor of nursery_size - initial_cleanup");
	OP_RAW_MALLOC_USAGE(l_totalsize_14, l_v4061);
	OP_INT_LE(l_v4061, l_v4015, l_v4062);
	RPyAssert(l_v4062, "totalsize > nursery_cleanup");
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v4064);
	if (l_v4064) {
		goto block13;
	}
	goto block11;

    block11:
	OP_RAW_MEMCLEAR(l_v4014, l_v4015, /* nothing */);
	goto block12;

    block12:
	l_v4066 = RPyField(l_self_85, mmgc_inst_nursery_top);
	OP_ADR_ADD(l_v4066, l_v4015, l_v4067);
	RPyField(l_self_85, mmgc_inst_nursery_top) = l_v4067;
	goto block3;

    block13:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v4070 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4071 = (l_v4070 == NULL);
	if (!l_v4071) {
		goto block14;
	}
	goto block12;

    block14:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_collect_and_reserve");
	l_v4095 = NULL;
	goto block4;

    block15:
	pypy_g_MiniMarkGC_minor_collection(l_self_85);
	l_v4074 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4075 = (l_v4074 == NULL);
	if (!l_v4075) {
		goto block16;
	}
	goto block3;

    block16:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_collect_and_reserve");
	l_v4095 = NULL;
	goto block4;

    block17:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_collect_and_reserve");
	l_v4095 = NULL;
	goto block4;

    block18:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_collect_and_reserve");
	l_v4095 = NULL;
	goto block4;

    block19:
	l_v4013 = RPyField(l_self_85, mmgc_inst_nursery_cleanup);
	l_v4079 = RPyField(l_self_85, mmgc_inst_nursery_real_top);
	l_v4016 = RPyField(l_self_85, mmgc_inst_nursery_top);
	OP_ADR_DELTA(l_v4079, l_v4016, l_v4080);
	OP_INT_GE(l_v4080, l_v4013, l_v4081);
	RPyAssert(l_v4081, "nursery_cleanup not a divisor of nursery_size - initial_cleanup");
	OP_RAW_MALLOC_USAGE(l_totalsize_14, l_v4083);
	OP_INT_LE(l_v4083, l_v4013, l_v4084);
	RPyAssert(l_v4084, "totalsize > nursery_cleanup");
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v4086);
	if (l_v4086) {
		goto block22;
	}
	goto block20;

    block20:
	OP_RAW_MEMCLEAR(l_v4016, l_v4013, /* nothing */);
	goto block21;

    block21:
	l_v4088 = RPyField(l_self_85, mmgc_inst_nursery_top);
	OP_ADR_ADD(l_v4088, l_v4013, l_v4089);
	RPyField(l_self_85, mmgc_inst_nursery_top) = l_v4089;
	l_v4095 = l_prev_result_1;
	goto block4;

    block22:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v4092 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4093 = (l_v4092 == NULL);
	if (!l_v4093) {
		goto block23;
	}
	goto block21;

    block23:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_collect_and_reserve");
	l_v4095 = NULL;
	goto block4;
}
/*/*/
void* pypy_g_MiniMarkGC_external_malloc(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_86, unsigned short l_typeid_13, Signed l_length_36, bool_t l_can_make_young_1) {
	void* l_addr_6; Signed l_allocsize_0; void* l_arena_0;
	bool_t l_can_make_young_2; Signed l_cardheadersize_0;
	Signed l_extra_flags_0; Signed l_extra_flags_1; Signed l_i_15;
	Signed l_nonvarsize_1; void* l_result_13;
	struct pypy_rpython_memory_support_AddressStack0 *l_self_87;
	Signed l_totalsize_15; Signed l_used_15; Signed l_v4096;
	Signed l_v4097; Signed l_v4102; Signed l_v4104; Signed l_v4108;
	Signed l_v4109; Signed l_v4112; Signed l_v4119; Signed l_v4120;
	Signed l_v4125; Signed l_v4132; Signed l_v4137; Signed l_v4140;
	Signed l_v4141; Signed l_v4144; Signed l_v4146; Signed l_v4147;
	Signed l_v4150; Signed l_v4151; Signed l_v4163; Signed l_v4168;
	Signed l_v4170; Signed l_v4172; Signed l_v4175; Signed l_v4176;
	Signed l_v4179; Signed l_v4184; Signed l_v4185; Signed l_v4188;
	Signed l_v4213; Signed l_v4223; Signed l_v4229; Signed l_v4234;
	Signed l_v4235; Signed l_v4237; Signed l_v4238; Signed l_v4245;
	Signed l_v4252; Signed l_v4273; Unsigned l_v4128; Unsigned l_v4129;
	Unsigned l_v4130; Unsigned l_v4159; Unsigned l_v4160;
	Unsigned l_v4161; Unsigned l_v4231; Unsigned l_v4232;
	Unsigned l_v4233; bool_t l_v4105; bool_t l_v4110; bool_t l_v4113;
	bool_t l_v4114; bool_t l_v4121; bool_t l_v4124; bool_t l_v4127;
	bool_t l_v4136; bool_t l_v4138; bool_t l_v4142; bool_t l_v4145;
	bool_t l_v4148; bool_t l_v4149; bool_t l_v4152; bool_t l_v4153;
	bool_t l_v4154; bool_t l_v4157; bool_t l_v4158; bool_t l_v4164;
	bool_t l_v4177; bool_t l_v4180; bool_t l_v4186; bool_t l_v4194;
	bool_t l_v4197; bool_t l_v4199; bool_t l_v4205; bool_t l_v4210;
	bool_t l_v4212; bool_t l_v4216; bool_t l_v4221; bool_t l_v4225;
	bool_t l_v4230; bool_t l_v4236; bool_t l_v4239; bool_t l_v4242;
	bool_t l_v4247; bool_t l_v4251; bool_t l_v4255; double l_v4131;
	double l_v4133; double l_v4134; double l_v4135;
	struct pypy_AddressChunk0 *l_v4165; struct pypy_DICT0 *l_v4100;
	struct pypy_DICT0 *l_v4196; struct pypy_DICT0 *l_v4201;
	struct pypy_header0 *l_v4171; struct pypy_object0 *l_v4258;
	struct pypy_object0 *l_v4265; struct pypy_object_vtable0 *l_v4123;
	struct pypy_object_vtable0 *l_v4126;
	struct pypy_object_vtable0 *l_v4193;
	struct pypy_object_vtable0 *l_v4198;
	struct pypy_object_vtable0 *l_v4204;
	struct pypy_object_vtable0 *l_v4209;
	struct pypy_object_vtable0 *l_v4215;
	struct pypy_object_vtable0 *l_v4220;
	struct pypy_object_vtable0 *l_v4224;
	struct pypy_object_vtable0 *l_v4241;
	struct pypy_object_vtable0 *l_v4246;
	struct pypy_object_vtable0 *l_v4250;
	struct pypy_object_vtable0 *l_v4254;
	struct pypy_object_vtable0 *l_v4259;
	struct pypy_object_vtable0 *l_v4266; struct pypy_type_info0 *l_v4107;
	struct pypy_type_info0 *l_v4118; struct pypy_type_info0 *l_v4139;
	struct pypy_type_info0 *l_v4174; struct pypy_type_info0 *l_v4183;
	struct pypy_varsize_type_info0 *l_v4117;
	struct pypy_varsize_type_info0 *l_v4182; void* *l_v4166;
	void* l_v4098; void* l_v4099; void* l_v4101; void* l_v4103;
	void* l_v4181; void* l_v4189; void* l_v4190; void* l_v4202;
	void* l_v4219; void* l_v4272;
	goto block0;

    block0:
	OP_COMBINE_USHORT(l_typeid_13, 0L, l_v4104);
	OP_INT_IS_TRUE(l_v4104, l_v4105);
	RPyAssert(l_v4105, "external_malloc: typeid == 0");
	l_v4107 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_13);
	l_v4108 = RPyField(l_v4107, ti_infobits);
	OP_INT_AND(l_v4108, -16777216L, l_v4109);
	OP_INT_EQ(l_v4109, 1509949440L, l_v4110);
	RPyAssert(l_v4110, "invalid type_id");
	l_v4112 = RPyField(l_v4107, ti_fixedsize);
	OP_INT_ADD(0, l_v4112, l_nonvarsize_1);
	OP_INT_EQ(l_length_36, 0L, l_v4113);
	if (l_v4113) {
		l_totalsize_15 = l_nonvarsize_1;
		goto block6;
	}
	goto block1;

    block1:
	OP_INT_GT(l_length_36, 0L, l_v4114);
	if (l_v4114) {
		goto block4;
	}
	goto block2;

    block2:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_external_malloc");
	l_v4272 = NULL;
	goto block3;

    block3:
	RPY_DEBUG_RETURN();
	return l_v4272;

    block4:
	l_v4117 = (struct pypy_varsize_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_13);
	l_v4118 = (struct pypy_type_info0 *)l_v4117;
	l_v4119 = RPyField(l_v4118, ti_infobits);
	OP_INT_AND(l_v4119, -16711680L, l_v4120);
	OP_INT_EQ(l_v4120, 1510014976L, l_v4121);
	RPyAssert(l_v4121, "invalid varsize type_id");
	l_v4097 = RPyField(l_v4117, vti_varitemsize);
	OP_INT_MUL_OVF(l_v4097, l_length_36, l_v4096);
	l_v4123 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4124 = (l_v4123 == NULL);
	if (!l_v4124) {
		goto block58;
	}
	goto block5;

    block5:
	OP_INT_ADD_OVF(l_nonvarsize_1, l_v4096, l_v4125);
	l_v4126 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4127 = (l_v4126 == NULL);
	if (!l_v4127) {
		goto block57;
	}
	l_totalsize_15 = l_v4125;
	goto block6;

    block6:
	l_v4128 = (&pypy_g_rpython_memory_gc_minimarkpage_ArenaCollection)->ac_inst_total_memory_used;
	l_v4129 = RPyField(l_self_86, mmgc_inst_rawmalloced_total_size);
	OP_UINT_ADD(l_v4128, l_v4129, l_v4130);
	OP_CAST_UINT_TO_FLOAT(l_v4130, l_v4131);
	OP_RAW_MALLOC_USAGE(l_totalsize_15, l_v4132);
	OP_CAST_INT_TO_FLOAT(l_v4132, l_v4133);
	OP_FLOAT_ADD(l_v4131, l_v4133, l_v4134);
	l_v4135 = RPyField(l_self_86, mmgc_inst_next_major_collection_threshold);
	OP_FLOAT_GT(l_v4134, l_v4135, l_v4136);
	if (l_v4136) {
		goto block53;
	}
	goto block7;

    block7:
	OP_RAW_MALLOC_USAGE(l_totalsize_15, l_v4137);
	OP_INT_LE(l_v4137, 140L, l_v4138);
	if (l_v4138) {
		goto block46;
	}
	goto block8;

    block8:
	l_v4139 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_13);
	l_v4140 = RPyField(l_v4139, ti_infobits);
	OP_INT_AND(l_v4140, -16777216L, l_v4141);
	OP_INT_EQ(l_v4141, 1509949440L, l_v4142);
	RPyAssert(l_v4142, "invalid type_id");
	OP_INT_AND(l_v4140, 131072L, l_v4144);
	OP_INT_NE(l_v4144, 0L, l_v4145);
	if (l_v4145) {
		goto block44;
	}
	l_can_make_young_2 = l_can_make_young_1;
	l_extra_flags_0 = 0L;
	l_cardheadersize_0 = 0L;
	goto block9;

    block9:
	OP_RAW_MALLOC_USAGE(l_totalsize_15, l_v4146);
	OP_INT_SUB(2147483644L, l_cardheadersize_0, l_v4147);
	OP_INT_GT(l_v4146, l_v4147, l_v4148);
	if (l_v4148) {
		goto block43;
	}
	goto block10;

    block10:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v4149);
	if (l_v4149) {
		goto block41;
	}
	goto block11;

    block11:
	l_v4150 = ROUND_UP_FOR_ALLOCATION(l_totalsize_15, 0L);
	l_v4273 = l_v4150;
	goto block12;

    block12:
	OP_RAW_MALLOC_USAGE(l_v4273, l_v4151);
	OP_INT_ADD(l_cardheadersize_0, l_v4151, l_allocsize_0);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v4152);
	if (l_v4152) {
		goto block39;
	}
	goto block13;

    block13:
	l_v4103 = malloc(l_allocsize_0);
	OP_ADR_NE(l_v4103, NULL, l_v4153);
	if (l_v4153) {
		goto block38;
	}
	l_arena_0 = l_v4103;
	goto block14;

    block14:
	OP_ADR_NE(l_arena_0, NULL, l_v4154);
	if (l_v4154) {
		l_i_15 = 0L;
		goto block16;
	}
	goto block15;

    block15:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_external_malloc");
	l_v4272 = NULL;
	goto block3;

    block16:
	while (1) {
		OP_INT_LT(l_i_15, l_cardheadersize_0, l_v4157);
		if (!l_v4157) break;
		goto block34;
	  block16_back: ;
	}
	goto block17;

    block17:
	OP_ADR_ADD(l_arena_0, l_cardheadersize_0, l_v4098);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v4158);
	if (l_v4158) {
		goto block32;
	}
	goto block18;

    block18:
	l_v4159 = RPyField(l_self_86, mmgc_inst_rawmalloced_total_size);
	OP_CAST_INT_TO_UINT(l_allocsize_0, l_v4160);
	OP_UINT_ADD(l_v4159, l_v4160, l_v4161);
	RPyField(l_self_86, mmgc_inst_rawmalloced_total_size) = l_v4161;
	if (l_can_make_young_2) {
		goto block26;
	}
	goto block19;

    block19:
	l_self_87 = RPyField(l_self_86, mmgc_inst_old_rawmalloced_objects);
	OP_ADR_ADD(l_v4098, 0, l_addr_6);
	l_v4163 = RPyField(l_self_87, as_inst_used_in_last_chunk);
	OP_INT_EQ(l_v4163, 1019L, l_v4164);
	if (l_v4164) {
		goto block24;
	}
	l_used_15 = l_v4163;
	goto block20;

    block20:
	l_v4165 = RPyField(l_self_87, as_inst_chunk);
	l_v4166 = RPyField(l_v4165, ac_items);
	RPyFxItem(l_v4166, l_used_15, 1019) = l_addr_6;
	OP_INT_ADD(l_used_15, 1L, l_v4168);
	RPyField(l_self_87, as_inst_used_in_last_chunk) = l_v4168;
	OP_INT_OR(l_extra_flags_0, 65536L, l_v4170);
	l_extra_flags_1 = l_v4170;
	l_result_13 = l_v4098;
	goto block21;

    block21:
	l_v4171 = (struct pypy_header0 *)l_result_13;
	OP_COMBINE_USHORT(l_typeid_13, l_extra_flags_1, l_v4172);
	RPyField(l_v4171, h_tid) = l_v4172;
	l_v4174 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_13);
	l_v4175 = RPyField(l_v4174, ti_infobits);
	OP_INT_AND(l_v4175, -16777216L, l_v4176);
	OP_INT_EQ(l_v4176, 1509949440L, l_v4177);
	RPyAssert(l_v4177, "invalid type_id");
	OP_INT_AND(l_v4175, 65536L, l_v4179);
	OP_INT_NE(l_v4179, 0L, l_v4180);
	if (l_v4180) {
		goto block23;
	}
	goto block22;

    block22:
	OP_ADR_ADD(l_result_13, 0, l_v4181);
	l_v4272 = l_v4181;
	goto block3;

    block23:
	l_v4182 = (struct pypy_varsize_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_typeid_13);
	l_v4183 = (struct pypy_type_info0 *)l_v4182;
	l_v4184 = RPyField(l_v4183, ti_infobits);
	OP_INT_AND(l_v4184, -16711680L, l_v4185);
	OP_INT_EQ(l_v4185, 1510014976L, l_v4186);
	RPyAssert(l_v4186, "invalid varsize type_id");
	l_v4188 = RPyField(l_v4182, vti_ofstolength);
	OP_ADR_ADD(l_result_13, 0, l_v4189);
	OP_ADR_ADD(l_v4189, l_v4188, l_v4190);
	((Signed *) (((char *)l_v4190) + 0))[0] = l_length_36;
	goto block22;

    block24:
	pypy_g_AddressStack_enlarge(l_self_87);
	l_v4193 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4194 = (l_v4193 == NULL);
	if (!l_v4194) {
		goto block25;
	}
	l_used_15 = 0L;
	goto block20;

    block25:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_external_malloc");
	l_v4272 = NULL;
	goto block3;

    block26:
	l_v4196 = RPyField(l_self_86, mmgc_inst_young_rawmalloced_objects);
	l_v4197 = (l_v4196 != NULL);
	if (l_v4197) {
		goto block29;
	}
	goto block27;

    block27:
	l_v4100 = pypy_g_ll_newdict_size__Struct_DICTLlT_Signed(0L);
	l_v4198 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4199 = (l_v4198 == NULL);
	if (!l_v4199) {
		goto block31;
	}
	goto block28;

    block28:
	RPyField(l_self_86, mmgc_inst_young_rawmalloced_objects) = l_v4100;
	goto block29;

    block29:
	l_v4201 = RPyField(l_self_86, mmgc_inst_young_rawmalloced_objects);
	OP_ADR_ADD(l_v4098, 0, l_v4202);
	pypy_g_ll_dict_setitem__DICTPtr_Address_Address(l_v4201, l_v4202, NULL);
	l_v4204 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4205 = (l_v4204 == NULL);
	if (!l_v4205) {
		goto block30;
	}
	l_extra_flags_1 = l_extra_flags_0;
	l_result_13 = l_v4098;
	goto block21;

    block30:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_external_malloc");
	l_v4272 = NULL;
	goto block3;

    block31:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_external_malloc");
	l_v4272 = NULL;
	goto block3;

    block32:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v4209 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4210 = (l_v4209 == NULL);
	if (!l_v4210) {
		goto block33;
	}
	goto block18;

    block33:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_external_malloc");
	l_v4272 = NULL;
	goto block3;

    block34:
	OP_ADR_ADD(l_arena_0, l_i_15, l_v4101);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v4212);
	if (l_v4212) {
		goto block36;
	}
	goto block35;

    block35:
	OP_INT_ADD(l_i_15, 1L, l_v4213);
	l_i_15 = l_v4213;
	goto block16_back;

    block36:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v4215 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4216 = (l_v4215 == NULL);
	if (!l_v4216) {
		goto block37;
	}
	goto block35;

    block37:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_external_malloc");
	l_v4272 = NULL;
	goto block3;

    block38:
	OP_RAW_MEMCLEAR(l_v4103, l_allocsize_0, /* nothing */);
	l_arena_0 = l_v4103;
	goto block14;

    block39:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v4219 = (void*)0;
	l_v4220 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4221 = (l_v4220 == NULL);
	if (!l_v4221) {
		goto block40;
	}
	l_arena_0 = l_v4219;
	goto block14;

    block40:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_external_malloc");
	l_v4272 = NULL;
	goto block3;

    block41:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v4223 = (Signed)0;
	l_v4224 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4225 = (l_v4224 == NULL);
	if (!l_v4225) {
		goto block42;
	}
	l_v4273 = l_v4223;
	goto block12;

    block42:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_external_malloc");
	l_v4272 = NULL;
	goto block3;

    block43:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_external_malloc");
	l_v4272 = NULL;
	goto block3;

    block44:
	OP_RAW_MALLOC_USAGE(l_totalsize_15, l_v4229);
	OP_INT_LE(l_v4229, 67583L, l_v4230);
	if (l_v4230) {
		l_can_make_young_2 = l_can_make_young_1;
		l_extra_flags_0 = 0L;
		l_cardheadersize_0 = 0L;
		goto block9;
	}
	goto block45;

    block45:
	OP_CAST_INT_TO_UINT(l_length_36, l_v4231);
	OP_UINT_ADD(l_v4231, 4095UL, l_v4232);
	OP_UINT_RSHIFT(l_v4232, 12L, l_v4233);
	OP_CAST_UINT_TO_INT(l_v4233, l_v4234);
	OP_INT_MUL(4L, l_v4234, l_v4235);
	if (l_can_make_young_1) {
		l_can_make_young_2 = 1;
		l_extra_flags_0 = 12648448L;
		l_cardheadersize_0 = l_v4235;
		goto block9;
	}
	l_can_make_young_2 = 0;
	l_extra_flags_0 = 4259840L;
	l_cardheadersize_0 = l_v4235;
	goto block9;

    block46:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v4236);
	if (l_v4236) {
		goto block51;
	}
	goto block47;

    block47:
	l_v4237 = ROUND_UP_FOR_ALLOCATION(l_totalsize_15, 0L);
	l_v4102 = l_v4237;
	goto block48;

    block48:
	OP_RAW_MALLOC_USAGE(l_v4102, l_v4238);
	OP_INT_LE(l_v4238, 140L, l_v4239);
	RPyAssert(l_v4239, "rounding up made totalsize > small_request_threshold");
	l_v4099 = pypy_g_ArenaCollection_malloc((&pypy_g_rpython_memory_gc_minimarkpage_ArenaCollection), l_v4102);
	l_v4241 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4242 = (l_v4241 == NULL);
	if (!l_v4242) {
		goto block50;
	}
	goto block49;

    block49:
	OP_RAW_MEMCLEAR(l_v4099, l_v4102, /* nothing */);
	l_extra_flags_1 = 65536L;
	l_result_13 = l_v4099;
	goto block21;

    block50:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_external_malloc");
	l_v4272 = NULL;
	goto block3;

    block51:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v4245 = (Signed)0;
	l_v4246 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4247 = (l_v4246 == NULL);
	if (!l_v4247) {
		goto block52;
	}
	l_v4102 = l_v4245;
	goto block48;

    block52:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_external_malloc");
	l_v4272 = NULL;
	goto block3;

    block53:
	pypy_g_MiniMarkGC_minor_collection(l_self_86);
	l_v4250 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4251 = (l_v4250 == NULL);
	if (!l_v4251) {
		goto block56;
	}
	goto block54;

    block54:
	OP_RAW_MALLOC_USAGE(l_totalsize_15, l_v4252);
	pypy_g_MiniMarkGC_major_collection(l_self_86, l_v4252);
	l_v4254 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4255 = (l_v4254 == NULL);
	if (!l_v4255) {
		goto block55;
	}
	goto block7;

    block55:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_external_malloc");
	l_v4272 = NULL;
	goto block3;

    block56:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_external_malloc");
	l_v4272 = NULL;
	goto block3;

    block57:
	l_v4258 = (&pypy_g_ExcData)->ed_exc_value;
	l_v4259 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("MiniMarkGC_external_malloc", l_v4259, l_v4259 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_v4259 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_external_malloc");
	l_v4272 = NULL;
	goto block3;

    block58:
	l_v4265 = (&pypy_g_ExcData)->ed_exc_value;
	l_v4266 = (&pypy_g_ExcData)->ed_exc_type;
	PYPY_DEBUG_CATCH_EXCEPTION("MiniMarkGC_external_malloc", l_v4266, l_v4266 == (&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super) || l_v4266 == (&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super));
	(&pypy_g_ExcData)->ed_exc_value = ((struct pypy_object0 *) NULL);
	(&pypy_g_ExcData)->ed_exc_type = ((struct pypy_object_vtable0 *) NULL);
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_external_malloc");
	l_v4272 = NULL;
	goto block3;
}
/*/*/
bool_t pypy_g_MiniMarkGC_set_major_threshold_from(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_88, double l_threshold_0, Signed l_v4274) {
	bool_t l_bounded_0; double l_threshold_1; double l_threshold_2;
	bool_t l_v4278; bool_t l_v4282; bool_t l_v4284; bool_t l_v4288;
	double l_v4275; double l_v4276; double l_v4277; double l_v4279;
	double l_v4280; double l_v4281; double l_v4283; double l_v4287;
	double l_v4289; double l_v4290; double l_v4291;
	goto block0;

    block0:
	l_v4275 = RPyField(l_self_88, mmgc_inst_next_major_collection_initial);
	l_v4276 = RPyField(l_self_88, mmgc_inst_growth_rate_max);
	OP_FLOAT_MUL(l_v4275, l_v4276, l_v4277);
	OP_FLOAT_GT(l_threshold_0, l_v4277, l_v4278);
	if (l_v4278) {
		l_v4291 = l_v4277;
		goto block1;
	}
	l_v4291 = l_threshold_0;
	goto block1;

    block1:
	OP_CAST_INT_TO_FLOAT(l_v4274, l_v4279);
	OP_FLOAT_ADD(l_v4291, l_v4279, l_v4280);
	l_v4281 = RPyField(l_self_88, mmgc_inst_min_heap_size);
	OP_FLOAT_LT(l_v4280, l_v4281, l_v4282);
	if (l_v4282) {
		goto block7;
	}
	l_threshold_1 = l_v4280;
	goto block2;

    block2:
	l_v4283 = RPyField(l_self_88, mmgc_inst_max_heap_size);
	OP_FLOAT_GT(l_v4283, 0.0, l_v4284);
	if (l_v4284) {
		goto block5;
	}
	l_bounded_0 = 0;
	l_threshold_2 = l_threshold_1;
	goto block3;

    block3:
	RPyField(l_self_88, mmgc_inst_next_major_collection_initial) = l_threshold_2;
	RPyField(l_self_88, mmgc_inst_next_major_collection_threshold) = l_threshold_2;
	goto block4;

    block4:
	RPY_DEBUG_RETURN();
	return l_bounded_0;

    block5:
	l_v4287 = RPyField(l_self_88, mmgc_inst_max_heap_size);
	OP_FLOAT_GT(l_threshold_1, l_v4287, l_v4288);
	if (l_v4288) {
		goto block6;
	}
	l_bounded_0 = 0;
	l_threshold_2 = l_threshold_1;
	goto block3;

    block6:
	l_v4289 = RPyField(l_self_88, mmgc_inst_max_heap_size);
	l_bounded_0 = 1;
	l_threshold_2 = l_v4289;
	goto block3;

    block7:
	l_v4290 = RPyField(l_self_88, mmgc_inst_min_heap_size);
	l_threshold_1 = l_v4290;
	goto block2;
}
/*/*/
void pypy_g_MiniMarkGC__trace_drag_out1(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_11, void* l_root_0) {
	void* l_addr_7; void* l_newhdr_6; Signed l_totalsize_16;
	Signed l_totalsize_17; Signed l_used_16; Signed l_v4295;
	Signed l_v4298; Signed l_v4300; Signed l_v4301; Signed l_v4302;
	Signed l_v4303; Signed l_v4310; Signed l_v4311; Signed l_v4322;
	Signed l_v4323; Signed l_v4325; Signed l_v4326; Signed l_v4339;
	Signed l_v4343; Signed l_v4352; Signed l_v4353; Signed l_v4357;
	Signed l_v4361; Signed l_v4373; Signed l_v4378; Signed l_v4404;
	Signed l_v4408; Unsigned l_v4313; Unsigned l_v4314; Unsigned l_v4317;
	Unsigned l_v4420; bool_t l_v4304; bool_t l_v4307; bool_t l_v4309;
	bool_t l_v4312; bool_t l_v4315; bool_t l_v4319; bool_t l_v4324;
	bool_t l_v4327; bool_t l_v4330; bool_t l_v4334; bool_t l_v4340;
	bool_t l_v4341; bool_t l_v4344; bool_t l_v4348; bool_t l_v4360;
	bool_t l_v4364; bool_t l_v4365; bool_t l_v4366; bool_t l_v4374;
	bool_t l_v4382; bool_t l_v4386; bool_t l_v4390; bool_t l_v4394;
	bool_t l_v4397; bool_t l_v4407; bool_t l_v4409; bool_t l_v4412;
	bool_t l_v4416; struct pypy_AddressChunk0 *l_v4375;
	struct pypy_DICT0 *l_v4294; struct pypy_DICT0 *l_v4308;
	struct pypy_DICT0 *l_v4346; struct pypy_forwarding_stub0 *l_v4370;
	struct pypy_forwarding_stub0 *l_v4399; struct pypy_header0 *l_v4321;
	struct pypy_header0 *l_v4338; struct pypy_header0 *l_v4351;
	struct pypy_header0 *l_v4356; struct pypy_header0 *l_v4368;
	struct pypy_header0 *l_v4403; struct pypy_object_vtable0 *l_v4359;
	struct pypy_object_vtable0 *l_v4381;
	struct pypy_object_vtable0 *l_v4385;
	struct pypy_object_vtable0 *l_v4389;
	struct pypy_object_vtable0 *l_v4393;
	struct pypy_object_vtable0 *l_v4406;
	struct pypy_object_vtable0 *l_v4411;
	struct pypy_object_vtable0 *l_v4415; unsigned short l_v4358;
	unsigned short l_v4405; void* *l_v4376; void* l_v4292; void* l_v4293;
	void* l_v4296; void* l_v4297; void* l_v4299; void* l_v4306;
	void* l_v4318; void* l_v4320; void* l_v4329; void* l_v4333;
	void* l_v4337; void* l_v4347; void* l_v4350; void* l_v4355;
	void* l_v4362; void* l_v4367; void* l_v4392; void* l_v4400;
	void* l_v4402; void* l_v4410; void* l_v4414;
	goto block0;

    block0:
	l_v4292 = ((void* *) (((char *)l_root_0) + 0))[0];
	OP_CAST_ADR_TO_INT(l_v4292, /* nothing */, l_v4302);
	OP_INT_AND(l_v4302, 1L, l_v4303);
	OP_INT_EQ(l_v4303, 0L, l_v4304);
	RPyAssert(l_v4304, "odd-valued (i.e. tagged) pointer unexpected here");
	l_v4306 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery;
	OP_ADR_LE(l_v4306, l_v4292, l_v4307);
	if (l_v4307) {
		goto block8;
	}
	goto block1;

    block1:
	l_v4308 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_young_rawmalloced_objects;
	l_v4309 = (l_v4308 != NULL);
	if (l_v4309) {
		goto block3;
	}
	goto block2;

    block2:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block3:
	l_v4294 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_young_rawmalloced_objects;
	OP_CAST_ADR_TO_INT(l_v4292, /* nothing */, l_v4310);
	OP_INT_RSHIFT(l_v4310, 4L, l_v4311);
	OP_INT_XOR(l_v4310, l_v4311, l_v4295);
	OP_INT_IS_TRUE(0 /* we are not jitted here */, l_v4312);
	if (l_v4312) {
		goto block7;
	}
	goto block4;

    block4:
	l_v4313 = pypy_g_ll_dict_lookup__v51___simple_call__function_ll(l_v4294, l_v4292, l_v4295);
	l_v4420 = l_v4313;
	goto block5;

    block5:
	OP_UINT_AND(l_v4420, 2147483648UL, l_v4314);
	OP_UINT_IS_TRUE(l_v4314, l_v4315);
	if (l_v4315) {
		goto block2;
	}
	goto block6;

    block6:
	pypy_g_MiniMarkGC__visit_young_rawmalloced_object((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_v4292);
	goto block2;

    block7:
	l_v4317 = pypy_g_ll_dict_lookup__v60___simple_call__function_ll(l_v4294, l_v4292, l_v4295);
	l_v4420 = l_v4317;
	goto block5;

    block8:
	l_v4318 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_real_top;
	OP_ADR_LT(l_v4292, l_v4318, l_v4319);
	if (l_v4319) {
		goto block9;
	}
	goto block1;

    block9:
	OP_ADR_SUB(l_v4292, 0, l_v4320);
	l_v4321 = (struct pypy_header0 *)l_v4320;
	l_v4322 = RPyField(l_v4321, h_tid);
	OP_INT_AND(l_v4322, 524288L, l_v4323);
	OP_INT_EQ(l_v4323, 0L, l_v4324);
	if (l_v4324) {
		goto block32;
	}
	goto block10;

    block10:
	OP_CAST_ADR_TO_INT(l_v4292, /* nothing */, l_v4325);
	OP_INT_AND(l_v4325, 1L, l_v4326);
	OP_INT_EQ(l_v4326, 0L, l_v4327);
	RPyAssert(l_v4327, "odd-valued (i.e. tagged) pointer unexpected here");
	l_v4329 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery;
	OP_ADR_LE(l_v4329, l_v4292, l_v4330);
	if (l_v4330) {
		goto block12;
	}
	goto block11;

    block11:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC__trace_drag_out1");
	goto block2;

    block12:
	l_v4333 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_real_top;
	OP_ADR_LT(l_v4292, l_v4333, l_v4334);
	if (l_v4334) {
		goto block14;
	}
	goto block13;

    block13:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC__trace_drag_out1");
	goto block2;

    block14:
	OP_ADR_SUB(l_v4292, 0, l_v4337);
	l_v4338 = (struct pypy_header0 *)l_v4337;
	l_v4300 = RPyField(l_v4338, h_tid);
	OP_INT_AND(l_v4300, 1048576L, l_v4339);
	OP_INT_NE(l_v4339, 0L, l_v4340);
	if (l_v4340) {
		goto block31;
	}
	goto block15;

    block15:
	OP_INT_IS_TRUE(l_v4300, l_v4341);
	RPyAssert(l_v4341, "bogus header (1)");
	OP_INT_AND(l_v4300, -16777216L, l_v4343);
	OP_INT_EQ(l_v4343, 0L, l_v4344);
	RPyAssert(l_v4344, "bogus header (2)");
	l_v4346 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_objects_shadows;
	l_v4347 = pypy_g_ll_get__DICTPtr_Address_Address(l_v4346, l_v4292, NULL);
	OP_ADR_NE(l_v4347, NULL, l_v4348);
	RPyAssert(l_v4348, "GCFLAG_HAS_SHADOW but no shadow found");
	OP_ADR_SUB(l_v4347, 0, l_v4299);
	OP_ADR_SUB(l_v4292, 0, l_v4350);
	l_v4351 = (struct pypy_header0 *)l_v4350;
	l_v4352 = RPyField(l_v4351, h_tid);
	OP_INT_AND(l_v4352, -524289L, l_v4353);
	RPyField(l_v4351, h_tid) = l_v4353;
	OP_ADR_SUB(l_v4292, 0, l_v4355);
	l_v4356 = (struct pypy_header0 *)l_v4355;
	l_v4357 = RPyField(l_v4356, h_tid);
	OP_EXTRACT_USHORT(l_v4357, l_v4358);
	l_v4301 = pypy_g_GCBase__get_size_for_typeid((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_v4292, l_v4358);
	l_v4359 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4360 = (l_v4359 == NULL);
	if (!l_v4360) {
		goto block30;
	}
	goto block16;

    block16:
	OP_INT_ADD(0, l_v4301, l_v4361);
	l_totalsize_16 = l_v4361;
	l_newhdr_6 = l_v4299;
	goto block17;

    block17:
	OP_ADR_SUB(l_v4292, 0, l_v4362);
	OP_RAW_MEMCOPY(l_v4362, l_newhdr_6, l_totalsize_16, /* nothing */);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v4364);
	if (l_v4364) {
		goto block28;
	}
	l_v4296 = l_v4292;
	goto block18;

    block18:
	OP_ADR_SUB(l_v4296, 0, l_v4297);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v4365);
	if (l_v4365) {
		goto block26;
	}
	goto block19;

    block19:
	OP_ADR_SUB(l_v4296, 0, l_v4293);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v4366);
	if (l_v4366) {
		goto block24;
	}
	goto block20;

    block20:
	OP_ADR_SUB(l_v4296, 0, l_v4367);
	l_v4368 = (struct pypy_header0 *)l_v4367;
	RPyField(l_v4368, h_tid) = -42L;
	OP_ADR_ADD(l_newhdr_6, 0, l_addr_7);
	l_v4370 = (struct pypy_forwarding_stub0 *)l_v4296;
	RPyField(l_v4370, fs_forw) = l_addr_7;
	((void* *) (((char *)l_root_0) + 0))[0] = l_addr_7;
	l_v4373 = (&pypy_g_rpython_memory_support_AddressStack)->as_inst_used_in_last_chunk;
	OP_INT_EQ(l_v4373, 1019L, l_v4374);
	if (l_v4374) {
		goto block22;
	}
	l_used_16 = l_v4373;
	goto block21;

    block21:
	l_v4375 = (&pypy_g_rpython_memory_support_AddressStack)->as_inst_chunk;
	l_v4376 = RPyField(l_v4375, ac_items);
	RPyFxItem(l_v4376, l_used_16, 1019) = l_addr_7;
	OP_INT_ADD(l_used_16, 1L, l_v4378);
	(&pypy_g_rpython_memory_support_AddressStack)->as_inst_used_in_last_chunk = l_v4378;
	goto block2;

    block22:
	pypy_g_AddressStack_enlarge((&pypy_g_rpython_memory_support_AddressStack));
	l_v4381 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4382 = (l_v4381 == NULL);
	if (!l_v4382) {
		goto block23;
	}
	l_used_16 = 0L;
	goto block21;

    block23:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC__trace_drag_out1");
	goto block2;

    block24:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v4385 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4386 = (l_v4385 == NULL);
	if (!l_v4386) {
		goto block25;
	}
	goto block20;

    block25:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC__trace_drag_out1");
	goto block2;

    block26:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v4389 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4390 = (l_v4389 == NULL);
	if (!l_v4390) {
		goto block27;
	}
	goto block19;

    block27:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC__trace_drag_out1");
	goto block2;

    block28:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v4392 = (void*)0;
	l_v4393 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4394 = (l_v4393 == NULL);
	if (!l_v4394) {
		goto block29;
	}
	l_v4296 = l_v4392;
	goto block18;

    block29:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC__trace_drag_out1");
	goto block2;

    block30:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC__trace_drag_out1");
	goto block2;

    block31:
	OP_INT_EQ(l_v4300, -42L, l_v4397);
	RPyAssert(l_v4397, "bogus header for young obj");
	l_v4399 = (struct pypy_forwarding_stub0 *)l_v4292;
	l_v4400 = RPyField(l_v4399, fs_forw);
	((void* *) (((char *)l_root_0) + 0))[0] = l_v4400;
	goto block2;

    block32:
	OP_ADR_SUB(l_v4292, 0, l_v4402);
	l_v4403 = (struct pypy_header0 *)l_v4402;
	l_v4404 = RPyField(l_v4403, h_tid);
	OP_EXTRACT_USHORT(l_v4404, l_v4405);
	l_v4298 = pypy_g_GCBase__get_size_for_typeid((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_v4292, l_v4405);
	l_v4406 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4407 = (l_v4406 == NULL);
	if (!l_v4407) {
		goto block38;
	}
	goto block33;

    block33:
	OP_INT_ADD(0, l_v4298, l_totalsize_17);
	OP_RAW_MALLOC_USAGE(l_totalsize_17, l_v4408);
	OP_INT_LE(l_v4408, 140L, l_v4409);
	if (l_v4409) {
		goto block36;
	}
	goto block34;

    block34:
	l_v4410 = pypy_g_MiniMarkGC__malloc_out_of_nursery_nonsmall((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_totalsize_17);
	l_v4411 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4412 = (l_v4411 == NULL);
	if (!l_v4412) {
		goto block35;
	}
	l_totalsize_16 = l_totalsize_17;
	l_newhdr_6 = l_v4410;
	goto block17;

    block35:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC__trace_drag_out1");
	goto block2;

    block36:
	l_v4414 = pypy_g_ArenaCollection_malloc((&pypy_g_rpython_memory_gc_minimarkpage_ArenaCollection), l_totalsize_17);
	l_v4415 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4416 = (l_v4415 == NULL);
	if (!l_v4416) {
		goto block37;
	}
	l_totalsize_16 = l_totalsize_17;
	l_newhdr_6 = l_v4414;
	goto block17;

    block37:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC__trace_drag_out1");
	goto block2;

    block38:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC__trace_drag_out1");
	goto block2;
}
/*/*/
void pypy_g_MiniMarkGC_collect_cardrefs_to_nursery(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_89) {
	Signed l_bytes_0; Signed l_bytes_1; Signed l_bytes_2;
	Signed l_cardbyte_0; Signed l_interval_start_0;
	Signed l_interval_start_1; Signed l_interval_start_2;
	Signed l_interval_stop_0; Signed l_interval_stop_1;
	Signed l_length_37; Signed l_next_byte_start_0; void* l_obj_28;
	void* l_p_0; void* l_p_1; Signed l_v4421; Signed l_v4424;
	Signed l_v4426; Signed l_v4427; Signed l_v4436; Signed l_v4437;
	Signed l_v4442; Signed l_v4443; Signed l_v4447; Signed l_v4451;
	Signed l_v4452; Signed l_v4455; Signed l_v4463; Signed l_v4464;
	Signed l_v4468; Signed l_v4471; Signed l_v4473; Signed l_v4487;
	Unsigned l_v4457; Unsigned l_v4458; Unsigned l_v4459; bool_t l_v4425;
	bool_t l_v4428; bool_t l_v4433; bool_t l_v4438; bool_t l_v4453;
	bool_t l_v4460; bool_t l_v4465; bool_t l_v4466; bool_t l_v4470;
	bool_t l_v4472; bool_t l_v4474; bool_t l_v4475; bool_t l_v4479;
	bool_t l_v4481; bool_t l_v4483; bool_t l_v4484; bool_t l_v4490;
	bool_t l_v4494; bool_t l_v4498; char l_v4467;
	struct pypy_AddressChunk0 *l_v4430;
	struct pypy_AddressChunk0 *l_v4492;
	struct pypy_AddressChunk0 *l_v4493; struct pypy_header0 *l_v4435;
	struct pypy_header0 *l_v4441; struct pypy_header0 *l_v4446;
	struct pypy_header0 *l_v4462; struct pypy_object_vtable0 *l_v4478;
	struct pypy_object_vtable0 *l_v4489; struct pypy_type_info0 *l_v4450;
	struct pypy_varsize_type_info0 *l_v4449; unsigned short l_v4448;
	void* *l_v4431; void* l_v4422; void* l_v4423; void* l_v4434;
	void* l_v4440; void* l_v4445; void* l_v4456; void* l_v4461;
	void* l_v4485; void* l_v4488; void* l_v4497;
	goto block0;

    block0:
	goto block1;

    block1:
	while (1) {
		l_v4424 = (&pypy_g_rpython_memory_support_AddressStack_1)->as_inst_used_in_last_chunk;
		OP_INT_NE(l_v4424, 0L, l_v4425);
		if (!l_v4425) break;
		goto block3;
	  block1_back: ;
	}
	goto block2;

    block2:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block3:
	l_v4426 = (&pypy_g_rpython_memory_support_AddressStack_1)->as_inst_used_in_last_chunk;
	OP_INT_SUB(l_v4426, 1L, l_v4427);
	OP_INT_GE(l_v4427, 0L, l_v4428);
	RPyAssert(l_v4428, "pop on empty AddressStack");
	l_v4430 = (&pypy_g_rpython_memory_support_AddressStack_1)->as_inst_chunk;
	l_v4431 = RPyField(l_v4430, ac_items);
	l_obj_28 = RPyFxItem(l_v4431, l_v4427, 1019);
	(&pypy_g_rpython_memory_support_AddressStack_1)->as_inst_used_in_last_chunk = l_v4427;
	OP_INT_EQ(l_v4427, 0L, l_v4433);
	if (l_v4433) {
		goto block21;
	}
	goto block4;

    block4:
	OP_ADR_SUB(l_obj_28, 0, l_v4434);
	l_v4435 = (struct pypy_header0 *)l_v4434;
	l_v4436 = RPyField(l_v4435, h_tid);
	OP_INT_AND(l_v4436, 8388608L, l_v4437);
	OP_INT_NE(l_v4437, 0L, l_v4438);
	RPyAssert(l_v4438, "!GCFLAG_CARDS_SET but object in 'old_objects_with_cards_set'");
	OP_ADR_SUB(l_obj_28, 0, l_v4440);
	l_v4441 = (struct pypy_header0 *)l_v4440;
	l_v4442 = RPyField(l_v4441, h_tid);
	OP_INT_AND(l_v4442, -8388609L, l_v4443);
	RPyField(l_v4441, h_tid) = l_v4443;
	OP_ADR_SUB(l_obj_28, 0, l_v4445);
	l_v4446 = (struct pypy_header0 *)l_v4445;
	l_v4447 = RPyField(l_v4446, h_tid);
	OP_EXTRACT_USHORT(l_v4447, l_v4448);
	l_v4449 = (struct pypy_varsize_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_v4448);
	l_v4450 = (struct pypy_type_info0 *)l_v4449;
	l_v4451 = RPyField(l_v4450, ti_infobits);
	OP_INT_AND(l_v4451, -16711680L, l_v4452);
	OP_INT_EQ(l_v4452, 1510014976L, l_v4453);
	RPyAssert(l_v4453, "invalid varsize type_id");
	l_v4455 = RPyField(l_v4449, vti_ofstolength);
	OP_ADR_ADD(l_obj_28, l_v4455, l_v4456);
	l_length_37 = ((Signed *) (((char *)l_v4456) + 0))[0];
	OP_CAST_INT_TO_UINT(l_length_37, l_v4457);
	OP_UINT_ADD(l_v4457, 1023UL, l_v4458);
	OP_UINT_RSHIFT(l_v4458, 10L, l_v4459);
	OP_CAST_UINT_TO_INT(l_v4459, l_v4421);
	OP_ADR_SUB(l_obj_28, 0, l_v4423);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v4460);
	if (l_v4460) {
		goto block19;
	}
	l_v4497 = l_v4423;
	goto block5;

    block5:
	OP_ADR_SUB(l_obj_28, 0, l_v4461);
	l_v4462 = (struct pypy_header0 *)l_v4461;
	l_v4463 = RPyField(l_v4462, h_tid);
	OP_INT_AND(l_v4463, 65536L, l_v4464);
	OP_INT_EQ(l_v4464, 0L, l_v4465);
	if (l_v4465) {
		l_v4422 = l_v4497;
		l_bytes_2 = l_v4421;
		goto block17;
	}
	l_p_1 = l_v4497;
	l_bytes_1 = l_v4421;
	l_interval_start_0 = 0L;
	goto block6;

    block6:
	OP_INT_GT(l_bytes_1, 0L, l_v4466);
	if (l_v4466) {
		goto block7;
	}
	goto block1_back;

    block7:
	OP_ADR_SUB(l_p_1, 1L, l_p_0);
	l_v4467 = ((char *) (((char *)l_p_0) + 0))[0];
	OP_CAST_CHAR_TO_INT(l_v4467, l_v4468);
	((char *) (((char *)l_p_0) + 0))[0] = ((char)0);
	OP_INT_SUB(l_bytes_1, 1L, l_bytes_0);
	OP_INT_ADD(l_interval_start_0, 1024L, l_next_byte_start_0);
	l_cardbyte_0 = l_v4468;
	l_interval_start_1 = l_interval_start_0;
	goto block8;

    block8:
	while (1) {
		OP_INT_NE(l_cardbyte_0, 0L, l_v4470);
		if (!l_v4470) break;
		goto block9;
	  block8_back: ;
	}
	l_p_1 = l_p_0;
	l_bytes_1 = l_bytes_0;
	l_interval_start_0 = l_next_byte_start_0;
	goto block6;

    block9:
	OP_INT_ADD(l_interval_start_1, 128L, l_interval_stop_0);
	OP_INT_AND(l_cardbyte_0, 1L, l_v4471);
	OP_INT_IS_TRUE(l_v4471, l_v4472);
	if (l_v4472) {
		goto block11;
	}
	l_interval_start_2 = l_interval_stop_0;
	goto block10;

    block10:
	OP_INT_RSHIFT(l_cardbyte_0, 1L, l_v4473);
	l_cardbyte_0 = l_v4473;
	l_interval_start_1 = l_interval_start_2;
	goto block8_back;

    block11:
	OP_INT_GT(l_interval_stop_0, l_length_37, l_v4474);
	if (l_v4474) {
		goto block14;
	}
	l_interval_stop_1 = l_interval_stop_0;
	goto block12;

    block12:
	OP_INT_LT(l_interval_start_1, l_interval_stop_1, l_v4475);
	RPyAssert(l_v4475, "empty or negative range in trace_and_drag_out_of_nursery_partial"
	"()");
	pypy_g_trace_partial___trace_drag_out(l_self_89, l_obj_28, l_interval_start_1, l_interval_stop_1, l_self_89);
	l_v4478 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4479 = (l_v4478 == NULL);
	if (!l_v4479) {
		goto block13;
	}
	l_interval_start_2 = l_interval_stop_1;
	goto block10;

    block13:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_collect_cardrefs_to_nursery");
	goto block2;

    block14:
	OP_INT_LE(l_cardbyte_0, 1L, l_v4481);
	if (l_v4481) {
		goto block16;
	}
	l_v4498 = 0;
	goto block15;

    block15:
	RPyAssert(l_v4498, "premature end of object");
	l_interval_stop_1 = l_length_37;
	goto block12;

    block16:
	OP_INT_EQ(l_bytes_0, 0L, l_v4483);
	l_v4498 = l_v4483;
	goto block15;

    block17:
	while (1) {
		OP_INT_GT(l_bytes_2, 0L, l_v4484);
		if (!l_v4484) break;
		goto block18;
	  block17_back: ;
	}
	goto block1;

    block18:
	OP_ADR_SUB(l_v4422, 1L, l_v4485);
	((char *) (((char *)l_v4485) + 0))[0] = ((char)0);
	OP_INT_SUB(l_bytes_2, 1L, l_v4487);
	l_v4422 = l_v4485;
	l_bytes_2 = l_v4487;
	goto block17_back;

    block19:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v4488 = (void*)0;
	l_v4489 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4490 = (l_v4489 == NULL);
	if (!l_v4490) {
		goto block20;
	}
	l_v4497 = l_v4488;
	goto block5;

    block20:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_collect_cardrefs_to_nursery");
	goto block2;

    block21:
	l_v4492 = (&pypy_g_rpython_memory_support_AddressStack_1)->as_inst_chunk;
	l_v4493 = RPyField(l_v4492, ac_next);
	l_v4494 = (l_v4493 != NULL);
	if (l_v4494) {
		goto block22;
	}
	goto block4;

    block22:
	pypy_g_AddressStack_shrink((&pypy_g_rpython_memory_support_AddressStack_1));
	goto block4;
}
/*/*/
void pypy_g_MiniMarkGC_collect_oldrefs_to_nursery(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_90) {
	void* l_result_14; Signed l_v4499; Signed l_v4501; Signed l_v4502;
	Signed l_v4511; Signed l_v4512; Signed l_v4517; Signed l_v4518;
	bool_t l_v4500; bool_t l_v4503; bool_t l_v4508; bool_t l_v4513;
	bool_t l_v4522; bool_t l_v4526; struct pypy_AddressChunk0 *l_v4505;
	struct pypy_AddressChunk0 *l_v4524;
	struct pypy_AddressChunk0 *l_v4525; struct pypy_header0 *l_v4510;
	struct pypy_header0 *l_v4516; struct pypy_object_vtable0 *l_v4521;
	void* *l_v4506; void* l_v4509; void* l_v4515;
	goto block0;

    block0:
	goto block1;

    block1:
	while (1) {
		l_v4499 = (&pypy_g_rpython_memory_support_AddressStack)->as_inst_used_in_last_chunk;
		OP_INT_NE(l_v4499, 0L, l_v4500);
		if (!l_v4500) break;
		goto block3;
	  block1_back: ;
	}
	goto block2;

    block2:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block3:
	l_v4501 = (&pypy_g_rpython_memory_support_AddressStack)->as_inst_used_in_last_chunk;
	OP_INT_SUB(l_v4501, 1L, l_v4502);
	OP_INT_GE(l_v4502, 0L, l_v4503);
	RPyAssert(l_v4503, "pop on empty AddressStack");
	l_v4505 = (&pypy_g_rpython_memory_support_AddressStack)->as_inst_chunk;
	l_v4506 = RPyField(l_v4505, ac_items);
	l_result_14 = RPyFxItem(l_v4506, l_v4502, 1019);
	(&pypy_g_rpython_memory_support_AddressStack)->as_inst_used_in_last_chunk = l_v4502;
	OP_INT_EQ(l_v4502, 0L, l_v4508);
	if (l_v4508) {
		goto block6;
	}
	goto block4;

    block4:
	OP_ADR_SUB(l_result_14, 0, l_v4509);
	l_v4510 = (struct pypy_header0 *)l_v4509;
	l_v4511 = RPyField(l_v4510, h_tid);
	OP_INT_AND(l_v4511, 65536L, l_v4512);
	OP_INT_EQ(l_v4512, 0L, l_v4513);
	RPyAssert(l_v4513, "old_objects_pointing_to_young contains obj with GCFLAG_TRACK_YOU"
	"NG_PTRS");
	OP_ADR_SUB(l_result_14, 0, l_v4515);
	l_v4516 = (struct pypy_header0 *)l_v4515;
	l_v4517 = RPyField(l_v4516, h_tid);
	OP_INT_OR(l_v4517, 65536L, l_v4518);
	RPyField(l_v4516, h_tid) = l_v4518;
	pypy_g_trace___trace_drag_out(l_self_90, l_result_14, l_self_90);
	l_v4521 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4522 = (l_v4521 == NULL);
	if (!l_v4522) {
		goto block5;
	}
	goto block1_back;

    block5:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_collect_oldrefs_to_nursery");
	goto block2;

    block6:
	l_v4524 = (&pypy_g_rpython_memory_support_AddressStack)->as_inst_chunk;
	l_v4525 = RPyField(l_v4524, ac_next);
	l_v4526 = (l_v4525 != NULL);
	if (l_v4526) {
		goto block7;
	}
	goto block4;

    block7:
	pypy_g_AddressStack_shrink((&pypy_g_rpython_memory_support_AddressStack));
	goto block4;
}
/*/*/
void pypy_g_MiniMarkGC_debug_rotate_nursery(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_91) {
	Signed l_end_5; Signed l_i_16; void* l_newnurs_0; void* l_oldnurs_0;
	Signed l_start_12; Signed l_v4529; Signed l_v4530; Signed l_v4531;
	Signed l_v4532; Signed l_v4536; Signed l_v4538; Signed l_v4539;
	Signed l_v4540; Signed l_v4544; Signed l_v4545; Signed l_v4549;
	Signed l_v4551; Signed l_v4552; Signed l_v4553; Signed l_v4557;
	Signed l_v4560; Signed l_v4566; Signed l_v4568; Signed l_v4569;
	Signed l_v4575; Signed l_v4578; Signed l_v4580; Signed l_v4582;
	Signed l_v4583; Unsigned l_v4567; Unsigned l_v4581; bool_t l_v4534;
	bool_t l_v4537; bool_t l_v4541; bool_t l_v4546; bool_t l_v4550;
	bool_t l_v4554; bool_t l_v4572; bool_t l_v4586;
	struct pypy_array1 *l_v4533; struct pypy_array1 *l_v4542;
	struct pypy_array1 *l_v4543; struct pypy_array1 *l_v4547;
	struct pypy_array1 *l_v4574; struct pypy_object_vtable0 *l_v4571;
	struct pypy_object_vtable0 *l_v4585; void* l_v4556; void* l_v4558;
	void* l_v4561; void* l_v4565; void* l_v4576; void* l_v4579;
	goto block0;

    block0:
	l_v4533 = RPyField(l_self_91, mmgc_inst_debug_rotating_nurseries);
	l_v4534 = (l_v4533 != NULL);
	if (l_v4534) {
		goto block2;
	}
	goto block1;

    block1:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block2:
	PYPY_DEBUG_START("gc-debug");
	l_oldnurs_0 = RPyField(l_self_91, mmgc_inst_nursery);
	l_v4536 = RPyField(l_self_91, mmgc_inst_nursery_size);
	OP_INT_ADD(l_v4536, 67584L, l_v4531);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v4537);
	if (l_v4537) {
		goto block14;
	}
	goto block3;

    block3:
	l_v4538 = (Signed)(l_oldnurs_0);
	OP_INT_ADD(l_v4538, l_v4531, l_v4539);
	OP_INT_ADD(l_v4538, 4095L, l_v4540);
	OP_INT_AND(l_v4540, -4096L, l_v4529);
	OP_INT_AND(l_v4539, -4096L, l_end_5);
	OP_INT_GT(l_end_5, l_v4529, l_v4541);
	if (l_v4541) {
		goto block13;
	}
	goto block4;

    block4:
	l_v4542 = RPyField(l_self_91, mmgc_inst_debug_rotating_nurseries);
	l_newnurs_0 = RPyItem(l_v4542, 0L);
	l_i_16 = 0L;
	goto block5;

    block5:
	while (1) {
		l_v4543 = RPyField(l_self_91, mmgc_inst_debug_rotating_nurseries);
		l_v4544 = l_v4543->length;
		OP_INT_SUB(l_v4544, 1L, l_v4545);
		OP_INT_LT(l_i_16, l_v4545, l_v4546);
		if (!l_v4546) break;
		goto block12;
	  block5_back: ;
	}
	goto block6;

    block6:
	l_v4547 = RPyField(l_self_91, mmgc_inst_debug_rotating_nurseries);
	RPyItem(l_v4547, l_i_16) = l_oldnurs_0;
	l_v4549 = RPyField(l_self_91, mmgc_inst_nursery_size);
	OP_INT_ADD(l_v4549, 67584L, l_v4530);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v4550);
	if (l_v4550) {
		goto block10;
	}
	goto block7;

    block7:
	l_v4551 = (Signed)(l_newnurs_0);
	OP_INT_ADD(l_v4551, l_v4530, l_v4552);
	OP_INT_ADD(l_v4551, 4095L, l_v4553);
	OP_INT_AND(l_v4553, -4096L, l_start_12);
	OP_INT_AND(l_v4552, -4096L, l_v4532);
	OP_INT_GT(l_v4532, l_start_12, l_v4554);
	if (l_v4554) {
		goto block9;
	}
	goto block8;

    block8:
	RPyField(l_self_91, mmgc_inst_nursery) = l_newnurs_0;
	l_v4556 = RPyField(l_self_91, mmgc_inst_nursery);
	l_v4557 = RPyField(l_self_91, mmgc_inst_initial_cleanup);
	OP_ADR_ADD(l_v4556, l_v4557, l_v4558);
	RPyField(l_self_91, mmgc_inst_nursery_top) = l_v4558;
	l_v4560 = RPyField(l_self_91, mmgc_inst_nursery_size);
	OP_ADR_ADD(l_v4556, l_v4560, l_v4561);
	RPyField(l_self_91, mmgc_inst_nursery_real_top) = l_v4561;
	if (PYPY_HAVE_DEBUG_PRINTS) { fprintf(PYPY_DEBUG_FILE, "switching from nursery %p to nursery %p size %ld\012", l_oldnurs_0, l_v4556, l_v4560); }
	PYPY_DEBUG_STOP("gc-debug");
	goto block1;

    block9:
	l_v4565 = (void*)(l_start_12);
	OP_INT_SUB(l_v4532, l_start_12, l_v4566);
	l_v4567 = (Unsigned)(l_v4566);
	l_v4568 = (Signed)(3L);
	l_v4569 = mprotect(l_v4565, l_v4567, l_v4568);
	goto block8;

    block10:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v4571 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4572 = (l_v4571 == NULL);
	if (!l_v4572) {
		goto block11;
	}
	goto block8;

    block11:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_debug_rotate_nursery");
	goto block1;

    block12:
	l_v4574 = RPyField(l_self_91, mmgc_inst_debug_rotating_nurseries);
	OP_INT_ADD(l_i_16, 1L, l_v4575);
	l_v4576 = RPyItem(l_v4574, l_v4575);
	RPyItem(l_v4574, l_i_16) = l_v4576;
	OP_INT_ADD(l_i_16, 1L, l_v4578);
	l_i_16 = l_v4578;
	goto block5_back;

    block13:
	l_v4579 = (void*)(l_v4529);
	OP_INT_SUB(l_end_5, l_v4529, l_v4580);
	l_v4581 = (Unsigned)(l_v4580);
	l_v4582 = (Signed)(0L);
	l_v4583 = mprotect(l_v4579, l_v4581, l_v4582);
	goto block4;

    block14:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v4585 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4586 = (l_v4585 == NULL);
	if (!l_v4586) {
		goto block15;
	}
	goto block4;

    block15:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_debug_rotate_nursery");
	goto block1;
}
/*/*/
void pypy_g_MiniMarkGC_deal_with_young_objects_with_finalize(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_v4589) {
	void* l_addr_8;
	struct pypy_rpython_memory_support_AddressStack0 *l_self_92;
	Signed l_used_17; Signed l_v4591; Signed l_v4595; Signed l_v4597;
	Signed l_v4598; Signed l_v4605; Signed l_v4606; Signed l_v4619;
	Signed l_v4623; Signed l_v4628; Signed l_v4630; Signed l_v4631;
	Signed l_v4634; Signed l_v4647; Signed l_v4652; bool_t l_v4596;
	bool_t l_v4599; bool_t l_v4604; bool_t l_v4607; bool_t l_v4610;
	bool_t l_v4614; bool_t l_v4620; bool_t l_v4621; bool_t l_v4624;
	bool_t l_v4632; bool_t l_v4635; bool_t l_v4639; bool_t l_v4643;
	bool_t l_v4644; bool_t l_v4648; bool_t l_v4656; bool_t l_v4660;
	bool_t l_v4663; struct pypy_AddressChunk0 *l_v4601;
	struct pypy_AddressChunk0 *l_v4649;
	struct pypy_AddressChunk0 *l_v4658;
	struct pypy_AddressChunk0 *l_v4659;
	struct pypy_forwarding_stub0 *l_v4646; struct pypy_header0 *l_v4618;
	struct pypy_header0 *l_v4627; struct pypy_object_vtable0 *l_v4638;
	struct pypy_object_vtable0 *l_v4655;
	struct pypy_rpython_memory_support_AddressStack0 *l_v4592;
	struct pypy_rpython_memory_support_AddressStack0 *l_v4594;
	struct pypy_type_info0 *l_v4593;
	struct pypy_type_info_extra0 *l_v4641; unsigned short l_v4629;
	void (*l_v4642)(void*); void (*l_v4664)(void*); void* *l_v4602;
	void* *l_v4650; void* l_v4590; void* l_v4609; void* l_v4613;
	void* l_v4617; void* l_v4626;
	goto block0;

    block0:
	goto block1;

    block1:
	while (1) {
		l_v4594 = RPyField(l_v4589, mmgc_inst_young_objects_with_light_finalizers);
		l_v4595 = RPyField(l_v4594, as_inst_used_in_last_chunk);
		OP_INT_NE(l_v4595, 0L, l_v4596);
		if (!l_v4596) break;
		goto block3;
	  block1_back: ;
	}
	goto block2;

    block2:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block3:
	l_self_92 = RPyField(l_v4589, mmgc_inst_young_objects_with_light_finalizers);
	l_v4597 = RPyField(l_self_92, as_inst_used_in_last_chunk);
	OP_INT_SUB(l_v4597, 1L, l_v4598);
	OP_INT_GE(l_v4598, 0L, l_v4599);
	RPyAssert(l_v4599, "pop on empty AddressStack");
	l_v4601 = RPyField(l_self_92, as_inst_chunk);
	l_v4602 = RPyField(l_v4601, ac_items);
	l_v4590 = RPyFxItem(l_v4602, l_v4598, 1019);
	RPyField(l_self_92, as_inst_used_in_last_chunk) = l_v4598;
	OP_INT_EQ(l_v4598, 0L, l_v4604);
	if (l_v4604) {
		goto block17;
	}
	goto block4;

    block4:
	OP_CAST_ADR_TO_INT(l_v4590, /* nothing */, l_v4605);
	OP_INT_AND(l_v4605, 1L, l_v4606);
	OP_INT_EQ(l_v4606, 0L, l_v4607);
	RPyAssert(l_v4607, "odd-valued (i.e. tagged) pointer unexpected here");
	l_v4609 = RPyField(l_v4589, mmgc_inst_nursery);
	OP_ADR_LE(l_v4609, l_v4590, l_v4610);
	if (l_v4610) {
		goto block6;
	}
	goto block5;

    block5:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_deal_with_young_objects_with_finalize");
	goto block2;

    block6:
	l_v4613 = RPyField(l_v4589, mmgc_inst_nursery_real_top);
	OP_ADR_LT(l_v4590, l_v4613, l_v4614);
	if (l_v4614) {
		goto block8;
	}
	goto block7;

    block7:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_deal_with_young_objects_with_finalize");
	goto block2;

    block8:
	OP_ADR_SUB(l_v4590, 0, l_v4617);
	l_v4618 = (struct pypy_header0 *)l_v4617;
	l_v4591 = RPyField(l_v4618, h_tid);
	OP_INT_AND(l_v4591, 1048576L, l_v4619);
	OP_INT_NE(l_v4619, 0L, l_v4620);
	if (l_v4620) {
		goto block13;
	}
	goto block9;

    block9:
	OP_INT_IS_TRUE(l_v4591, l_v4621);
	RPyAssert(l_v4621, "bogus header (1)");
	OP_INT_AND(l_v4591, -16777216L, l_v4623);
	OP_INT_EQ(l_v4623, 0L, l_v4624);
	RPyAssert(l_v4624, "bogus header (2)");
	OP_ADR_SUB(l_v4590, 0, l_v4626);
	l_v4627 = (struct pypy_header0 *)l_v4626;
	l_v4628 = RPyField(l_v4627, h_tid);
	OP_EXTRACT_USHORT(l_v4628, l_v4629);
	l_v4593 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_v4629);
	l_v4630 = RPyField(l_v4593, ti_infobits);
	OP_INT_AND(l_v4630, -16777216L, l_v4631);
	OP_INT_EQ(l_v4631, 1509949440L, l_v4632);
	RPyAssert(l_v4632, "invalid type_id");
	OP_INT_AND(l_v4630, 8388608L, l_v4634);
	OP_INT_IS_TRUE(l_v4634, l_v4635);
	if (l_v4635) {
		goto block12;
	}
	l_v4664 = ((void (*)(void*)) NULL);
	l_v4663 = 0;
	goto block10;

    block10:
	RPyAssert(l_v4663, "no light finalizer found");
	l_v4664(l_v4590);
	l_v4638 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4639 = (l_v4638 == NULL);
	if (!l_v4639) {
		goto block11;
	}
	goto block1_back;

    block11:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_deal_with_young_objects_with_finalize");
	goto block2;

    block12:
	l_v4641 = RPyField(l_v4593, ti_extra);
	l_v4642 = RPyField(l_v4641, tie_finalizer);
	l_v4643 = (l_v4642 != NULL);
	l_v4664 = l_v4642;
	l_v4663 = l_v4643;
	goto block10;

    block13:
	OP_INT_EQ(l_v4591, -42L, l_v4644);
	RPyAssert(l_v4644, "bogus header for young obj");
	l_v4646 = (struct pypy_forwarding_stub0 *)l_v4590;
	l_addr_8 = RPyField(l_v4646, fs_forw);
	l_v4592 = RPyField(l_v4589, mmgc_inst_old_objects_with_light_finalizers);
	l_v4647 = RPyField(l_v4592, as_inst_used_in_last_chunk);
	OP_INT_EQ(l_v4647, 1019L, l_v4648);
	if (l_v4648) {
		goto block15;
	}
	l_used_17 = l_v4647;
	goto block14;

    block14:
	l_v4649 = RPyField(l_v4592, as_inst_chunk);
	l_v4650 = RPyField(l_v4649, ac_items);
	RPyFxItem(l_v4650, l_used_17, 1019) = l_addr_8;
	OP_INT_ADD(l_used_17, 1L, l_v4652);
	RPyField(l_v4592, as_inst_used_in_last_chunk) = l_v4652;
	goto block1;

    block15:
	pypy_g_AddressStack_enlarge(l_v4592);
	l_v4655 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4656 = (l_v4655 == NULL);
	if (!l_v4656) {
		goto block16;
	}
	l_used_17 = 0L;
	goto block14;

    block16:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_deal_with_young_objects_with_finalize");
	goto block2;

    block17:
	l_v4658 = RPyField(l_self_92, as_inst_chunk);
	l_v4659 = RPyField(l_v4658, ac_next);
	l_v4660 = (l_v4659 != NULL);
	if (l_v4660) {
		goto block18;
	}
	goto block4;

    block18:
	pypy_g_AddressStack_shrink(l_self_92);
	goto block4;
}
/*/*/
void pypy_g_MiniMarkGC_invalidate_young_weakrefs(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_93) {
	void* l_obj_29; Signed l_offset_1; void* l_pointing_to_0;
	struct pypy_rpython_memory_support_AddressStack0 *l_self_94;
	Signed l_tid_3; Signed l_used_18; Signed l_v4665; Signed l_v4668;
	Signed l_v4671; Signed l_v4673; Signed l_v4674; Signed l_v4681;
	Signed l_v4682; Signed l_v4695; Signed l_v4699; Signed l_v4707;
	Signed l_v4710; Signed l_v4711; Signed l_v4714; Signed l_v4717;
	Signed l_v4718; Signed l_v4727; Signed l_v4728; Signed l_v4730;
	Signed l_v4735; Signed l_v4741; Signed l_v4742; Signed l_v4749;
	Signed l_v4750; Signed l_v4757; Signed l_v4758; Signed l_v4771;
	Signed l_v4775; Unsigned l_v4744; Unsigned l_v4745; Unsigned l_v4754;
	Unsigned l_v4791; bool_t l_v4672; bool_t l_v4675; bool_t l_v4680;
	bool_t l_v4683; bool_t l_v4686; bool_t l_v4690; bool_t l_v4696;
	bool_t l_v4697; bool_t l_v4700; bool_t l_v4702; bool_t l_v4712;
	bool_t l_v4715; bool_t l_v4719; bool_t l_v4722; bool_t l_v4724;
	bool_t l_v4729; bool_t l_v4731; bool_t l_v4739; bool_t l_v4743;
	bool_t l_v4746; bool_t l_v4751; bool_t l_v4756; bool_t l_v4759;
	bool_t l_v4762; bool_t l_v4766; bool_t l_v4772; bool_t l_v4773;
	bool_t l_v4776; bool_t l_v4780; bool_t l_v4788;
	struct pypy_AddressChunk0 *l_v4677;
	struct pypy_AddressChunk0 *l_v4732;
	struct pypy_AddressChunk0 *l_v4786;
	struct pypy_AddressChunk0 *l_v4787; struct pypy_DICT0 *l_v4667;
	struct pypy_DICT0 *l_v4723; struct pypy_forwarding_stub0 *l_v4704;
	struct pypy_forwarding_stub0 *l_v4782; struct pypy_header0 *l_v4694;
	struct pypy_header0 *l_v4706; struct pypy_header0 *l_v4726;
	struct pypy_header0 *l_v4748; struct pypy_header0 *l_v4770;
	struct pypy_object_vtable0 *l_v4738;
	struct pypy_rpython_memory_support_AddressStack0 *l_v4669;
	struct pypy_rpython_memory_support_AddressStack0 *l_v4670;
	struct pypy_type_info0 *l_v4709; unsigned short l_v4708;
	void* *l_v4678; void* *l_v4733; void* l_v4666; void* l_v4685;
	void* l_v4689; void* l_v4693; void* l_v4705; void* l_v4716;
	void* l_v4721; void* l_v4725; void* l_v4747; void* l_v4752;
	void* l_v4755; void* l_v4761; void* l_v4765; void* l_v4769;
	void* l_v4778; void* l_v4783; void* l_v4784;
	goto block0;

    block0:
	goto block1;

    block1:
	while (1) {
		l_v4670 = RPyField(l_self_93, mmgc_inst_young_objects_with_weakrefs);
		l_v4671 = RPyField(l_v4670, as_inst_used_in_last_chunk);
		OP_INT_NE(l_v4671, 0L, l_v4672);
		if (!l_v4672) break;
		goto block3;
	  block1_back: ;
	}
	goto block2;

    block2:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block3:
	l_v4669 = RPyField(l_self_93, mmgc_inst_young_objects_with_weakrefs);
	l_v4673 = RPyField(l_v4669, as_inst_used_in_last_chunk);
	OP_INT_SUB(l_v4673, 1L, l_v4674);
	OP_INT_GE(l_v4674, 0L, l_v4675);
	RPyAssert(l_v4675, "pop on empty AddressStack");
	l_v4677 = RPyField(l_v4669, as_inst_chunk);
	l_v4678 = RPyField(l_v4677, ac_items);
	l_v4666 = RPyFxItem(l_v4678, l_v4674, 1019);
	RPyField(l_v4669, as_inst_used_in_last_chunk) = l_v4674;
	OP_INT_EQ(l_v4674, 0L, l_v4680);
	if (l_v4680) {
		goto block32;
	}
	goto block4;

    block4:
	OP_CAST_ADR_TO_INT(l_v4666, /* nothing */, l_v4681);
	OP_INT_AND(l_v4681, 1L, l_v4682);
	OP_INT_EQ(l_v4682, 0L, l_v4683);
	RPyAssert(l_v4683, "odd-valued (i.e. tagged) pointer unexpected here");
	l_v4685 = RPyField(l_self_93, mmgc_inst_nursery);
	OP_ADR_LE(l_v4685, l_v4666, l_v4686);
	if (l_v4686) {
		goto block6;
	}
	goto block5;

    block5:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_invalidate_young_weakrefs");
	goto block2;

    block6:
	l_v4689 = RPyField(l_self_93, mmgc_inst_nursery_real_top);
	OP_ADR_LT(l_v4666, l_v4689, l_v4690);
	if (l_v4690) {
		goto block8;
	}
	goto block7;

    block7:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_invalidate_young_weakrefs");
	goto block2;

    block8:
	OP_ADR_SUB(l_v4666, 0, l_v4693);
	l_v4694 = (struct pypy_header0 *)l_v4693;
	l_v4668 = RPyField(l_v4694, h_tid);
	OP_INT_AND(l_v4668, 1048576L, l_v4695);
	OP_INT_NE(l_v4695, 0L, l_v4696);
	if (l_v4696) {
		goto block10;
	}
	goto block9;

    block9:
	OP_INT_IS_TRUE(l_v4668, l_v4697);
	RPyAssert(l_v4697, "bogus header (1)");
	OP_INT_AND(l_v4668, -16777216L, l_v4699);
	OP_INT_EQ(l_v4699, 0L, l_v4700);
	RPyAssert(l_v4700, "bogus header (2)");
	goto block1_back;

    block10:
	OP_INT_EQ(l_v4668, -42L, l_v4702);
	RPyAssert(l_v4702, "bogus header for young obj");
	l_v4704 = (struct pypy_forwarding_stub0 *)l_v4666;
	l_obj_29 = RPyField(l_v4704, fs_forw);
	OP_ADR_SUB(l_obj_29, 0, l_v4705);
	l_v4706 = (struct pypy_header0 *)l_v4705;
	l_v4707 = RPyField(l_v4706, h_tid);
	OP_EXTRACT_USHORT(l_v4707, l_v4708);
	l_v4709 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_v4708);
	l_v4710 = RPyField(l_v4709, ti_infobits);
	OP_INT_AND(l_v4710, -16777216L, l_v4711);
	OP_INT_EQ(l_v4711, 1509949440L, l_v4712);
	RPyAssert(l_v4712, "invalid type_id");
	OP_INT_AND(l_v4710, 524288L, l_v4714);
	OP_INT_IS_TRUE(l_v4714, l_v4715);
	if (l_v4715) {
		l_offset_1 = offsetof(struct pypy_weakref0, w_weakptr);
		goto block11;
	}
	l_offset_1 = -1L;
	goto block11;

    block11:
	OP_ADR_ADD(l_obj_29, l_offset_1, l_v4716);
	l_pointing_to_0 = ((void* *) (((char *)l_v4716) + 0))[0];
	OP_CAST_ADR_TO_INT(l_pointing_to_0, /* nothing */, l_v4717);
	OP_INT_AND(l_v4717, 1L, l_v4718);
	OP_INT_EQ(l_v4718, 0L, l_v4719);
	RPyAssert(l_v4719, "odd-valued (i.e. tagged) pointer unexpected here");
	l_v4721 = RPyField(l_self_93, mmgc_inst_nursery);
	OP_ADR_LE(l_v4721, l_pointing_to_0, l_v4722);
	if (l_v4722) {
		goto block24;
	}
	goto block12;

    block12:
	l_v4723 = RPyField(l_self_93, mmgc_inst_young_rawmalloced_objects);
	l_v4724 = (l_v4723 != NULL);
	if (l_v4724) {
		goto block18;
	}
	goto block13;

    block13:
	OP_ADR_SUB(l_pointing_to_0, 0, l_v4725);
	l_v4726 = (struct pypy_header0 *)l_v4725;
	l_v4727 = RPyField(l_v4726, h_tid);
	OP_INT_AND(l_v4727, 131072L, l_v4728);
	OP_INT_IS_TRUE(l_v4728, l_v4729);
	if (l_v4729) {
		goto block1;
	}
	goto block14;

    block14:
	l_self_94 = RPyField(l_self_93, mmgc_inst_old_objects_with_weakrefs);
	l_v4730 = RPyField(l_self_94, as_inst_used_in_last_chunk);
	OP_INT_EQ(l_v4730, 1019L, l_v4731);
	if (l_v4731) {
		goto block16;
	}
	l_used_18 = l_v4730;
	goto block15;

    block15:
	l_v4732 = RPyField(l_self_94, as_inst_chunk);
	l_v4733 = RPyField(l_v4732, ac_items);
	RPyFxItem(l_v4733, l_used_18, 1019) = l_obj_29;
	OP_INT_ADD(l_used_18, 1L, l_v4735);
	RPyField(l_self_94, as_inst_used_in_last_chunk) = l_v4735;
	goto block1;

    block16:
	pypy_g_AddressStack_enlarge(l_self_94);
	l_v4738 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4739 = (l_v4738 == NULL);
	if (!l_v4739) {
		goto block17;
	}
	l_used_18 = 0L;
	goto block15;

    block17:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_invalidate_young_weakrefs");
	goto block2;

    block18:
	l_v4667 = RPyField(l_self_93, mmgc_inst_young_rawmalloced_objects);
	OP_CAST_ADR_TO_INT(l_pointing_to_0, /* nothing */, l_v4741);
	OP_INT_RSHIFT(l_v4741, 4L, l_v4742);
	OP_INT_XOR(l_v4741, l_v4742, l_v4665);
	OP_INT_IS_TRUE(0 /* we are not jitted here */, l_v4743);
	if (l_v4743) {
		goto block23;
	}
	goto block19;

    block19:
	l_v4744 = pypy_g_ll_dict_lookup__v51___simple_call__function_ll(l_v4667, l_pointing_to_0, l_v4665);
	l_v4791 = l_v4744;
	goto block20;

    block20:
	OP_UINT_AND(l_v4791, 2147483648UL, l_v4745);
	OP_UINT_IS_TRUE(l_v4745, l_v4746);
	if (l_v4746) {
		goto block13;
	}
	goto block21;

    block21:
	OP_ADR_SUB(l_pointing_to_0, 0, l_v4747);
	l_v4748 = (struct pypy_header0 *)l_v4747;
	l_v4749 = RPyField(l_v4748, h_tid);
	OP_INT_AND(l_v4749, 262144L, l_v4750);
	OP_INT_IS_TRUE(l_v4750, l_v4751);
	if (l_v4751) {
		goto block14;
	}
	goto block22;

    block22:
	OP_ADR_ADD(l_obj_29, l_offset_1, l_v4752);
	((void* *) (((char *)l_v4752) + 0))[0] = NULL;
	goto block1;

    block23:
	l_v4754 = pypy_g_ll_dict_lookup__v60___simple_call__function_ll(l_v4667, l_pointing_to_0, l_v4665);
	l_v4791 = l_v4754;
	goto block20;

    block24:
	l_v4755 = RPyField(l_self_93, mmgc_inst_nursery_real_top);
	OP_ADR_LT(l_pointing_to_0, l_v4755, l_v4756);
	if (l_v4756) {
		goto block25;
	}
	goto block12;

    block25:
	OP_CAST_ADR_TO_INT(l_pointing_to_0, /* nothing */, l_v4757);
	OP_INT_AND(l_v4757, 1L, l_v4758);
	OP_INT_EQ(l_v4758, 0L, l_v4759);
	RPyAssert(l_v4759, "odd-valued (i.e. tagged) pointer unexpected here");
	l_v4761 = RPyField(l_self_93, mmgc_inst_nursery);
	OP_ADR_LE(l_v4761, l_pointing_to_0, l_v4762);
	if (l_v4762) {
		goto block27;
	}
	goto block26;

    block26:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_invalidate_young_weakrefs");
	goto block2;

    block27:
	l_v4765 = RPyField(l_self_93, mmgc_inst_nursery_real_top);
	OP_ADR_LT(l_pointing_to_0, l_v4765, l_v4766);
	if (l_v4766) {
		goto block29;
	}
	goto block28;

    block28:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_invalidate_young_weakrefs");
	goto block2;

    block29:
	OP_ADR_SUB(l_pointing_to_0, 0, l_v4769);
	l_v4770 = (struct pypy_header0 *)l_v4769;
	l_tid_3 = RPyField(l_v4770, h_tid);
	OP_INT_AND(l_tid_3, 1048576L, l_v4771);
	OP_INT_NE(l_v4771, 0L, l_v4772);
	if (l_v4772) {
		goto block31;
	}
	goto block30;

    block30:
	OP_INT_IS_TRUE(l_tid_3, l_v4773);
	RPyAssert(l_v4773, "bogus header (1)");
	OP_INT_AND(l_tid_3, -16777216L, l_v4775);
	OP_INT_EQ(l_v4775, 0L, l_v4776);
	RPyAssert(l_v4776, "bogus header (2)");
	OP_ADR_ADD(l_obj_29, l_offset_1, l_v4778);
	((void* *) (((char *)l_v4778) + 0))[0] = NULL;
	goto block1;

    block31:
	OP_INT_EQ(l_tid_3, -42L, l_v4780);
	RPyAssert(l_v4780, "bogus header for young obj");
	l_v4782 = (struct pypy_forwarding_stub0 *)l_pointing_to_0;
	l_v4783 = RPyField(l_v4782, fs_forw);
	OP_ADR_ADD(l_obj_29, l_offset_1, l_v4784);
	((void* *) (((char *)l_v4784) + 0))[0] = l_v4783;
	goto block14;

    block32:
	l_v4786 = RPyField(l_v4669, as_inst_chunk);
	l_v4787 = RPyField(l_v4786, ac_next);
	l_v4788 = (l_v4787 != NULL);
	if (l_v4788) {
		goto block33;
	}
	goto block4;

    block33:
	pypy_g_AddressStack_shrink(l_v4669);
	goto block4;
}
/*/*/
void pypy_g_MiniMarkGC_remove_young_arrays_from_old_objects_(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_95) {
	struct pypy_AddressChunk0 *l_cur_1; struct pypy_DICT0 *l_d_31;
	Signed l_hash_21;
	struct pypy_rpython_memory_support_AddressStack0 *l_new_0;
	void* l_result_15; Signed l_used_19; Signed l_used_20;
	Signed l_v4814; Signed l_v4816; Signed l_v4827; Signed l_v4828;
	Signed l_v4835; Signed l_v4840; Signed l_v4850; Signed l_v4851;
	Signed l_v4858; Signed l_v4859; Signed l_v4864; Signed l_v4869;
	Unsigned l_v4861; Unsigned l_v4862; Unsigned l_v4875;
	Unsigned l_v4887; bool_t l_v4793; bool_t l_v4797; bool_t l_v4801;
	bool_t l_v4805; bool_t l_v4806; bool_t l_v4815; bool_t l_v4817;
	bool_t l_v4819; bool_t l_v4829; bool_t l_v4834; bool_t l_v4836;
	bool_t l_v4844; bool_t l_v4848; bool_t l_v4852; bool_t l_v4857;
	bool_t l_v4860; bool_t l_v4863; bool_t l_v4865; bool_t l_v4873;
	bool_t l_v4878; struct pypy_AddressChunk0 *l_v4795;
	struct pypy_AddressChunk0 *l_v4804;
	struct pypy_AddressChunk0 *l_v4811;
	struct pypy_AddressChunk0 *l_v4818;
	struct pypy_AddressChunk0 *l_v4823;
	struct pypy_AddressChunk0 *l_v4824;
	struct pypy_AddressChunk0 *l_v4831;
	struct pypy_AddressChunk0 *l_v4837;
	struct pypy_AddressChunk0 *l_v4846;
	struct pypy_AddressChunk0 *l_v4847;
	struct pypy_AddressChunk0 *l_v4854;
	struct pypy_AddressChunk0 *l_v4866;
	struct pypy_AddressChunk0 *l_v4876;
	struct pypy_AddressChunk0 *l_v4877;
	struct pypy_AddressChunk0 *l_v4880;
	struct pypy_AddressChunk0 *l_v4881;
	struct pypy_AddressChunk0 *l_v4886;
	struct pypy_nongcobject0 *l_v4802;
	struct pypy_object_vtable0 *l_v4843;
	struct pypy_object_vtable0 *l_v4872; void* *l_v4832; void* *l_v4838;
	void* *l_v4855; void* *l_v4867; void* l_v4792; void* l_v4794;
	void* l_v4796; void* l_v4820; void* l_v4885;
	goto block0;

    block0:
	OP_RAW_MALLOC(sizeof(struct pypy_rpython_memory_support_AddressStack0), l_v4796, void *);
	OP_ADR_NE(l_v4796, NULL, l_v4797);
	if (l_v4797) {
		l_v4885 = l_v4796;
		goto block2;
	}
	goto block1;

    block1:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_remove_young_arrays_from_old_objects_");
	l_v4885 = NULL;
	goto block2;

    block2:
	OP_TRACK_ALLOC_START(l_v4885, /* nothing */);
	l_new_0 = (struct pypy_rpython_memory_support_AddressStack0 *)l_v4885;
	l_v4801 = (l_new_0 != NULL);
	if (!l_v4801) {
		goto block36;
	}
	goto block3;

    block3:
	l_v4802 = (struct pypy_nongcobject0 *)l_new_0;
	RPyField(l_v4802, n_typeptr) = (&pypy_g_rpython_memory_support_AddressStack_vtable.as_super);
	l_v4804 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v4805 = (l_v4804 != NULL);
	if (l_v4805) {
		goto block35;
	}
	goto block4;

    block4:
	OP_RAW_MALLOC(sizeof(struct pypy_AddressChunk0), l_v4794, void *);
	OP_ADR_NE(l_v4794, NULL, l_v4806);
	if (l_v4806) {
		goto block8;
	}
	goto block5;

    block5:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_remove_young_arrays_from_old_objects_");
	goto block6;

    block6:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_remove_young_arrays_from_old_objects_");
	goto block7;

    block7:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block8:
	l_v4795 = (struct pypy_AddressChunk0 *)l_v4794;
	l_v4793 = (l_v4795 != NULL);
	goto block9;

    block9:
	if (!l_v4793) {
		goto block6;
	}
	l_v4886 = l_v4795;
	goto block10;

    block10:
	RPyField(l_new_0, as_inst_chunk) = l_v4886;
	l_v4811 = RPyField(l_new_0, as_inst_chunk);
	RPyField(l_v4811, ac_next) = ((struct pypy_AddressChunk0 *) NULL);
	RPyField(l_new_0, as_inst_used_in_last_chunk) = 0L;
	goto block11;

    block11:
	while (1) {
		l_v4814 = (&pypy_g_rpython_memory_support_AddressStack)->as_inst_used_in_last_chunk;
		OP_INT_NE(l_v4814, 0L, l_v4815);
		if (!l_v4815) break;
		goto block24;
	  block11_back: ;
	}
	goto block12;

    block12:
	while (1) {
		l_v4816 = RPyField(l_new_0, as_inst_used_in_last_chunk);
		OP_INT_NE(l_v4816, 0L, l_v4817);
		if (!l_v4817) break;
		goto block17;
	  block12_back: ;
	}
	goto block13;

    block13:
	l_v4818 = RPyField(l_new_0, as_inst_chunk);
	l_cur_1 = l_v4818;
	goto block14;

    block14:
	while (1) {
		l_v4819 = (l_cur_1 != NULL);
		if (!l_v4819) break;
		goto block16;
	  block14_back: ;
	}
	goto block15;

    block15:
	l_v4820 = (void*)l_new_0;
	OP_TRACK_ALLOC_STOP(l_v4820, /* nothing */);
	OP_RAW_FREE(l_v4820, /* nothing */);
	goto block7;

    block16:
	l_v4823 = RPyField(l_cur_1, ac_next);
	l_v4824 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	RPyField(l_cur_1, ac_next) = l_v4824;
	(&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list = l_cur_1;
	l_cur_1 = l_v4823;
	goto block14_back;

    block17:
	l_v4827 = RPyField(l_new_0, as_inst_used_in_last_chunk);
	OP_INT_SUB(l_v4827, 1L, l_v4828);
	OP_INT_GE(l_v4828, 0L, l_v4829);
	RPyAssert(l_v4829, "pop on empty AddressStack");
	l_v4831 = RPyField(l_new_0, as_inst_chunk);
	l_v4832 = RPyField(l_v4831, ac_items);
	l_result_15 = RPyFxItem(l_v4832, l_v4828, 1019);
	RPyField(l_new_0, as_inst_used_in_last_chunk) = l_v4828;
	OP_INT_EQ(l_v4828, 0L, l_v4834);
	if (l_v4834) {
		goto block22;
	}
	goto block18;

    block18:
	l_v4835 = (&pypy_g_rpython_memory_support_AddressStack)->as_inst_used_in_last_chunk;
	OP_INT_EQ(l_v4835, 1019L, l_v4836);
	if (l_v4836) {
		goto block20;
	}
	l_used_19 = l_v4835;
	goto block19;

    block19:
	l_v4837 = (&pypy_g_rpython_memory_support_AddressStack)->as_inst_chunk;
	l_v4838 = RPyField(l_v4837, ac_items);
	RPyFxItem(l_v4838, l_used_19, 1019) = l_result_15;
	OP_INT_ADD(l_used_19, 1L, l_v4840);
	(&pypy_g_rpython_memory_support_AddressStack)->as_inst_used_in_last_chunk = l_v4840;
	goto block12_back;

    block20:
	pypy_g_AddressStack_enlarge((&pypy_g_rpython_memory_support_AddressStack));
	l_v4843 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4844 = (l_v4843 == NULL);
	if (!l_v4844) {
		goto block21;
	}
	l_used_19 = 0L;
	goto block19;

    block21:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_remove_young_arrays_from_old_objects_");
	goto block7;

    block22:
	l_v4846 = RPyField(l_new_0, as_inst_chunk);
	l_v4847 = RPyField(l_v4846, ac_next);
	l_v4848 = (l_v4847 != NULL);
	if (l_v4848) {
		goto block23;
	}
	goto block18;

    block23:
	pypy_g_AddressStack_shrink(l_new_0);
	goto block18;

    block24:
	l_v4850 = (&pypy_g_rpython_memory_support_AddressStack)->as_inst_used_in_last_chunk;
	OP_INT_SUB(l_v4850, 1L, l_v4851);
	OP_INT_GE(l_v4851, 0L, l_v4852);
	RPyAssert(l_v4852, "pop on empty AddressStack");
	l_v4854 = (&pypy_g_rpython_memory_support_AddressStack)->as_inst_chunk;
	l_v4855 = RPyField(l_v4854, ac_items);
	l_v4792 = RPyFxItem(l_v4855, l_v4851, 1019);
	(&pypy_g_rpython_memory_support_AddressStack)->as_inst_used_in_last_chunk = l_v4851;
	OP_INT_EQ(l_v4851, 0L, l_v4857);
	if (l_v4857) {
		goto block33;
	}
	goto block25;

    block25:
	l_d_31 = RPyField(l_self_95, mmgc_inst_young_rawmalloced_objects);
	OP_CAST_ADR_TO_INT(l_v4792, /* nothing */, l_v4858);
	OP_INT_RSHIFT(l_v4858, 4L, l_v4859);
	OP_INT_XOR(l_v4858, l_v4859, l_hash_21);
	OP_INT_IS_TRUE(0 /* we are not jitted here */, l_v4860);
	if (l_v4860) {
		goto block32;
	}
	goto block26;

    block26:
	l_v4861 = pypy_g_ll_dict_lookup__v51___simple_call__function_ll(l_d_31, l_v4792, l_hash_21);
	l_v4887 = l_v4861;
	goto block27;

    block27:
	OP_UINT_AND(l_v4887, 2147483648UL, l_v4862);
	OP_UINT_IS_TRUE(l_v4862, l_v4863);
	if (l_v4863) {
		goto block28;
	}
	goto block11_back;

    block28:
	l_v4864 = RPyField(l_new_0, as_inst_used_in_last_chunk);
	OP_INT_EQ(l_v4864, 1019L, l_v4865);
	if (l_v4865) {
		goto block30;
	}
	l_used_20 = l_v4864;
	goto block29;

    block29:
	l_v4866 = RPyField(l_new_0, as_inst_chunk);
	l_v4867 = RPyField(l_v4866, ac_items);
	RPyFxItem(l_v4867, l_used_20, 1019) = l_v4792;
	OP_INT_ADD(l_used_20, 1L, l_v4869);
	RPyField(l_new_0, as_inst_used_in_last_chunk) = l_v4869;
	goto block11;

    block30:
	pypy_g_AddressStack_enlarge(l_new_0);
	l_v4872 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4873 = (l_v4872 == NULL);
	if (!l_v4873) {
		goto block31;
	}
	l_used_20 = 0L;
	goto block29;

    block31:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_remove_young_arrays_from_old_objects_");
	goto block7;

    block32:
	l_v4875 = pypy_g_ll_dict_lookup__v60___simple_call__function_ll(l_d_31, l_v4792, l_hash_21);
	l_v4887 = l_v4875;
	goto block27;

    block33:
	l_v4876 = (&pypy_g_rpython_memory_support_AddressStack)->as_inst_chunk;
	l_v4877 = RPyField(l_v4876, ac_next);
	l_v4878 = (l_v4877 != NULL);
	if (l_v4878) {
		goto block34;
	}
	goto block25;

    block34:
	pypy_g_AddressStack_shrink((&pypy_g_rpython_memory_support_AddressStack));
	goto block25;

    block35:
	l_v4880 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v4881 = RPyField(l_v4880, ac_next);
	(&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list = l_v4881;
	l_v4886 = l_v4880;
	goto block10;

    block36:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_remove_young_arrays_from_old_objects_");
	goto block7;
}
/*/*/
bool_t pypy_g_MiniMarkGC_can_move(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_19, void* l_obj_1) {
	Signed l_v4888; Signed l_v4889; bool_t l_v4890; bool_t l_v4893;
	bool_t l_v4895; bool_t l_v4896; void* l_v4892; void* l_v4894;
	goto block0;

    block0:
	OP_CAST_ADR_TO_INT(l_obj_1, /* nothing */, l_v4888);
	OP_INT_AND(l_v4888, 1L, l_v4889);
	OP_INT_EQ(l_v4889, 0L, l_v4890);
	RPyAssert(l_v4890, "odd-valued (i.e. tagged) pointer unexpected here");
	l_v4892 = RPyField(l_self_19, mmgc_inst_nursery);
	OP_ADR_LE(l_v4892, l_obj_1, l_v4893);
	if (l_v4893) {
		goto block2;
	}
	l_v4896 = 0;
	goto block1;

    block1:
	RPY_DEBUG_RETURN();
	return l_v4896;

    block2:
	l_v4894 = RPyField(l_self_19, mmgc_inst_nursery_real_top);
	OP_ADR_LT(l_obj_1, l_v4894, l_v4895);
	l_v4896 = l_v4895;
	goto block1;
}
/*/*/
void pypy_g_MiniMarkGC_write_barrier_from_array(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_20, void* l_newvalue_1, void* l_addr_array_2, Signed l_index_5) {
	Signed l_v4899; Signed l_v4900; bool_t l_v4901;
	struct pypy_header0 *l_v4898; void* l_v4897;
	goto block0;

    block0:
	OP_ADR_SUB(l_addr_array_2, 0, l_v4897);
	l_v4898 = (struct pypy_header0 *)l_v4897;
	l_v4899 = RPyField(l_v4898, h_tid);
	OP_INT_AND(l_v4899, 65536L, l_v4900);
	OP_INT_IS_TRUE(l_v4900, l_v4901);
	if (l_v4901) {
		goto block2;
	}
	goto block1;

    block1:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block2:
	pypy_g_remember_young_pointer_from_array2(l_addr_array_2, l_index_5);
	goto block1;
}
/*/*/
void pypy_g_remember_young_pointer(void* l_addr_struct_3, void* l_addr_9) {
	Signed l_used_21; Signed l_used_22; Signed l_v4905; Signed l_v4912;
	Signed l_v4913; Signed l_v4915; Signed l_v4916; Signed l_v4918;
	Signed l_v4923; Signed l_v4929; Signed l_v4930; Signed l_v4935;
	Signed l_v4940; Signed l_v4942; Signed l_v4943; Unsigned l_v4932;
	Unsigned l_v4933; Unsigned l_v4949; Unsigned l_v4953; bool_t l_v4909;
	bool_t l_v4911; bool_t l_v4914; bool_t l_v4919; bool_t l_v4927;
	bool_t l_v4931; bool_t l_v4934; bool_t l_v4936; bool_t l_v4947;
	bool_t l_v4951; struct pypy_AddressChunk0 *l_v4920;
	struct pypy_AddressChunk0 *l_v4937; struct pypy_DICT0 *l_v4906;
	struct pypy_DICT0 *l_v4910; struct pypy_header0 *l_v4904;
	struct pypy_object_vtable0 *l_v4926;
	struct pypy_object_vtable0 *l_v4946; void* *l_v4921; void* *l_v4938;
	void* l_v4907; void* l_v4908; void* l_v4950;
	goto block0;

    block0:
	OP_ADR_SUB(l_addr_struct_3, 0, l_v4907);
	l_v4904 = (struct pypy_header0 *)l_v4907;
	l_v4908 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery;
	OP_ADR_LE(l_v4908, l_addr_9, l_v4909);
	if (l_v4909) {
		goto block16;
	}
	goto block1;

    block1:
	l_v4910 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_young_rawmalloced_objects;
	l_v4911 = (l_v4910 != NULL);
	if (l_v4911) {
		goto block8;
	}
	goto block2;

    block2:
	l_v4912 = RPyField(l_v4904, h_tid);
	OP_INT_AND(l_v4912, 131072L, l_v4913);
	OP_INT_IS_TRUE(l_v4913, l_v4914);
	if (l_v4914) {
		goto block4;
	}
	goto block3;

    block3:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block4:
	l_v4915 = RPyField(l_v4904, h_tid);
	OP_INT_AND(l_v4915, -131073L, l_v4916);
	RPyField(l_v4904, h_tid) = l_v4916;
	l_v4918 = (&pypy_g_rpython_memory_support_AddressStack_2)->as_inst_used_in_last_chunk;
	OP_INT_EQ(l_v4918, 1019L, l_v4919);
	if (l_v4919) {
		goto block6;
	}
	l_used_21 = l_v4918;
	goto block5;

    block5:
	l_v4920 = (&pypy_g_rpython_memory_support_AddressStack_2)->as_inst_chunk;
	l_v4921 = RPyField(l_v4920, ac_items);
	RPyFxItem(l_v4921, l_used_21, 1019) = l_addr_struct_3;
	OP_INT_ADD(l_used_21, 1L, l_v4923);
	(&pypy_g_rpython_memory_support_AddressStack_2)->as_inst_used_in_last_chunk = l_v4923;
	goto block3;

    block6:
	pypy_g_AddressStack_enlarge((&pypy_g_rpython_memory_support_AddressStack_2));
	l_v4926 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4927 = (l_v4926 == NULL);
	if (!l_v4927) {
		goto block7;
	}
	l_used_21 = 0L;
	goto block5;

    block7:
	PYPY_DEBUG_RECORD_TRACEBACK("remember_young_pointer");
	goto block3;

    block8:
	l_v4906 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_young_rawmalloced_objects;
	OP_CAST_ADR_TO_INT(l_addr_9, /* nothing */, l_v4929);
	OP_INT_RSHIFT(l_v4929, 4L, l_v4930);
	OP_INT_XOR(l_v4929, l_v4930, l_v4905);
	OP_INT_IS_TRUE(0 /* we are not jitted here */, l_v4931);
	if (l_v4931) {
		goto block15;
	}
	goto block9;

    block9:
	l_v4932 = pypy_g_ll_dict_lookup__v51___simple_call__function_ll(l_v4906, l_addr_9, l_v4905);
	l_v4953 = l_v4932;
	goto block10;

    block10:
	OP_UINT_AND(l_v4953, 2147483648UL, l_v4933);
	OP_UINT_IS_TRUE(l_v4933, l_v4934);
	if (l_v4934) {
		goto block2;
	}
	goto block11;

    block11:
	l_v4935 = (&pypy_g_rpython_memory_support_AddressStack)->as_inst_used_in_last_chunk;
	OP_INT_EQ(l_v4935, 1019L, l_v4936);
	if (l_v4936) {
		goto block13;
	}
	l_used_22 = l_v4935;
	goto block12;

    block12:
	l_v4937 = (&pypy_g_rpython_memory_support_AddressStack)->as_inst_chunk;
	l_v4938 = RPyField(l_v4937, ac_items);
	RPyFxItem(l_v4938, l_used_22, 1019) = l_addr_struct_3;
	OP_INT_ADD(l_used_22, 1L, l_v4940);
	(&pypy_g_rpython_memory_support_AddressStack)->as_inst_used_in_last_chunk = l_v4940;
	l_v4942 = RPyField(l_v4904, h_tid);
	OP_INT_AND(l_v4942, -65537L, l_v4943);
	RPyField(l_v4904, h_tid) = l_v4943;
	goto block2;

    block13:
	pypy_g_AddressStack_enlarge((&pypy_g_rpython_memory_support_AddressStack));
	l_v4946 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4947 = (l_v4946 == NULL);
	if (!l_v4947) {
		goto block14;
	}
	l_used_22 = 0L;
	goto block12;

    block14:
	PYPY_DEBUG_RECORD_TRACEBACK("remember_young_pointer");
	goto block3;

    block15:
	l_v4949 = pypy_g_ll_dict_lookup__v60___simple_call__function_ll(l_v4906, l_addr_9, l_v4905);
	l_v4953 = l_v4949;
	goto block10;

    block16:
	l_v4950 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_real_top;
	OP_ADR_LT(l_addr_9, l_v4950, l_v4951);
	if (l_v4951) {
		goto block11;
	}
	goto block1;
}
/*/*/
void pypy_g_MiniMarkGC_major_collection(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_96, Signed l_reserving_size_2) {
	struct pypy_AddressChunk0 *l_cur_2;
	struct pypy_rpython_memory_support_AddressStack0 *l_self_97;
	Signed l_v4971; Signed l_v5001; Signed l_v5002; Signed l_v5010;
	Signed l_v5013; Signed l_v5022; Signed l_v5024; Signed l_v5025;
	Signed l_v5032; Signed l_v5064; Signed l_v5099; Unsigned l_v4963;
	Unsigned l_v4965; Unsigned l_v5028; Unsigned l_v5030;
	Unsigned l_v5036; Unsigned l_v5037; Unsigned l_v5038;
	Unsigned l_v5047; Unsigned l_v5048; Unsigned l_v5049; bool_t l_v4958;
	bool_t l_v4969; bool_t l_v4972; bool_t l_v4974; bool_t l_v4978;
	bool_t l_v4982; bool_t l_v4983; bool_t l_v4994; bool_t l_v4997;
	bool_t l_v5000; bool_t l_v5003; bool_t l_v5005; bool_t l_v5011;
	bool_t l_v5014; bool_t l_v5017; bool_t l_v5020; bool_t l_v5023;
	bool_t l_v5044; bool_t l_v5045; bool_t l_v5054; bool_t l_v5055;
	bool_t l_v5061; bool_t l_v5065; bool_t l_v5069; bool_t l_v5075;
	bool_t l_v5079; bool_t l_v5087; bool_t l_v5096; bool_t l_v5100;
	bool_t l_v5104; bool_t l_v5110; bool_t l_v5111; bool_t l_v5112;
	bool_t l_v5113; double l_v5039; double l_v5040; double l_v5041;
	double l_v5042; double l_v5043; double l_v5050; double l_v5051;
	double l_v5052; double l_v5053; double l_v5109;
	struct pypy_AddressChunk0 *l_v4955;
	struct pypy_AddressChunk0 *l_v4981;
	struct pypy_AddressChunk0 *l_v4988;
	struct pypy_AddressChunk0 *l_v4998;
	struct pypy_AddressChunk0 *l_v4999;
	struct pypy_AddressChunk0 *l_v5004;
	struct pypy_AddressChunk0 *l_v5081;
	struct pypy_AddressChunk0 *l_v5082;
	struct pypy_AddressChunk0 *l_v5091;
	struct pypy_AddressChunk0 *l_v5092;
	struct pypy_AddressChunk0 *l_v5108; struct pypy_DICT0 *l_v5060;
	struct pypy_DICT0 *l_v5095; struct pypy_nongcobject0 *l_v4979;
	struct pypy_object_vtable0 *l_v4993;
	struct pypy_object_vtable0 *l_v4996;
	struct pypy_object_vtable0 *l_v5016;
	struct pypy_object_vtable0 *l_v5019;
	struct pypy_object_vtable0 *l_v5068;
	struct pypy_object_vtable0 *l_v5074;
	struct pypy_object_vtable0 *l_v5078;
	struct pypy_object_vtable0 *l_v5086;
	struct pypy_object_vtable0 *l_v5103;
	struct pypy_rpython_memory_support_AddressDeque0 *l_v4956;
	struct pypy_rpython_memory_support_AddressStack0 *l_v4954;
	struct pypy_rpython_memory_support_AddressStack0 *l_v5009;
	struct pypy_rpython_memory_support_AddressStack0 *l_v5012;
	struct pypy_rpython_memory_support_AddressStack0 *l_v5063;
	struct pypy_rpython_memory_support_AddressStack0 *l_v5098;
	void* l_v4957; void* l_v4967; void* l_v4968; void* l_v4973;
	void* l_v5006; void* l_v5107;
	goto block0;

    block0:
	PYPY_DEBUG_START("gc-collect");
	if (PYPY_HAVE_DEBUG_PRINTS) { fprintf(PYPY_DEBUG_FILE, "\012"); }
	if (PYPY_HAVE_DEBUG_PRINTS) { fprintf(PYPY_DEBUG_FILE, ".----------- Full collection ------------------\012"); }
	if (PYPY_HAVE_DEBUG_PRINTS) { fprintf(PYPY_DEBUG_FILE, "| used before collection:\012"); }
	l_v4963 = (&pypy_g_rpython_memory_gc_minimarkpage_ArenaCollection)->ac_inst_total_memory_used;
	if (PYPY_HAVE_DEBUG_PRINTS) { fprintf(PYPY_DEBUG_FILE, "|          in ArenaCollection:      %lu bytes\012", l_v4963); }
	l_v4965 = RPyField(l_self_96, mmgc_inst_rawmalloced_total_size);
	if (PYPY_HAVE_DEBUG_PRINTS) { fprintf(PYPY_DEBUG_FILE, "|          raw_malloced:            %lu bytes\012", l_v4965); }
	l_v4967 = RPyField(l_self_96, mmgc_inst_nursery_free);
	l_v4968 = RPyField(l_self_96, mmgc_inst_nursery);
	OP_ADR_EQ(l_v4967, l_v4968, l_v4969);
	RPyAssert(l_v4969, "nursery not empty in major_collection()");
	l_v4971 = RPyField(l_self_96, mmgc_inst_DEBUG);
	OP_INT_IS_TRUE(l_v4971, l_v4972);
	if (l_v4972) {
		goto block46;
	}
	goto block1;

    block1:
	OP_RAW_MALLOC(sizeof(struct pypy_rpython_memory_support_AddressStack0), l_v4973, void *);
	OP_ADR_NE(l_v4973, NULL, l_v4974);
	if (l_v4974) {
		l_v5107 = l_v4973;
		goto block3;
	}
	goto block2;

    block2:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_major_collection");
	l_v5107 = NULL;
	goto block3;

    block3:
	OP_TRACK_ALLOC_START(l_v5107, /* nothing */);
	l_v4954 = (struct pypy_rpython_memory_support_AddressStack0 *)l_v5107;
	l_v4978 = (l_v4954 != NULL);
	if (!l_v4978) {
		goto block45;
	}
	goto block4;

    block4:
	l_v4979 = (struct pypy_nongcobject0 *)l_v4954;
	RPyField(l_v4979, n_typeptr) = (&pypy_g_rpython_memory_support_AddressStack_vtable.as_super);
	l_v4981 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v4982 = (l_v4981 != NULL);
	if (l_v4982) {
		goto block44;
	}
	goto block5;

    block5:
	OP_RAW_MALLOC(sizeof(struct pypy_AddressChunk0), l_v4957, void *);
	OP_ADR_NE(l_v4957, NULL, l_v4983);
	if (l_v4983) {
		goto block9;
	}
	goto block6;

    block6:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_major_collection");
	goto block7;

    block7:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_major_collection");
	goto block8;

    block8:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block9:
	l_v4955 = (struct pypy_AddressChunk0 *)l_v4957;
	l_v4958 = (l_v4955 != NULL);
	goto block10;

    block10:
	if (!l_v4958) {
		goto block7;
	}
	l_v5108 = l_v4955;
	goto block11;

    block11:
	RPyField(l_v4954, as_inst_chunk) = l_v5108;
	l_v4988 = RPyField(l_v4954, as_inst_chunk);
	RPyField(l_v4988, ac_next) = ((struct pypy_AddressChunk0 *) NULL);
	RPyField(l_v4954, as_inst_used_in_last_chunk) = 0L;
	RPyField(l_self_96, mmgc_inst_objects_to_trace) = l_v4954;
	pypy_g_MiniMarkGC_collect_roots(l_self_96);
	l_v4993 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4994 = (l_v4993 == NULL);
	if (!l_v4994) {
		goto block43;
	}
	goto block12;

    block12:
	pypy_g_MiniMarkGC_visit_all_objects(l_self_96);
	l_v4996 = (&pypy_g_ExcData)->ed_exc_type;
	l_v4997 = (l_v4996 == NULL);
	if (!l_v4997) {
		goto block42;
	}
	goto block13;

    block13:
	l_v4956 = RPyField(l_self_96, mmgc_inst_objects_with_finalizers);
	l_v4998 = RPyField(l_v4956, ad_inst_oldest_chunk);
	l_v4999 = RPyField(l_v4956, ad_inst_newest_chunk);
	l_v5000 = (l_v4998 != l_v4999);
	if (l_v5000) {
		goto block40;
	}
	goto block14;

    block14:
	l_v5001 = RPyField(l_v4956, ad_inst_index_in_oldest);
	l_v5002 = RPyField(l_v4956, ad_inst_index_in_newest);
	OP_INT_LT(l_v5001, l_v5002, l_v5003);
	if (l_v5003) {
		goto block40;
	}
	goto block15;

    block15:
	l_self_97 = RPyField(l_self_96, mmgc_inst_objects_to_trace);
	l_v5004 = RPyField(l_self_97, as_inst_chunk);
	l_cur_2 = l_v5004;
	goto block16;

    block16:
	while (1) {
		l_v5005 = (l_cur_2 != NULL);
		if (!l_v5005) break;
		goto block39;
	  block16_back: ;
	}
	goto block17;

    block17:
	l_v5006 = (void*)l_self_97;
	OP_TRACK_ALLOC_STOP(l_v5006, /* nothing */);
	OP_RAW_FREE(l_v5006, /* nothing */);
	l_v5009 = RPyField(l_self_96, mmgc_inst_old_objects_with_weakrefs);
	l_v5010 = RPyField(l_v5009, as_inst_used_in_last_chunk);
	OP_INT_NE(l_v5010, 0L, l_v5011);
	if (l_v5011) {
		goto block37;
	}
	goto block18;

    block18:
	l_v5012 = RPyField(l_self_96, mmgc_inst_old_objects_with_light_finalizers);
	l_v5013 = RPyField(l_v5012, as_inst_used_in_last_chunk);
	OP_INT_NE(l_v5013, 0L, l_v5014);
	if (l_v5014) {
		goto block35;
	}
	goto block19;

    block19:
	pypy_g_MiniMarkGC_free_unvisited_rawmalloc_objects(l_self_96);
	l_v5016 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5017 = (l_v5016 == NULL);
	if (!l_v5017) {
		goto block34;
	}
	goto block20;

    block20:
	pypy_g_ArenaCollection_mass_free((&pypy_g_rpython_memory_gc_minimarkpage_ArenaCollection), l_self_96);
	l_v5019 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5020 = (l_v5019 == NULL);
	if (!l_v5020) {
		goto block33;
	}
	goto block21;

    block21:
	pypy_g_foreach___reset_gcflag_visited((&pypy_g_rpython_memory_support_AddressStack_2), l_self_96);
	l_v5022 = RPyField(l_self_96, mmgc_inst_DEBUG);
	OP_INT_IS_TRUE(l_v5022, l_v5023);
	if (l_v5023) {
		goto block29;
	}
	goto block22;

    block22:
	l_v5024 = RPyField(l_self_96, mmgc_inst_num_major_collects);
	OP_INT_ADD(l_v5024, 1L, l_v5025);
	RPyField(l_self_96, mmgc_inst_num_major_collects) = l_v5025;
	if (PYPY_HAVE_DEBUG_PRINTS) { fprintf(PYPY_DEBUG_FILE, "| used after collection:\012"); }
	l_v5028 = (&pypy_g_rpython_memory_gc_minimarkpage_ArenaCollection)->ac_inst_total_memory_used;
	if (PYPY_HAVE_DEBUG_PRINTS) { fprintf(PYPY_DEBUG_FILE, "|          in ArenaCollection:      %lu bytes\012", l_v5028); }
	l_v5030 = RPyField(l_self_96, mmgc_inst_rawmalloced_total_size);
	if (PYPY_HAVE_DEBUG_PRINTS) { fprintf(PYPY_DEBUG_FILE, "|          raw_malloced:            %lu bytes\012", l_v5030); }
	l_v5032 = RPyField(l_self_96, mmgc_inst_num_major_collects);
	if (PYPY_HAVE_DEBUG_PRINTS) { fprintf(PYPY_DEBUG_FILE, "| number of major collects:         %ld\012", l_v5032); }
	if (PYPY_HAVE_DEBUG_PRINTS) { fprintf(PYPY_DEBUG_FILE, "`----------------------------------------------\012"); }
	PYPY_DEBUG_STOP("gc-collect");
	l_v5036 = (&pypy_g_rpython_memory_gc_minimarkpage_ArenaCollection)->ac_inst_total_memory_used;
	l_v5037 = RPyField(l_self_96, mmgc_inst_rawmalloced_total_size);
	OP_UINT_ADD(l_v5036, l_v5037, l_v5038);
	OP_CAST_UINT_TO_FLOAT(l_v5038, l_v5039);
	l_v5040 = RPyField(l_self_96, mmgc_inst_major_collection_threshold);
	OP_FLOAT_MUL(l_v5039, l_v5040, l_v5041);
	l_v5042 = RPyField(l_self_96, mmgc_inst_max_delta);
	OP_FLOAT_ADD(l_v5039, l_v5042, l_v5043);
	OP_FLOAT_LT(l_v5041, l_v5043, l_v5044);
	if (l_v5044) {
		l_v5109 = l_v5041;
		goto block23;
	}
	l_v5109 = l_v5043;
	goto block23;

    block23:
	l_v5045 = pypy_g_MiniMarkGC_set_major_threshold_from(l_self_96, l_v5109, l_reserving_size_2);
	if (l_v5045) {
		goto block25;
	}
	goto block24;

    block24:
	pypy_g_GCBase_execute_finalizers(l_self_96);
	goto block8;

    block25:
	l_v5047 = (&pypy_g_rpython_memory_gc_minimarkpage_ArenaCollection)->ac_inst_total_memory_used;
	l_v5048 = RPyField(l_self_96, mmgc_inst_rawmalloced_total_size);
	OP_UINT_ADD(l_v5047, l_v5048, l_v5049);
	OP_CAST_UINT_TO_FLOAT(l_v5049, l_v5050);
	OP_CAST_INT_TO_FLOAT(l_reserving_size_2, l_v5051);
	OP_FLOAT_ADD(l_v5050, l_v5051, l_v5052);
	l_v5053 = RPyField(l_self_96, mmgc_inst_next_major_collection_initial);
	OP_FLOAT_GE(l_v5052, l_v5053, l_v5054);
	if (l_v5054) {
		goto block26;
	}
	goto block24;

    block26:
	l_v5055 = RPyField(l_self_96, mmgc_inst_max_heap_size_already_raised);
	if (l_v5055) {
		goto block28;
	}
	goto block27;

    block27:
	RPyField(l_self_96, mmgc_inst_max_heap_size_already_raised) = 1;
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_major_collection");
	goto block8;

    block28:
	fprintf(stderr, "%s\n", "Using too much memory, aborting"); abort();
	goto block27;

    block29:
	l_v5060 = RPyField(l_self_96, mmgc_inst_young_rawmalloced_objects);
	l_v5061 = (l_v5060 != NULL);
	if (l_v5061) {
		l_v5110 = 0;
		goto block30;
	}
	l_v5110 = 1;
	goto block30;

    block30:
	RPyAssert(l_v5110, "young raw-malloced objects in a major collection");
	l_v5063 = RPyField(l_self_96, mmgc_inst_young_objects_with_weakrefs);
	l_v5064 = RPyField(l_v5063, as_inst_used_in_last_chunk);
	OP_INT_NE(l_v5064, 0L, l_v5065);
	if (l_v5065) {
		l_v5111 = 0;
		goto block31;
	}
	l_v5111 = 1;
	goto block31;

    block31:
	RPyAssert(l_v5111, "young objects with weakrefs in a major collection");
	pypy_g_GCBase_debug_check_consistency(l_self_96);
	l_v5068 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5069 = (l_v5068 == NULL);
	if (!l_v5069) {
		goto block32;
	}
	goto block22;

    block32:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_major_collection");
	goto block8;

    block33:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_major_collection");
	goto block8;

    block34:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_major_collection");
	goto block8;

    block35:
	pypy_g_MiniMarkGC_deal_with_old_objects_with_finalizers(l_self_96);
	l_v5074 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5075 = (l_v5074 == NULL);
	if (!l_v5075) {
		goto block36;
	}
	goto block19;

    block36:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_major_collection");
	goto block8;

    block37:
	pypy_g_MiniMarkGC_invalidate_old_weakrefs(l_self_96);
	l_v5078 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5079 = (l_v5078 == NULL);
	if (!l_v5079) {
		goto block38;
	}
	goto block18;

    block38:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_major_collection");
	goto block8;

    block39:
	l_v5081 = RPyField(l_cur_2, ac_next);
	l_v5082 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	RPyField(l_cur_2, ac_next) = l_v5082;
	(&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list = l_cur_2;
	l_cur_2 = l_v5081;
	goto block16_back;

    block40:
	pypy_g_MiniMarkGC_deal_with_objects_with_finalizers(l_self_96);
	l_v5086 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5087 = (l_v5086 == NULL);
	if (!l_v5087) {
		goto block41;
	}
	goto block15;

    block41:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_major_collection");
	goto block8;

    block42:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_major_collection");
	goto block8;

    block43:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_major_collection");
	goto block8;

    block44:
	l_v5091 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v5092 = RPyField(l_v5091, ac_next);
	(&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list = l_v5092;
	l_v5108 = l_v5091;
	goto block11;

    block45:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_major_collection");
	goto block8;

    block46:
	l_v5095 = RPyField(l_self_96, mmgc_inst_young_rawmalloced_objects);
	l_v5096 = (l_v5095 != NULL);
	if (l_v5096) {
		l_v5112 = 0;
		goto block47;
	}
	l_v5112 = 1;
	goto block47;

    block47:
	RPyAssert(l_v5112, "young raw-malloced objects in a major collection");
	l_v5098 = RPyField(l_self_96, mmgc_inst_young_objects_with_weakrefs);
	l_v5099 = RPyField(l_v5098, as_inst_used_in_last_chunk);
	OP_INT_NE(l_v5099, 0L, l_v5100);
	if (l_v5100) {
		l_v5113 = 0;
		goto block48;
	}
	l_v5113 = 1;
	goto block48;

    block48:
	RPyAssert(l_v5113, "young objects with weakrefs in a major collection");
	pypy_g_GCBase_debug_check_consistency(l_self_96);
	l_v5103 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5104 = (l_v5103 == NULL);
	if (!l_v5104) {
		goto block49;
	}
	goto block1;

    block49:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_major_collection");
	goto block8;
}
/*/*/
void pypy_g_MiniMarkGC__visit_young_rawmalloced_object(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_24, void* l_addr_10) {
	bool_t l_added_somewhere_0; struct pypy_header0 *l_hdr_0;
	Signed l_used_23; Signed l_used_24; Signed l_v5115; Signed l_v5116;
	Signed l_v5118; Signed l_v5119; Signed l_v5121; Signed l_v5122;
	Signed l_v5124; Signed l_v5125; Signed l_v5128; Signed l_v5129;
	Signed l_v5132; Signed l_v5137; Signed l_v5143; Signed l_v5148;
	bool_t l_v5117; bool_t l_v5123; bool_t l_v5126; bool_t l_v5130;
	bool_t l_v5133; bool_t l_v5141; bool_t l_v5144; bool_t l_v5152;
	bool_t l_v5155; struct pypy_AddressChunk0 *l_v5134;
	struct pypy_AddressChunk0 *l_v5145;
	struct pypy_object_vtable0 *l_v5140;
	struct pypy_object_vtable0 *l_v5151; void* *l_v5135; void* *l_v5146;
	void* l_v5114;
	goto block0;

    block0:
	OP_ADR_SUB(l_addr_10, 0, l_v5114);
	l_hdr_0 = (struct pypy_header0 *)l_v5114;
	l_v5115 = RPyField(l_hdr_0, h_tid);
	OP_INT_AND(l_v5115, 262144L, l_v5116);
	OP_INT_IS_TRUE(l_v5116, l_v5117);
	if (l_v5117) {
		goto block4;
	}
	goto block1;

    block1:
	l_v5118 = RPyField(l_hdr_0, h_tid);
	OP_INT_OR(l_v5118, 262144L, l_v5119);
	RPyField(l_hdr_0, h_tid) = l_v5119;
	l_v5121 = RPyField(l_hdr_0, h_tid);
	OP_INT_AND(l_v5121, 65536L, l_v5122);
	OP_INT_EQ(l_v5122, 0L, l_v5123);
	if (l_v5123) {
		goto block9;
	}
	l_added_somewhere_0 = 0;
	goto block2;

    block2:
	l_v5124 = RPyField(l_hdr_0, h_tid);
	OP_INT_AND(l_v5124, 4194304L, l_v5125);
	OP_INT_NE(l_v5125, 0L, l_v5126);
	if (l_v5126) {
		goto block5;
	}
	l_v5155 = l_added_somewhere_0;
	goto block3;

    block3:
	RPyAssert(l_v5155, "wrong flag combination on young array");
	goto block4;

    block4:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block5:
	l_v5128 = RPyField(l_hdr_0, h_tid);
	OP_INT_AND(l_v5128, 8388608L, l_v5129);
	OP_INT_NE(l_v5129, 0L, l_v5130);
	RPyAssert(l_v5130, "young array: GCFLAG_HAS_CARDS without GCFLAG_CARDS_SET");
	l_v5132 = (&pypy_g_rpython_memory_support_AddressStack_1)->as_inst_used_in_last_chunk;
	OP_INT_EQ(l_v5132, 1019L, l_v5133);
	if (l_v5133) {
		goto block7;
	}
	l_used_23 = l_v5132;
	goto block6;

    block6:
	l_v5134 = (&pypy_g_rpython_memory_support_AddressStack_1)->as_inst_chunk;
	l_v5135 = RPyField(l_v5134, ac_items);
	RPyFxItem(l_v5135, l_used_23, 1019) = l_addr_10;
	OP_INT_ADD(l_used_23, 1L, l_v5137);
	(&pypy_g_rpython_memory_support_AddressStack_1)->as_inst_used_in_last_chunk = l_v5137;
	l_v5155 = 1;
	goto block3;

    block7:
	pypy_g_AddressStack_enlarge((&pypy_g_rpython_memory_support_AddressStack_1));
	l_v5140 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5141 = (l_v5140 == NULL);
	if (!l_v5141) {
		goto block8;
	}
	l_used_23 = 0L;
	goto block6;

    block8:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC__visit_young_rawmalloced_object");
	goto block4;

    block9:
	l_v5143 = (&pypy_g_rpython_memory_support_AddressStack)->as_inst_used_in_last_chunk;
	OP_INT_EQ(l_v5143, 1019L, l_v5144);
	if (l_v5144) {
		goto block11;
	}
	l_used_24 = l_v5143;
	goto block10;

    block10:
	l_v5145 = (&pypy_g_rpython_memory_support_AddressStack)->as_inst_chunk;
	l_v5146 = RPyField(l_v5145, ac_items);
	RPyFxItem(l_v5146, l_used_24, 1019) = l_addr_10;
	OP_INT_ADD(l_used_24, 1L, l_v5148);
	(&pypy_g_rpython_memory_support_AddressStack)->as_inst_used_in_last_chunk = l_v5148;
	l_added_somewhere_0 = 1;
	goto block2;

    block11:
	pypy_g_AddressStack_enlarge((&pypy_g_rpython_memory_support_AddressStack));
	l_v5151 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5152 = (l_v5151 == NULL);
	if (!l_v5152) {
		goto block12;
	}
	l_used_24 = 0L;
	goto block10;

    block12:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC__visit_young_rawmalloced_object");
	goto block4;
}
/*/*/
void* pypy_g_MiniMarkGC__malloc_out_of_nursery_nonsmall(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_98, Signed l_totalsize_18) {
	void* l_arena_1;
	struct pypy_rpython_memory_support_AddressStack0 *l_self_99;
	Signed l_used_25; Signed l_v5157; Signed l_v5158; Signed l_v5159;
	Signed l_v5170; Signed l_v5174; Signed l_v5179; Unsigned l_v5169;
	Unsigned l_v5171; Unsigned l_v5172; bool_t l_v5160; bool_t l_v5162;
	bool_t l_v5164; bool_t l_v5165; bool_t l_v5168; bool_t l_v5175;
	bool_t l_v5183; bool_t l_v5187; bool_t l_v5191;
	struct pypy_AddressChunk0 *l_v5176;
	struct pypy_object_vtable0 *l_v5182;
	struct pypy_object_vtable0 *l_v5186;
	struct pypy_object_vtable0 *l_v5190; void* *l_v5177; void* l_v5156;
	void* l_v5163; void* l_v5189; void* l_v5193;
	goto block0;

    block0:
	OP_RAW_MALLOC_USAGE(l_totalsize_18, l_v5158);
	OP_INT_AND(l_v5158, 3L, l_v5159);
	OP_INT_EQ(l_v5159, 0L, l_v5160);
	RPyAssert(l_v5160, "misaligned totalsize in _malloc_out_of_nursery_nonsmall");
	OP_RAW_MALLOC_USAGE(l_totalsize_18, l_v5157);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v5162);
	if (l_v5162) {
		goto block12;
	}
	goto block1;

    block1:
	l_v5163 = malloc(l_v5157);
	OP_ADR_NE(l_v5163, NULL, l_v5164);
	if (l_v5164) {
		l_arena_1 = l_v5163;
		goto block2;
	}
	l_arena_1 = l_v5163;
	goto block2;

    block2:
	OP_ADR_NE(l_arena_1, NULL, l_v5165);
	if (l_v5165) {
		goto block5;
	}
	goto block3;

    block3:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC__malloc_out_of_nursery_nonsmall");
	l_v5193 = NULL;
	goto block4;

    block4:
	RPY_DEBUG_RETURN();
	return l_v5193;

    block5:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v5168);
	if (l_v5168) {
		goto block10;
	}
	goto block6;

    block6:
	l_v5169 = RPyField(l_self_98, mmgc_inst_rawmalloced_total_size);
	OP_RAW_MALLOC_USAGE(l_totalsize_18, l_v5170);
	OP_CAST_INT_TO_UINT(l_v5170, l_v5171);
	OP_UINT_ADD(l_v5169, l_v5171, l_v5172);
	RPyField(l_self_98, mmgc_inst_rawmalloced_total_size) = l_v5172;
	l_self_99 = RPyField(l_self_98, mmgc_inst_old_rawmalloced_objects);
	OP_ADR_ADD(l_arena_1, 0, l_v5156);
	l_v5174 = RPyField(l_self_99, as_inst_used_in_last_chunk);
	OP_INT_EQ(l_v5174, 1019L, l_v5175);
	if (l_v5175) {
		goto block8;
	}
	l_used_25 = l_v5174;
	goto block7;

    block7:
	l_v5176 = RPyField(l_self_99, as_inst_chunk);
	l_v5177 = RPyField(l_v5176, ac_items);
	RPyFxItem(l_v5177, l_used_25, 1019) = l_v5156;
	OP_INT_ADD(l_used_25, 1L, l_v5179);
	RPyField(l_self_99, as_inst_used_in_last_chunk) = l_v5179;
	l_v5193 = l_arena_1;
	goto block4;

    block8:
	pypy_g_AddressStack_enlarge(l_self_99);
	l_v5182 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5183 = (l_v5182 == NULL);
	if (!l_v5183) {
		goto block9;
	}
	l_used_25 = 0L;
	goto block7;

    block9:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC__malloc_out_of_nursery_nonsmall");
	l_v5193 = NULL;
	goto block4;

    block10:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v5186 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5187 = (l_v5186 == NULL);
	if (!l_v5187) {
		goto block11;
	}
	goto block6;

    block11:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC__malloc_out_of_nursery_nonsmall");
	l_v5193 = NULL;
	goto block4;

    block12:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v5189 = (void*)0;
	l_v5190 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5191 = (l_v5190 == NULL);
	if (!l_v5191) {
		goto block13;
	}
	l_arena_1 = l_v5189;
	goto block2;

    block13:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC__malloc_out_of_nursery_nonsmall");
	l_v5193 = NULL;
	goto block4;
}
/*/*/
void pypy_g_MiniMarkGC_free_rawmalloced_object_if_unvisited(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_100, void* l_obj_30) {
	Signed l_allocsize_1; Signed l_allocsize_2; Signed l_used_26;
	Signed l_v5195; Signed l_v5201; Signed l_v5202; Signed l_v5206;
	Signed l_v5210; Signed l_v5214; Signed l_v5215; Signed l_v5229;
	Signed l_v5232; Signed l_v5233; Signed l_v5236; Signed l_v5241;
	Signed l_v5242; Signed l_v5245; Signed l_v5247; Signed l_v5251;
	Signed l_v5252; Signed l_v5254; Signed l_v5255; Signed l_v5263;
	Signed l_v5264; Signed l_v5266; Signed l_v5271; Unsigned l_v5219;
	Unsigned l_v5220; Unsigned l_v5221; Unsigned l_v5248;
	Unsigned l_v5249; Unsigned l_v5250; bool_t l_v5203; bool_t l_v5209;
	bool_t l_v5211; bool_t l_v5216; bool_t l_v5217; bool_t l_v5225;
	bool_t l_v5234; bool_t l_v5237; bool_t l_v5243; bool_t l_v5258;
	bool_t l_v5267; bool_t l_v5275; struct pypy_AddressChunk0 *l_v5268;
	struct pypy_header0 *l_v5200; struct pypy_header0 *l_v5205;
	struct pypy_header0 *l_v5213; struct pypy_header0 *l_v5228;
	struct pypy_header0 *l_v5262; struct pypy_object_vtable0 *l_v5208;
	struct pypy_object_vtable0 *l_v5224;
	struct pypy_object_vtable0 *l_v5257;
	struct pypy_object_vtable0 *l_v5274;
	struct pypy_rpython_memory_support_AddressStack0 *l_v5198;
	struct pypy_type_info0 *l_v5231; struct pypy_type_info0 *l_v5240;
	struct pypy_varsize_type_info0 *l_v5239; unsigned short l_v5207;
	unsigned short l_v5230; void* *l_v5269; void* l_v5194; void* l_v5196;
	void* l_v5197; void* l_v5199; void* l_v5204; void* l_v5212;
	void* l_v5227; void* l_v5246; void* l_v5253; void* l_v5256;
	void* l_v5261;
	goto block0;

    block0:
	OP_ADR_SUB(l_obj_30, 0, l_v5199);
	l_v5200 = (struct pypy_header0 *)l_v5199;
	l_v5201 = RPyField(l_v5200, h_tid);
	OP_INT_AND(l_v5201, 262144L, l_v5202);
	OP_INT_IS_TRUE(l_v5202, l_v5203);
	if (l_v5203) {
		goto block14;
	}
	goto block1;

    block1:
	OP_ADR_SUB(l_obj_30, 0, l_v5204);
	l_v5205 = (struct pypy_header0 *)l_v5204;
	l_v5206 = RPyField(l_v5205, h_tid);
	OP_EXTRACT_USHORT(l_v5206, l_v5207);
	l_v5195 = pypy_g_GCBase__get_size_for_typeid(l_self_100, l_obj_30, l_v5207);
	l_v5208 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5209 = (l_v5208 == NULL);
	if (!l_v5209) {
		goto block13;
	}
	goto block2;

    block2:
	OP_INT_ADD(0, l_v5195, l_v5210);
	OP_RAW_MALLOC_USAGE(l_v5210, l_allocsize_2);
	OP_ADR_SUB(l_obj_30, 0, l_v5197);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v5211);
	if (l_v5211) {
		goto block11;
	}
	l_v5196 = l_v5197;
	goto block3;

    block3:
	OP_ADR_SUB(l_obj_30, 0, l_v5212);
	l_v5213 = (struct pypy_header0 *)l_v5212;
	l_v5214 = RPyField(l_v5213, h_tid);
	OP_INT_AND(l_v5214, 4194304L, l_v5215);
	OP_INT_IS_TRUE(l_v5215, l_v5216);
	if (l_v5216) {
		goto block10;
	}
	l_allocsize_1 = l_allocsize_2;
	l_v5194 = l_v5196;
	goto block4;

    block4:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v5217);
	if (l_v5217) {
		goto block8;
	}
	goto block5;

    block5:
	free(l_v5194);
	goto block6;

    block6:
	l_v5219 = RPyField(l_self_100, mmgc_inst_rawmalloced_total_size);
	OP_CAST_INT_TO_UINT(l_allocsize_1, l_v5220);
	OP_UINT_SUB(l_v5219, l_v5220, l_v5221);
	RPyField(l_self_100, mmgc_inst_rawmalloced_total_size) = l_v5221;
	goto block7;

    block7:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block8:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v5224 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5225 = (l_v5224 == NULL);
	if (!l_v5225) {
		goto block9;
	}
	goto block6;

    block9:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_free_rawmalloced_object_if_unvisited");
	goto block7;

    block10:
	OP_ADR_SUB(l_obj_30, 0, l_v5227);
	l_v5228 = (struct pypy_header0 *)l_v5227;
	l_v5229 = RPyField(l_v5228, h_tid);
	OP_EXTRACT_USHORT(l_v5229, l_v5230);
	l_v5231 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_v5230);
	l_v5232 = RPyField(l_v5231, ti_infobits);
	OP_INT_AND(l_v5232, -16777216L, l_v5233);
	OP_INT_EQ(l_v5233, 1509949440L, l_v5234);
	RPyAssert(l_v5234, "invalid type_id");
	OP_INT_AND(l_v5232, 131072L, l_v5236);
	OP_INT_NE(l_v5236, 0L, l_v5237);
	RPyAssert(l_v5237, "GCFLAG_HAS_CARDS but not has_gcptr_in_varsize");
	l_v5239 = (struct pypy_varsize_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_v5230);
	l_v5240 = (struct pypy_type_info0 *)l_v5239;
	l_v5241 = RPyField(l_v5240, ti_infobits);
	OP_INT_AND(l_v5241, -16711680L, l_v5242);
	OP_INT_EQ(l_v5242, 1510014976L, l_v5243);
	RPyAssert(l_v5243, "invalid varsize type_id");
	l_v5245 = RPyField(l_v5239, vti_ofstolength);
	OP_ADR_ADD(l_obj_30, l_v5245, l_v5246);
	l_v5247 = ((Signed *) (((char *)l_v5246) + 0))[0];
	OP_CAST_INT_TO_UINT(l_v5247, l_v5248);
	OP_UINT_ADD(l_v5248, 4095UL, l_v5249);
	OP_UINT_RSHIFT(l_v5249, 12L, l_v5250);
	OP_CAST_UINT_TO_INT(l_v5250, l_v5251);
	OP_INT_MUL(l_v5251, 4L, l_v5252);
	OP_ADR_SUB(l_v5196, l_v5252, l_v5253);
	OP_INT_MUL(l_v5251, 4L, l_v5254);
	OP_INT_ADD(l_allocsize_2, l_v5254, l_v5255);
	l_allocsize_1 = l_v5255;
	l_v5194 = l_v5253;
	goto block4;

    block11:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v5256 = (void*)0;
	l_v5257 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5258 = (l_v5257 == NULL);
	if (!l_v5258) {
		goto block12;
	}
	l_v5196 = l_v5256;
	goto block3;

    block12:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_free_rawmalloced_object_if_unvisited");
	goto block7;

    block13:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_free_rawmalloced_object_if_unvisited");
	goto block7;

    block14:
	OP_ADR_SUB(l_obj_30, 0, l_v5261);
	l_v5262 = (struct pypy_header0 *)l_v5261;
	l_v5263 = RPyField(l_v5262, h_tid);
	OP_INT_AND(l_v5263, -262145L, l_v5264);
	RPyField(l_v5262, h_tid) = l_v5264;
	l_v5198 = RPyField(l_self_100, mmgc_inst_old_rawmalloced_objects);
	l_v5266 = RPyField(l_v5198, as_inst_used_in_last_chunk);
	OP_INT_EQ(l_v5266, 1019L, l_v5267);
	if (l_v5267) {
		goto block16;
	}
	l_used_26 = l_v5266;
	goto block15;

    block15:
	l_v5268 = RPyField(l_v5198, as_inst_chunk);
	l_v5269 = RPyField(l_v5268, ac_items);
	RPyFxItem(l_v5269, l_used_26, 1019) = l_obj_30;
	OP_INT_ADD(l_used_26, 1L, l_v5271);
	RPyField(l_v5198, as_inst_used_in_last_chunk) = l_v5271;
	goto block7;

    block16:
	pypy_g_AddressStack_enlarge(l_v5198);
	l_v5274 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5275 = (l_v5274 == NULL);
	if (!l_v5275) {
		goto block17;
	}
	l_used_26 = 0L;
	goto block15;

    block17:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_free_rawmalloced_object_if_unvisited");
	goto block7;
}
/*/*/
void pypy_g_remember_young_pointer_from_array2(void* l_addr_array_3, Signed l_index_6) {
	void* l_addr_byte_0; Signed l_byteindex_0;
	struct pypy_header0 *l_objhdr_0; Signed l_used_27; Signed l_used_28;
	Signed l_used_29; Signed l_v5278; Signed l_v5279; Signed l_v5282;
	Signed l_v5283; Signed l_v5285; Signed l_v5286; Signed l_v5288;
	Signed l_v5290; Signed l_v5292; Signed l_v5295; Signed l_v5296;
	Signed l_v5298; Signed l_v5303; Signed l_v5305; Signed l_v5306;
	Signed l_v5316; Signed l_v5321; Signed l_v5323; Signed l_v5324;
	Signed l_v5326; Signed l_v5327; Signed l_v5329; Signed l_v5330;
	Signed l_v5332; Signed l_v5337; bool_t l_v5284; bool_t l_v5287;
	bool_t l_v5291; bool_t l_v5297; bool_t l_v5299; bool_t l_v5310;
	bool_t l_v5314; bool_t l_v5317; bool_t l_v5328; bool_t l_v5333;
	bool_t l_v5341; bool_t l_v5345; char l_v5289; char l_v5293;
	struct pypy_AddressChunk0 *l_v5300;
	struct pypy_AddressChunk0 *l_v5318;
	struct pypy_AddressChunk0 *l_v5334;
	struct pypy_object_vtable0 *l_v5309;
	struct pypy_object_vtable0 *l_v5313;
	struct pypy_object_vtable0 *l_v5340;
	struct pypy_object_vtable0 *l_v5344; void* *l_v5301; void* *l_v5319;
	void* *l_v5335; void* l_v5280; void* l_v5281; void* l_v5312;
	void* l_v5348;
	goto block0;

    block0:
	OP_ADR_SUB(l_addr_array_3, 0, l_v5281);
	l_objhdr_0 = (struct pypy_header0 *)l_v5281;
	l_v5282 = RPyField(l_objhdr_0, h_tid);
	OP_INT_AND(l_v5282, 4194304L, l_v5283);
	OP_INT_EQ(l_v5283, 0L, l_v5284);
	if (l_v5284) {
		goto block11;
	}
	goto block1;

    block1:
	OP_INT_RSHIFT(l_index_6, 7L, l_v5285);
	OP_INT_RSHIFT(l_v5285, 3L, l_byteindex_0);
	OP_INT_AND(l_v5285, 7L, l_v5286);
	OP_INT_LSHIFT(1L, l_v5286, l_v5278);
	OP_ADR_SUB(l_addr_array_3, 0, l_v5280);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v5287);
	if (l_v5287) {
		goto block9;
	}
	l_v5348 = l_v5280;
	goto block2;

    block2:
	OP_INT_INVERT(l_byteindex_0, l_v5288);
	OP_ADR_ADD(l_v5348, l_v5288, l_addr_byte_0);
	l_v5289 = ((char *) (((char *)l_addr_byte_0) + 0))[0];
	OP_CAST_CHAR_TO_INT(l_v5289, l_v5279);
	OP_INT_AND(l_v5279, l_v5278, l_v5290);
	OP_INT_IS_TRUE(l_v5290, l_v5291);
	if (l_v5291) {
		goto block4;
	}
	goto block3;

    block3:
	OP_INT_OR(l_v5279, l_v5278, l_v5292);
	OP_CAST_INT_TO_CHAR(l_v5292, l_v5293);
	((char *) (((char *)l_addr_byte_0) + 0))[0] = l_v5293;
	l_v5295 = RPyField(l_objhdr_0, h_tid);
	OP_INT_AND(l_v5295, 8388608L, l_v5296);
	OP_INT_EQ(l_v5296, 0L, l_v5297);
	if (l_v5297) {
		goto block5;
	}
	goto block4;

    block4:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block5:
	l_v5298 = (&pypy_g_rpython_memory_support_AddressStack_1)->as_inst_used_in_last_chunk;
	OP_INT_EQ(l_v5298, 1019L, l_v5299);
	if (l_v5299) {
		goto block7;
	}
	l_used_27 = l_v5298;
	goto block6;

    block6:
	l_v5300 = (&pypy_g_rpython_memory_support_AddressStack_1)->as_inst_chunk;
	l_v5301 = RPyField(l_v5300, ac_items);
	RPyFxItem(l_v5301, l_used_27, 1019) = l_addr_array_3;
	OP_INT_ADD(l_used_27, 1L, l_v5303);
	(&pypy_g_rpython_memory_support_AddressStack_1)->as_inst_used_in_last_chunk = l_v5303;
	l_v5305 = RPyField(l_objhdr_0, h_tid);
	OP_INT_OR(l_v5305, 8388608L, l_v5306);
	RPyField(l_objhdr_0, h_tid) = l_v5306;
	goto block4;

    block7:
	pypy_g_AddressStack_enlarge((&pypy_g_rpython_memory_support_AddressStack_1));
	l_v5309 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5310 = (l_v5309 == NULL);
	if (!l_v5310) {
		goto block8;
	}
	l_used_27 = 0L;
	goto block6;

    block8:
	PYPY_DEBUG_RECORD_TRACEBACK("remember_young_pointer_from_array2");
	goto block4;

    block9:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v5312 = (void*)0;
	l_v5313 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5314 = (l_v5313 == NULL);
	if (!l_v5314) {
		goto block10;
	}
	l_v5348 = l_v5312;
	goto block2;

    block10:
	PYPY_DEBUG_RECORD_TRACEBACK("remember_young_pointer_from_array2");
	goto block4;

    block11:
	l_v5316 = (&pypy_g_rpython_memory_support_AddressStack)->as_inst_used_in_last_chunk;
	OP_INT_EQ(l_v5316, 1019L, l_v5317);
	if (l_v5317) {
		goto block17;
	}
	l_used_28 = l_v5316;
	goto block12;

    block12:
	l_v5318 = (&pypy_g_rpython_memory_support_AddressStack)->as_inst_chunk;
	l_v5319 = RPyField(l_v5318, ac_items);
	RPyFxItem(l_v5319, l_used_28, 1019) = l_addr_array_3;
	OP_INT_ADD(l_used_28, 1L, l_v5321);
	(&pypy_g_rpython_memory_support_AddressStack)->as_inst_used_in_last_chunk = l_v5321;
	l_v5323 = RPyField(l_objhdr_0, h_tid);
	OP_INT_AND(l_v5323, -65537L, l_v5324);
	RPyField(l_objhdr_0, h_tid) = l_v5324;
	l_v5326 = RPyField(l_objhdr_0, h_tid);
	OP_INT_AND(l_v5326, 131072L, l_v5327);
	OP_INT_IS_TRUE(l_v5327, l_v5328);
	if (l_v5328) {
		goto block13;
	}
	goto block4;

    block13:
	l_v5329 = RPyField(l_objhdr_0, h_tid);
	OP_INT_AND(l_v5329, -131073L, l_v5330);
	RPyField(l_objhdr_0, h_tid) = l_v5330;
	l_v5332 = (&pypy_g_rpython_memory_support_AddressStack_2)->as_inst_used_in_last_chunk;
	OP_INT_EQ(l_v5332, 1019L, l_v5333);
	if (l_v5333) {
		goto block15;
	}
	l_used_29 = l_v5332;
	goto block14;

    block14:
	l_v5334 = (&pypy_g_rpython_memory_support_AddressStack_2)->as_inst_chunk;
	l_v5335 = RPyField(l_v5334, ac_items);
	RPyFxItem(l_v5335, l_used_29, 1019) = l_addr_array_3;
	OP_INT_ADD(l_used_29, 1L, l_v5337);
	(&pypy_g_rpython_memory_support_AddressStack_2)->as_inst_used_in_last_chunk = l_v5337;
	goto block4;

    block15:
	pypy_g_AddressStack_enlarge((&pypy_g_rpython_memory_support_AddressStack_2));
	l_v5340 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5341 = (l_v5340 == NULL);
	if (!l_v5341) {
		goto block16;
	}
	l_used_29 = 0L;
	goto block14;

    block16:
	PYPY_DEBUG_RECORD_TRACEBACK("remember_young_pointer_from_array2");
	goto block4;

    block17:
	pypy_g_AddressStack_enlarge((&pypy_g_rpython_memory_support_AddressStack));
	l_v5344 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5345 = (l_v5344 == NULL);
	if (!l_v5345) {
		goto block18;
	}
	l_used_28 = 0L;
	goto block12;

    block18:
	PYPY_DEBUG_RECORD_TRACEBACK("remember_young_pointer_from_array2");
	goto block4;
}
/*/*/
void pypy_g_MiniMarkGC_collect_roots(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_101) {
	bool_t l_v5352; bool_t l_v5355; struct pypy_object_vtable0 *l_v5351;
	struct pypy_object_vtable0 *l_v5354;
	struct pypy_rpython_memory_support_AddressDeque0 *l_v5356;
	struct pypy_rpython_memory_support_AddressStack0 *l_v5349;
	struct pypy_rpython_memory_support_AddressStack0 *l_v5357;
	goto block0;

    block0:
	l_v5349 = RPyField(l_self_101, mmgc_inst_objects_to_trace);
	pypy_g_foreach___collect_obj((&pypy_g_rpython_memory_support_AddressStack_2), l_v5349);
	l_v5351 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5352 = (l_v5351 == NULL);
	if (!l_v5352) {
		goto block5;
	}
	goto block1;

    block1:
	pypy_g_walk_roots(pypy_g_MiniMarkGC__collect_ref_stk, pypy_g_MiniMarkGC__collect_ref_stk, ((void (*)(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *, void*)) NULL));
	l_v5354 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5355 = (l_v5354 == NULL);
	if (!l_v5355) {
		goto block4;
	}
	goto block2;

    block2:
	l_v5356 = RPyField(l_self_101, mmgc_inst_run_finalizers);
	l_v5357 = RPyField(l_self_101, mmgc_inst_objects_to_trace);
	pypy_g_foreach___collect_obj_1(l_v5356, l_v5357);
	goto block3;

    block3:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block4:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_collect_roots");
	goto block3;

    block5:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_collect_roots");
	goto block3;
}
/*/*/
void pypy_g_MiniMarkGC_visit_all_objects(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_103) {
	struct pypy_rpython_memory_support_AddressStack0 *l_self_102;
	Signed l_v5364; Signed l_v5366; Signed l_v5367; Signed l_v5375;
	Signed l_v5376; Signed l_v5378; Signed l_v5379; bool_t l_v5365;
	bool_t l_v5368; bool_t l_v5373; bool_t l_v5377; bool_t l_v5383;
	bool_t l_v5387; struct pypy_AddressChunk0 *l_v5370;
	struct pypy_AddressChunk0 *l_v5385;
	struct pypy_AddressChunk0 *l_v5386; struct pypy_header0 *l_v5363;
	struct pypy_object_vtable0 *l_v5382; void* *l_v5371; void* l_v5362;
	void* l_v5374;
	goto block0;

    block0:
	l_self_102 = RPyField(l_self_103, mmgc_inst_objects_to_trace);
	goto block1;

    block1:
	while (1) {
		l_v5364 = RPyField(l_self_102, as_inst_used_in_last_chunk);
		OP_INT_NE(l_v5364, 0L, l_v5365);
		if (!l_v5365) break;
		goto block3;
	  block1_back: ;
	}
	goto block2;

    block2:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block3:
	l_v5366 = RPyField(l_self_102, as_inst_used_in_last_chunk);
	OP_INT_SUB(l_v5366, 1L, l_v5367);
	OP_INT_GE(l_v5367, 0L, l_v5368);
	RPyAssert(l_v5368, "pop on empty AddressStack");
	l_v5370 = RPyField(l_self_102, as_inst_chunk);
	l_v5371 = RPyField(l_v5370, ac_items);
	l_v5362 = RPyFxItem(l_v5371, l_v5367, 1019);
	RPyField(l_self_102, as_inst_used_in_last_chunk) = l_v5367;
	OP_INT_EQ(l_v5367, 0L, l_v5373);
	if (l_v5373) {
		goto block7;
	}
	goto block4;

    block4:
	OP_ADR_SUB(l_v5362, 0, l_v5374);
	l_v5363 = (struct pypy_header0 *)l_v5374;
	l_v5375 = RPyField(l_v5363, h_tid);
	OP_INT_AND(l_v5375, 393216L, l_v5376);
	OP_INT_IS_TRUE(l_v5376, l_v5377);
	if (l_v5377) {
		goto block1_back;
	}
	goto block5;

    block5:
	l_v5378 = RPyField(l_v5363, h_tid);
	OP_INT_OR(l_v5378, 262144L, l_v5379);
	RPyField(l_v5363, h_tid) = l_v5379;
	pypy_g_trace___collect_ref_rec(l_self_103, l_v5362, l_self_103);
	l_v5382 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5383 = (l_v5382 == NULL);
	if (!l_v5383) {
		goto block6;
	}
	goto block1;

    block6:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_visit_all_objects");
	goto block2;

    block7:
	l_v5385 = RPyField(l_self_102, as_inst_chunk);
	l_v5386 = RPyField(l_v5385, ac_next);
	l_v5387 = (l_v5386 != NULL);
	if (l_v5387) {
		goto block8;
	}
	goto block4;

    block8:
	pypy_g_AddressStack_shrink(l_self_102);
	goto block4;
}
/*/*/
void pypy_g_MiniMarkGC_free_unvisited_rawmalloc_objects(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_36) {
	struct pypy_AddressChunk0 *l_cur_3;
	struct pypy_rpython_memory_support_AddressStack0 *l_list_0;
	Signed l_v5414; Signed l_v5425; Signed l_v5426; bool_t l_v5393;
	bool_t l_v5396; bool_t l_v5400; bool_t l_v5404; bool_t l_v5405;
	bool_t l_v5415; bool_t l_v5417; bool_t l_v5427; bool_t l_v5432;
	bool_t l_v5435; bool_t l_v5439; struct pypy_AddressChunk0 *l_v5392;
	struct pypy_AddressChunk0 *l_v5403;
	struct pypy_AddressChunk0 *l_v5410;
	struct pypy_AddressChunk0 *l_v5416;
	struct pypy_AddressChunk0 *l_v5421;
	struct pypy_AddressChunk0 *l_v5422;
	struct pypy_AddressChunk0 *l_v5429;
	struct pypy_AddressChunk0 *l_v5437;
	struct pypy_AddressChunk0 *l_v5438;
	struct pypy_AddressChunk0 *l_v5441;
	struct pypy_AddressChunk0 *l_v5442;
	struct pypy_AddressChunk0 *l_v5447;
	struct pypy_nongcobject0 *l_v5401;
	struct pypy_object_vtable0 *l_v5434;
	struct pypy_rpython_memory_support_AddressStack0 *l_v5390;
	void* *l_v5430; void* l_v5391; void* l_v5394; void* l_v5395;
	void* l_v5418; void* l_v5446;
	goto block0;

    block0:
	l_list_0 = RPyField(l_self_36, mmgc_inst_old_rawmalloced_objects);
	OP_RAW_MALLOC(sizeof(struct pypy_rpython_memory_support_AddressStack0), l_v5395, void *);
	OP_ADR_NE(l_v5395, NULL, l_v5396);
	if (l_v5396) {
		l_v5446 = l_v5395;
		goto block2;
	}
	goto block1;

    block1:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_free_unvisited_rawmalloc_objects");
	l_v5446 = NULL;
	goto block2;

    block2:
	OP_TRACK_ALLOC_START(l_v5446, /* nothing */);
	l_v5390 = (struct pypy_rpython_memory_support_AddressStack0 *)l_v5446;
	l_v5400 = (l_v5390 != NULL);
	if (!l_v5400) {
		goto block22;
	}
	goto block3;

    block3:
	l_v5401 = (struct pypy_nongcobject0 *)l_v5390;
	RPyField(l_v5401, n_typeptr) = (&pypy_g_rpython_memory_support_AddressStack_vtable.as_super);
	l_v5403 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v5404 = (l_v5403 != NULL);
	if (l_v5404) {
		goto block21;
	}
	goto block4;

    block4:
	OP_RAW_MALLOC(sizeof(struct pypy_AddressChunk0), l_v5394, void *);
	OP_ADR_NE(l_v5394, NULL, l_v5405);
	if (l_v5405) {
		goto block8;
	}
	goto block5;

    block5:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_free_unvisited_rawmalloc_objects");
	goto block6;

    block6:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_free_unvisited_rawmalloc_objects");
	goto block7;

    block7:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block8:
	l_v5392 = (struct pypy_AddressChunk0 *)l_v5394;
	l_v5393 = (l_v5392 != NULL);
	goto block9;

    block9:
	if (!l_v5393) {
		goto block6;
	}
	l_v5447 = l_v5392;
	goto block10;

    block10:
	RPyField(l_v5390, as_inst_chunk) = l_v5447;
	l_v5410 = RPyField(l_v5390, as_inst_chunk);
	RPyField(l_v5410, ac_next) = ((struct pypy_AddressChunk0 *) NULL);
	RPyField(l_v5390, as_inst_used_in_last_chunk) = 0L;
	RPyField(l_self_36, mmgc_inst_old_rawmalloced_objects) = l_v5390;
	goto block11;

    block11:
	while (1) {
		l_v5414 = RPyField(l_list_0, as_inst_used_in_last_chunk);
		OP_INT_NE(l_v5414, 0L, l_v5415);
		if (!l_v5415) break;
		goto block16;
	  block11_back: ;
	}
	goto block12;

    block12:
	l_v5416 = RPyField(l_list_0, as_inst_chunk);
	l_cur_3 = l_v5416;
	goto block13;

    block13:
	while (1) {
		l_v5417 = (l_cur_3 != NULL);
		if (!l_v5417) break;
		goto block15;
	  block13_back: ;
	}
	goto block14;

    block14:
	l_v5418 = (void*)l_list_0;
	OP_TRACK_ALLOC_STOP(l_v5418, /* nothing */);
	OP_RAW_FREE(l_v5418, /* nothing */);
	goto block7;

    block15:
	l_v5421 = RPyField(l_cur_3, ac_next);
	l_v5422 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	RPyField(l_cur_3, ac_next) = l_v5422;
	(&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list = l_cur_3;
	l_cur_3 = l_v5421;
	goto block13_back;

    block16:
	l_v5425 = RPyField(l_list_0, as_inst_used_in_last_chunk);
	OP_INT_SUB(l_v5425, 1L, l_v5426);
	OP_INT_GE(l_v5426, 0L, l_v5427);
	RPyAssert(l_v5427, "pop on empty AddressStack");
	l_v5429 = RPyField(l_list_0, as_inst_chunk);
	l_v5430 = RPyField(l_v5429, ac_items);
	l_v5391 = RPyFxItem(l_v5430, l_v5426, 1019);
	RPyField(l_list_0, as_inst_used_in_last_chunk) = l_v5426;
	OP_INT_EQ(l_v5426, 0L, l_v5432);
	if (l_v5432) {
		goto block19;
	}
	goto block17;

    block17:
	pypy_g_MiniMarkGC_free_rawmalloced_object_if_unvisited(l_self_36, l_v5391);
	l_v5434 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5435 = (l_v5434 == NULL);
	if (!l_v5435) {
		goto block18;
	}
	goto block11_back;

    block18:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_free_unvisited_rawmalloc_objects");
	goto block7;

    block19:
	l_v5437 = RPyField(l_list_0, as_inst_chunk);
	l_v5438 = RPyField(l_v5437, ac_next);
	l_v5439 = (l_v5438 != NULL);
	if (l_v5439) {
		goto block20;
	}
	goto block17;

    block20:
	pypy_g_AddressStack_shrink(l_list_0);
	goto block17;

    block21:
	l_v5441 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v5442 = RPyField(l_v5441, ac_next);
	(&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list = l_v5442;
	l_v5447 = l_v5441;
	goto block10;

    block22:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_free_unvisited_rawmalloc_objects");
	goto block7;
}
/*/*/
void pypy_g_MiniMarkGC_deal_with_old_objects_with_finalizers(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_104) {
	void* l_addr_11; struct pypy_AddressChunk0 *l_cur_4;
	struct pypy_rpython_memory_support_AddressStack0 *l_new_objects_0;
	struct pypy_rpython_memory_support_AddressStack0 *l_self_105;
	struct pypy_rpython_memory_support_AddressStack0 *l_self_106;
	Signed l_used_30; Signed l_v5471; Signed l_v5483; Signed l_v5484;
	Signed l_v5493; Signed l_v5494; Signed l_v5498; Signed l_v5500;
	Signed l_v5501; Signed l_v5504; Signed l_v5514; Signed l_v5519;
	bool_t l_v5448; bool_t l_v5453; bool_t l_v5457; bool_t l_v5461;
	bool_t l_v5462; bool_t l_v5472; bool_t l_v5474; bool_t l_v5485;
	bool_t l_v5490; bool_t l_v5495; bool_t l_v5502; bool_t l_v5505;
	bool_t l_v5509; bool_t l_v5513; bool_t l_v5515; bool_t l_v5523;
	bool_t l_v5527; bool_t l_v5536; struct pypy_AddressChunk0 *l_v5451;
	struct pypy_AddressChunk0 *l_v5460;
	struct pypy_AddressChunk0 *l_v5467;
	struct pypy_AddressChunk0 *l_v5473;
	struct pypy_AddressChunk0 *l_v5479;
	struct pypy_AddressChunk0 *l_v5480;
	struct pypy_AddressChunk0 *l_v5487;
	struct pypy_AddressChunk0 *l_v5516;
	struct pypy_AddressChunk0 *l_v5525;
	struct pypy_AddressChunk0 *l_v5526;
	struct pypy_AddressChunk0 *l_v5529;
	struct pypy_AddressChunk0 *l_v5530;
	struct pypy_AddressChunk0 *l_v5535; struct pypy_header0 *l_v5492;
	struct pypy_header0 *l_v5497; struct pypy_nongcobject0 *l_v5458;
	struct pypy_object_vtable0 *l_v5508;
	struct pypy_object_vtable0 *l_v5522;
	struct pypy_rpython_memory_support_AddressStack0 *l_v5470;
	struct pypy_type_info0 *l_v5449;
	struct pypy_type_info_extra0 *l_v5511; unsigned short l_v5499;
	void (*l_v5512)(void*); void (*l_v5537)(void*); void* *l_v5488;
	void* *l_v5517; void* l_v5450; void* l_v5452; void* l_v5475;
	void* l_v5491; void* l_v5496; void* l_v5534;
	goto block0;

    block0:
	OP_RAW_MALLOC(sizeof(struct pypy_rpython_memory_support_AddressStack0), l_v5452, void *);
	OP_ADR_NE(l_v5452, NULL, l_v5453);
	if (l_v5453) {
		l_v5534 = l_v5452;
		goto block2;
	}
	goto block1;

    block1:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_deal_with_old_objects_with_finalizers");
	l_v5534 = NULL;
	goto block2;

    block2:
	OP_TRACK_ALLOC_START(l_v5534, /* nothing */);
	l_new_objects_0 = (struct pypy_rpython_memory_support_AddressStack0 *)l_v5534;
	l_v5457 = (l_new_objects_0 != NULL);
	if (!l_v5457) {
		goto block29;
	}
	goto block3;

    block3:
	l_v5458 = (struct pypy_nongcobject0 *)l_new_objects_0;
	RPyField(l_v5458, n_typeptr) = (&pypy_g_rpython_memory_support_AddressStack_vtable.as_super);
	l_v5460 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v5461 = (l_v5460 != NULL);
	if (l_v5461) {
		goto block28;
	}
	goto block4;

    block4:
	OP_RAW_MALLOC(sizeof(struct pypy_AddressChunk0), l_v5450, void *);
	OP_ADR_NE(l_v5450, NULL, l_v5462);
	if (l_v5462) {
		goto block8;
	}
	goto block5;

    block5:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_deal_with_old_objects_with_finalizers");
	goto block6;

    block6:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_deal_with_old_objects_with_finalizers");
	goto block7;

    block7:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block8:
	l_v5451 = (struct pypy_AddressChunk0 *)l_v5450;
	l_v5448 = (l_v5451 != NULL);
	goto block9;

    block9:
	if (!l_v5448) {
		goto block6;
	}
	l_v5535 = l_v5451;
	goto block10;

    block10:
	RPyField(l_new_objects_0, as_inst_chunk) = l_v5535;
	l_v5467 = RPyField(l_new_objects_0, as_inst_chunk);
	RPyField(l_v5467, ac_next) = ((struct pypy_AddressChunk0 *) NULL);
	RPyField(l_new_objects_0, as_inst_used_in_last_chunk) = 0L;
	goto block11;

    block11:
	while (1) {
		l_v5470 = RPyField(l_self_104, mmgc_inst_old_objects_with_light_finalizers);
		l_v5471 = RPyField(l_v5470, as_inst_used_in_last_chunk);
		OP_INT_NE(l_v5471, 0L, l_v5472);
		if (!l_v5472) break;
		goto block16;
	  block11_back: ;
	}
	goto block12;

    block12:
	l_self_106 = RPyField(l_self_104, mmgc_inst_old_objects_with_light_finalizers);
	l_v5473 = RPyField(l_self_106, as_inst_chunk);
	l_cur_4 = l_v5473;
	goto block13;

    block13:
	while (1) {
		l_v5474 = (l_cur_4 != NULL);
		if (!l_v5474) break;
		goto block15;
	  block13_back: ;
	}
	goto block14;

    block14:
	l_v5475 = (void*)l_self_106;
	OP_TRACK_ALLOC_STOP(l_v5475, /* nothing */);
	OP_RAW_FREE(l_v5475, /* nothing */);
	RPyField(l_self_104, mmgc_inst_old_objects_with_light_finalizers) = l_new_objects_0;
	goto block7;

    block15:
	l_v5479 = RPyField(l_cur_4, ac_next);
	l_v5480 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	RPyField(l_cur_4, ac_next) = l_v5480;
	(&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list = l_cur_4;
	l_cur_4 = l_v5479;
	goto block13_back;

    block16:
	l_self_105 = RPyField(l_self_104, mmgc_inst_old_objects_with_light_finalizers);
	l_v5483 = RPyField(l_self_105, as_inst_used_in_last_chunk);
	OP_INT_SUB(l_v5483, 1L, l_v5484);
	OP_INT_GE(l_v5484, 0L, l_v5485);
	RPyAssert(l_v5485, "pop on empty AddressStack");
	l_v5487 = RPyField(l_self_105, as_inst_chunk);
	l_v5488 = RPyField(l_v5487, ac_items);
	l_addr_11 = RPyFxItem(l_v5488, l_v5484, 1019);
	RPyField(l_self_105, as_inst_used_in_last_chunk) = l_v5484;
	OP_INT_EQ(l_v5484, 0L, l_v5490);
	if (l_v5490) {
		goto block26;
	}
	goto block17;

    block17:
	OP_ADR_SUB(l_addr_11, 0, l_v5491);
	l_v5492 = (struct pypy_header0 *)l_v5491;
	l_v5493 = RPyField(l_v5492, h_tid);
	OP_INT_AND(l_v5493, 262144L, l_v5494);
	OP_INT_IS_TRUE(l_v5494, l_v5495);
	if (l_v5495) {
		goto block22;
	}
	goto block18;

    block18:
	OP_ADR_SUB(l_addr_11, 0, l_v5496);
	l_v5497 = (struct pypy_header0 *)l_v5496;
	l_v5498 = RPyField(l_v5497, h_tid);
	OP_EXTRACT_USHORT(l_v5498, l_v5499);
	l_v5449 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_v5499);
	l_v5500 = RPyField(l_v5449, ti_infobits);
	OP_INT_AND(l_v5500, -16777216L, l_v5501);
	OP_INT_EQ(l_v5501, 1509949440L, l_v5502);
	RPyAssert(l_v5502, "invalid type_id");
	OP_INT_AND(l_v5500, 8388608L, l_v5504);
	OP_INT_IS_TRUE(l_v5504, l_v5505);
	if (l_v5505) {
		goto block21;
	}
	l_v5537 = ((void (*)(void*)) NULL);
	l_v5536 = 0;
	goto block19;

    block19:
	RPyAssert(l_v5536, "no light finalizer found");
	l_v5537(l_addr_11);
	l_v5508 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5509 = (l_v5508 == NULL);
	if (!l_v5509) {
		goto block20;
	}
	goto block11_back;

    block20:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_deal_with_old_objects_with_finalizers");
	goto block7;

    block21:
	l_v5511 = RPyField(l_v5449, ti_extra);
	l_v5512 = RPyField(l_v5511, tie_finalizer);
	l_v5513 = (l_v5512 != NULL);
	l_v5537 = l_v5512;
	l_v5536 = l_v5513;
	goto block19;

    block22:
	l_v5514 = RPyField(l_new_objects_0, as_inst_used_in_last_chunk);
	OP_INT_EQ(l_v5514, 1019L, l_v5515);
	if (l_v5515) {
		goto block24;
	}
	l_used_30 = l_v5514;
	goto block23;

    block23:
	l_v5516 = RPyField(l_new_objects_0, as_inst_chunk);
	l_v5517 = RPyField(l_v5516, ac_items);
	RPyFxItem(l_v5517, l_used_30, 1019) = l_addr_11;
	OP_INT_ADD(l_used_30, 1L, l_v5519);
	RPyField(l_new_objects_0, as_inst_used_in_last_chunk) = l_v5519;
	goto block11;

    block24:
	pypy_g_AddressStack_enlarge(l_new_objects_0);
	l_v5522 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5523 = (l_v5522 == NULL);
	if (!l_v5523) {
		goto block25;
	}
	l_used_30 = 0L;
	goto block23;

    block25:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_deal_with_old_objects_with_finalizers");
	goto block7;

    block26:
	l_v5525 = RPyField(l_self_105, as_inst_chunk);
	l_v5526 = RPyField(l_v5525, ac_next);
	l_v5527 = (l_v5526 != NULL);
	if (l_v5527) {
		goto block27;
	}
	goto block17;

    block27:
	pypy_g_AddressStack_shrink(l_self_105);
	goto block17;

    block28:
	l_v5529 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v5530 = RPyField(l_v5529, ac_next);
	(&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list = l_v5530;
	l_v5535 = l_v5529;
	goto block10;

    block29:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_deal_with_old_objects_with_finalizers");
	goto block7;
}
/*/*/
void pypy_g_MiniMarkGC_invalidate_old_weakrefs(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_107) {
	struct pypy_AddressChunk0 *l_cur_5;
	struct pypy_rpython_memory_support_AddressStack0 *l_new_with_weakref_0;
	void* l_obj_31;
	struct pypy_rpython_memory_support_AddressStack0 *l_self_108;
	Signed l_used_31; Signed l_v5540; Signed l_v5562; Signed l_v5574;
	Signed l_v5575; Signed l_v5584; Signed l_v5585; Signed l_v5589;
	Signed l_v5592; Signed l_v5593; Signed l_v5596; Signed l_v5602;
	Signed l_v5603; Signed l_v5608; Signed l_v5609; Signed l_v5613;
	Signed l_v5618; bool_t l_v5541; bool_t l_v5544; bool_t l_v5548;
	bool_t l_v5552; bool_t l_v5553; bool_t l_v5563; bool_t l_v5565;
	bool_t l_v5576; bool_t l_v5581; bool_t l_v5586; bool_t l_v5594;
	bool_t l_v5597; bool_t l_v5604; bool_t l_v5610; bool_t l_v5614;
	bool_t l_v5622; bool_t l_v5626; struct pypy_AddressChunk0 *l_v5539;
	struct pypy_AddressChunk0 *l_v5551;
	struct pypy_AddressChunk0 *l_v5558;
	struct pypy_AddressChunk0 *l_v5564;
	struct pypy_AddressChunk0 *l_v5570;
	struct pypy_AddressChunk0 *l_v5571;
	struct pypy_AddressChunk0 *l_v5578;
	struct pypy_AddressChunk0 *l_v5615;
	struct pypy_AddressChunk0 *l_v5624;
	struct pypy_AddressChunk0 *l_v5625;
	struct pypy_AddressChunk0 *l_v5628;
	struct pypy_AddressChunk0 *l_v5629;
	struct pypy_AddressChunk0 *l_v5634; struct pypy_header0 *l_v5583;
	struct pypy_header0 *l_v5588; struct pypy_header0 *l_v5601;
	struct pypy_header0 *l_v5607; struct pypy_nongcobject0 *l_v5549;
	struct pypy_object_vtable0 *l_v5621;
	struct pypy_rpython_memory_support_AddressStack0 *l_v5538;
	struct pypy_rpython_memory_support_AddressStack0 *l_v5561;
	struct pypy_type_info0 *l_v5591; unsigned short l_v5590;
	void* *l_v5579; void* *l_v5616; void* l_v5542; void* l_v5543;
	void* l_v5566; void* l_v5582; void* l_v5587; void* l_v5598;
	void* l_v5599; void* l_v5600; void* l_v5606; void* l_v5611;
	void* l_v5633;
	goto block0;

    block0:
	OP_RAW_MALLOC(sizeof(struct pypy_rpython_memory_support_AddressStack0), l_v5543, void *);
	OP_ADR_NE(l_v5543, NULL, l_v5544);
	if (l_v5544) {
		l_v5633 = l_v5543;
		goto block2;
	}
	goto block1;

    block1:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_invalidate_old_weakrefs");
	l_v5633 = NULL;
	goto block2;

    block2:
	OP_TRACK_ALLOC_START(l_v5633, /* nothing */);
	l_new_with_weakref_0 = (struct pypy_rpython_memory_support_AddressStack0 *)l_v5633;
	l_v5548 = (l_new_with_weakref_0 != NULL);
	if (!l_v5548) {
		goto block28;
	}
	goto block3;

    block3:
	l_v5549 = (struct pypy_nongcobject0 *)l_new_with_weakref_0;
	RPyField(l_v5549, n_typeptr) = (&pypy_g_rpython_memory_support_AddressStack_vtable.as_super);
	l_v5551 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v5552 = (l_v5551 != NULL);
	if (l_v5552) {
		goto block27;
	}
	goto block4;

    block4:
	OP_RAW_MALLOC(sizeof(struct pypy_AddressChunk0), l_v5542, void *);
	OP_ADR_NE(l_v5542, NULL, l_v5553);
	if (l_v5553) {
		goto block8;
	}
	goto block5;

    block5:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_invalidate_old_weakrefs");
	goto block6;

    block6:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_invalidate_old_weakrefs");
	goto block7;

    block7:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block8:
	l_v5539 = (struct pypy_AddressChunk0 *)l_v5542;
	l_v5541 = (l_v5539 != NULL);
	goto block9;

    block9:
	if (!l_v5541) {
		goto block6;
	}
	l_v5634 = l_v5539;
	goto block10;

    block10:
	RPyField(l_new_with_weakref_0, as_inst_chunk) = l_v5634;
	l_v5558 = RPyField(l_new_with_weakref_0, as_inst_chunk);
	RPyField(l_v5558, ac_next) = ((struct pypy_AddressChunk0 *) NULL);
	RPyField(l_new_with_weakref_0, as_inst_used_in_last_chunk) = 0L;
	goto block11;

    block11:
	while (1) {
		l_v5561 = RPyField(l_self_107, mmgc_inst_old_objects_with_weakrefs);
		l_v5562 = RPyField(l_v5561, as_inst_used_in_last_chunk);
		OP_INT_NE(l_v5562, 0L, l_v5563);
		if (!l_v5563) break;
		goto block16;
	  block11_back: ;
	}
	goto block12;

    block12:
	l_self_108 = RPyField(l_self_107, mmgc_inst_old_objects_with_weakrefs);
	l_v5564 = RPyField(l_self_108, as_inst_chunk);
	l_cur_5 = l_v5564;
	goto block13;

    block13:
	while (1) {
		l_v5565 = (l_cur_5 != NULL);
		if (!l_v5565) break;
		goto block15;
	  block13_back: ;
	}
	goto block14;

    block14:
	l_v5566 = (void*)l_self_108;
	OP_TRACK_ALLOC_STOP(l_v5566, /* nothing */);
	OP_RAW_FREE(l_v5566, /* nothing */);
	RPyField(l_self_107, mmgc_inst_old_objects_with_weakrefs) = l_new_with_weakref_0;
	goto block7;

    block15:
	l_v5570 = RPyField(l_cur_5, ac_next);
	l_v5571 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	RPyField(l_cur_5, ac_next) = l_v5571;
	(&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list = l_cur_5;
	l_cur_5 = l_v5570;
	goto block13_back;

    block16:
	l_v5538 = RPyField(l_self_107, mmgc_inst_old_objects_with_weakrefs);
	l_v5574 = RPyField(l_v5538, as_inst_used_in_last_chunk);
	OP_INT_SUB(l_v5574, 1L, l_v5575);
	OP_INT_GE(l_v5575, 0L, l_v5576);
	RPyAssert(l_v5576, "pop on empty AddressStack");
	l_v5578 = RPyField(l_v5538, as_inst_chunk);
	l_v5579 = RPyField(l_v5578, ac_items);
	l_obj_31 = RPyFxItem(l_v5579, l_v5575, 1019);
	RPyField(l_v5538, as_inst_used_in_last_chunk) = l_v5575;
	OP_INT_EQ(l_v5575, 0L, l_v5581);
	if (l_v5581) {
		goto block25;
	}
	goto block17;

    block17:
	OP_ADR_SUB(l_obj_31, 0, l_v5582);
	l_v5583 = (struct pypy_header0 *)l_v5582;
	l_v5584 = RPyField(l_v5583, h_tid);
	OP_INT_AND(l_v5584, 262144L, l_v5585);
	OP_INT_EQ(l_v5585, 0L, l_v5586);
	if (l_v5586) {
		goto block11_back;
	}
	goto block18;

    block18:
	OP_ADR_SUB(l_obj_31, 0, l_v5587);
	l_v5588 = (struct pypy_header0 *)l_v5587;
	l_v5589 = RPyField(l_v5588, h_tid);
	OP_EXTRACT_USHORT(l_v5589, l_v5590);
	l_v5591 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_v5590);
	l_v5592 = RPyField(l_v5591, ti_infobits);
	OP_INT_AND(l_v5592, -16777216L, l_v5593);
	OP_INT_EQ(l_v5593, 1509949440L, l_v5594);
	RPyAssert(l_v5594, "invalid type_id");
	OP_INT_AND(l_v5592, 524288L, l_v5596);
	OP_INT_IS_TRUE(l_v5596, l_v5597);
	if (l_v5597) {
		l_v5540 = offsetof(struct pypy_weakref0, w_weakptr);
		goto block19;
	}
	l_v5540 = -1L;
	goto block19;

    block19:
	OP_ADR_ADD(l_obj_31, l_v5540, l_v5598);
	l_v5599 = ((void* *) (((char *)l_v5598) + 0))[0];
	OP_ADR_SUB(l_v5599, 0, l_v5600);
	l_v5601 = (struct pypy_header0 *)l_v5600;
	l_v5602 = RPyField(l_v5601, h_tid);
	OP_INT_AND(l_v5602, 131072L, l_v5603);
	OP_INT_EQ(l_v5603, 0L, l_v5604);
	RPyAssert(l_v5604, "registered old weakref should not point to a NO_HEAP_PTRS obj");
	OP_ADR_SUB(l_v5599, 0, l_v5606);
	l_v5607 = (struct pypy_header0 *)l_v5606;
	l_v5608 = RPyField(l_v5607, h_tid);
	OP_INT_AND(l_v5608, 262144L, l_v5609);
	OP_INT_IS_TRUE(l_v5609, l_v5610);
	if (l_v5610) {
		goto block21;
	}
	goto block20;

    block20:
	OP_ADR_ADD(l_obj_31, l_v5540, l_v5611);
	((void* *) (((char *)l_v5611) + 0))[0] = NULL;
	goto block11;

    block21:
	l_v5613 = RPyField(l_new_with_weakref_0, as_inst_used_in_last_chunk);
	OP_INT_EQ(l_v5613, 1019L, l_v5614);
	if (l_v5614) {
		goto block23;
	}
	l_used_31 = l_v5613;
	goto block22;

    block22:
	l_v5615 = RPyField(l_new_with_weakref_0, as_inst_chunk);
	l_v5616 = RPyField(l_v5615, ac_items);
	RPyFxItem(l_v5616, l_used_31, 1019) = l_obj_31;
	OP_INT_ADD(l_used_31, 1L, l_v5618);
	RPyField(l_new_with_weakref_0, as_inst_used_in_last_chunk) = l_v5618;
	goto block11;

    block23:
	pypy_g_AddressStack_enlarge(l_new_with_weakref_0);
	l_v5621 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5622 = (l_v5621 == NULL);
	if (!l_v5622) {
		goto block24;
	}
	l_used_31 = 0L;
	goto block22;

    block24:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_invalidate_old_weakrefs");
	goto block7;

    block25:
	l_v5624 = RPyField(l_v5538, as_inst_chunk);
	l_v5625 = RPyField(l_v5624, ac_next);
	l_v5626 = (l_v5625 != NULL);
	if (l_v5626) {
		goto block26;
	}
	goto block17;

    block26:
	pypy_g_AddressStack_shrink(l_v5538);
	goto block17;

    block27:
	l_v5628 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v5629 = RPyField(l_v5628, ac_next);
	(&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list = l_v5629;
	l_v5634 = l_v5628;
	goto block10;

    block28:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_invalidate_old_weakrefs");
	goto block7;
}
/*/*/
void pypy_g_MiniMarkGC_deal_with_objects_with_finalizers(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_109) {
	struct pypy_AddressChunk0 *l_cur_6;
	struct pypy_AddressChunk0 *l_cur_7;
	struct pypy_AddressChunk0 *l_cur_8;
	struct pypy_AddressChunk0 *l_cur_9; Signed l_index_10;
	Signed l_index_11; Signed l_index_12; Signed l_index_13;
	Signed l_index_14; Signed l_index_9;
	struct pypy_rpython_memory_support_AddressStack0 *l_pending_0;
	struct pypy_rpython_memory_support_AddressDeque0 *l_self_110;
	struct pypy_rpython_memory_support_AddressDeque0 *l_self_111;
	struct pypy_rpython_memory_support_AddressDeque0 *l_self_114;
	struct pypy_rpython_memory_support_AddressDeque0 *l_self_115;
	struct pypy_rpython_memory_support_AddressDeque0 *l_self_116;
	struct pypy_rpython_memory_support_AddressDeque0 *l_self_117;
	struct pypy_rpython_memory_support_AddressStack0 *l_self_112;
	struct pypy_rpython_memory_support_AddressStack0 *l_self_113;
	Signed l_used_32; Signed l_used_33; Signed l_v5637; Signed l_v5639;
	Signed l_v5640; Signed l_v5646; Signed l_v5731; Signed l_v5732;
	Signed l_v5737; Signed l_v5738; Signed l_v5780; Signed l_v5781;
	Signed l_v5784; Signed l_v5788; Signed l_v5792; Signed l_v5794;
	Signed l_v5798; Signed l_v5803; Signed l_v5809; Signed l_v5814;
	Signed l_v5824; Signed l_v5830; Signed l_v5831; Signed l_v5834;
	Signed l_v5838; Signed l_v5842; Signed l_v5844; Signed l_v5849;
	Signed l_v5850; Signed l_v5852; Signed l_v5857; Signed l_v5859;
	Signed l_v5864; Signed l_v5866; Signed l_v5868; Signed l_v5873;
	Signed l_v5883; Signed l_v5884; Signed l_v5893; Signed l_v5895;
	Signed l_v5899; Signed l_v5901; Signed l_v5906; Signed l_v5907;
	Signed l_v5913; Signed l_v5915; Signed l_v5933; Signed l_v5938;
	Signed l_v5944; Signed l_v5974; bool_t l_v5636; bool_t l_v5647;
	bool_t l_v5649; bool_t l_v5650; bool_t l_v5654; bool_t l_v5658;
	bool_t l_v5662; bool_t l_v5663; bool_t l_v5673; bool_t l_v5677;
	bool_t l_v5681; bool_t l_v5682; bool_t l_v5692; bool_t l_v5696;
	bool_t l_v5700; bool_t l_v5701; bool_t l_v5710; bool_t l_v5714;
	bool_t l_v5718; bool_t l_v5719; bool_t l_v5730; bool_t l_v5733;
	bool_t l_v5736; bool_t l_v5739; bool_t l_v5741; bool_t l_v5746;
	bool_t l_v5751; bool_t l_v5756; bool_t l_v5779; bool_t l_v5782;
	bool_t l_v5785; bool_t l_v5793; bool_t l_v5795; bool_t l_v5797;
	bool_t l_v5799; bool_t l_v5807; bool_t l_v5810; bool_t l_v5818;
	bool_t l_v5822; bool_t l_v5825; bool_t l_v5829; bool_t l_v5832;
	bool_t l_v5835; bool_t l_v5843; bool_t l_v5845; bool_t l_v5851;
	bool_t l_v5853; bool_t l_v5860; bool_t l_v5867; bool_t l_v5869;
	bool_t l_v5877; bool_t l_v5881; bool_t l_v5885; bool_t l_v5890;
	bool_t l_v5894; bool_t l_v5896; bool_t l_v5900; bool_t l_v5902;
	bool_t l_v5911; bool_t l_v5914; bool_t l_v5916; bool_t l_v5919;
	bool_t l_v5923; bool_t l_v5927; bool_t l_v5931; bool_t l_v5934;
	bool_t l_v5942; bool_t l_v5945; bool_t l_v5972; bool_t l_v5973;
	bool_t l_v5975; bool_t l_v5976; bool_t l_v5977;
	struct pypy_AddressChunk0 *l_v5638;
	struct pypy_AddressChunk0 *l_v5642;
	struct pypy_AddressChunk0 *l_v5648;
	struct pypy_AddressChunk0 *l_v5652;
	struct pypy_AddressChunk0 *l_v5661;
	struct pypy_AddressChunk0 *l_v5680;
	struct pypy_AddressChunk0 *l_v5699;
	struct pypy_AddressChunk0 *l_v5706;
	struct pypy_AddressChunk0 *l_v5717;
	struct pypy_AddressChunk0 *l_v5724;
	struct pypy_AddressChunk0 *l_v5728;
	struct pypy_AddressChunk0 *l_v5729;
	struct pypy_AddressChunk0 *l_v5734;
	struct pypy_AddressChunk0 *l_v5735;
	struct pypy_AddressChunk0 *l_v5740;
	struct pypy_AddressChunk0 *l_v5745;
	struct pypy_AddressChunk0 *l_v5750;
	struct pypy_AddressChunk0 *l_v5755;
	struct pypy_AddressChunk0 *l_v5761;
	struct pypy_AddressChunk0 *l_v5762;
	struct pypy_AddressChunk0 *l_v5765;
	struct pypy_AddressChunk0 *l_v5766;
	struct pypy_AddressChunk0 *l_v5769;
	struct pypy_AddressChunk0 *l_v5770;
	struct pypy_AddressChunk0 *l_v5773;
	struct pypy_AddressChunk0 *l_v5774;
	struct pypy_AddressChunk0 *l_v5777;
	struct pypy_AddressChunk0 *l_v5778;
	struct pypy_AddressChunk0 *l_v5786;
	struct pypy_AddressChunk0 *l_v5800;
	struct pypy_AddressChunk0 *l_v5811;
	struct pypy_AddressChunk0 *l_v5827;
	struct pypy_AddressChunk0 *l_v5828;
	struct pypy_AddressChunk0 *l_v5836;
	struct pypy_AddressChunk0 *l_v5854;
	struct pypy_AddressChunk0 *l_v5861;
	struct pypy_AddressChunk0 *l_v5870;
	struct pypy_AddressChunk0 *l_v5887;
	struct pypy_AddressChunk0 *l_v5921;
	struct pypy_AddressChunk0 *l_v5922;
	struct pypy_AddressChunk0 *l_v5935;
	struct pypy_AddressChunk0 *l_v5947;
	struct pypy_AddressChunk0 *l_v5948;
	struct pypy_AddressChunk0 *l_v5951;
	struct pypy_AddressChunk0 *l_v5952;
	struct pypy_AddressChunk0 *l_v5955;
	struct pypy_AddressChunk0 *l_v5956;
	struct pypy_AddressChunk0 *l_v5959;
	struct pypy_AddressChunk0 *l_v5960;
	struct pypy_AddressChunk0 *l_v5965;
	struct pypy_AddressChunk0 *l_v5967;
	struct pypy_AddressChunk0 *l_v5969;
	struct pypy_AddressChunk0 *l_v5971; struct pypy_header0 *l_v5791;
	struct pypy_header0 *l_v5841; struct pypy_header0 *l_v5848;
	struct pypy_header0 *l_v5892; struct pypy_header0 *l_v5898;
	struct pypy_header0 *l_v5905; struct pypy_nongcobject0 *l_v5659;
	struct pypy_nongcobject0 *l_v5678; struct pypy_nongcobject0 *l_v5697;
	struct pypy_nongcobject0 *l_v5715;
	struct pypy_object_vtable0 *l_v5806;
	struct pypy_object_vtable0 *l_v5817;
	struct pypy_object_vtable0 *l_v5821;
	struct pypy_object_vtable0 *l_v5876;
	struct pypy_object_vtable0 *l_v5880;
	struct pypy_object_vtable0 *l_v5910;
	struct pypy_object_vtable0 *l_v5918;
	struct pypy_object_vtable0 *l_v5926;
	struct pypy_object_vtable0 *l_v5930;
	struct pypy_object_vtable0 *l_v5941;
	struct pypy_rpython_memory_support_AddressStack0 *l_v5644;
	void* *l_v5787; void* *l_v5801; void* *l_v5812; void* *l_v5837;
	void* *l_v5855; void* *l_v5862; void* *l_v5871; void* *l_v5888;
	void* *l_v5936; void* l_v5635; void* l_v5641; void* l_v5643;
	void* l_v5645; void* l_v5651; void* l_v5653; void* l_v5672;
	void* l_v5691; void* l_v5709; void* l_v5742; void* l_v5747;
	void* l_v5752; void* l_v5757; void* l_v5790; void* l_v5840;
	void* l_v5847; void* l_v5891; void* l_v5897; void* l_v5904;
	void* l_v5964; void* l_v5966; void* l_v5968; void* l_v5970;
	void* l_x_0; void* l_x_1;
	goto block0;

    block0:
	OP_RAW_MALLOC(sizeof(struct pypy_rpython_memory_support_AddressDeque0), l_v5653, void *);
	OP_ADR_NE(l_v5653, NULL, l_v5654);
	if (l_v5654) {
		l_v5964 = l_v5653;
		goto block2;
	}
	goto block1;

    block1:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_deal_with_objects_with_finalizers");
	l_v5964 = NULL;
	goto block2;

    block2:
	OP_TRACK_ALLOC_START(l_v5964, /* nothing */);
	l_self_111 = (struct pypy_rpython_memory_support_AddressDeque0 *)l_v5964;
	l_v5658 = (l_self_111 != NULL);
	if (!l_v5658) {
		goto block117;
	}
	goto block3;

    block3:
	l_v5659 = (struct pypy_nongcobject0 *)l_self_111;
	RPyField(l_v5659, n_typeptr) = (&pypy_g_rpython_memory_support_AddressDeque_vtable.ad_super);
	l_v5661 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v5662 = (l_v5661 != NULL);
	if (l_v5662) {
		goto block116;
	}
	goto block4;

    block4:
	OP_RAW_MALLOC(sizeof(struct pypy_AddressChunk0), l_v5641, void *);
	OP_ADR_NE(l_v5641, NULL, l_v5663);
	if (l_v5663) {
		goto block8;
	}
	goto block5;

    block5:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_deal_with_objects_with_finalizers");
	goto block6;

    block6:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_deal_with_objects_with_finalizers");
	goto block7;

    block7:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block8:
	l_v5642 = (struct pypy_AddressChunk0 *)l_v5641;
	l_v5650 = (l_v5642 != NULL);
	goto block9;

    block9:
	if (!l_v5650) {
		goto block6;
	}
	l_v5965 = l_v5642;
	goto block10;

    block10:
	RPyField(l_v5965, ac_next) = ((struct pypy_AddressChunk0 *) NULL);
	RPyField(l_self_111, ad_inst_oldest_chunk) = l_v5965;
	RPyField(l_self_111, ad_inst_newest_chunk) = l_v5965;
	RPyField(l_self_111, ad_inst_index_in_oldest) = 0L;
	RPyField(l_self_111, ad_inst_index_in_newest) = 0L;
	OP_RAW_MALLOC(sizeof(struct pypy_rpython_memory_support_AddressDeque0), l_v5672, void *);
	OP_ADR_NE(l_v5672, NULL, l_v5673);
	if (l_v5673) {
		l_v5966 = l_v5672;
		goto block12;
	}
	goto block11;

    block11:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_deal_with_objects_with_finalizers");
	l_v5966 = NULL;
	goto block12;

    block12:
	OP_TRACK_ALLOC_START(l_v5966, /* nothing */);
	l_self_110 = (struct pypy_rpython_memory_support_AddressDeque0 *)l_v5966;
	l_v5677 = (l_self_110 != NULL);
	if (!l_v5677) {
		goto block115;
	}
	goto block13;

    block13:
	l_v5678 = (struct pypy_nongcobject0 *)l_self_110;
	RPyField(l_v5678, n_typeptr) = (&pypy_g_rpython_memory_support_AddressDeque_vtable.ad_super);
	l_v5680 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v5681 = (l_v5680 != NULL);
	if (l_v5681) {
		goto block114;
	}
	goto block14;

    block14:
	OP_RAW_MALLOC(sizeof(struct pypy_AddressChunk0), l_v5651, void *);
	OP_ADR_NE(l_v5651, NULL, l_v5682);
	if (l_v5682) {
		goto block17;
	}
	goto block15;

    block15:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_deal_with_objects_with_finalizers");
	goto block16;

    block16:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_deal_with_objects_with_finalizers");
	goto block7;

    block17:
	l_v5638 = (struct pypy_AddressChunk0 *)l_v5651;
	l_v5649 = (l_v5638 != NULL);
	goto block18;

    block18:
	if (!l_v5649) {
		goto block16;
	}
	l_v5967 = l_v5638;
	goto block19;

    block19:
	RPyField(l_v5967, ac_next) = ((struct pypy_AddressChunk0 *) NULL);
	RPyField(l_self_110, ad_inst_oldest_chunk) = l_v5967;
	RPyField(l_self_110, ad_inst_newest_chunk) = l_v5967;
	RPyField(l_self_110, ad_inst_index_in_oldest) = 0L;
	RPyField(l_self_110, ad_inst_index_in_newest) = 0L;
	OP_RAW_MALLOC(sizeof(struct pypy_rpython_memory_support_AddressStack0), l_v5691, void *);
	OP_ADR_NE(l_v5691, NULL, l_v5692);
	if (l_v5692) {
		l_v5968 = l_v5691;
		goto block21;
	}
	goto block20;

    block20:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_deal_with_objects_with_finalizers");
	l_v5968 = NULL;
	goto block21;

    block21:
	OP_TRACK_ALLOC_START(l_v5968, /* nothing */);
	l_pending_0 = (struct pypy_rpython_memory_support_AddressStack0 *)l_v5968;
	l_v5696 = (l_pending_0 != NULL);
	if (!l_v5696) {
		goto block113;
	}
	goto block22;

    block22:
	l_v5697 = (struct pypy_nongcobject0 *)l_pending_0;
	RPyField(l_v5697, n_typeptr) = (&pypy_g_rpython_memory_support_AddressStack_vtable.as_super);
	l_v5699 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v5700 = (l_v5699 != NULL);
	if (l_v5700) {
		goto block112;
	}
	goto block23;

    block23:
	OP_RAW_MALLOC(sizeof(struct pypy_AddressChunk0), l_v5643, void *);
	OP_ADR_NE(l_v5643, NULL, l_v5701);
	if (l_v5701) {
		goto block26;
	}
	goto block24;

    block24:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_deal_with_objects_with_finalizers");
	goto block25;

    block25:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_deal_with_objects_with_finalizers");
	goto block7;

    block26:
	l_v5648 = (struct pypy_AddressChunk0 *)l_v5643;
	l_v5647 = (l_v5648 != NULL);
	goto block27;

    block27:
	if (!l_v5647) {
		goto block25;
	}
	l_v5969 = l_v5648;
	goto block28;

    block28:
	RPyField(l_pending_0, as_inst_chunk) = l_v5969;
	l_v5706 = RPyField(l_pending_0, as_inst_chunk);
	RPyField(l_v5706, ac_next) = ((struct pypy_AddressChunk0 *) NULL);
	RPyField(l_pending_0, as_inst_used_in_last_chunk) = 0L;
	OP_RAW_MALLOC(sizeof(struct pypy_rpython_memory_support_AddressStack0), l_v5709, void *);
	OP_ADR_NE(l_v5709, NULL, l_v5710);
	if (l_v5710) {
		l_v5970 = l_v5709;
		goto block30;
	}
	goto block29;

    block29:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_deal_with_objects_with_finalizers");
	l_v5970 = NULL;
	goto block30;

    block30:
	OP_TRACK_ALLOC_START(l_v5970, /* nothing */);
	l_self_112 = (struct pypy_rpython_memory_support_AddressStack0 *)l_v5970;
	l_v5714 = (l_self_112 != NULL);
	if (!l_v5714) {
		goto block111;
	}
	goto block31;

    block31:
	l_v5715 = (struct pypy_nongcobject0 *)l_self_112;
	RPyField(l_v5715, n_typeptr) = (&pypy_g_rpython_memory_support_AddressStack_vtable.as_super);
	l_v5717 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v5718 = (l_v5717 != NULL);
	if (l_v5718) {
		goto block110;
	}
	goto block32;

    block32:
	OP_RAW_MALLOC(sizeof(struct pypy_AddressChunk0), l_v5645, void *);
	OP_ADR_NE(l_v5645, NULL, l_v5719);
	if (l_v5719) {
		goto block35;
	}
	goto block33;

    block33:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super), (&pypy_g_exceptions_MemoryError.me_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_deal_with_objects_with_finalizers");
	goto block34;

    block34:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_deal_with_objects_with_finalizers");
	goto block7;

    block35:
	l_v5652 = (struct pypy_AddressChunk0 *)l_v5645;
	l_v5636 = (l_v5652 != NULL);
	goto block36;

    block36:
	if (!l_v5636) {
		goto block34;
	}
	l_v5971 = l_v5652;
	goto block37;

    block37:
	RPyField(l_self_112, as_inst_chunk) = l_v5971;
	l_v5724 = RPyField(l_self_112, as_inst_chunk);
	RPyField(l_v5724, ac_next) = ((struct pypy_AddressChunk0 *) NULL);
	RPyField(l_self_112, as_inst_used_in_last_chunk) = 0L;
	RPyField(l_self_109, mmgc_inst_tmpstack) = l_self_112;
	goto block38;

    block38:
	while (1) {
		l_self_117 = RPyField(l_self_109, mmgc_inst_objects_with_finalizers);
		l_v5728 = RPyField(l_self_117, ad_inst_oldest_chunk);
		l_v5729 = RPyField(l_self_117, ad_inst_newest_chunk);
		l_v5730 = (l_v5728 != l_v5729);
		if (l_v5730) break;
		goto block39;
	  block38_back: ;
	}
	goto block72;

    block39:
	l_v5731 = RPyField(l_self_117, ad_inst_index_in_oldest);
	l_v5732 = RPyField(l_self_117, ad_inst_index_in_newest);
	OP_INT_LT(l_v5731, l_v5732, l_v5733);
	if (l_v5733) {
		goto block72;
	}
	goto block40;

    block40:
	while (1) {
		l_v5734 = RPyField(l_self_110, ad_inst_oldest_chunk);
		l_v5735 = RPyField(l_self_110, ad_inst_newest_chunk);
		l_v5736 = (l_v5734 != l_v5735);
		if (l_v5736) break;
		goto block41;
	  block40_back: ;
	}
	goto block55;

    block41:
	l_v5737 = RPyField(l_self_110, ad_inst_index_in_oldest);
	l_v5738 = RPyField(l_self_110, ad_inst_index_in_newest);
	OP_INT_LT(l_v5737, l_v5738, l_v5739);
	if (l_v5739) {
		goto block55;
	}
	goto block42;

    block42:
	l_v5644 = RPyField(l_self_109, mmgc_inst_tmpstack);
	l_v5740 = RPyField(l_v5644, as_inst_chunk);
	l_cur_6 = l_v5740;
	goto block43;

    block43:
	while (1) {
		l_v5741 = (l_cur_6 != NULL);
		if (!l_v5741) break;
		goto block54;
	  block43_back: ;
	}
	goto block44;

    block44:
	l_v5742 = (void*)l_v5644;
	OP_TRACK_ALLOC_STOP(l_v5742, /* nothing */);
	OP_RAW_FREE(l_v5742, /* nothing */);
	l_v5745 = RPyField(l_pending_0, as_inst_chunk);
	l_cur_7 = l_v5745;
	goto block45;

    block45:
	while (1) {
		l_v5746 = (l_cur_7 != NULL);
		if (!l_v5746) break;
		goto block53;
	  block45_back: ;
	}
	goto block46;

    block46:
	l_v5747 = (void*)l_pending_0;
	OP_TRACK_ALLOC_STOP(l_v5747, /* nothing */);
	OP_RAW_FREE(l_v5747, /* nothing */);
	l_v5750 = RPyField(l_self_110, ad_inst_oldest_chunk);
	l_cur_8 = l_v5750;
	goto block47;

    block47:
	while (1) {
		l_v5751 = (l_cur_8 != NULL);
		if (!l_v5751) break;
		goto block52;
	  block47_back: ;
	}
	goto block48;

    block48:
	l_v5752 = (void*)l_self_110;
	OP_TRACK_ALLOC_STOP(l_v5752, /* nothing */);
	OP_RAW_FREE(l_v5752, /* nothing */);
	l_self_115 = RPyField(l_self_109, mmgc_inst_objects_with_finalizers);
	l_v5755 = RPyField(l_self_115, ad_inst_oldest_chunk);
	l_cur_9 = l_v5755;
	goto block49;

    block49:
	while (1) {
		l_v5756 = (l_cur_9 != NULL);
		if (!l_v5756) break;
		goto block51;
	  block49_back: ;
	}
	goto block50;

    block50:
	l_v5757 = (void*)l_self_115;
	OP_TRACK_ALLOC_STOP(l_v5757, /* nothing */);
	OP_RAW_FREE(l_v5757, /* nothing */);
	RPyField(l_self_109, mmgc_inst_objects_with_finalizers) = l_self_111;
	goto block7;

    block51:
	l_v5761 = RPyField(l_cur_9, ac_next);
	l_v5762 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	RPyField(l_cur_9, ac_next) = l_v5762;
	(&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list = l_cur_9;
	l_cur_9 = l_v5761;
	goto block49_back;

    block52:
	l_v5765 = RPyField(l_cur_8, ac_next);
	l_v5766 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	RPyField(l_cur_8, ac_next) = l_v5766;
	(&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list = l_cur_8;
	l_cur_8 = l_v5765;
	goto block47_back;

    block53:
	l_v5769 = RPyField(l_cur_7, ac_next);
	l_v5770 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	RPyField(l_cur_7, ac_next) = l_v5770;
	(&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list = l_cur_7;
	l_cur_7 = l_v5769;
	goto block45_back;

    block54:
	l_v5773 = RPyField(l_cur_6, ac_next);
	l_v5774 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	RPyField(l_cur_6, ac_next) = l_v5774;
	(&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list = l_cur_6;
	l_cur_6 = l_v5773;
	goto block43_back;

    block55:
	l_v5777 = RPyField(l_self_110, ad_inst_oldest_chunk);
	l_v5778 = RPyField(l_self_110, ad_inst_newest_chunk);
	l_v5779 = (l_v5777 != l_v5778);
	if (l_v5779) {
		l_v5972 = 1;
		goto block57;
	}
	goto block56;

    block56:
	l_v5780 = RPyField(l_self_110, ad_inst_index_in_oldest);
	l_v5781 = RPyField(l_self_110, ad_inst_index_in_newest);
	OP_INT_LT(l_v5780, l_v5781, l_v5782);
	l_v5972 = l_v5782;
	goto block57;

    block57:
	RPyAssert(l_v5972, "pop on empty AddressDeque");
	l_v5784 = RPyField(l_self_110, ad_inst_index_in_oldest);
	OP_INT_EQ(l_v5784, 1019L, l_v5785);
	if (l_v5785) {
		goto block71;
	}
	l_index_9 = l_v5784;
	goto block58;

    block58:
	l_v5786 = RPyField(l_self_110, ad_inst_oldest_chunk);
	l_v5787 = RPyField(l_v5786, ac_items);
	l_x_1 = RPyFxItem(l_v5787, l_index_9, 1019);
	OP_INT_ADD(l_index_9, 1L, l_v5788);
	RPyField(l_self_110, ad_inst_index_in_oldest) = l_v5788;
	OP_ADR_SUB(l_x_1, 0, l_v5790);
	l_v5791 = (struct pypy_header0 *)l_v5790;
	l_v5637 = RPyField(l_v5791, h_tid);
	OP_INT_AND(l_v5637, 262144L, l_v5792);
	OP_INT_IS_TRUE(l_v5792, l_v5793);
	if (l_v5793) {
		goto block70;
	}
	goto block59;

    block59:
	OP_INT_AND(l_v5637, 1048576L, l_v5794);
	OP_INT_IS_TRUE(l_v5794, l_v5795);
	if (l_v5795) {
		l_v5973 = 0;
		l_v5974 = 1L;
		goto block60;
	}
	l_v5973 = 0;
	l_v5974 = 0L;
	goto block60;

    block60:
	RPyAssert(l_v5973, "unexpected finalization state < 2");
	OP_INT_EQ(l_v5974, 2L, l_v5797);
	if (l_v5797) {
		goto block65;
	}
	goto block61;

    block61:
	l_v5798 = RPyField(l_self_111, ad_inst_index_in_newest);
	OP_INT_EQ(l_v5798, 1019L, l_v5799);
	if (l_v5799) {
		goto block63;
	}
	l_index_10 = l_v5798;
	goto block62;

    block62:
	l_v5800 = RPyField(l_self_111, ad_inst_newest_chunk);
	l_v5801 = RPyField(l_v5800, ac_items);
	RPyFxItem(l_v5801, l_index_10, 1019) = l_x_1;
	OP_INT_ADD(l_index_10, 1L, l_v5803);
	RPyField(l_self_111, ad_inst_index_in_newest) = l_v5803;
	goto block40_back;

    block63:
	pypy_g_AddressDeque_enlarge(l_self_111);
	l_v5806 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5807 = (l_v5806 == NULL);
	if (!l_v5807) {
		goto block64;
	}
	l_index_10 = 0L;
	goto block62;

    block64:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_deal_with_objects_with_finalizers");
	goto block7;

    block65:
	l_self_114 = RPyField(l_self_109, mmgc_inst_run_finalizers);
	l_v5809 = RPyField(l_self_114, ad_inst_index_in_newest);
	OP_INT_EQ(l_v5809, 1019L, l_v5810);
	if (l_v5810) {
		goto block68;
	}
	l_index_11 = l_v5809;
	goto block66;

    block66:
	l_v5811 = RPyField(l_self_114, ad_inst_newest_chunk);
	l_v5812 = RPyField(l_v5811, ac_items);
	RPyFxItem(l_v5812, l_index_11, 1019) = l_x_1;
	OP_INT_ADD(l_index_11, 1L, l_v5814);
	RPyField(l_self_114, ad_inst_index_in_newest) = l_v5814;
	pypy_g_MiniMarkGC__recursively_bump_finalization_state_(l_self_109, l_x_1);
	l_v5817 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5818 = (l_v5817 == NULL);
	if (!l_v5818) {
		goto block67;
	}
	goto block40;

    block67:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_deal_with_objects_with_finalizers");
	goto block7;

    block68:
	pypy_g_AddressDeque_enlarge(l_self_114);
	l_v5821 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5822 = (l_v5821 == NULL);
	if (!l_v5822) {
		goto block69;
	}
	l_index_11 = 0L;
	goto block66;

    block69:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_deal_with_objects_with_finalizers");
	goto block7;

    block70:
	OP_INT_AND(l_v5637, 1048576L, l_v5824);
	OP_INT_IS_TRUE(l_v5824, l_v5825);
	if (l_v5825) {
		l_v5973 = 1;
		l_v5974 = 2L;
		goto block60;
	}
	l_v5973 = 1;
	l_v5974 = 3L;
	goto block60;

    block71:
	pypy_g_AddressDeque_shrink(l_self_110);
	l_index_9 = 0L;
	goto block58;

    block72:
	l_self_116 = RPyField(l_self_109, mmgc_inst_objects_with_finalizers);
	l_v5827 = RPyField(l_self_116, ad_inst_oldest_chunk);
	l_v5828 = RPyField(l_self_116, ad_inst_newest_chunk);
	l_v5829 = (l_v5827 != l_v5828);
	if (l_v5829) {
		l_v5975 = 1;
		goto block74;
	}
	goto block73;

    block73:
	l_v5830 = RPyField(l_self_116, ad_inst_index_in_oldest);
	l_v5831 = RPyField(l_self_116, ad_inst_index_in_newest);
	OP_INT_LT(l_v5830, l_v5831, l_v5832);
	l_v5975 = l_v5832;
	goto block74;

    block74:
	RPyAssert(l_v5975, "pop on empty AddressDeque");
	l_v5834 = RPyField(l_self_116, ad_inst_index_in_oldest);
	OP_INT_EQ(l_v5834, 1019L, l_v5835);
	if (l_v5835) {
		goto block109;
	}
	l_index_12 = l_v5834;
	goto block75;

    block75:
	l_v5836 = RPyField(l_self_116, ad_inst_oldest_chunk);
	l_v5837 = RPyField(l_v5836, ac_items);
	l_x_0 = RPyFxItem(l_v5837, l_index_12, 1019);
	OP_INT_ADD(l_index_12, 1L, l_v5838);
	RPyField(l_self_116, ad_inst_index_in_oldest) = l_v5838;
	OP_ADR_SUB(l_x_0, 0, l_v5840);
	l_v5841 = (struct pypy_header0 *)l_v5840;
	l_v5640 = RPyField(l_v5841, h_tid);
	OP_INT_AND(l_v5640, 262144L, l_v5842);
	OP_INT_IS_TRUE(l_v5842, l_v5843);
	if (l_v5843) {
		goto block108;
	}
	goto block76;

    block76:
	OP_INT_AND(l_v5640, 1048576L, l_v5844);
	OP_INT_IS_TRUE(l_v5844, l_v5845);
	if (l_v5845) {
		l_v5976 = 0;
		goto block77;
	}
	l_v5976 = 1;
	goto block77;

    block77:
	RPyAssert(l_v5976, "bad finalization state 1");
	OP_ADR_SUB(l_x_0, 0, l_v5847);
	l_v5848 = (struct pypy_header0 *)l_v5847;
	l_v5849 = RPyField(l_v5848, h_tid);
	OP_INT_AND(l_v5849, 262144L, l_v5850);
	OP_INT_IS_TRUE(l_v5850, l_v5851);
	if (l_v5851) {
		goto block104;
	}
	goto block78;

    block78:
	l_v5852 = RPyField(l_self_110, ad_inst_index_in_newest);
	OP_INT_EQ(l_v5852, 1019L, l_v5853);
	if (l_v5853) {
		goto block102;
	}
	l_index_13 = l_v5852;
	goto block79;

    block79:
	l_v5854 = RPyField(l_self_110, ad_inst_newest_chunk);
	l_v5855 = RPyField(l_v5854, ac_items);
	RPyFxItem(l_v5855, l_index_13, 1019) = l_x_0;
	OP_INT_ADD(l_index_13, 1L, l_v5857);
	RPyField(l_self_110, ad_inst_index_in_newest) = l_v5857;
	l_v5859 = RPyField(l_pending_0, as_inst_used_in_last_chunk);
	OP_INT_EQ(l_v5859, 1019L, l_v5860);
	if (l_v5860) {
		goto block100;
	}
	l_used_32 = l_v5859;
	goto block80;

    block80:
	l_v5861 = RPyField(l_pending_0, as_inst_chunk);
	l_v5862 = RPyField(l_v5861, ac_items);
	RPyFxItem(l_v5862, l_used_32, 1019) = l_x_0;
	OP_INT_ADD(l_used_32, 1L, l_v5864);
	RPyField(l_pending_0, as_inst_used_in_last_chunk) = l_v5864;
	goto block81;

    block81:
	while (1) {
		l_v5866 = RPyField(l_pending_0, as_inst_used_in_last_chunk);
		OP_INT_NE(l_v5866, 0L, l_v5867);
		if (!l_v5867) break;
		goto block87;
	  block81_back: ;
	}
	goto block82;

    block82:
	l_self_113 = RPyField(l_self_109, mmgc_inst_objects_to_trace);
	l_v5868 = RPyField(l_self_113, as_inst_used_in_last_chunk);
	OP_INT_EQ(l_v5868, 1019L, l_v5869);
	if (l_v5869) {
		goto block85;
	}
	l_used_33 = l_v5868;
	goto block83;

    block83:
	l_v5870 = RPyField(l_self_113, as_inst_chunk);
	l_v5871 = RPyField(l_v5870, ac_items);
	RPyFxItem(l_v5871, l_used_33, 1019) = l_x_0;
	OP_INT_ADD(l_used_33, 1L, l_v5873);
	RPyField(l_self_113, as_inst_used_in_last_chunk) = l_v5873;
	pypy_g_MiniMarkGC_visit_all_objects(l_self_109);
	l_v5876 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5877 = (l_v5876 == NULL);
	if (!l_v5877) {
		goto block84;
	}
	goto block38;

    block84:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_deal_with_objects_with_finalizers");
	goto block7;

    block85:
	pypy_g_AddressStack_enlarge(l_self_113);
	l_v5880 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5881 = (l_v5880 == NULL);
	if (!l_v5881) {
		goto block86;
	}
	l_used_33 = 0L;
	goto block83;

    block86:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_deal_with_objects_with_finalizers");
	goto block7;

    block87:
	l_v5883 = RPyField(l_pending_0, as_inst_used_in_last_chunk);
	OP_INT_SUB(l_v5883, 1L, l_v5884);
	OP_INT_GE(l_v5884, 0L, l_v5885);
	RPyAssert(l_v5885, "pop on empty AddressStack");
	l_v5887 = RPyField(l_pending_0, as_inst_chunk);
	l_v5888 = RPyField(l_v5887, ac_items);
	l_v5635 = RPyFxItem(l_v5888, l_v5884, 1019);
	RPyField(l_pending_0, as_inst_used_in_last_chunk) = l_v5884;
	OP_INT_EQ(l_v5884, 0L, l_v5890);
	if (l_v5890) {
		goto block98;
	}
	goto block88;

    block88:
	OP_ADR_SUB(l_v5635, 0, l_v5891);
	l_v5892 = (struct pypy_header0 *)l_v5891;
	l_v5639 = RPyField(l_v5892, h_tid);
	OP_INT_AND(l_v5639, 262144L, l_v5893);
	OP_INT_IS_TRUE(l_v5893, l_v5894);
	if (l_v5894) {
		goto block95;
	}
	goto block89;

    block89:
	OP_INT_AND(l_v5639, 1048576L, l_v5895);
	OP_INT_IS_TRUE(l_v5895, l_v5896);
	if (l_v5896) {
		goto block81_back;
	}
	goto block90;

    block90:
	OP_ADR_SUB(l_v5635, 0, l_v5897);
	l_v5898 = (struct pypy_header0 *)l_v5897;
	l_v5646 = RPyField(l_v5898, h_tid);
	OP_INT_AND(l_v5646, 262144L, l_v5899);
	OP_INT_IS_TRUE(l_v5899, l_v5900);
	if (l_v5900) {
		goto block94;
	}
	goto block91;

    block91:
	OP_INT_AND(l_v5646, 1048576L, l_v5901);
	OP_INT_IS_TRUE(l_v5901, l_v5902);
	if (l_v5902) {
		l_v5977 = 0;
		goto block92;
	}
	l_v5977 = 1;
	goto block92;

    block92:
	RPyAssert(l_v5977, "unexpected finalization state != 0");
	OP_ADR_SUB(l_v5635, 0, l_v5904);
	l_v5905 = (struct pypy_header0 *)l_v5904;
	l_v5906 = RPyField(l_v5905, h_tid);
	OP_INT_OR(l_v5906, 1048576L, l_v5907);
	RPyField(l_v5905, h_tid) = l_v5907;
	pypy_g_trace___append_if_nonnull(l_self_109, l_v5635, l_pending_0);
	l_v5910 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5911 = (l_v5910 == NULL);
	if (!l_v5911) {
		goto block93;
	}
	goto block81;

    block93:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_deal_with_objects_with_finalizers");
	goto block7;

    block94:
	OP_INT_AND(l_v5646, 1048576L, l_v5913);
	OP_INT_IS_TRUE(l_v5913, l_v5914);
	if (l_v5914) {
		l_v5977 = 0;
		goto block92;
	}
	l_v5977 = 0;
	goto block92;

    block95:
	OP_INT_AND(l_v5639, 1048576L, l_v5915);
	OP_INT_IS_TRUE(l_v5915, l_v5916);
	if (l_v5916) {
		goto block96;
	}
	goto block81;

    block96:
	pypy_g_MiniMarkGC__recursively_bump_finalization_state_(l_self_109, l_v5635);
	l_v5918 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5919 = (l_v5918 == NULL);
	if (!l_v5919) {
		goto block97;
	}
	goto block81;

    block97:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_deal_with_objects_with_finalizers");
	goto block7;

    block98:
	l_v5921 = RPyField(l_pending_0, as_inst_chunk);
	l_v5922 = RPyField(l_v5921, ac_next);
	l_v5923 = (l_v5922 != NULL);
	if (l_v5923) {
		goto block99;
	}
	goto block88;

    block99:
	pypy_g_AddressStack_shrink(l_pending_0);
	goto block88;

    block100:
	pypy_g_AddressStack_enlarge(l_pending_0);
	l_v5926 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5927 = (l_v5926 == NULL);
	if (!l_v5927) {
		goto block101;
	}
	l_used_32 = 0L;
	goto block80;

    block101:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_deal_with_objects_with_finalizers");
	goto block7;

    block102:
	pypy_g_AddressDeque_enlarge(l_self_110);
	l_v5930 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5931 = (l_v5930 == NULL);
	if (!l_v5931) {
		goto block103;
	}
	l_index_13 = 0L;
	goto block79;

    block103:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_deal_with_objects_with_finalizers");
	goto block7;

    block104:
	l_v5933 = RPyField(l_self_111, ad_inst_index_in_newest);
	OP_INT_EQ(l_v5933, 1019L, l_v5934);
	if (l_v5934) {
		goto block106;
	}
	l_index_14 = l_v5933;
	goto block105;

    block105:
	l_v5935 = RPyField(l_self_111, ad_inst_newest_chunk);
	l_v5936 = RPyField(l_v5935, ac_items);
	RPyFxItem(l_v5936, l_index_14, 1019) = l_x_0;
	OP_INT_ADD(l_index_14, 1L, l_v5938);
	RPyField(l_self_111, ad_inst_index_in_newest) = l_v5938;
	goto block38_back;

    block106:
	pypy_g_AddressDeque_enlarge(l_self_111);
	l_v5941 = (&pypy_g_ExcData)->ed_exc_type;
	l_v5942 = (l_v5941 == NULL);
	if (!l_v5942) {
		goto block107;
	}
	l_index_14 = 0L;
	goto block105;

    block107:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_deal_with_objects_with_finalizers");
	goto block7;

    block108:
	OP_INT_AND(l_v5640, 1048576L, l_v5944);
	OP_INT_IS_TRUE(l_v5944, l_v5945);
	if (l_v5945) {
		l_v5976 = 1;
		goto block77;
	}
	l_v5976 = 1;
	goto block77;

    block109:
	pypy_g_AddressDeque_shrink(l_self_116);
	l_index_12 = 0L;
	goto block75;

    block110:
	l_v5947 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v5948 = RPyField(l_v5947, ac_next);
	(&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list = l_v5948;
	l_v5971 = l_v5947;
	goto block37;

    block111:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_deal_with_objects_with_finalizers");
	goto block7;

    block112:
	l_v5951 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v5952 = RPyField(l_v5951, ac_next);
	(&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list = l_v5952;
	l_v5969 = l_v5951;
	goto block28;

    block113:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_deal_with_objects_with_finalizers");
	goto block7;

    block114:
	l_v5955 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v5956 = RPyField(l_v5955, ac_next);
	(&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list = l_v5956;
	l_v5967 = l_v5955;
	goto block19;

    block115:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_deal_with_objects_with_finalizers");
	goto block7;

    block116:
	l_v5959 = (&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list;
	l_v5960 = RPyField(l_v5959, ac_next);
	(&pypy_g_rpython_memory_support_FreeList)->fl_inst_free_list = l_v5960;
	l_v5965 = l_v5959;
	goto block10;

    block117:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_deal_with_objects_with_finalizers");
	goto block7;
}
/*/*/
bool_t pypy_g_MiniMarkGC_shrink_array(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_44, void* l_obj_8, Signed l_smallerlength_1) {
	Signed l_v5979; Signed l_v5981; Signed l_v5982; Signed l_v5991;
	Signed l_v5992; Signed l_v5996; Signed l_v5998; Signed l_v5999;
	Signed l_v6002; Signed l_v6003; Signed l_v6006; Signed l_v6007;
	Signed l_v6010; Signed l_v6011; Signed l_v6015; Signed l_v6016;
	Signed l_v6019; bool_t l_v5983; bool_t l_v5986; bool_t l_v5988;
	bool_t l_v5993; bool_t l_v6000; bool_t l_v6008; bool_t l_v6012;
	bool_t l_v6017; bool_t l_v6024; bool_t l_v6026;
	struct pypy_header0 *l_v5990; struct pypy_header0 *l_v5995;
	struct pypy_object_vtable0 *l_v6023; struct pypy_type_info0 *l_v5997;
	struct pypy_type_info0 *l_v6005; struct pypy_type_info0 *l_v6014;
	struct pypy_varsize_type_info0 *l_v6004;
	struct pypy_varsize_type_info0 *l_v6013; unsigned short l_v5978;
	void* l_v5980; void* l_v5985; void* l_v5987; void* l_v5989;
	void* l_v5994; void* l_v6020;
	goto block0;

    block0:
	OP_CAST_ADR_TO_INT(l_obj_8, /* nothing */, l_v5981);
	OP_INT_AND(l_v5981, 1L, l_v5982);
	OP_INT_EQ(l_v5982, 0L, l_v5983);
	RPyAssert(l_v5983, "odd-valued (i.e. tagged) pointer unexpected here");
	l_v5985 = RPyField(l_self_44, mmgc_inst_nursery);
	OP_ADR_LE(l_v5985, l_obj_8, l_v5986);
	if (l_v5986) {
		goto block2;
	}
	l_v6026 = 0;
	goto block1;

    block1:
	RPY_DEBUG_RETURN();
	return l_v6026;

    block2:
	l_v5987 = RPyField(l_self_44, mmgc_inst_nursery_real_top);
	OP_ADR_LT(l_obj_8, l_v5987, l_v5988);
	if (l_v5988) {
		goto block3;
	}
	l_v6026 = 0;
	goto block1;

    block3:
	OP_ADR_SUB(l_obj_8, 0, l_v5989);
	l_v5990 = (struct pypy_header0 *)l_v5989;
	l_v5991 = RPyField(l_v5990, h_tid);
	OP_INT_AND(l_v5991, 524288L, l_v5992);
	OP_INT_IS_TRUE(l_v5992, l_v5993);
	if (l_v5993) {
		l_v6026 = 0;
		goto block1;
	}
	goto block4;

    block4:
	OP_ADR_SUB(l_obj_8, 0, l_v5994);
	l_v5995 = (struct pypy_header0 *)l_v5994;
	l_v5996 = RPyField(l_v5995, h_tid);
	OP_EXTRACT_USHORT(l_v5996, l_v5978);
	l_v5997 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_v5978);
	l_v5998 = RPyField(l_v5997, ti_infobits);
	OP_INT_AND(l_v5998, -16777216L, l_v5999);
	OP_INT_EQ(l_v5999, 1509949440L, l_v6000);
	RPyAssert(l_v6000, "invalid type_id");
	l_v6002 = RPyField(l_v5997, ti_fixedsize);
	OP_INT_ADD(0, l_v6002, l_v6003);
	l_v6004 = (struct pypy_varsize_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_v5978);
	l_v6005 = (struct pypy_type_info0 *)l_v6004;
	l_v6006 = RPyField(l_v6005, ti_infobits);
	OP_INT_AND(l_v6006, -16711680L, l_v6007);
	OP_INT_EQ(l_v6007, 1510014976L, l_v6008);
	RPyAssert(l_v6008, "invalid varsize type_id");
	l_v6010 = RPyField(l_v6004, vti_varitemsize);
	OP_INT_MUL(l_v6010, l_smallerlength_1, l_v6011);
	OP_INT_ADD(l_v6003, l_v6011, l_v5979);
	OP_ADR_SUB(l_obj_8, 0, l_v5980);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v6012);
	if (l_v6012) {
		goto block6;
	}
	goto block5;

    block5:
	l_v6013 = (struct pypy_varsize_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_v5978);
	l_v6014 = (struct pypy_type_info0 *)l_v6013;
	l_v6015 = RPyField(l_v6014, ti_infobits);
	OP_INT_AND(l_v6015, -16711680L, l_v6016);
	OP_INT_EQ(l_v6016, 1510014976L, l_v6017);
	RPyAssert(l_v6017, "invalid varsize type_id");
	l_v6019 = RPyField(l_v6013, vti_ofstolength);
	OP_ADR_ADD(l_obj_8, l_v6019, l_v6020);
	((Signed *) (((char *)l_v6020) + 0))[0] = l_smallerlength_1;
	l_v6026 = 1;
	goto block1;

    block6:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v6023 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6024 = (l_v6023 == NULL);
	if (!l_v6024) {
		goto block7;
	}
	goto block5;

    block7:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_shrink_array");
	l_v6026 = 1;
	goto block1;
}
/*/*/
void pypy_g_MiniMarkGC__collect_ref_stk(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_49, void* l_root_2) {
	void* l_addr_12; Signed l_used_34; Signed l_v6029; Signed l_v6034;
	bool_t l_v6030; bool_t l_v6038; struct pypy_AddressChunk0 *l_v6031;
	struct pypy_object_vtable0 *l_v6037;
	struct pypy_rpython_memory_support_AddressStack0 *l_v6027;
	void* *l_v6032;
	goto block0;

    block0:
	l_addr_12 = ((void* *) (((char *)l_root_2) + 0))[0];
	if ((-8192 <= (long)l_addr_12) && (((long)l_addr_12) < 8192)) abort();
	l_v6027 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_objects_to_trace;
	l_v6029 = RPyField(l_v6027, as_inst_used_in_last_chunk);
	OP_INT_EQ(l_v6029, 1019L, l_v6030);
	if (l_v6030) {
		goto block3;
	}
	l_used_34 = l_v6029;
	goto block1;

    block1:
	l_v6031 = RPyField(l_v6027, as_inst_chunk);
	l_v6032 = RPyField(l_v6031, ac_items);
	RPyFxItem(l_v6032, l_used_34, 1019) = l_addr_12;
	OP_INT_ADD(l_used_34, 1L, l_v6034);
	RPyField(l_v6027, as_inst_used_in_last_chunk) = l_v6034;
	goto block2;

    block2:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block3:
	pypy_g_AddressStack_enlarge(l_v6027);
	l_v6037 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6038 = (l_v6037 == NULL);
	if (!l_v6038) {
		goto block4;
	}
	l_used_34 = 0L;
	goto block1;

    block4:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC__collect_ref_stk");
	goto block2;
}
/*/*/
void pypy_g_MiniMarkGC__recursively_bump_finalization_state_(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_119, void* l_obj_32) {
	void* l_result_16;
	struct pypy_rpython_memory_support_AddressStack0 *l_self_118;
	Signed l_used_35; Signed l_v6042; Signed l_v6045; Signed l_v6047;
	Signed l_v6050; Signed l_v6053; Signed l_v6058; Signed l_v6060;
	Signed l_v6062; Signed l_v6063; Signed l_v6071; Signed l_v6072;
	Signed l_v6074; Signed l_v6075; Signed l_v6089; bool_t l_v6046;
	bool_t l_v6048; bool_t l_v6051; bool_t l_v6054; bool_t l_v6061;
	bool_t l_v6064; bool_t l_v6069; bool_t l_v6073; bool_t l_v6079;
	bool_t l_v6083; bool_t l_v6087; bool_t l_v6090; bool_t l_v6092;
	bool_t l_v6093; struct pypy_AddressChunk0 *l_v6055;
	struct pypy_AddressChunk0 *l_v6066;
	struct pypy_AddressChunk0 *l_v6081;
	struct pypy_AddressChunk0 *l_v6082; struct pypy_header0 *l_v6041;
	struct pypy_header0 *l_v6044; struct pypy_object_vtable0 *l_v6078;
	struct pypy_object_vtable0 *l_v6086; void* *l_v6056; void* *l_v6067;
	void* l_v6043; void* l_v6070;
	goto block0;

    block0:
	OP_ADR_SUB(l_obj_32, 0, l_v6043);
	l_v6044 = (struct pypy_header0 *)l_v6043;
	l_v6042 = RPyField(l_v6044, h_tid);
	OP_INT_AND(l_v6042, 262144L, l_v6045);
	OP_INT_IS_TRUE(l_v6045, l_v6046);
	if (l_v6046) {
		goto block15;
	}
	goto block1;

    block1:
	OP_INT_AND(l_v6042, 1048576L, l_v6047);
	OP_INT_IS_TRUE(l_v6047, l_v6048);
	if (l_v6048) {
		l_v6092 = 0;
		goto block2;
	}
	l_v6092 = 0;
	goto block2;

    block2:
	RPyAssert(l_v6092, "unexpected finalization state != 2");
	l_self_118 = RPyField(l_self_119, mmgc_inst_tmpstack);
	l_v6050 = RPyField(l_self_118, as_inst_used_in_last_chunk);
	OP_INT_NE(l_v6050, 0L, l_v6051);
	if (l_v6051) {
		l_v6093 = 0;
		goto block3;
	}
	l_v6093 = 1;
	goto block3;

    block3:
	RPyAssert(l_v6093, "tmpstack not empty");
	l_v6053 = RPyField(l_self_118, as_inst_used_in_last_chunk);
	OP_INT_EQ(l_v6053, 1019L, l_v6054);
	if (l_v6054) {
		goto block13;
	}
	l_used_35 = l_v6053;
	goto block4;

    block4:
	l_v6055 = RPyField(l_self_118, as_inst_chunk);
	l_v6056 = RPyField(l_v6055, ac_items);
	RPyFxItem(l_v6056, l_used_35, 1019) = l_obj_32;
	OP_INT_ADD(l_used_35, 1L, l_v6058);
	RPyField(l_self_118, as_inst_used_in_last_chunk) = l_v6058;
	goto block5;

    block5:
	while (1) {
		l_v6060 = RPyField(l_self_118, as_inst_used_in_last_chunk);
		OP_INT_NE(l_v6060, 0L, l_v6061);
		if (!l_v6061) break;
		goto block7;
	  block5_back: ;
	}
	goto block6;

    block6:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block7:
	l_v6062 = RPyField(l_self_118, as_inst_used_in_last_chunk);
	OP_INT_SUB(l_v6062, 1L, l_v6063);
	OP_INT_GE(l_v6063, 0L, l_v6064);
	RPyAssert(l_v6064, "pop on empty AddressStack");
	l_v6066 = RPyField(l_self_118, as_inst_chunk);
	l_v6067 = RPyField(l_v6066, ac_items);
	l_result_16 = RPyFxItem(l_v6067, l_v6063, 1019);
	RPyField(l_self_118, as_inst_used_in_last_chunk) = l_v6063;
	OP_INT_EQ(l_v6063, 0L, l_v6069);
	if (l_v6069) {
		goto block11;
	}
	goto block8;

    block8:
	OP_ADR_SUB(l_result_16, 0, l_v6070);
	l_v6041 = (struct pypy_header0 *)l_v6070;
	l_v6071 = RPyField(l_v6041, h_tid);
	OP_INT_AND(l_v6071, 1048576L, l_v6072);
	OP_INT_IS_TRUE(l_v6072, l_v6073);
	if (l_v6073) {
		goto block9;
	}
	goto block5_back;

    block9:
	l_v6074 = RPyField(l_v6041, h_tid);
	OP_INT_AND(l_v6074, -1048577L, l_v6075);
	RPyField(l_v6041, h_tid) = l_v6075;
	pypy_g_trace___append_if_nonnull(l_self_119, l_result_16, l_self_118);
	l_v6078 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6079 = (l_v6078 == NULL);
	if (!l_v6079) {
		goto block10;
	}
	goto block5;

    block10:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC__recursively_bump_finalization_state_");
	goto block6;

    block11:
	l_v6081 = RPyField(l_self_118, as_inst_chunk);
	l_v6082 = RPyField(l_v6081, ac_next);
	l_v6083 = (l_v6082 != NULL);
	if (l_v6083) {
		goto block12;
	}
	goto block8;

    block12:
	pypy_g_AddressStack_shrink(l_self_118);
	goto block8;

    block13:
	pypy_g_AddressStack_enlarge(l_self_118);
	l_v6086 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6087 = (l_v6086 == NULL);
	if (!l_v6087) {
		goto block14;
	}
	l_used_35 = 0L;
	goto block4;

    block14:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC__recursively_bump_finalization_state_");
	goto block6;

    block15:
	OP_INT_AND(l_v6042, 1048576L, l_v6089);
	OP_INT_IS_TRUE(l_v6089, l_v6090);
	if (l_v6090) {
		l_v6092 = 1;
		goto block2;
	}
	l_v6092 = 0;
	goto block2;
}
/*/*/
void pypy_g_MiniMarkGC_debug_check_object(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_v6097, void* l_v6094) {
	Signed l_i_17; Signed l_v6095; Signed l_v6099; Signed l_v6100;
	Signed l_v6108; Signed l_v6109; Signed l_v6114; Signed l_v6115;
	Signed l_v6120; Signed l_v6121; Signed l_v6126; Signed l_v6127;
	Signed l_v6132; Signed l_v6133; Signed l_v6137; Signed l_v6140;
	Signed l_v6141; Signed l_v6144; Signed l_v6149; Signed l_v6150;
	Signed l_v6155; Signed l_v6156; Signed l_v6159; Signed l_v6161;
	Signed l_v6166; Signed l_v6172; Unsigned l_v6162; Unsigned l_v6163;
	Unsigned l_v6164; bool_t l_v6101; bool_t l_v6104; bool_t l_v6110;
	bool_t l_v6116; bool_t l_v6122; bool_t l_v6128; bool_t l_v6134;
	bool_t l_v6142; bool_t l_v6145; bool_t l_v6151; bool_t l_v6157;
	bool_t l_v6165; bool_t l_v6167; bool_t l_v6170; bool_t l_v6175;
	bool_t l_v6178; bool_t l_v6180; char l_v6169;
	struct pypy_header0 *l_v6107; struct pypy_header0 *l_v6113;
	struct pypy_header0 *l_v6119; struct pypy_header0 *l_v6125;
	struct pypy_header0 *l_v6131; struct pypy_header0 *l_v6136;
	struct pypy_header0 *l_v6148; struct pypy_object_vtable0 *l_v6174;
	struct pypy_type_info0 *l_v6139; struct pypy_type_info0 *l_v6154;
	struct pypy_varsize_type_info0 *l_v6153; unsigned short l_v6138;
	void* l_v6096; void* l_v6098; void* l_v6103; void* l_v6106;
	void* l_v6112; void* l_v6118; void* l_v6124; void* l_v6130;
	void* l_v6135; void* l_v6147; void* l_v6160; void* l_v6168;
	void* l_v6173; void* l_v6177; void* l_v6181;
	goto block0;

    block0:
	OP_CAST_ADR_TO_INT(l_v6094, /* nothing */, l_v6099);
	OP_INT_AND(l_v6099, 1L, l_v6100);
	OP_INT_EQ(l_v6100, 0L, l_v6101);
	RPyAssert(l_v6101, "odd-valued (i.e. tagged) pointer unexpected here");
	l_v6103 = RPyField(l_v6097, mmgc_inst_nursery);
	OP_ADR_LE(l_v6103, l_v6094, l_v6104);
	if (l_v6104) {
		goto block9;
	}
	l_v6180 = 1;
	goto block1;

    block1:
	RPyAssert(l_v6180, "object in nursery after collection");
	OP_ADR_SUB(l_v6094, 0, l_v6106);
	l_v6107 = (struct pypy_header0 *)l_v6106;
	l_v6108 = RPyField(l_v6107, h_tid);
	OP_INT_AND(l_v6108, 65536L, l_v6109);
	OP_INT_NE(l_v6109, 0L, l_v6110);
	RPyAssert(l_v6110, "missing GCFLAG_TRACK_YOUNG_PTRS");
	OP_ADR_SUB(l_v6094, 0, l_v6112);
	l_v6113 = (struct pypy_header0 *)l_v6112;
	l_v6114 = RPyField(l_v6113, h_tid);
	OP_INT_AND(l_v6114, 262144L, l_v6115);
	OP_INT_EQ(l_v6115, 0L, l_v6116);
	RPyAssert(l_v6116, "unexpected GCFLAG_VISITED");
	OP_ADR_SUB(l_v6094, 0, l_v6118);
	l_v6119 = (struct pypy_header0 *)l_v6118;
	l_v6120 = RPyField(l_v6119, h_tid);
	OP_INT_AND(l_v6120, 1048576L, l_v6121);
	OP_INT_EQ(l_v6121, 0L, l_v6122);
	RPyAssert(l_v6122, "unexpected GCFLAG_FINALIZATION_ORDERING");
	OP_ADR_SUB(l_v6094, 0, l_v6124);
	l_v6125 = (struct pypy_header0 *)l_v6124;
	l_v6126 = RPyField(l_v6125, h_tid);
	OP_INT_AND(l_v6126, 8388608L, l_v6127);
	OP_INT_EQ(l_v6127, 0L, l_v6128);
	RPyAssert(l_v6128, "unexpected GCFLAG_CARDS_SET");
	OP_ADR_SUB(l_v6094, 0, l_v6130);
	l_v6131 = (struct pypy_header0 *)l_v6130;
	l_v6132 = RPyField(l_v6131, h_tid);
	OP_INT_AND(l_v6132, 4194304L, l_v6133);
	OP_INT_IS_TRUE(l_v6133, l_v6134);
	if (l_v6134) {
		goto block3;
	}
	goto block2;

    block2:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block3:
	OP_ADR_SUB(l_v6094, 0, l_v6135);
	l_v6136 = (struct pypy_header0 *)l_v6135;
	l_v6137 = RPyField(l_v6136, h_tid);
	OP_EXTRACT_USHORT(l_v6137, l_v6138);
	l_v6139 = (struct pypy_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_v6138);
	l_v6140 = RPyField(l_v6139, ti_infobits);
	OP_INT_AND(l_v6140, -16777216L, l_v6141);
	OP_INT_EQ(l_v6141, 1509949440L, l_v6142);
	RPyAssert(l_v6142, "invalid type_id");
	OP_INT_AND(l_v6140, 131072L, l_v6144);
	OP_INT_NE(l_v6144, 0L, l_v6145);
	RPyAssert(l_v6145, "GCFLAG_HAS_CARDS but not has_gcptr_in_varsize");
	OP_ADR_SUB(l_v6094, 0, l_v6147);
	l_v6148 = (struct pypy_header0 *)l_v6147;
	l_v6149 = RPyField(l_v6148, h_tid);
	OP_INT_AND(l_v6149, 131072L, l_v6150);
	OP_INT_EQ(l_v6150, 0L, l_v6151);
	RPyAssert(l_v6151, "GCFLAG_HAS_CARDS && GCFLAG_NO_HEAP_PTRS");
	l_v6153 = (struct pypy_varsize_type_info0 *)_OP_GET_GROUP_MEMBER((&pypy_g_typeinfo), l_v6138);
	l_v6154 = (struct pypy_type_info0 *)l_v6153;
	l_v6155 = RPyField(l_v6154, ti_infobits);
	OP_INT_AND(l_v6155, -16711680L, l_v6156);
	OP_INT_EQ(l_v6156, 1510014976L, l_v6157);
	RPyAssert(l_v6157, "invalid varsize type_id");
	l_v6159 = RPyField(l_v6153, vti_ofstolength);
	OP_ADR_ADD(l_v6094, l_v6159, l_v6160);
	l_v6161 = ((Signed *) (((char *)l_v6160) + 0))[0];
	OP_CAST_INT_TO_UINT(l_v6161, l_v6162);
	OP_UINT_ADD(l_v6162, 4095UL, l_v6163);
	OP_UINT_RSHIFT(l_v6163, 12L, l_v6164);
	OP_CAST_UINT_TO_INT(l_v6164, l_v6095);
	OP_ADR_SUB(l_v6094, 0, l_v6098);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v6165);
	if (l_v6165) {
		goto block7;
	}
	l_v6181 = l_v6098;
	goto block4;

    block4:
	OP_INT_MUL(l_v6095, 4L, l_v6166);
	l_i_17 = l_v6166;
	l_v6096 = l_v6181;
	goto block5;

    block5:
	while (1) {
		OP_INT_GT(l_i_17, 0L, l_v6167);
		if (!l_v6167) break;
		goto block6;
	  block5_back: ;
	}
	goto block2;

    block6:
	OP_ADR_SUB(l_v6096, 1L, l_v6168);
	l_v6169 = ((char *) (((char *)l_v6168) + 0))[0];
	OP_CHAR_EQ(l_v6169, ((char)0), l_v6170);
	RPyAssert(l_v6170, "the card marker bits are not cleared");
	OP_INT_SUB(l_i_17, 1L, l_v6172);
	l_i_17 = l_v6172;
	l_v6096 = l_v6168;
	goto block5_back;

    block7:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v6173 = (void*)0;
	l_v6174 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6175 = (l_v6174 == NULL);
	if (!l_v6175) {
		goto block8;
	}
	l_v6181 = l_v6173;
	goto block4;

    block8:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_debug_check_object");
	goto block2;

    block9:
	l_v6177 = RPyField(l_v6097, mmgc_inst_nursery_real_top);
	OP_ADR_LT(l_v6094, l_v6177, l_v6178);
	if (l_v6178) {
		l_v6180 = 0;
		goto block1;
	}
	l_v6180 = 1;
	goto block1;
}
/*/*/
bool_t pypy_g_MiniMarkGC_writebarrier_before_copy(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_120, void* l_source_addr_2, void* l_dest_addr_2, Signed l_source_start_2, Signed l_dest_start_2, Signed l_length_38) {
	Signed l_used_36; Signed l_used_37; Signed l_v6186; Signed l_v6187;
	Signed l_v6189; Signed l_v6190; Signed l_v6192; Signed l_v6193;
	Signed l_v6195; Signed l_v6196; Signed l_v6198; Signed l_v6199;
	Signed l_v6201; Signed l_v6202; Signed l_v6204; Signed l_v6209;
	Signed l_v6215; Signed l_v6220; Signed l_v6222; Signed l_v6223;
	Signed l_v6229; Signed l_v6230; Signed l_v6232; Signed l_v6233;
	Signed l_v6235; Signed l_v6236; bool_t l_v6188; bool_t l_v6191;
	bool_t l_v6194; bool_t l_v6197; bool_t l_v6200; bool_t l_v6205;
	bool_t l_v6213; bool_t l_v6216; bool_t l_v6227; bool_t l_v6231;
	bool_t l_v6234; bool_t l_v6237; bool_t l_v6238; bool_t l_v6239;
	bool_t l_v6242; bool_t l_v6244; struct pypy_AddressChunk0 *l_v6206;
	struct pypy_AddressChunk0 *l_v6217; struct pypy_header0 *l_v6182;
	struct pypy_header0 *l_v6183; struct pypy_object_vtable0 *l_v6212;
	struct pypy_object_vtable0 *l_v6226;
	struct pypy_object_vtable0 *l_v6241; void* *l_v6207; void* *l_v6218;
	void* l_v6184; void* l_v6185;
	goto block0;

    block0:
	OP_ADR_SUB(l_source_addr_2, 0, l_v6184);
	l_v6183 = (struct pypy_header0 *)l_v6184;
	OP_ADR_SUB(l_dest_addr_2, 0, l_v6185);
	l_v6182 = (struct pypy_header0 *)l_v6185;
	l_v6186 = RPyField(l_v6182, h_tid);
	OP_INT_AND(l_v6186, 65536L, l_v6187);
	OP_INT_EQ(l_v6187, 0L, l_v6188);
	if (l_v6188) {
		l_v6244 = 1;
		goto block4;
	}
	goto block1;

    block1:
	l_v6189 = RPyField(l_v6183, h_tid);
	OP_INT_AND(l_v6189, 4194304L, l_v6190);
	OP_INT_NE(l_v6190, 0L, l_v6191);
	if (l_v6191) {
		goto block14;
	}
	goto block2;

    block2:
	l_v6192 = RPyField(l_v6183, h_tid);
	OP_INT_AND(l_v6192, 65536L, l_v6193);
	OP_INT_EQ(l_v6193, 0L, l_v6194);
	if (l_v6194) {
		goto block10;
	}
	goto block3;

    block3:
	l_v6195 = RPyField(l_v6182, h_tid);
	OP_INT_AND(l_v6195, 131072L, l_v6196);
	OP_INT_IS_TRUE(l_v6196, l_v6197);
	if (l_v6197) {
		goto block5;
	}
	l_v6244 = 1;
	goto block4;

    block4:
	RPY_DEBUG_RETURN();
	return l_v6244;

    block5:
	l_v6198 = RPyField(l_v6183, h_tid);
	OP_INT_AND(l_v6198, 131072L, l_v6199);
	OP_INT_EQ(l_v6199, 0L, l_v6200);
	if (l_v6200) {
		goto block6;
	}
	l_v6244 = 1;
	goto block4;

    block6:
	l_v6201 = RPyField(l_v6182, h_tid);
	OP_INT_AND(l_v6201, -131073L, l_v6202);
	RPyField(l_v6182, h_tid) = l_v6202;
	l_v6204 = (&pypy_g_rpython_memory_support_AddressStack_2)->as_inst_used_in_last_chunk;
	OP_INT_EQ(l_v6204, 1019L, l_v6205);
	if (l_v6205) {
		goto block8;
	}
	l_used_36 = l_v6204;
	goto block7;

    block7:
	l_v6206 = (&pypy_g_rpython_memory_support_AddressStack_2)->as_inst_chunk;
	l_v6207 = RPyField(l_v6206, ac_items);
	RPyFxItem(l_v6207, l_used_36, 1019) = l_dest_addr_2;
	OP_INT_ADD(l_used_36, 1L, l_v6209);
	(&pypy_g_rpython_memory_support_AddressStack_2)->as_inst_used_in_last_chunk = l_v6209;
	l_v6244 = 1;
	goto block4;

    block8:
	pypy_g_AddressStack_enlarge((&pypy_g_rpython_memory_support_AddressStack_2));
	l_v6212 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6213 = (l_v6212 == NULL);
	if (!l_v6213) {
		goto block9;
	}
	l_used_36 = 0L;
	goto block7;

    block9:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_writebarrier_before_copy");
	l_v6244 = 1;
	goto block4;

    block10:
	l_v6215 = (&pypy_g_rpython_memory_support_AddressStack)->as_inst_used_in_last_chunk;
	OP_INT_EQ(l_v6215, 1019L, l_v6216);
	if (l_v6216) {
		goto block12;
	}
	l_used_37 = l_v6215;
	goto block11;

    block11:
	l_v6217 = (&pypy_g_rpython_memory_support_AddressStack)->as_inst_chunk;
	l_v6218 = RPyField(l_v6217, ac_items);
	RPyFxItem(l_v6218, l_used_37, 1019) = l_dest_addr_2;
	OP_INT_ADD(l_used_37, 1L, l_v6220);
	(&pypy_g_rpython_memory_support_AddressStack)->as_inst_used_in_last_chunk = l_v6220;
	l_v6222 = RPyField(l_v6182, h_tid);
	OP_INT_AND(l_v6222, -65537L, l_v6223);
	RPyField(l_v6182, h_tid) = l_v6223;
	goto block3;

    block12:
	pypy_g_AddressStack_enlarge((&pypy_g_rpython_memory_support_AddressStack));
	l_v6226 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6227 = (l_v6226 == NULL);
	if (!l_v6227) {
		goto block13;
	}
	l_used_37 = 0L;
	goto block11;

    block13:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_writebarrier_before_copy");
	l_v6244 = 1;
	goto block4;

    block14:
	l_v6229 = RPyField(l_v6183, h_tid);
	OP_INT_AND(l_v6229, 65536L, l_v6230);
	OP_INT_EQ(l_v6230, 0L, l_v6231);
	if (l_v6231) {
		l_v6244 = 0;
		goto block4;
	}
	goto block15;

    block15:
	l_v6232 = RPyField(l_v6183, h_tid);
	OP_INT_AND(l_v6232, 8388608L, l_v6233);
	OP_INT_EQ(l_v6233, 0L, l_v6234);
	if (l_v6234) {
		l_v6244 = 1;
		goto block4;
	}
	goto block16;

    block16:
	l_v6235 = RPyField(l_v6182, h_tid);
	OP_INT_AND(l_v6235, 4194304L, l_v6236);
	OP_INT_EQ(l_v6236, 0L, l_v6237);
	if (l_v6237) {
		l_v6244 = 0;
		goto block4;
	}
	goto block17;

    block17:
	OP_INT_NE(l_source_start_2, 0L, l_v6238);
	if (l_v6238) {
		l_v6244 = 0;
		goto block4;
	}
	goto block18;

    block18:
	OP_INT_NE(l_dest_start_2, 0L, l_v6239);
	if (l_v6239) {
		l_v6244 = 0;
		goto block4;
	}
	goto block19;

    block19:
	pypy_g_MiniMarkGC_manually_copy_card_bits(l_self_120, l_source_addr_2, l_dest_addr_2, l_length_38);
	l_v6241 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6242 = (l_v6241 == NULL);
	if (!l_v6242) {
		goto block20;
	}
	l_v6244 = 1;
	goto block4;

    block20:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_writebarrier_before_copy");
	l_v6244 = 1;
	goto block4;
}
/*/*/
void pypy_g_MiniMarkGC_manually_copy_card_bits(struct pypy_rpython_memory_gc_minimark_MiniMarkGC0 *l_self_64, void* l_source_addr_3, void* l_addr_13, Signed l_length_21) {
	Signed l_anybyte_0; Signed l_byteindex_1; Signed l_bytes_3;
	struct pypy_header0 *l_dest_hdr_0; Signed l_used_38; Signed l_v6254;
	Signed l_v6255; Signed l_v6257; Signed l_v6262; Signed l_v6264;
	Signed l_v6265; Signed l_v6272; Signed l_v6274; Signed l_v6277;
	Signed l_v6278; Signed l_v6280; Signed l_v6281; Signed l_v6284;
	Unsigned l_v6248; Unsigned l_v6249; Unsigned l_v6250; bool_t l_v6251;
	bool_t l_v6252; bool_t l_v6256; bool_t l_v6258; bool_t l_v6269;
	bool_t l_v6271; bool_t l_v6273; bool_t l_v6287; bool_t l_v6291;
	char l_v6276; char l_v6279; char l_v6282;
	struct pypy_AddressChunk0 *l_v6259;
	struct pypy_object_vtable0 *l_v6268;
	struct pypy_object_vtable0 *l_v6286;
	struct pypy_object_vtable0 *l_v6290; void* *l_v6260; void* l_v6245;
	void* l_v6246; void* l_v6247; void* l_v6253; void* l_v6275;
	void* l_v6285; void* l_v6289; void* l_v6294; void* l_v6295;
	goto block0;

    block0:
	OP_CAST_INT_TO_UINT(l_length_21, l_v6248);
	OP_UINT_ADD(l_v6248, 1023UL, l_v6249);
	OP_UINT_RSHIFT(l_v6249, 10L, l_v6250);
	OP_CAST_UINT_TO_INT(l_v6250, l_bytes_3);
	l_byteindex_1 = 0L;
	l_anybyte_0 = 0L;
	goto block1;

    block1:
	while (1) {
		OP_INT_LT(l_byteindex_1, l_bytes_3, l_v6251);
		if (!l_v6251) break;
		goto block9;
	  block1_back: ;
	}
	goto block2;

    block2:
	OP_INT_IS_TRUE(l_anybyte_0, l_v6252);
	if (l_v6252) {
		goto block4;
	}
	goto block3;

    block3:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block4:
	OP_ADR_SUB(l_addr_13, 0, l_v6253);
	l_dest_hdr_0 = (struct pypy_header0 *)l_v6253;
	l_v6254 = RPyField(l_dest_hdr_0, h_tid);
	OP_INT_AND(l_v6254, 8388608L, l_v6255);
	OP_INT_EQ(l_v6255, 0L, l_v6256);
	if (l_v6256) {
		goto block5;
	}
	goto block3;

    block5:
	l_v6257 = (&pypy_g_rpython_memory_support_AddressStack_1)->as_inst_used_in_last_chunk;
	OP_INT_EQ(l_v6257, 1019L, l_v6258);
	if (l_v6258) {
		goto block7;
	}
	l_used_38 = l_v6257;
	goto block6;

    block6:
	l_v6259 = (&pypy_g_rpython_memory_support_AddressStack_1)->as_inst_chunk;
	l_v6260 = RPyField(l_v6259, ac_items);
	RPyFxItem(l_v6260, l_used_38, 1019) = l_addr_13;
	OP_INT_ADD(l_used_38, 1L, l_v6262);
	(&pypy_g_rpython_memory_support_AddressStack_1)->as_inst_used_in_last_chunk = l_v6262;
	l_v6264 = RPyField(l_dest_hdr_0, h_tid);
	OP_INT_OR(l_v6264, 8388608L, l_v6265);
	RPyField(l_dest_hdr_0, h_tid) = l_v6265;
	goto block3;

    block7:
	pypy_g_AddressStack_enlarge((&pypy_g_rpython_memory_support_AddressStack_1));
	l_v6268 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6269 = (l_v6268 == NULL);
	if (!l_v6269) {
		goto block8;
	}
	l_used_38 = 0L;
	goto block6;

    block8:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_manually_copy_card_bits");
	goto block3;

    block9:
	OP_ADR_SUB(l_source_addr_3, 0, l_v6245);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v6271);
	if (l_v6271) {
		goto block14;
	}
	l_v6294 = l_v6245;
	goto block10;

    block10:
	OP_INT_INVERT(l_byteindex_1, l_v6272);
	OP_ADR_ADD(l_v6294, l_v6272, l_v6247);
	OP_ADR_SUB(l_addr_13, 0, l_v6246);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v6273);
	if (l_v6273) {
		goto block12;
	}
	l_v6295 = l_v6246;
	goto block11;

    block11:
	OP_INT_INVERT(l_byteindex_1, l_v6274);
	OP_ADR_ADD(l_v6295, l_v6274, l_v6275);
	l_v6276 = ((char *) (((char *)l_v6247) + 0))[0];
	OP_CAST_CHAR_TO_INT(l_v6276, l_v6277);
	OP_INT_OR(l_anybyte_0, l_v6277, l_v6278);
	l_v6279 = ((char *) (((char *)l_v6275) + 0))[0];
	OP_CAST_CHAR_TO_INT(l_v6279, l_v6280);
	OP_INT_OR(l_v6280, l_v6277, l_v6281);
	OP_CAST_INT_TO_CHAR(l_v6281, l_v6282);
	((char *) (((char *)l_v6275) + 0))[0] = l_v6282;
	OP_INT_ADD(l_byteindex_1, 1L, l_v6284);
	l_byteindex_1 = l_v6284;
	l_anybyte_0 = l_v6278;
	goto block1_back;

    block12:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v6285 = (void*)0;
	l_v6286 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6287 = (l_v6286 == NULL);
	if (!l_v6287) {
		goto block13;
	}
	l_v6295 = l_v6285;
	goto block11;

    block13:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_manually_copy_card_bits");
	goto block3;

    block14:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v6289 = (void*)0;
	l_v6290 = (&pypy_g_ExcData)->ed_exc_type;
	l_v6291 = (l_v6290 == NULL);
	if (!l_v6291) {
		goto block15;
	}
	l_v6294 = l_v6289;
	goto block10;

    block15:
	PYPY_DEBUG_RECORD_TRACEBACK("MiniMarkGC_manually_copy_card_bits");
	goto block3;
}
/*/*/
/***********************************************************/
