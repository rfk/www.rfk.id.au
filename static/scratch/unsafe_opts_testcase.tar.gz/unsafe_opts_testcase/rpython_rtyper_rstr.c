/***********************************************************/
/***  Implementations                                    ***/

#define PYPY_FILE_NAME "rpython_rtyper_rstr.c"
#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"
#include "src/g_include.h"

/*/*/
double pypy_g_ll_float__rpy_stringPtr(struct pypy_rpy_string0 *l_s_6) {
	Signed l_n_4; Signed l_start_17; Signed l_stop_4; Signed l_v9884;
	Signed l_v9888; Signed l_v9894; Signed l_v9902; Signed l_v9903;
	Signed l_v9905; Signed l_v9908; Signed l_v9913; Signed l_v9918;
	Signed l_v9923; Signed l_v9927; bool_t l_v9885; bool_t l_v9886;
	bool_t l_v9887; bool_t l_v9889; bool_t l_v9890; bool_t l_v9893;
	bool_t l_v9895; bool_t l_v9898; bool_t l_v9901; bool_t l_v9904;
	bool_t l_v9906; bool_t l_v9909; bool_t l_v9912; bool_t l_v9916;
	bool_t l_v9919; bool_t l_v9922; char l_v9911; char l_v9921;
	double l_v9899; double l_v9926; struct pypy_object_vtable0 *l_v9897;
	struct pypy_rpy_string0 *l_v9896; struct pypy_rpy_string0 *l_v9928;
	goto block0;

    block0:
	l_v9885 = (l_s_6 == NULL);
	if (l_v9885) {
		goto block23;
	}
	goto block1;

    block1:
	l_n_4 = RPyField(l_s_6, rs_chars).length;
	l_start_17 = 0L;
	goto block2;

    block2:
	while (1) {
		OP_INT_LT(l_start_17, l_n_4, l_v9886);
		if (!l_v9886) break;
		goto block21;
	  block2_back: ;
	}
	goto block3;

    block3:
	OP_INT_EQ(l_start_17, l_n_4, l_v9887);
	if (l_v9887) {
		goto block20;
	}
	goto block4;

    block4:
	OP_INT_SUB(l_n_4, 1L, l_v9888);
	l_v9884 = l_v9888;
	goto block5;

    block5:
	while (1) {
		OP_INT_GE(l_v9884, 0L, l_v9889);
		if (!l_v9889) break;
		goto block18;
	  block5_back: ;
	}
	goto block6;

    block6:
	OP_INT_GE(l_v9884, 0L, l_v9890);
	if (l_v9890) {
		goto block9;
	}
	goto block7;

    block7:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("ll_float__rpy_stringPtr");
	l_v9926 = -1.0;
	goto block8;

    block8:
	RPY_DEBUG_RETURN();
	return l_v9926;

    block9:
	OP_INT_ADD(l_v9884, 1L, l_stop_4);
	OP_INT_IS_TRUE(0 /* we are not jitted here */, l_v9893);
	if (l_v9893) {
		goto block16;
	}
	goto block10;

    block10:
	l_v9894 = RPyField(l_s_6, rs_chars).length;
	OP_INT_GE(l_stop_4, l_v9894, l_v9895);
	if (l_v9895) {
		goto block14;
	}
	l_v9927 = l_stop_4;
	goto block11;

    block11:
	l_v9896 = pypy_g__ll_stringslice__rpy_stringPtr_Signed_Signed(l_s_6, l_start_17, l_v9927);
	l_v9897 = (&pypy_g_ExcData)->ed_exc_type;
	l_v9898 = (l_v9897 == NULL);
	if (!l_v9898) {
		goto block13;
	}
	l_v9928 = l_v9896;
	goto block12;

    block12:
	l_v9899 = pypy_g_strtod(l_v9928);
	l_v9926 = l_v9899;
	goto block8;

    block13:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_float__rpy_stringPtr");
	l_v9926 = -1.0;
	goto block8;

    block14:
	OP_INT_EQ(l_start_17, 0L, l_v9901);
	if (l_v9901) {
		l_v9928 = l_s_6;
		goto block12;
	}
	goto block15;

    block15:
	l_v9902 = RPyField(l_s_6, rs_chars).length;
	l_v9927 = l_v9902;
	goto block11;

    block16:
	l_v9903 = RPyField(l_s_6, rs_chars).length;
	OP_INT_GT(l_stop_4, l_v9903, l_v9904);
	if (l_v9904) {
		goto block17;
	}
	l_v9927 = l_stop_4;
	goto block11;

    block17:
	l_v9905 = RPyField(l_s_6, rs_chars).length;
	l_v9927 = l_v9905;
	goto block11;

    block18:
	OP_INT_GE(l_v9884, 0L, l_v9906);
	RPyAssert(l_v9906, "negative str getitem index");
	l_v9908 = RPyField(l_s_6, rs_chars).length;
	OP_INT_LT(l_v9884, l_v9908, l_v9909);
	RPyAssert(l_v9909, "str getitem index out of bound");
	l_v9911 = RPyField(l_s_6, rs_chars).items[l_v9884];
	OP_CHAR_EQ(l_v9911, ' ', l_v9912);
	if (l_v9912) {
		goto block19;
	}
	goto block6;

    block19:
	OP_INT_SUB(l_v9884, 1L, l_v9913);
	l_v9884 = l_v9913;
	goto block5_back;

    block20:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_ValueError_vtable.ve_super.se_super.e_super), (&pypy_g_exceptions_ValueError.ve_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("ll_float__rpy_stringPtr");
	l_v9926 = -1.0;
	goto block8;

    block21:
	OP_INT_GE(l_start_17, 0L, l_v9916);
	RPyAssert(l_v9916, "negative str getitem index");
	l_v9918 = RPyField(l_s_6, rs_chars).length;
	OP_INT_LT(l_start_17, l_v9918, l_v9919);
	RPyAssert(l_v9919, "str getitem index out of bound");
	l_v9921 = RPyField(l_s_6, rs_chars).items[l_start_17];
	OP_CHAR_EQ(l_v9921, ' ', l_v9922);
	if (l_v9922) {
		goto block22;
	}
	goto block3;

    block22:
	OP_INT_ADD(l_start_17, 1L, l_v9923);
	l_start_17 = l_v9923;
	goto block2_back;

    block23:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("ll_float__rpy_stringPtr");
	l_v9926 = -1.0;
	goto block8;
}
/*/*/
/***********************************************************/
