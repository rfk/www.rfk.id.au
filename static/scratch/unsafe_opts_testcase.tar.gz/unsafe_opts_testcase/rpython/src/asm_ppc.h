void LL_flush_icache(long base, long size);
