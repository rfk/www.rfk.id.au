#ifndef _PYPY_PROFILING_H
#define _PYPY_PROFILING_H

void pypy_setup_profiling();
void pypy_teardown_profiling();

#endif
