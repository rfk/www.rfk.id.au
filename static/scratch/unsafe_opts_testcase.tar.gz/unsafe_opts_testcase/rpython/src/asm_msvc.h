#ifdef PYPY_X86_CHECK_SSE2
#define PYPY_X86_CHECK_SSE2_DEFINED
extern void pypy_x86_check_sse2(void);
#endif
