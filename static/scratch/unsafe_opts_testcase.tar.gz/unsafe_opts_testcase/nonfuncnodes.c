/***********************************************************/
/***  Non-function Implementations                       ***/

#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"

#include "src/g_include.h"

/*/*/
struct pypy_exceptions_ValueError0 pypy_g_exceptions_ValueError = {
	{
		{
			{
				{
					(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member2)+196608L),	/* super.super.super.gcheader.tid */
				},
				(&pypy_g_exceptions_ValueError_vtable.ve_super.se_super.e_super),	/* super.super.super.typeptr */
			},
		},
	},
};
/*/*/
struct pypy_exceptions_NotImplementedError0 pypy_g_exceptions_NotImplementedError = {
	{
		{
			{
				{
					{
						(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member3)+196608L),	/* super.super.super.super.gcheader.tid */
					},
					(&pypy_g_exceptions_NotImplementedError_vtable.nie_super.re_super.se_super.e_super),	/* super.super.super.super.typeptr */
				},
			},
		},
	},
};
/*/*/
struct pypy_rpython_rlib_rstackovf_StackOverflow0 pypy_g_rpython_rlib_rstackovf_StackOverflow = {
	{
		{
			{
				{
					{
						(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member4)+196608L),	/* super.super.super.super.gcheader.tid */
					},
					(&pypy_g_rpython_rlib_rstackovf_StackOverflow_vtable.so_super.re_super.se_super.e_super),	/* super.super.super.super.typeptr */
				},
			},
		},
	},
};
/*/*/
struct pypy_exceptions_OSError0 pypy_g_exceptions_OSError = {
	{
		{
			{
				{
					{
						(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member1)+196608L),	/* super.super.super.super.gcheader.tid */
					},
					(&pypy_g_exceptions_OSError_vtable.ose_super.ee_super.se_super.e_super),	/* super.super.super.super.typeptr */
				},
			},
		},
	},
	0L,	/* inst_errno */
};
/*/*/
struct pypy_exceptions_ZeroDivisionError0 pypy_g_exceptions_ZeroDivisionError = {
	{
		{
			{
				{
					{
						(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member5)+196608L),	/* super.super.super.super.gcheader.tid */
					},
					(&pypy_g_exceptions_ZeroDivisionError_vtable.zde_super.ae_super.se_super.e_super),	/* super.super.super.super.typeptr */
				},
			},
		},
	},
};
/*/*/
struct pypy_exceptions_RuntimeError0 pypy_g_exceptions_RuntimeError = {
	{
		{
			{
				{
					(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member6)+196608L),	/* super.super.super.gcheader.tid */
				},
				(&pypy_g_exceptions_RuntimeError_vtable.re_super.se_super.e_super),	/* super.super.super.typeptr */
			},
		},
	},
};
/*/*/
struct pypy_exceptions_KeyError0 pypy_g_exceptions_KeyError = {
	{
		{
			{
				{
					{
						(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member7)+196608L),	/* super.super.super.super.gcheader.tid */
					},
					(&pypy_g_exceptions_KeyError_vtable.ke_super.le_super.se_super.e_super),	/* super.super.super.super.typeptr */
				},
			},
		},
	},
};
/*/*/
struct pypy_exceptions_UnicodeEncodeError0 pypy_g_exceptions_UnicodeEncodeError = {
	{
		{
			{
				{
					{
						{
							(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member8)+196608L),	/* super.super.super.super.super.gcheader.tid */
						},
						(&pypy_g_exceptions_UnicodeEncodeError_vtable.uee_super.ue_super.ve_super.se_super.e_super),	/* super.super.super.super.super.typeptr */
					},
				},
			},
		},
	},
};
/*/*/
struct pypy_exceptions_AssertionError0 pypy_g_exceptions_AssertionError = {
	{
		{
			{
				{
					(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member9)+196608L),	/* super.super.super.gcheader.tid */
				},
				(&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super),	/* super.super.super.typeptr */
			},
		},
	},
};
/*/*/
struct pypy_exceptions_TypeError0 pypy_g_exceptions_TypeError = {
	{
		{
			{
				{
					(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member10)+196608L),	/* super.super.super.gcheader.tid */
				},
				(&pypy_g_exceptions_TypeError_vtable.te_super.se_super.e_super),	/* super.super.super.typeptr */
			},
		},
	},
};
/*/*/
struct pypy_exceptions_UnicodeDecodeError0 pypy_g_exceptions_UnicodeDecodeError = {
	{
		{
			{
				{
					{
						{
							(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member11)+196608L),	/* super.super.super.super.super.gcheader.tid */
						},
						(&pypy_g_exceptions_UnicodeDecodeError_vtable.ude_super.ue_super.ve_super.se_super.e_super),	/* super.super.super.super.super.typeptr */
					},
				},
			},
		},
	},
};
/*/*/
struct pypy_exceptions_StopIteration0 pypy_g_exceptions_StopIteration = {
	{
		{
			{
				(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member12)+196608L),	/* super.super.gcheader.tid */
			},
			(&pypy_g_exceptions_StopIteration_vtable.si_super.e_super),	/* super.super.typeptr */
		},
	},
};
/*/*/
struct pypy_exceptions_IndexError0 pypy_g_exceptions_IndexError = {
	{
		{
			{
				{
					{
						(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member13)+196608L),	/* super.super.super.super.gcheader.tid */
					},
					(&pypy_g_exceptions_IndexError_vtable.ie_super.le_super.se_super.e_super),	/* super.super.super.super.typeptr */
				},
			},
		},
	},
};
/*/*/
struct pypy_exceptions_IOError0 pypy_g_exceptions_IOError = {
	{
		{
			{
				{
					{
						(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member14)+196608L),	/* super.super.super.super.gcheader.tid */
					},
					(&pypy_g_exceptions_IOError_vtable.ioe_super.ee_super.se_super.e_super),	/* super.super.super.super.typeptr */
				},
			},
		},
	},
};
/*/*/
struct pypy_exceptions_OverflowError0 pypy_g_exceptions_OverflowError = {
	{
		{
			{
				{
					{
						(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member15)+196608L),	/* super.super.super.super.gcheader.tid */
					},
					(&pypy_g_exceptions_OverflowError_vtable.oe_super.ae_super.se_super.e_super),	/* super.super.super.super.typeptr */
				},
			},
		},
	},
};
/*/*/
struct pypy_exceptions_MemoryError0 pypy_g_exceptions_MemoryError = {
	{
		{
			{
				{
					(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member16)+196608L),	/* super.super.super.gcheader.tid */
				},
				(&pypy_g_exceptions_MemoryError_vtable.me_super.se_super.e_super),	/* super.super.super.typeptr */
			},
		},
	},
};
/*/*/
struct pypy_exceptions_MemoryError_vtable0 pypy_g_exceptions_MemoryError_vtable = {
	{
		{
			{
				42L,	/* super.super.super.subclassrange_min */
				43L,	/* super.super.super.subclassrange_max */
				(&pypy_g_rtti_v_exceptions_MemoryError0),	/* super.super.super.rtti */
				(&pypy_g_array.b),	/* super.super.super.name */
				-1062572356L,	/* super.super.super.hash */
				((struct pypy_object0 *(*)(void)) NULL),	/* super.super.super.instantiate */
			},
		},
	},
};
/*/*/
struct pypy_rpython_rtyper_lltypesystem_rffi_StackCounter0 pypy_g_rpython_rtyper_lltypesystem_rffi_StackCounter = {
	{
		{
			(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member18)+196608L),	/* super.gcheader.tid */
		},
		(&pypy_g_rpython_rtyper_lltypesystem_rffi_StackCounter_vt.sc_super),	/* super.typeptr */
	},
	0L,	/* inst_stacks_counter */
};
/*/*/
struct pypy_exceptions_OSError_vtable0 pypy_g_exceptions_OSError_vtable = {
	{
		{
			{
				{
					23L,	/* super.super.super.super.subclassrange_min */
					24L,	/* super.super.super.super.subclassrange_max */
					(&pypy_g_rtti_v_exceptions_OSError0),	/* super.super.super.super.rtti */
					(&pypy_g_array_1.b),	/* super.super.super.super.name */
					-1062572446L,	/* super.super.super.super.hash */
					((struct pypy_object0 *(*)(void)) NULL),	/* super.super.super.super.instantiate */
				},
			},
		},
	},
};
/*/*/
struct pypy_exceptions_AssertionError_vtable0 pypy_g_exceptions_AssertionError_vtable = {
	{
		{
			{
				6L,	/* super.super.super.subclassrange_min */
				7L,	/* super.super.super.subclassrange_max */
				(&pypy_g_rtti_v_exceptions_AssertionError0),	/* super.super.super.rtti */
				(&pypy_g_array_2.b),	/* super.super.super.name */
				-1062572398L,	/* super.super.super.hash */
				((struct pypy_object0 *(*)(void)) NULL),	/* super.super.super.instantiate */
			},
		},
	},
};
/*/*/
struct pypy_exceptions_NotImplementedError_vtable0 pypy_g_exceptions_NotImplementedError_vtable = {
	{
		{
			{
				{
					17L,	/* super.super.super.super.subclassrange_min */
					18L,	/* super.super.super.super.subclassrange_max */
					(&pypy_g_rtti_v_exceptions_NotImplementedError0),	/* super.super.super.super.rtti */
					(&pypy_g_array_3.b),	/* super.super.super.super.name */
					-1062572462L,	/* super.super.super.super.hash */
					((struct pypy_object0 *(*)(void)) NULL),	/* super.super.super.super.instantiate */
				},
			},
		},
	},
};
/*/*/
struct pypy_exceptions_ValueError_vtable0 pypy_g_exceptions_ValueError_vtable = {
	{
		{
			{
				8L,	/* super.super.super.subclassrange_min */
				15L,	/* super.super.super.subclassrange_max */
				(&pypy_g_rtti_v_exceptions_ValueError0),	/* super.super.super.rtti */
				(&pypy_g_array_4.b),	/* super.super.super.name */
				-1062583006L,	/* super.super.super.hash */
				((struct pypy_object0 *(*)(void)) NULL),	/* super.super.super.instantiate */
			},
		},
	},
};
/*/*/
struct pypy_rpython_rlib_rstackovf_StackOverflow_vtable0 pypy_g_rpython_rlib_rstackovf_StackOverflow_vtable = {
	{
		{
			{
				{
					19L,	/* super.super.super.super.subclassrange_min */
					20L,	/* super.super.super.super.subclassrange_max */
					(&pypy_g_rtti_v_rpython_rlib_rstackovf_StackOverflow0),	/* super.super.super.super.rtti */
					(&pypy_g_array_5.b),	/* super.super.super.super.name */
					-1062572452L,	/* super.super.super.super.hash */
					((struct pypy_object0 *(*)(void)) NULL),	/* super.super.super.super.instantiate */
				},
			},
		},
	},
};
/*/*/
struct pypy_exceptions_ZeroDivisionError_vtable0 pypy_g_exceptions_ZeroDivisionError_vtable = {
	{
		{
			{
				{
					29L,	/* super.super.super.super.subclassrange_min */
					30L,	/* super.super.super.super.subclassrange_max */
					(&pypy_g_rtti_v_exceptions_ZeroDivisionError0),	/* super.super.super.super.rtti */
					(&pypy_g_array_6.b),	/* super.super.super.super.name */
					-1062572434L,	/* super.super.super.super.hash */
					((struct pypy_object0 *(*)(void)) NULL),	/* super.super.super.super.instantiate */
				},
			},
		},
	},
};
/*/*/
struct pypy_exceptions_RuntimeError_vtable0 pypy_g_exceptions_RuntimeError_vtable = {
	{
		{
			{
				16L,	/* super.super.super.subclassrange_min */
				21L,	/* super.super.super.subclassrange_max */
				(&pypy_g_rtti_v_exceptions_RuntimeError0),	/* super.super.super.rtti */
				(&pypy_g_array_7.b),	/* super.super.super.name */
				-1062572458L,	/* super.super.super.hash */
				((struct pypy_object0 *(*)(void)) NULL),	/* super.super.super.instantiate */
			},
		},
	},
};
/*/*/
struct pypy_exceptions_KeyError_vtable0 pypy_g_exceptions_KeyError_vtable = {
	{
		{
			{
				{
					35L,	/* super.super.super.super.subclassrange_min */
					36L,	/* super.super.super.super.subclassrange_max */
					(&pypy_g_rtti_v_exceptions_KeyError0),	/* super.super.super.super.rtti */
					(&pypy_g_array_8.b),	/* super.super.super.super.name */
					-1062572422L,	/* super.super.super.super.hash */
					((struct pypy_object0 *(*)(void)) NULL),	/* super.super.super.super.instantiate */
				},
			},
		},
	},
};
/*/*/
struct pypy_exceptions_UnicodeEncodeError_vtable0 pypy_g_exceptions_UnicodeEncodeError_vtable = {
	{
		{
			{
				{
					{
						10L,	/* super.super.super.super.super.subclassrange_min */
						11L,	/* super.super.super.super.super.subclassrange_max */
						(&pypy_g_rtti_v_exceptions_UnicodeEncodeError0),	/* super.super.super.super.super.rtti */
						(&pypy_g_array_9.b),	/* super.super.super.super.super.name */
						-1062572410L,	/* super.super.super.super.super.hash */
						((struct pypy_object0 *(*)(void)) NULL),	/* super.super.super.super.super.instantiate */
					},
				},
			},
		},
	},
};
/*/*/
struct pypy_exceptions_TypeError_vtable0 pypy_g_exceptions_TypeError_vtable = {
	{
		{
			{
				40L,	/* super.super.super.subclassrange_min */
				41L,	/* super.super.super.subclassrange_max */
				(&pypy_g_rtti_v_exceptions_TypeError0),	/* super.super.super.rtti */
				(&pypy_g_array_10.b),	/* super.super.super.name */
				-1062572392L,	/* super.super.super.hash */
				((struct pypy_object0 *(*)(void)) NULL),	/* super.super.super.instantiate */
			},
		},
	},
};
/*/*/
struct pypy_exceptions_UnicodeDecodeError_vtable0 pypy_g_exceptions_UnicodeDecodeError_vtable = {
	{
		{
			{
				{
					{
						12L,	/* super.super.super.super.super.subclassrange_min */
						13L,	/* super.super.super.super.super.subclassrange_max */
						(&pypy_g_rtti_v_exceptions_UnicodeDecodeError0),	/* super.super.super.super.super.rtti */
						(&pypy_g_array_11.b),	/* super.super.super.super.super.name */
						-1062572386L,	/* super.super.super.super.super.hash */
						((struct pypy_object0 *(*)(void)) NULL),	/* super.super.super.super.super.instantiate */
					},
				},
			},
		},
	},
};
/*/*/
struct pypy_exceptions_StopIteration_vtable0 pypy_g_exceptions_StopIteration_vtable = {
	{
		{
			3L,	/* super.super.subclassrange_min */
			4L,	/* super.super.subclassrange_max */
			(&pypy_g_rtti_v_exceptions_StopIteration0),	/* super.super.rtti */
			(&pypy_g_array_12.b),	/* super.super.name */
			-1062572380L,	/* super.super.hash */
			((struct pypy_object0 *(*)(void)) NULL),	/* super.super.instantiate */
		},
	},
};
/*/*/
struct pypy_exceptions_IndexError_vtable0 pypy_g_exceptions_IndexError_vtable = {
	{
		{
			{
				{
					37L,	/* super.super.super.super.subclassrange_min */
					38L,	/* super.super.super.super.subclassrange_max */
					(&pypy_g_rtti_v_exceptions_IndexError0),	/* super.super.super.super.rtti */
					(&pypy_g_array_13.b),	/* super.super.super.super.name */
					-1062572374L,	/* super.super.super.super.hash */
					((struct pypy_object0 *(*)(void)) NULL),	/* super.super.super.super.instantiate */
				},
			},
		},
	},
};
/*/*/
struct pypy_exceptions_IOError_vtable0 pypy_g_exceptions_IOError_vtable = {
	{
		{
			{
				{
					25L,	/* super.super.super.super.subclassrange_min */
					26L,	/* super.super.super.super.subclassrange_max */
					(&pypy_g_rtti_v_exceptions_IOError0),	/* super.super.super.super.rtti */
					(&pypy_g_array_14.b),	/* super.super.super.super.name */
					-1062572368L,	/* super.super.super.super.hash */
					((struct pypy_object0 *(*)(void)) NULL),	/* super.super.super.super.instantiate */
				},
			},
		},
	},
};
/*/*/
struct pypy_exceptions_OverflowError_vtable0 pypy_g_exceptions_OverflowError_vtable = {
	{
		{
			{
				{
					31L,	/* super.super.super.super.subclassrange_min */
					32L,	/* super.super.super.super.subclassrange_max */
					(&pypy_g_rtti_v_exceptions_OverflowError0),	/* super.super.super.super.rtti */
					(&pypy_g_array_15.b),	/* super.super.super.super.name */
					-1062572362L,	/* super.super.super.super.hash */
					((struct pypy_object0 *(*)(void)) NULL),	/* super.super.super.super.instantiate */
				},
			},
		},
	},
};
/*/*/
void* pypy_g_array1[1] = {
	NULL,	/* 0 */
};
/*/*/
struct pypy_rpython_memory_support_AddressDeque_vtable0 pypy_g_rpython_memory_support_AddressDeque_vtable = {
	{
		68L,	/* super.subclassrange_min */
		69L,	/* super.subclassrange_max */
		((char *) NULL),	/* super.rtti */
		(&pypy_g_array_16.b),	/* super.name */
		-1062417806L,	/* super.hash */
		((struct pypy_object0 *(*)(void)) NULL),	/* super.instantiate */
	},
	/* nothing */	/* cls_append */
	/* nothing */	/* cls_delete */
	/* nothing */	/* cls_enlarge */
	/* nothing */	/* cls_foreach */
	/* nothing */	/* cls_non_empty */
	/* nothing */	/* cls_popleft */
	/* nothing */	/* cls_shrink */
};
/*/*/
struct pypy_rpython_memory_support_AddressStack_vtable0 pypy_g_rpython_memory_support_AddressStack_vtable = {
	{
		58L,	/* super.subclassrange_min */
		59L,	/* super.subclassrange_max */
		((char *) NULL),	/* super.rtti */
		(&pypy_g_array_17.b),	/* super.name */
		-1062497276L,	/* super.hash */
		((struct pypy_object0 *(*)(void)) NULL),	/* super.instantiate */
	},
	/* nothing */	/* cls_append */
	/* nothing */	/* cls_delete */
	/* nothing */	/* cls_enlarge */
	/* nothing */	/* cls_foreach */
	/* nothing */	/* cls_non_empty */
	/* nothing */	/* cls_pop */
	/* nothing */	/* cls_shrink */
};
/*/*/
char pypy_g_rtti_v_exceptions_MemoryError0  /* uninitialized */;
/*/*/
union pypy_array2_len12u pypy_g_array = { {
	12, "MemoryError"
} };
/*/*/
char pypy_g_rtti_v_exceptions_OSError0  /* uninitialized */;
/*/*/
union pypy_array2_len8u pypy_g_array_1 = { {
	8, "OSError"
} };
/*/*/
char pypy_g_rtti_v_exceptions_AssertionError0  /* uninitialized */;
/*/*/
union pypy_array2_len15u pypy_g_array_2 = { {
	15, "AssertionError"
} };
/*/*/
char pypy_g_rtti_v_exceptions_NotImplementedError0  /* uninitialized */;
/*/*/
union pypy_array2_len20u pypy_g_array_3 = { {
	20, "NotImplementedError"
} };
/*/*/
char pypy_g_rtti_v_exceptions_ValueError0  /* uninitialized */;
/*/*/
union pypy_array2_len11u pypy_g_array_4 = { {
	11, "ValueError"
} };
/*/*/
char pypy_g_rtti_v_rpython_rlib_rstackovf_StackOverflow0  /* uninitialized */;
/*/*/
union pypy_array2_len14u pypy_g_array_5 = { {
	14, "StackOverflow"
} };
/*/*/
char pypy_g_rtti_v_exceptions_ZeroDivisionError0  /* uninitialized */;
/*/*/
union pypy_array2_len18u pypy_g_array_6 = { {
	18, "ZeroDivisionError"
} };
/*/*/
char pypy_g_rtti_v_exceptions_RuntimeError0  /* uninitialized */;
/*/*/
union pypy_array2_len13u pypy_g_array_7 = { {
	13, "RuntimeError"
} };
/*/*/
char pypy_g_rtti_v_exceptions_KeyError0  /* uninitialized */;
/*/*/
union pypy_array2_len9u pypy_g_array_8 = { {
	9, "KeyError"
} };
/*/*/
char pypy_g_rtti_v_exceptions_UnicodeEncodeError0  /* uninitialized */;
/*/*/
union pypy_array2_len19u pypy_g_array_9 = { {
	19, "UnicodeEncodeError"
} };
/*/*/
char pypy_g_rtti_v_exceptions_TypeError0  /* uninitialized */;
/*/*/
union pypy_array2_len10u pypy_g_array_10 = { {
	10, "TypeError"
} };
/*/*/
char pypy_g_rtti_v_exceptions_UnicodeDecodeError0  /* uninitialized */;
/*/*/
union pypy_array2_len19u pypy_g_array_11 = { {
	19, "UnicodeDecodeError"
} };
/*/*/
char pypy_g_rtti_v_exceptions_StopIteration0  /* uninitialized */;
/*/*/
union pypy_array2_len14u pypy_g_array_12 = { {
	14, "StopIteration"
} };
/*/*/
char pypy_g_rtti_v_exceptions_IndexError0  /* uninitialized */;
/*/*/
union pypy_array2_len11u pypy_g_array_13 = { {
	11, "IndexError"
} };
/*/*/
char pypy_g_rtti_v_exceptions_IOError0  /* uninitialized */;
/*/*/
union pypy_array2_len8u pypy_g_array_14 = { {
	8, "IOError"
} };
/*/*/
char pypy_g_rtti_v_exceptions_OverflowError0  /* uninitialized */;
/*/*/
union pypy_array2_len14u pypy_g_array_15 = { {
	14, "OverflowError"
} };
/*/*/
struct pypy_rpython_memory_gctransform_shadowstack_ShadowStack1 pypy_g_rpython_memory_gctransform_shadowstack_ShadowSta_1 = {
	{
		62L,	/* super.subclassrange_min */
		63L,	/* super.subclassrange_max */
		((char *) NULL),	/* super.rtti */
		(&pypy_g_array_28.b),	/* super.name */
		-1062259972L,	/* super.hash */
		((struct pypy_object0 *(*)(void)) NULL),	/* super.instantiate */
	},
	/* nothing */	/* cls__prepare_unused_stack */
	/* nothing */	/* cls_initial_setup */
	163840L,	/* cls_root_stack_depth */
	/* nothing */	/* cls_start_fresh_new_state */
};
/*/*/
struct pypy_rpython_memory_gctypelayout_GCData_vtable0 pypy_g_rpython_memory_gctypelayout_GCData_vtable = {
	{
		50L,	/* super.subclassrange_min */
		51L,	/* super.subclassrange_max */
		((char *) NULL),	/* super.rtti */
		(&pypy_g_array_29.b),	/* super.name */
		-1062355756L,	/* super.hash */
		((struct pypy_object0 *(*)(void)) NULL),	/* super.instantiate */
	},
	/* nothing */	/* cls_get */
	/* nothing */	/* cls_get_varsize */
	/* nothing */	/* cls_q_fast_path_tracing */
	/* nothing */	/* cls_q_finalizer */
	/* nothing */	/* cls_q_fixed_size */
	/* nothing */	/* cls_q_get_custom_trace */
	/* nothing */	/* cls_q_has_custom_trace */
	/* nothing */	/* cls_q_has_gcptr_in_varsize */
	/* nothing */	/* cls_q_is_gcarrayofgcptr */
	/* nothing */	/* cls_q_is_rpython_class */
	/* nothing */	/* cls_q_is_varsize */
	/* nothing */	/* cls_q_light_finalizer */
	/* nothing */	/* cls_q_member_index */
	/* nothing */	/* cls_q_offsets_to_gc_pointers */
	/* nothing */	/* cls_q_varsize_item_sizes */
	/* nothing */	/* cls_q_varsize_offset_to_length */
	/* nothing */	/* cls_q_varsize_offset_to_variable_part */
	/* nothing */	/* cls_q_varsize_offsets_to_gcpointers_in_var_part */
	/* nothing */	/* cls_q_weakpointer_offset */
};
/*/*/
union pypy_array2_len13u pypy_g_array_16 = { {
	13, "AddressDeque"
} };
/*/*/
union pypy_array2_len13u pypy_g_array_17 = { {
	13, "AddressStack"
} };
/*/*/
struct pypy_rpython_rtyper_lltypesystem_rffi_StackCounter_vtab0 pypy_g_rpython_rtyper_lltypesystem_rffi_StackCounter_vt = {
	{
		0L,	/* super.subclassrange_min */
		1L,	/* super.subclassrange_max */
		(&pypy_g_rtti_v_rpython_rtyper_lltypesystem_rffi_StackCou),	/* super.rtti */
		(&pypy_g_array_35.b),	/* super.name */
		-1062569966L,	/* super.hash */
		((struct pypy_object0 *(*)(void)) NULL),	/* super.instantiate */
	},
};
/*/*/
union pypy_array2_len16u pypy_g_array_28 = { {
	16, "ShadowStackPool"
} };
/*/*/
union pypy_array2_len7u pypy_g_array_29 = { {
	7, "GCData"
} };
/*/*/
struct pypy_rpython_memory_support_FreeList_vtable0 pypy_g_rpython_memory_support_FreeList_vtable = {
	{
		64L,	/* super.subclassrange_min */
		65L,	/* super.subclassrange_max */
		((char *) NULL),	/* super.rtti */
		(&pypy_g_array_36.b),	/* super.name */
		-1062045922L,	/* super.hash */
		((struct pypy_object0 *(*)(void)) NULL),	/* super.instantiate */
	},
	/* nothing */	/* cls_get */
	/* nothing */	/* cls_put */
};
/*/*/
struct pypy_rpython_memory_gc_minimarkpage_ArenaCollection_vta0 pypy_g_rpython_memory_gc_minimarkpage_ArenaCollection_v = {
	{
		66L,	/* super.subclassrange_min */
		67L,	/* super.subclassrange_max */
		((char *) NULL),	/* super.rtti */
		(&pypy_g_array_41.b),	/* super.name */
		-1062355918L,	/* super.hash */
		((struct pypy_object0 *(*)(void)) NULL),	/* super.instantiate */
	},
	/* nothing */	/* cls_allocate_new_arena */
	/* nothing */	/* cls_allocate_new_page */
	/* nothing */	/* cls_free_page */
	/* nothing */	/* cls_malloc */
	/* nothing */	/* cls_mass_free */
	/* nothing */	/* cls_mass_free_in_pages */
	/* nothing */	/* cls_walk_page */
};
/*/*/
char pypy_g_rtti_v_rpython_rtyper_lltypesystem_rffi_StackCou  /* uninitialized */;
/*/*/
union pypy_array2_len13u pypy_g_array_35 = { {
	13, "StackCounter"
} };
/*/*/
union pypy_array2_len9u pypy_g_array_36 = { {
	9, "FreeList"
} };
/*/*/
struct pypy_rpython_memory_gc_minimark_MiniMarkGC_vtable0 pypy_g_rpython_memory_gc_minimark_MiniMarkGC_vtable = {
	{
		{
			{
				54L,	/* super.super.super.subclassrange_min */
				55L,	/* super.super.super.subclassrange_max */
				((char *) NULL),	/* super.super.super.rtti */
				(&pypy_g_array_42.b),	/* super.super.super.name */
				-1062411880L,	/* super.super.super.hash */
				((struct pypy_object0 *(*)(void)) NULL),	/* super.super.super.instantiate */
			},
		},
	},
	/* nothing */	/* cls_HDR */
	/* nothing */	/* cls__alloc_nursery */
	/* nothing */	/* cls__allocate_shadow */
	/* nothing */	/* cls__append_if_nonnull */
	/* nothing */	/* cls__bump_finalization_state_from_0_to_1 */
	/* nothing */	/* cls__collect_obj */
	/* nothing */	/* cls__collect_ref_rec */
	/* nothing */	/* cls__debug_callback2 */
	/* nothing */	/* cls__debug_record */
	/* nothing */	/* cls__finalization_state */
	/* nothing */	/* cls__find_shadow */
	/* nothing */	/* cls__free_if_unvisited */
	/* nothing */	/* cls__free_young_rawmalloced_obj */
	/* nothing */	/* cls__get_size_for_typeid */
	/* nothing */	/* cls__malloc_out_of_nursery */
	/* nothing */	/* cls__malloc_out_of_nursery_nonsmall */
	/* nothing */	/* cls__nursery_memory_size */
	/* nothing */	/* cls__recursively_bump_finalization_state_from_1_to_2 */
	/* nothing */	/* cls__recursively_bump_finalization_state_from_2_to_3 */
	/* nothing */	/* cls__reset_gcflag_visited */
	/* nothing */	/* cls__teardown */
	/* nothing */	/* cls__trace_drag_out */
	/* nothing */	/* cls__trace_slow_path */
	/* nothing */	/* cls__visit_young_rawmalloced_object */
	/* nothing */	/* cls_allocate_nursery */
	/* nothing */	/* cls_appears_to_be_young */
	/* nothing */	/* cls_card_marking_bytes_for_length */
	/* nothing */	/* cls_card_marking_words_for_length */
	/* nothing */	/* cls_collect_and_reserve */
	/* nothing */	/* cls_collect_cardrefs_to_nursery */
	/* nothing */	/* cls_collect_oldrefs_to_nursery */
	/* nothing */	/* cls_collect_roots */
	/* nothing */	/* cls_collect_roots_in_nursery */
	/* nothing */	/* cls_combine */
	/* nothing */	/* cls_deal_with_objects_with_finalizers */
	/* nothing */	/* cls_deal_with_old_objects_with_finalizers */
	/* nothing */	/* cls_deal_with_young_objects_with_finalizers */
	/* nothing */	/* cls_debug_check_consistency */
	/* nothing */	/* cls_debug_check_object */
	/* nothing */	/* cls_debug_rotate_nursery */
	/* nothing */	/* cls_enumerate_all_roots */
	/* nothing */	/* cls_execute_finalizers */
	/* nothing */	/* cls_external_malloc */
	/* nothing */	/* cls_free_rawmalloced_object_if_unvisited */
	/* nothing */	/* cls_free_unvisited_rawmalloc_objects */
	/* nothing */	/* cls_free_young_rawmalloced_objects */
	2097152L,	/* cls_gcflag_extra */
	/* nothing */	/* cls_get_card */
	/* nothing */	/* cls_get_forwarding_address */
	/* nothing */	/* cls_get_member_index */
	/* nothing */	/* cls_get_size */
	/* nothing */	/* cls_get_size_incl_hash */
	/* nothing */	/* cls_get_total_memory_used */
	/* nothing */	/* cls_get_type_id */
	/* nothing */	/* cls_header */
	/* nothing */	/* cls_id_or_identityhash */
	/* nothing */	/* cls_init_gc_object */
	/* nothing */	/* cls_invalidate_old_weakrefs */
	/* nothing */	/* cls_invalidate_young_weakrefs */
	/* nothing */	/* cls_is_forwarded */
	/* nothing */	/* cls_is_in_nursery */
	/* nothing */	/* cls_is_valid_gc_object */
	/* nothing */	/* cls_major_collection */
	/* nothing */	/* cls_manually_copy_card_bits */
	(sizeof(struct pypy_header0) + sizeof(void*)),	/* cls_minimal_size_in_nursery */
	/* nothing */	/* cls_minor_collection */
	/* nothing */	/* cls_move_nursery_top */
	/* nothing */	/* cls_points_to_valid_gc_object */
	/* nothing */	/* cls_post_setup */
	/* nothing */	/* cls_raw_malloc_memory_pressure */
	/* nothing */	/* cls_remove_young_arrays_from_old_objects_pointing_to_young */
	/* nothing */	/* cls_set_major_threshold_from */
	/* nothing */	/* cls_setup */
	/* nothing */	/* cls_trace */
	/* nothing */	/* cls_trace_and_drag_out_of_nursery */
	/* nothing */	/* cls_trace_and_drag_out_of_nursery_partial */
	/* nothing */	/* cls_trace_partial */
	/* nothing */	/* cls_visit */
	/* nothing */	/* cls_visit_all_objects */
};
/*/*/
union pypy_array2_len16u pypy_g_array_41 = { {
	16, "ArenaCollection"
} };
/*/*/
union pypy_rpy_string0_len3u pypy_g_rpy_string_61 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	607676160L,	/* hash */
	{
		3, {112,112,99}
	},
} };
/*/*/
union pypy_rpy_string0_len5u pypy_g_rpy_string_62 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	845263833L,	/* hash */
	{
		5, {97,108,112,104,97}
	},
} };
/*/*/
union pypy_rpy_string0_len5u pypy_g_rpy_string_63 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	2073293196L,	/* hash */
	{
		5, {112,112,99,54,52}
	},
} };
/*/*/
union pypy_rpy_string0_len6u pypy_g_rpy_string_64 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	179717538L,	/* hash */
	{
		6, {112,97,114,105,115,99}
	},
} };
/*/*/
union pypy_rpy_string0_len8u pypy_g_rpy_string_65 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	-147967950L,	/* hash */
	{
		8, {112,97,114,105,115,99,54,52}
	},
} };
/*/*/
union pypy_rpy_string0_len5u pypy_g_rpy_string_66 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	787057874L,	/* hash */
	{
		5, {115,112,97,114,99}
	},
} };
/*/*/
union pypy_rpy_string0_len7u pypy_g_rpy_string_67 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	1008345642L,	/* hash */
	{
		7, {115,112,97,114,99,54,52}
	},
} };
/*/*/
union pypy_array2_len11u pypy_g_array_42 = { {
	11, "MiniMarkGC"
} };
/*/*/

/*/*/

/*/*/

/*/*/

/*/*/

/*/*/

/*/*/

/*/*/

/*/*/

/*/*/

/*/*/
union pypy_array8_len5u pypy_g_array_43 = { {
	5, {
	offsetof(struct pypy_tuple5_0, t_item0),	/* 0 */
	offsetof(struct pypy_tuple5_0, t_item1),	/* 1 */
	offsetof(struct pypy_tuple5_0, t_item2),	/* 2 */
	offsetof(struct pypy_tuple5_0, t_item3),	/* 3 */
	offsetof(struct pypy_tuple5_0, t_item4),	/* 4 */
} } };
/*/*/
union pypy_array8_len1u pypy_g_array_44 = { {
	1, {
	offsetof(struct pypy_dicttable0, d_entries),	/* 0 */
} } };
/*/*/
union pypy_array8_len1u pypy_g_array_45 = { {
	1, {
	offsetof(struct pypy_stringbuilder0, s_buf),	/* 0 */
} } };
/*/*/
union pypy_array8_len1u pypy_g_array_46 = { {
	1, {
	offsetof(struct pypy_dicttable1, d_entries),	/* 0 */
} } };
/*/*/
union pypy_array8_len1u pypy_g_array_47 = { {
	1, {
	offsetof(struct pypy_dictentry0, d_key),	/* 0 */
} } };
/*/*/
union pypy_array8_len1u pypy_g_array_48 = { {
	1, {
	offsetof(struct pypy_dicttable2, d_entries),	/* 0 */
} } };
/*/*/
union pypy_array1_len2u pypy_g_array_49 = { {
	2, {
	(&pypy_g_rpython_memory_gc_minimark_MiniMarkGC.mmgc_inst__list_rpy),	/* 0 */
	(&pypy_g_ExcData.ed_exc_value),	/* 1 */
} } };
/*/*/
union pypy_array2_len531u pypy_g_array_50 = { {
	531, {
120,218,173,149,223,111,155,48,16,199,223,247,87,248,121,66,40,64,210,252,
120,153,186,182,154,162,105,139,52,214,62,236,37,34,112,36,86,141,141,206,
38,43,155,246,191,207,134,52,148,132,91,35,173,121,192,152,248,243,189,239,
217,119,80,64,177,1,28,49,251,251,240,174,104,38,129,155,124,74,99,131,
85,106,24,60,165,80,26,174,164,246,87,241,29,162,66,246,155,233,170,4,
244,24,151,218,172,1,81,42,246,231,0,135,20,252,144,136,10,122,252,145,
137,40,230,171,50,203,162,20,80,128,52,144,13,195,227,30,140,101,109,118,
74,250,40,248,198,71,109,146,244,81,237,115,63,118,55,171,61,96,46,212,
207,51,137,9,21,255,7,160,186,229,123,174,237,108,56,250,21,133,126,171,
164,225,5,145,240,148,162,62,67,61,76,204,40,226,94,242,84,101,112,39,
155,235,32,59,167,216,107,173,1,13,153,91,48,34,184,239,117,73,132,10,
130,127,219,188,5,218,102,16,18,108,108,84,185,52,128,137,155,158,99,17,
129,45,101,6,79,68,168,49,197,172,8,96,66,181,196,161,166,8,236,138,
192,190,64,161,144,56,234,96,122,82,208,107,109,144,203,173,93,184,75,244,
206,99,233,46,65,221,45,159,13,214,191,177,103,132,190,16,110,212,181,54,
80,248,152,231,188,237,132,27,101,171,19,78,27,185,233,22,189,78,15,127,
30,3,204,95,6,16,92,27,203,9,144,91,99,189,112,43,220,121,9,219,
138,185,70,76,106,166,114,246,254,146,60,216,51,220,171,29,83,217,190,15,
237,90,23,97,212,6,10,186,64,225,229,158,162,51,217,201,137,108,59,132,
237,16,181,195,184,19,232,21,75,198,83,99,146,141,0,171,33,171,98,221,
4,243,24,130,230,191,224,121,239,60,102,95,88,200,225,133,139,73,127,103,
110,108,238,199,196,123,85,210,110,210,166,226,34,107,78,40,17,66,165,137,
125,253,121,172,210,238,186,169,242,78,118,250,63,27,62,123,139,196,230,125,
7,78,198,173,169,173,204,35,212,139,203,44,121,108,239,62,15,11,246,160,
120,214,57,140,70,111,224,48,10,94,113,232,206,194,99,249,26,108,47,187,
45,94,176,143,74,9,247,196,154,226,199,233,176,195,240,21,241,152,111,165,
59,181,115,249,19,189,191,140,192,165,40}
} };
/*/*/
/***********************************************************/
