/***********************************************************/
/***  Implementations                                    ***/

#define PYPY_FILE_NAME "implement.c"
#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"
#include "src/g_include.h"

/*/*/
void rpython_startup_code(void) {
	Signed l_v163; Signed l_v164; Signed l_v167; Signed l_v168;
	goto block0;

    block0:
	l_v163 = (&pypy_g_rpython_rtyper_lltypesystem_rffi_StackCounter)->sc_inst_stacks_counter;
	OP_INT_ADD(l_v163, 1L, l_v164);
	(&pypy_g_rpython_rtyper_lltypesystem_rffi_StackCounter)->sc_inst_stacks_counter = l_v164;

	pypy_g_rpython_startup_code();
	l_v167 = (&pypy_g_rpython_rtyper_lltypesystem_rffi_StackCounter)->sc_inst_stacks_counter;
	OP_INT_SUB(l_v167, 1L, l_v168);
	(&pypy_g_rpython_rtyper_lltypesystem_rffi_StackCounter)->sc_inst_stacks_counter = l_v168;
	goto block1;

    block1:
	RPY_DEBUG_RETURN();
	return /* nothing */;
}
/*/*/
void pypy_g__ll_list_resize_ge_look_inside_iff__listPtr_Sign(struct pypy_list1 *l_l_4, Signed l_v170) {
	Signed l_v173; Signed l_v192; bool_t l_v171; bool_t l_v174;
	bool_t l_v187; bool_t l_v193; bool_t l_v206;
	struct pypy_array6 *l_v172; struct pypy_array6 *l_v191;
	struct pypy_object_vtable0 *l_v186;
	struct pypy_object_vtable0 *l_v205; void* l_v175; void* l_v176;
	void* l_v178; void* l_v181; void* l_v182; void* l_v184; void* l_v194;
	void* l_v195; void* l_v197; void* l_v200; void* l_v201; void* l_v203;
	goto block0;

    block0:
	OP_INT_IS_TRUE(0 /* we are not jitted here */, l_v171);
	if (l_v171) {
		goto block7;
	}
	goto block1;

    block1:
	l_v172 = RPyField(l_l_4, l_items);
	l_v173 = l_v172->length;
	OP_INT_GE(l_v173, l_v170, l_v174);
	if (l_v174) {
		goto block6;
	}
	goto block2;

    block2:
	l_v175 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v175, sizeof(void*), l_v176);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v176;
	l_v178 = (void*)l_l_4;
	((void* *) (((char *)l_v175) + 0))[0] = l_v178;
	pypy_g__ll_list_resize_hint_really__listPtr_Signed_Bool(l_l_4, l_v170, 1);
	l_v181 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v181, sizeof(void*), l_v182);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v182;
	l_v184 = ((void* *) (((char *)l_v182) + 0))[0];
	l_l_4 = l_v184; /* for moving GCs */
	l_v186 = (&pypy_g_ExcData)->ed_exc_type;
	l_v187 = (l_v186 == NULL);
	if (!l_v187) {
		goto block5;
	}
	goto block3;

    block3:
	RPyField(l_l_4, l_length) = l_v170;
	goto block4;

    block4:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block5:
	PYPY_DEBUG_RECORD_TRACEBACK("_ll_list_resize_ge_look_inside_iff__listPtr_Sign");
	goto block4;

    block6:
	RPyField(l_l_4, l_length) = l_v170;
	goto block4;

    block7:
	l_v191 = RPyField(l_l_4, l_items);
	l_v192 = l_v191->length;
	OP_INT_GE(l_v192, l_v170, l_v193);
	if (l_v193) {
		goto block11;
	}
	goto block8;

    block8:
	l_v194 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v194, sizeof(void*), l_v195);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v195;
	l_v197 = (void*)l_l_4;
	((void* *) (((char *)l_v194) + 0))[0] = l_v197;
	pypy_g__ll_list_resize_hint_really__listPtr_Signed_Bool(l_l_4, l_v170, 1);
	l_v200 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v200, sizeof(void*), l_v201);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v201;
	l_v203 = ((void* *) (((char *)l_v201) + 0))[0];
	l_l_4 = l_v203; /* for moving GCs */
	l_v205 = (&pypy_g_ExcData)->ed_exc_type;
	l_v206 = (l_v205 == NULL);
	if (!l_v206) {
		goto block10;
	}
	goto block9;

    block9:
	RPyField(l_l_4, l_length) = l_v170;
	goto block4;

    block10:
	PYPY_DEBUG_RECORD_TRACEBACK("_ll_list_resize_ge_look_inside_iff__listPtr_Sign");
	goto block4;

    block11:
	RPyField(l_l_4, l_length) = l_v170;
	goto block4;
}
/*/*/
void pypy_g_ll_listdelslice_startonly_look_inside_iff__listP(struct pypy_list1 *l_l_21, Signed l_newsize_10) {
	Signed l_v214; Signed l_v219; Signed l_v220; Signed l_v221;
	Signed l_v240; Signed l_v241; Signed l_v242; Signed l_v262;
	Signed l_v267; Signed l_v268; Signed l_v269; Signed l_v288;
	Signed l_v289; Signed l_v290; bool_t l_v211; bool_t l_v212;
	bool_t l_v215; bool_t l_v217; bool_t l_v222; bool_t l_v235;
	bool_t l_v243; bool_t l_v256; bool_t l_v260; bool_t l_v263;
	bool_t l_v265; bool_t l_v270; bool_t l_v283; bool_t l_v291;
	bool_t l_v304; struct pypy_array6 *l_v218;
	struct pypy_array6 *l_v239; struct pypy_array6 *l_v266;
	struct pypy_array6 *l_v287; struct pypy_object_vtable0 *l_v234;
	struct pypy_object_vtable0 *l_v255;
	struct pypy_object_vtable0 *l_v282;
	struct pypy_object_vtable0 *l_v303; void* l_v223; void* l_v224;
	void* l_v226; void* l_v229; void* l_v230; void* l_v232; void* l_v244;
	void* l_v245; void* l_v247; void* l_v250; void* l_v251; void* l_v253;
	void* l_v271; void* l_v272; void* l_v274; void* l_v277; void* l_v278;
	void* l_v280; void* l_v292; void* l_v293; void* l_v295; void* l_v298;
	void* l_v299; void* l_v301;
	goto block0;

    block0:
	OP_INT_IS_TRUE(0 /* we are not jitted here */, l_v211);
	if (l_v211) {
		goto block13;
	}
	goto block1;

    block1:
	OP_INT_GE(l_newsize_10, 0L, l_v212);
	RPyAssert(l_v212, "del l[start:] with unexpectedly negative start");
	l_v214 = RPyField(l_l_21, l_length);
	OP_INT_LE(l_newsize_10, l_v214, l_v215);
	RPyAssert(l_v215, "del l[start:] with start > len(l)");
	OP_INT_IS_TRUE(0 /* we are not jitted here */, l_v217);
	if (l_v217) {
		goto block8;
	}
	goto block2;

    block2:
	l_v218 = RPyField(l_l_21, l_items);
	l_v219 = l_v218->length;
	OP_INT_RSHIFT(l_v219, 1L, l_v220);
	OP_INT_SUB(l_v220, 5L, l_v221);
	OP_INT_GE(l_newsize_10, l_v221, l_v222);
	if (l_v222) {
		goto block7;
	}
	goto block3;

    block3:
	l_v223 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v223, sizeof(void*), l_v224);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v224;
	l_v226 = (void*)l_l_21;
	((void* *) (((char *)l_v223) + 0))[0] = l_v226;
	pypy_g__ll_list_resize_hint_really__listPtr_Signed_Bool(l_l_21, l_newsize_10, 0);
	l_v229 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v229, sizeof(void*), l_v230);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v230;
	l_v232 = ((void* *) (((char *)l_v230) + 0))[0];
	l_l_21 = l_v232; /* for moving GCs */
	l_v234 = (&pypy_g_ExcData)->ed_exc_type;
	l_v235 = (l_v234 == NULL);
	if (!l_v235) {
		goto block6;
	}
	goto block4;

    block4:
	RPyField(l_l_21, l_length) = l_newsize_10;
	goto block5;

    block5:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block6:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_listdelslice_startonly_look_inside_iff__listP");
	goto block5;

    block7:
	RPyField(l_l_21, l_length) = l_newsize_10;
	goto block5;

    block8:
	l_v239 = RPyField(l_l_21, l_items);
	l_v240 = l_v239->length;
	OP_INT_RSHIFT(l_v240, 1L, l_v241);
	OP_INT_SUB(l_v241, 5L, l_v242);
	OP_INT_GE(l_newsize_10, l_v242, l_v243);
	if (l_v243) {
		goto block12;
	}
	goto block9;

    block9:
	l_v244 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v244, sizeof(void*), l_v245);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v245;
	l_v247 = (void*)l_l_21;
	((void* *) (((char *)l_v244) + 0))[0] = l_v247;
	pypy_g__ll_list_resize_hint_really__listPtr_Signed_Bool(l_l_21, l_newsize_10, 0);
	l_v250 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v250, sizeof(void*), l_v251);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v251;
	l_v253 = ((void* *) (((char *)l_v251) + 0))[0];
	l_l_21 = l_v253; /* for moving GCs */
	l_v255 = (&pypy_g_ExcData)->ed_exc_type;
	l_v256 = (l_v255 == NULL);
	if (!l_v256) {
		goto block11;
	}
	goto block10;

    block10:
	RPyField(l_l_21, l_length) = l_newsize_10;
	goto block5;

    block11:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_listdelslice_startonly_look_inside_iff__listP");
	goto block5;

    block12:
	RPyField(l_l_21, l_length) = l_newsize_10;
	goto block5;

    block13:
	OP_INT_GE(l_newsize_10, 0L, l_v260);
	RPyAssert(l_v260, "del l[start:] with unexpectedly negative start");
	l_v262 = RPyField(l_l_21, l_length);
	OP_INT_LE(l_newsize_10, l_v262, l_v263);
	RPyAssert(l_v263, "del l[start:] with start > len(l)");
	OP_INT_IS_TRUE(0 /* we are not jitted here */, l_v265);
	if (l_v265) {
		goto block19;
	}
	goto block14;

    block14:
	l_v266 = RPyField(l_l_21, l_items);
	l_v267 = l_v266->length;
	OP_INT_RSHIFT(l_v267, 1L, l_v268);
	OP_INT_SUB(l_v268, 5L, l_v269);
	OP_INT_GE(l_newsize_10, l_v269, l_v270);
	if (l_v270) {
		goto block18;
	}
	goto block15;

    block15:
	l_v271 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v271, sizeof(void*), l_v272);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v272;
	l_v274 = (void*)l_l_21;
	((void* *) (((char *)l_v271) + 0))[0] = l_v274;
	pypy_g__ll_list_resize_hint_really__listPtr_Signed_Bool(l_l_21, l_newsize_10, 0);
	l_v277 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v277, sizeof(void*), l_v278);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v278;
	l_v280 = ((void* *) (((char *)l_v278) + 0))[0];
	l_l_21 = l_v280; /* for moving GCs */
	l_v282 = (&pypy_g_ExcData)->ed_exc_type;
	l_v283 = (l_v282 == NULL);
	if (!l_v283) {
		goto block17;
	}
	goto block16;

    block16:
	RPyField(l_l_21, l_length) = l_newsize_10;
	goto block5;

    block17:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_listdelslice_startonly_look_inside_iff__listP");
	goto block5;

    block18:
	RPyField(l_l_21, l_length) = l_newsize_10;
	goto block5;

    block19:
	l_v287 = RPyField(l_l_21, l_items);
	l_v288 = l_v287->length;
	OP_INT_RSHIFT(l_v288, 1L, l_v289);
	OP_INT_SUB(l_v289, 5L, l_v290);
	OP_INT_GE(l_newsize_10, l_v290, l_v291);
	if (l_v291) {
		goto block23;
	}
	goto block20;

    block20:
	l_v292 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v292, sizeof(void*), l_v293);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v293;
	l_v295 = (void*)l_l_21;
	((void* *) (((char *)l_v292) + 0))[0] = l_v295;
	pypy_g__ll_list_resize_hint_really__listPtr_Signed_Bool(l_l_21, l_newsize_10, 0);
	l_v298 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v298, sizeof(void*), l_v299);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v299;
	l_v301 = ((void* *) (((char *)l_v299) + 0))[0];
	l_l_21 = l_v301; /* for moving GCs */
	l_v303 = (&pypy_g_ExcData)->ed_exc_type;
	l_v304 = (l_v303 == NULL);
	if (!l_v304) {
		goto block22;
	}
	goto block21;

    block21:
	RPyField(l_l_21, l_length) = l_newsize_10;
	goto block5;

    block22:
	PYPY_DEBUG_RECORD_TRACEBACK("ll_listdelslice_startonly_look_inside_iff__listP");
	goto block5;

    block23:
	RPyField(l_l_21, l_length) = l_newsize_10;
	goto block5;
}
/*/*/
Signed pypy_g_ccall_open__arrayPtr_Signed_Signed(char *l_a0_0, Signed l_a1_0, Signed l_a2_0) {
	Signed l_v309;
	goto block0;

    block0:
	l_v309 = open(l_a0_0, l_a1_0, l_a2_0);
	goto block1;

    block1:
	RPY_DEBUG_RETURN();
	return l_v309;
}
/*/*/
struct pypy_rpy_string0 *pypy_g_str_from_buffer(char *l_raw_buf_1, struct pypy_rpy_string0 *l_gc_buf_0, Signed l_allocated_size_0, Signed l_needed_size_1) {
	void* l_result_0; void* l_result_1; Unsigned l_toobig_0;
	Signed l_v310; Signed l_v311; Signed l_v312; Signed l_v317;
	Signed l_v319; Signed l_v323; Signed l_v325; Signed l_v326;
	Signed l_v327; Signed l_v347; Signed l_v360; Signed l_v368;
	Signed l_v369; Unsigned l_v321; Unsigned l_v370; Unsigned l_v371;
	bool_t l_v314; bool_t l_v318; bool_t l_v320; bool_t l_v322;
	bool_t l_v324; bool_t l_v328; bool_t l_v334; bool_t l_v335;
	bool_t l_v342; bool_t l_v354; bool_t l_v358; bool_t l_v362;
	bool_t l_v366; struct pypy_header0 *l_v336;
	struct pypy_object_vtable0 *l_v353;
	struct pypy_object_vtable0 *l_v357;
	struct pypy_object_vtable0 *l_v361;
	struct pypy_object_vtable0 *l_v365; struct pypy_rpy_string0 *l_v313;
	struct pypy_rpy_string0 *l_v372; void* l_v330; void* l_v332;
	void* l_v333; void* l_v338; void* l_v339; void* l_v341; void* l_v343;
	void* l_v344; void* l_v345; void* l_v346; void* l_v356; void* l_v364;
	void* l_v373; void* l_v374;
	goto block0;

    block0:
	OP_INT_GE(l_allocated_size_0, l_needed_size_1, l_v314);
	if (l_v314) {
		goto block3;
	}
	goto block1;

    block1:
	pypy_g_RPyRaiseException((&pypy_g_exceptions_AssertionError_vtable.ae_super.se_super.e_super), (&pypy_g_exceptions_AssertionError.ae_super.se_super.e_super));
	PYPY_DEBUG_RECORD_TRACEBACK("str_from_buffer");
	l_v372 = ((struct pypy_rpy_string0 *) NULL);
	goto block2;

    block2:
	RPY_DEBUG_RETURN();
	return l_v372;

    block3:
	OP_RAW_MALLOC_USAGE((0 + offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v317);
	OP_INT_SUB(67583L, l_v317, l_v310);
	OP_INT_LT(l_v310, 0L, l_v318);
	if (l_v318) {
		l_toobig_0 = 0UL;
		goto block5;
	}
	goto block4;

    block4:
	OP_RAW_MALLOC_USAGE(sizeof(char), l_v319);
	OP_INT_IS_TRUE(l_v319, l_v320);
	if (l_v320) {
		goto block23;
	}
	l_toobig_0 = 2147483648UL;
	goto block5;

    block5:
	OP_CAST_INT_TO_UINT(l_needed_size_1, l_v321);
	OP_UINT_GE(l_v321, l_toobig_0, l_v322);
	if (l_v322) {
		goto block21;
	}
	goto block6;

    block6:
	OP_INT_MUL(sizeof(char), l_needed_size_1, l_v323);
	OP_INT_ADD((0 + offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items) + 0), l_v323, l_v312);
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v324);
	if (l_v324) {
		goto block19;
	}
	goto block7;

    block7:
	l_v325 = ROUND_UP_FOR_ALLOCATION(l_v312, 0L);
	l_v311 = l_v325;
	goto block8;

    block8:
	OP_RAW_MALLOC_USAGE(l_v311, l_v326);
	OP_RAW_MALLOC_USAGE((sizeof(struct pypy_header0) + sizeof(void*)), l_v327);
	OP_INT_GE(l_v326, l_v327, l_v328);
	RPyAssert(l_v328, "malloc_varsize_clear(): totalsize < minimalsize");
	l_result_0 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	OP_ADR_ADD(l_result_0, l_v311, l_v330);
	(&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free = l_v330;
	l_v332 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_free;
	l_v333 = (&pypy_g_rpython_memory_gc_minimark_MiniMarkGC)->mmgc_inst_nursery_top;
	OP_ADR_GT(l_v332, l_v333, l_v334);
	if (l_v334) {
		goto block17;
	}
	l_result_1 = l_result_0;
	goto block9;

    block9:
	OP_INT_IS_TRUE(RUNNING_ON_LLINTERP, l_v335);
	if (l_v335) {
		goto block15;
	}
	goto block10;

    block10:
	l_v336 = (struct pypy_header0 *)l_result_1;
	RPyField(l_v336, h_tid) = (GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+0L);
	OP_ADR_ADD(l_result_1, 0, l_v338);
	OP_ADR_ADD(l_v338, (offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, length)), l_v339);
	((Signed *) (((char *)l_v339) + 0))[0] = l_needed_size_1;
	l_v373 = l_v338;
	goto block11;

    block11:
	l_v341 = (void*)l_v373;
	l_v374 = l_v341;
	goto block12;

    block12:
	l_v313 = (struct pypy_rpy_string0 *)l_v374;
	l_v342 = (l_v313 != NULL);
	if (!l_v342) {
		goto block14;
	}
	goto block13;

    block13:
	l_v343 = (void*)l_raw_buf_1;
	OP_ADR_ADD(l_v343, 0, l_v344);
	l_v345 = (void*)l_v313;
	OP_ADR_ADD(l_v345, (offsetof(struct pypy_rpy_string0, rs_chars) + offsetof(struct pypy_array4, items)), l_v346);
	OP_INT_MUL(sizeof(char), l_needed_size_1, l_v347);
	OP_RAW_MEMCOPY(l_v344, l_v346, l_v347, /* nothing */);
	/* kept alive: ((struct pypy_rpy_string0 *) NULL) */
	/* kept alive: l_v313 */
	l_v372 = l_v313;
	goto block2;

    block14:
	PYPY_DEBUG_RECORD_TRACEBACK("str_from_buffer");
	l_v372 = ((struct pypy_rpy_string0 *) NULL);
	goto block2;

    block15:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v353 = (&pypy_g_ExcData)->ed_exc_type;
	l_v354 = (l_v353 == NULL);
	if (!l_v354) {
		goto block16;
	}
	goto block10;

    block16:
	PYPY_DEBUG_RECORD_TRACEBACK("str_from_buffer");
	l_v374 = NULL;
	goto block12;

    block17:
	l_v356 = pypy_g_MiniMarkGC_collect_and_reserve((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), l_result_0, l_v311);
	l_v357 = (&pypy_g_ExcData)->ed_exc_type;
	l_v358 = (l_v357 == NULL);
	if (!l_v358) {
		goto block18;
	}
	l_result_1 = l_v356;
	goto block9;

    block18:
	PYPY_DEBUG_RECORD_TRACEBACK("str_from_buffer");
	l_v374 = NULL;
	goto block12;

    block19:
	abort();  /* debug_llinterpcall should be unreachable */
	l_v360 = (Signed)0;
	l_v361 = (&pypy_g_ExcData)->ed_exc_type;
	l_v362 = (l_v361 == NULL);
	if (!l_v362) {
		goto block20;
	}
	l_v311 = l_v360;
	goto block8;

    block20:
	PYPY_DEBUG_RECORD_TRACEBACK("str_from_buffer");
	l_v374 = NULL;
	goto block12;

    block21:
	l_v364 = pypy_g_MiniMarkGC_external_malloc((&pypy_g_rpython_memory_gc_minimark_MiniMarkGC), GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17), l_needed_size_1, 1);
	l_v365 = (&pypy_g_ExcData)->ed_exc_type;
	l_v366 = (l_v365 == NULL);
	if (!l_v366) {
		goto block22;
	}
	l_v373 = l_v364;
	goto block11;

    block22:
	PYPY_DEBUG_RECORD_TRACEBACK("str_from_buffer");
	l_v374 = NULL;
	goto block12;

    block23:
	OP_RAW_MALLOC_USAGE(sizeof(char), l_v368);
	OP_INT_FLOORDIV(l_v310, l_v368, l_v369);
	OP_CAST_INT_TO_UINT(l_v369, l_v370);
	OP_UINT_ADD(l_v370, 1UL, l_v371);
	l_toobig_0 = l_v371;
	goto block5;
}
/*/*/
Signed pypy_g_ccall_uname__utsnamePtr(struct utsname *l_a0_1) {
	Signed l_v375;
	goto block0;

    block0:
	l_v375 = uname(l_a0_1);
	goto block1;

    block1:
	RPY_DEBUG_RETURN();
	return l_v375;
}
/*/*/
void pypy_g__ll_list_resize_ge_look_inside_iff__listPtr_Sign_1(struct pypy_list0 *l_l_19, Signed l_newsize_8) {
	Signed l_v378; Signed l_v397; bool_t l_v376; bool_t l_v379;
	bool_t l_v392; bool_t l_v398; bool_t l_v411;
	struct pypy_array3 *l_v377; struct pypy_array3 *l_v396;
	struct pypy_object_vtable0 *l_v391;
	struct pypy_object_vtable0 *l_v410; void* l_v380; void* l_v381;
	void* l_v383; void* l_v386; void* l_v387; void* l_v389; void* l_v399;
	void* l_v400; void* l_v402; void* l_v405; void* l_v406; void* l_v408;
	goto block0;

    block0:
	OP_INT_IS_TRUE(0 /* we are not jitted here */, l_v376);
	if (l_v376) {
		goto block7;
	}
	goto block1;

    block1:
	l_v377 = RPyField(l_l_19, l_items);
	l_v378 = l_v377->length;
	OP_INT_GE(l_v378, l_newsize_8, l_v379);
	if (l_v379) {
		goto block6;
	}
	goto block2;

    block2:
	l_v380 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v380, sizeof(void*), l_v381);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v381;
	l_v383 = (void*)l_l_19;
	((void* *) (((char *)l_v380) + 0))[0] = l_v383;
	pypy_g__ll_list_resize_hint_really__listPtr_Signed_Bool_1(l_l_19, l_newsize_8, 1);
	l_v386 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v386, sizeof(void*), l_v387);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v387;
	l_v389 = ((void* *) (((char *)l_v387) + 0))[0];
	l_l_19 = l_v389; /* for moving GCs */
	l_v391 = (&pypy_g_ExcData)->ed_exc_type;
	l_v392 = (l_v391 == NULL);
	if (!l_v392) {
		goto block5;
	}
	goto block3;

    block3:
	RPyField(l_l_19, l_length) = l_newsize_8;
	goto block4;

    block4:
	RPY_DEBUG_RETURN();
	return /* nothing */;

    block5:
	PYPY_DEBUG_RECORD_TRACEBACK("_ll_list_resize_ge_look_inside_iff__listPtr_Sign_1");
	goto block4;

    block6:
	RPyField(l_l_19, l_length) = l_newsize_8;
	goto block4;

    block7:
	l_v396 = RPyField(l_l_19, l_items);
	l_v397 = l_v396->length;
	OP_INT_GE(l_v397, l_newsize_8, l_v398);
	if (l_v398) {
		goto block11;
	}
	goto block8;

    block8:
	l_v399 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_ADD(l_v399, sizeof(void*), l_v400);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v400;
	l_v402 = (void*)l_l_19;
	((void* *) (((char *)l_v399) + 0))[0] = l_v402;
	pypy_g__ll_list_resize_hint_really__listPtr_Signed_Bool_1(l_l_19, l_newsize_8, 1);
	l_v405 = (&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top;
	OP_ADR_SUB(l_v405, sizeof(void*), l_v406);
	(&pypy_g_rpython_memory_gctypelayout_GCData)->gcd_inst_root_stack_top = l_v406;
	l_v408 = ((void* *) (((char *)l_v406) + 0))[0];
	l_l_19 = l_v408; /* for moving GCs */
	l_v410 = (&pypy_g_ExcData)->ed_exc_type;
	l_v411 = (l_v410 == NULL);
	if (!l_v411) {
		goto block10;
	}
	goto block9;

    block9:
	RPyField(l_l_19, l_length) = l_newsize_8;
	goto block4;

    block10:
	PYPY_DEBUG_RECORD_TRACEBACK("_ll_list_resize_ge_look_inside_iff__listPtr_Sign_1");
	goto block4;

    block11:
	RPyField(l_l_19, l_length) = l_newsize_8;
	goto block4;
}
/*/*/
Unsigned pypy_g_ccall_write__Signed_arrayPtr_Unsigned(Signed l_a0_2, char *l_a1_1, Unsigned l_a2_1) {
	Unsigned l_v416;
	goto block0;

    block0:
	l_v416 = write(l_a0_2, l_a1_1, l_a2_1);
	goto block1;

    block1:
	RPY_DEBUG_RETURN();
	return l_v416;
}
/*/*/

/*/*/
Unsigned pypy_g_ccall_read__Signed_arrayPtr_Unsigned(Signed l_a0_3, void *l_a1_2, Unsigned l_a2_2) {
	Unsigned l_v417;
	goto block0;

    block0:
	l_v417 = read(l_a0_3, l_a1_2, l_a2_2);
	goto block1;

    block1:
	RPY_DEBUG_RETURN();
	return l_v417;
}
/*/*/

/*/*/

/*/*/

/*/*/
/***********************************************************/
