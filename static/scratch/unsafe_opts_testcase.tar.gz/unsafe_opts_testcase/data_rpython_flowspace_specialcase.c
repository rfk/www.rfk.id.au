/***********************************************************/
/***  Non-function Implementations                       ***/

#include "common_header.h"
#include "structdef.h"
#include "forwarddecl.h"
#include "preimpl.h"

#include "src/g_include.h"

/*/*/
struct pypy_list1 pypy_g_list = {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member22)+196608L),	/* gcheader.tid */
	},
	0L,	/* length */
	(&pypy_g_array_23.b),	/* items */
};
/*/*/
union pypy_rpy_string0_len1u pypy_g_rpy_string_14 = { {
	{
		(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member17)+196608L),	/* gcheader.tid */
	},
	1280003851L,	/* hash */
	{
		1, {10}
	},
} };
/*/*/
union pypy_array6_len0u pypy_g_array_23 = { {
{
	(GROUP_MEMBER_OFFSET(struct group_pypy_g_typeinfo_s, member25)+196608L),	/* gcheader.tid */
},
	0
} };
/*/*/
/***********************************************************/
