
:- set_prolog_flag(double_quotes,atom).

:- use_module(library(plunit)).

:- [fluent].
:- [epath].
:- [twb_vpdl].
:- [sitcalc].
:- [domain].

